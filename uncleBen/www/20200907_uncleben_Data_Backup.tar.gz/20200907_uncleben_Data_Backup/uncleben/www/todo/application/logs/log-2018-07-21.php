<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-07-21 06:49:12 --> Config Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Utf8 Class Initialized
DEBUG - 2018-07-21 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2018-07-21 06:49:12 --> URI Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Router Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Output Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Security Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Input Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-21 06:49:12 --> Language Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Loader Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Helper loaded: date_helper
DEBUG - 2018-07-21 06:49:12 --> Controller Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Database Driver Class Initialized
ERROR - 2018-07-21 06:49:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-21 06:49:12 --> Model Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Model Class Initialized
DEBUG - 2018-07-21 06:49:12 --> Helper loaded: url_helper
DEBUG - 2018-07-21 06:49:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-21 06:49:12 --> Final output sent to browser
DEBUG - 2018-07-21 06:49:12 --> Total execution time: 0.0328
DEBUG - 2018-07-21 07:09:30 --> Config Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Hooks Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Utf8 Class Initialized
DEBUG - 2018-07-21 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2018-07-21 07:09:30 --> URI Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Router Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Output Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Security Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Input Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-21 07:09:30 --> Language Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Loader Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Helper loaded: date_helper
DEBUG - 2018-07-21 07:09:30 --> Controller Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Database Driver Class Initialized
ERROR - 2018-07-21 07:09:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-21 07:09:30 --> Model Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Model Class Initialized
DEBUG - 2018-07-21 07:09:30 --> Helper loaded: url_helper
DEBUG - 2018-07-21 07:09:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-21 07:09:30 --> Final output sent to browser
DEBUG - 2018-07-21 07:09:30 --> Total execution time: 0.0293
DEBUG - 2018-07-21 15:50:17 --> Config Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Hooks Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Utf8 Class Initialized
DEBUG - 2018-07-21 15:50:17 --> UTF-8 Support Enabled
DEBUG - 2018-07-21 15:50:17 --> URI Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Router Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Output Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Security Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Input Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-21 15:50:17 --> Language Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Loader Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Helper loaded: date_helper
DEBUG - 2018-07-21 15:50:17 --> Controller Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Database Driver Class Initialized
ERROR - 2018-07-21 15:50:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-21 15:50:17 --> Model Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Model Class Initialized
DEBUG - 2018-07-21 15:50:17 --> Helper loaded: url_helper
DEBUG - 2018-07-21 15:50:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-21 15:50:17 --> Final output sent to browser
DEBUG - 2018-07-21 15:50:17 --> Total execution time: 0.0231
DEBUG - 2018-07-21 18:55:59 --> Config Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Hooks Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Utf8 Class Initialized
DEBUG - 2018-07-21 18:55:59 --> UTF-8 Support Enabled
DEBUG - 2018-07-21 18:55:59 --> URI Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Router Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Output Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Security Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Input Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-21 18:55:59 --> Language Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Loader Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Helper loaded: date_helper
DEBUG - 2018-07-21 18:55:59 --> Controller Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Database Driver Class Initialized
ERROR - 2018-07-21 18:55:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-21 18:55:59 --> Model Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Model Class Initialized
DEBUG - 2018-07-21 18:55:59 --> Helper loaded: url_helper
DEBUG - 2018-07-21 18:55:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-21 18:55:59 --> Final output sent to browser
DEBUG - 2018-07-21 18:55:59 --> Total execution time: 0.0210
DEBUG - 2018-07-21 19:11:55 --> Config Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Utf8 Class Initialized
DEBUG - 2018-07-21 19:11:55 --> UTF-8 Support Enabled
DEBUG - 2018-07-21 19:11:55 --> URI Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Router Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Output Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Security Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Input Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-21 19:11:55 --> Language Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Loader Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Helper loaded: date_helper
DEBUG - 2018-07-21 19:11:55 --> Controller Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Database Driver Class Initialized
ERROR - 2018-07-21 19:11:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-21 19:11:55 --> Model Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Model Class Initialized
DEBUG - 2018-07-21 19:11:55 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:11:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-21 19:11:55 --> Final output sent to browser
DEBUG - 2018-07-21 19:11:55 --> Total execution time: 0.0208
DEBUG - 2018-07-21 20:02:37 --> Config Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Utf8 Class Initialized
DEBUG - 2018-07-21 20:02:37 --> UTF-8 Support Enabled
DEBUG - 2018-07-21 20:02:37 --> URI Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Router Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Output Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Security Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Input Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-21 20:02:37 --> Language Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Loader Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Helper loaded: date_helper
DEBUG - 2018-07-21 20:02:37 --> Controller Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Database Driver Class Initialized
ERROR - 2018-07-21 20:02:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-21 20:02:37 --> Model Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Model Class Initialized
DEBUG - 2018-07-21 20:02:37 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:02:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-21 20:02:37 --> Final output sent to browser
DEBUG - 2018-07-21 20:02:37 --> Total execution time: 0.0202
DEBUG - 2018-07-21 21:45:14 --> Config Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Utf8 Class Initialized
DEBUG - 2018-07-21 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2018-07-21 21:45:14 --> URI Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Router Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Output Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Security Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Input Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-21 21:45:14 --> Language Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Loader Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Helper loaded: date_helper
DEBUG - 2018-07-21 21:45:14 --> Controller Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Database Driver Class Initialized
ERROR - 2018-07-21 21:45:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-21 21:45:14 --> Model Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Model Class Initialized
DEBUG - 2018-07-21 21:45:14 --> Helper loaded: url_helper
DEBUG - 2018-07-21 21:45:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-21 21:45:14 --> Final output sent to browser
DEBUG - 2018-07-21 21:45:14 --> Total execution time: 0.0211
