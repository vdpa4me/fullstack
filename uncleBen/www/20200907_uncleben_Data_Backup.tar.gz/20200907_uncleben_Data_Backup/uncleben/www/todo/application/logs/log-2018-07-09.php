<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-07-09 01:12:27 --> Config Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Hooks Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Utf8 Class Initialized
DEBUG - 2018-07-09 01:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 01:12:27 --> URI Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Router Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Output Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Security Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Input Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 01:12:27 --> Language Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Loader Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Helper loaded: date_helper
DEBUG - 2018-07-09 01:12:27 --> Controller Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Database Driver Class Initialized
ERROR - 2018-07-09 01:12:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 01:12:27 --> Model Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Model Class Initialized
DEBUG - 2018-07-09 01:12:27 --> Helper loaded: url_helper
DEBUG - 2018-07-09 01:12:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 01:12:27 --> Final output sent to browser
DEBUG - 2018-07-09 01:12:27 --> Total execution time: 0.0221
DEBUG - 2018-07-09 01:14:21 --> Config Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Hooks Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Utf8 Class Initialized
DEBUG - 2018-07-09 01:14:21 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 01:14:21 --> URI Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Router Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Output Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Security Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Input Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 01:14:21 --> Language Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Loader Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Helper loaded: date_helper
DEBUG - 2018-07-09 01:14:21 --> Controller Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Database Driver Class Initialized
ERROR - 2018-07-09 01:14:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 01:14:21 --> Model Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Model Class Initialized
DEBUG - 2018-07-09 01:14:21 --> Helper loaded: url_helper
DEBUG - 2018-07-09 01:14:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 01:14:21 --> Final output sent to browser
DEBUG - 2018-07-09 01:14:21 --> Total execution time: 0.0208
DEBUG - 2018-07-09 01:17:20 --> Config Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Hooks Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Utf8 Class Initialized
DEBUG - 2018-07-09 01:17:20 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 01:17:20 --> URI Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Router Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Output Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Security Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Input Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 01:17:20 --> Language Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Loader Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Helper loaded: date_helper
DEBUG - 2018-07-09 01:17:20 --> Controller Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Database Driver Class Initialized
ERROR - 2018-07-09 01:17:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 01:17:20 --> Model Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Model Class Initialized
DEBUG - 2018-07-09 01:17:20 --> Helper loaded: url_helper
DEBUG - 2018-07-09 01:17:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 01:17:20 --> Final output sent to browser
DEBUG - 2018-07-09 01:17:20 --> Total execution time: 0.0211
DEBUG - 2018-07-09 06:40:20 --> Config Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Hooks Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Utf8 Class Initialized
DEBUG - 2018-07-09 06:40:20 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 06:40:20 --> URI Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Router Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Output Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Security Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Input Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 06:40:20 --> Language Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Loader Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Helper loaded: date_helper
DEBUG - 2018-07-09 06:40:20 --> Controller Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Database Driver Class Initialized
ERROR - 2018-07-09 06:40:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 06:40:20 --> Model Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Model Class Initialized
DEBUG - 2018-07-09 06:40:20 --> Helper loaded: url_helper
DEBUG - 2018-07-09 06:40:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 06:40:20 --> Final output sent to browser
DEBUG - 2018-07-09 06:40:20 --> Total execution time: 0.0272
DEBUG - 2018-07-09 07:48:21 --> Config Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Hooks Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Utf8 Class Initialized
DEBUG - 2018-07-09 07:48:21 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 07:48:21 --> URI Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Router Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Output Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Security Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Input Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 07:48:21 --> Language Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Loader Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Helper loaded: date_helper
DEBUG - 2018-07-09 07:48:21 --> Controller Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Database Driver Class Initialized
ERROR - 2018-07-09 07:48:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 07:48:21 --> Model Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Model Class Initialized
DEBUG - 2018-07-09 07:48:21 --> Helper loaded: url_helper
DEBUG - 2018-07-09 07:48:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 07:48:21 --> Final output sent to browser
DEBUG - 2018-07-09 07:48:21 --> Total execution time: 0.0210
DEBUG - 2018-07-09 07:48:54 --> Config Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Hooks Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Utf8 Class Initialized
DEBUG - 2018-07-09 07:48:54 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 07:48:54 --> URI Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Router Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Output Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Security Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Input Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 07:48:54 --> Language Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Loader Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Helper loaded: date_helper
DEBUG - 2018-07-09 07:48:54 --> Controller Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Database Driver Class Initialized
ERROR - 2018-07-09 07:48:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 07:48:54 --> Model Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Model Class Initialized
DEBUG - 2018-07-09 07:48:54 --> Helper loaded: url_helper
DEBUG - 2018-07-09 07:48:54 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-07-09 07:48:54 --> Final output sent to browser
DEBUG - 2018-07-09 07:48:54 --> Total execution time: 0.0239
DEBUG - 2018-07-09 08:57:44 --> Config Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Hooks Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Utf8 Class Initialized
DEBUG - 2018-07-09 08:57:44 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 08:57:44 --> URI Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Router Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Output Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Security Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Input Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 08:57:44 --> Language Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Loader Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Helper loaded: date_helper
DEBUG - 2018-07-09 08:57:44 --> Controller Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Database Driver Class Initialized
ERROR - 2018-07-09 08:57:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 08:57:44 --> Model Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Model Class Initialized
DEBUG - 2018-07-09 08:57:44 --> Helper loaded: url_helper
DEBUG - 2018-07-09 08:57:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 08:57:44 --> Final output sent to browser
DEBUG - 2018-07-09 08:57:44 --> Total execution time: 0.0213
DEBUG - 2018-07-09 08:58:01 --> Config Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Hooks Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Utf8 Class Initialized
DEBUG - 2018-07-09 08:58:01 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 08:58:01 --> URI Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Router Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Output Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Security Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Input Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 08:58:01 --> Language Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Loader Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Helper loaded: date_helper
DEBUG - 2018-07-09 08:58:01 --> Controller Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Database Driver Class Initialized
ERROR - 2018-07-09 08:58:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 08:58:01 --> Model Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Model Class Initialized
DEBUG - 2018-07-09 08:58:01 --> Helper loaded: url_helper
DEBUG - 2018-07-09 08:58:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 08:58:01 --> Final output sent to browser
DEBUG - 2018-07-09 08:58:01 --> Total execution time: 0.0200
DEBUG - 2018-07-09 08:58:17 --> Config Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Hooks Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Utf8 Class Initialized
DEBUG - 2018-07-09 08:58:17 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 08:58:17 --> URI Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Router Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Output Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Security Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Input Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 08:58:17 --> Language Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Loader Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Helper loaded: date_helper
DEBUG - 2018-07-09 08:58:17 --> Controller Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Database Driver Class Initialized
ERROR - 2018-07-09 08:58:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 08:58:17 --> Model Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Model Class Initialized
DEBUG - 2018-07-09 08:58:17 --> Helper loaded: url_helper
DEBUG - 2018-07-09 08:58:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 08:58:17 --> Final output sent to browser
DEBUG - 2018-07-09 08:58:17 --> Total execution time: 0.0213
DEBUG - 2018-07-09 08:58:33 --> Config Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Hooks Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Utf8 Class Initialized
DEBUG - 2018-07-09 08:58:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 08:58:33 --> URI Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Router Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Output Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Security Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Input Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 08:58:33 --> Language Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Loader Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Helper loaded: date_helper
DEBUG - 2018-07-09 08:58:33 --> Controller Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Database Driver Class Initialized
ERROR - 2018-07-09 08:58:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 08:58:33 --> Model Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Model Class Initialized
DEBUG - 2018-07-09 08:58:33 --> Helper loaded: url_helper
DEBUG - 2018-07-09 08:58:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 08:58:33 --> Final output sent to browser
DEBUG - 2018-07-09 08:58:33 --> Total execution time: 0.0210
DEBUG - 2018-07-09 09:02:22 --> Config Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Hooks Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Utf8 Class Initialized
DEBUG - 2018-07-09 09:02:22 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 09:02:22 --> URI Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Router Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Output Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Security Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Input Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 09:02:22 --> Language Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Loader Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Helper loaded: date_helper
DEBUG - 2018-07-09 09:02:22 --> Controller Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Database Driver Class Initialized
ERROR - 2018-07-09 09:02:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 09:02:22 --> Model Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Model Class Initialized
DEBUG - 2018-07-09 09:02:22 --> Helper loaded: url_helper
DEBUG - 2018-07-09 09:02:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 09:02:22 --> Final output sent to browser
DEBUG - 2018-07-09 09:02:22 --> Total execution time: 0.0207
DEBUG - 2018-07-09 09:06:27 --> Config Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Hooks Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Utf8 Class Initialized
DEBUG - 2018-07-09 09:06:27 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 09:06:27 --> URI Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Router Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Output Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Security Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Input Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 09:06:27 --> Language Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Loader Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Helper loaded: date_helper
DEBUG - 2018-07-09 09:06:27 --> Controller Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Database Driver Class Initialized
ERROR - 2018-07-09 09:06:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 09:06:27 --> Model Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Model Class Initialized
DEBUG - 2018-07-09 09:06:27 --> Helper loaded: url_helper
DEBUG - 2018-07-09 09:06:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 09:06:27 --> Final output sent to browser
DEBUG - 2018-07-09 09:06:27 --> Total execution time: 0.0212
DEBUG - 2018-07-09 09:30:40 --> Config Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Hooks Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Utf8 Class Initialized
DEBUG - 2018-07-09 09:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 09:30:40 --> URI Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Router Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Output Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Security Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Input Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 09:30:40 --> Language Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Loader Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Helper loaded: date_helper
DEBUG - 2018-07-09 09:30:40 --> Controller Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Database Driver Class Initialized
ERROR - 2018-07-09 09:30:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 09:30:40 --> Model Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Model Class Initialized
DEBUG - 2018-07-09 09:30:40 --> Helper loaded: url_helper
DEBUG - 2018-07-09 09:30:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 09:30:40 --> Final output sent to browser
DEBUG - 2018-07-09 09:30:40 --> Total execution time: 0.0211
DEBUG - 2018-07-09 10:04:24 --> Config Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Hooks Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Utf8 Class Initialized
DEBUG - 2018-07-09 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 10:04:24 --> URI Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Router Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Output Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Security Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Input Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 10:04:24 --> Language Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Loader Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Helper loaded: date_helper
DEBUG - 2018-07-09 10:04:24 --> Controller Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Database Driver Class Initialized
ERROR - 2018-07-09 10:04:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 10:04:24 --> Model Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Model Class Initialized
DEBUG - 2018-07-09 10:04:24 --> Helper loaded: url_helper
DEBUG - 2018-07-09 10:04:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 10:04:24 --> Final output sent to browser
DEBUG - 2018-07-09 10:04:24 --> Total execution time: 0.0209
DEBUG - 2018-07-09 10:30:48 --> Config Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Hooks Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Utf8 Class Initialized
DEBUG - 2018-07-09 10:30:48 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 10:30:48 --> URI Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Router Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Output Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Security Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Input Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 10:30:48 --> Language Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Loader Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Helper loaded: date_helper
DEBUG - 2018-07-09 10:30:48 --> Controller Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Database Driver Class Initialized
ERROR - 2018-07-09 10:30:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 10:30:48 --> Model Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Model Class Initialized
DEBUG - 2018-07-09 10:30:48 --> Helper loaded: url_helper
DEBUG - 2018-07-09 10:30:48 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 10:30:48 --> Final output sent to browser
DEBUG - 2018-07-09 10:30:48 --> Total execution time: 0.0209
DEBUG - 2018-07-09 10:40:20 --> Config Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Hooks Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Utf8 Class Initialized
DEBUG - 2018-07-09 10:40:20 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 10:40:20 --> URI Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Router Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Output Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Security Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Input Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 10:40:20 --> Language Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Loader Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Helper loaded: date_helper
DEBUG - 2018-07-09 10:40:20 --> Controller Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Database Driver Class Initialized
ERROR - 2018-07-09 10:40:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 10:40:20 --> Model Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Model Class Initialized
DEBUG - 2018-07-09 10:40:20 --> Helper loaded: url_helper
DEBUG - 2018-07-09 10:40:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 10:40:20 --> Final output sent to browser
DEBUG - 2018-07-09 10:40:20 --> Total execution time: 0.0211
DEBUG - 2018-07-09 11:23:30 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:30 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:30 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:30 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:30 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:31 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:31 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:31 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:31 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:31 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-07-09 11:23:31 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:31 --> Total execution time: 0.0255
DEBUG - 2018-07-09 11:23:32 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:32 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:32 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:32 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:32 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:32 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:32 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-07-09 11:23:32 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:32 --> Total execution time: 0.0209
DEBUG - 2018-07-09 11:23:34 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:34 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:34 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:34 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:34 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:34 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:34 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:34 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:34 --> Total execution time: 0.0204
DEBUG - 2018-07-09 11:23:37 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:37 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:37 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:37 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:37 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:37 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:37 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:37 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:37 --> Total execution time: 0.0201
DEBUG - 2018-07-09 11:23:40 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:40 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:40 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:40 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:40 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:40 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:40 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:40 --> Total execution time: 0.0211
DEBUG - 2018-07-09 11:23:42 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:42 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:42 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:42 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:42 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:42 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:42 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:42 --> Total execution time: 0.0208
DEBUG - 2018-07-09 11:23:45 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:45 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:45 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:45 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:45 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:45 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:45 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:45 --> Total execution time: 0.0207
DEBUG - 2018-07-09 11:23:47 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:47 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:47 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:47 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:47 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:47 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:47 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:47 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:47 --> Total execution time: 0.0201
DEBUG - 2018-07-09 11:23:50 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:50 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:50 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:50 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:50 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:50 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:50 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:50 --> Total execution time: 0.0197
DEBUG - 2018-07-09 11:23:53 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:53 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:53 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:53 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:53 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:53 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:53 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:53 --> Total execution time: 0.0206
DEBUG - 2018-07-09 11:23:56 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:56 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:56 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:56 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:56 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:56 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:56 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:56 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:56 --> Total execution time: 0.0201
DEBUG - 2018-07-09 11:23:58 --> Config Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:23:58 --> URI Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Router Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Output Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Security Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Input Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:23:58 --> Language Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Loader Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:23:58 --> Controller Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:23:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:23:58 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Model Class Initialized
DEBUG - 2018-07-09 11:23:58 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:23:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:23:58 --> Final output sent to browser
DEBUG - 2018-07-09 11:23:58 --> Total execution time: 0.0218
DEBUG - 2018-07-09 11:24:01 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:01 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:01 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:01 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:01 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:01 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:01 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:01 --> Total execution time: 0.0204
DEBUG - 2018-07-09 11:24:06 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:06 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:06 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:06 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:06 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:06 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:06 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:06 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:06 --> Total execution time: 0.0206
DEBUG - 2018-07-09 11:24:09 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:09 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:09 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:09 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:09 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:09 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:09 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:09 --> Total execution time: 0.0202
DEBUG - 2018-07-09 11:24:11 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:11 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:11 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:11 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:11 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:11 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:11 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:11 --> Total execution time: 0.0204
DEBUG - 2018-07-09 11:24:14 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:14 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:14 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:14 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:14 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:14 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:14 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:14 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:14 --> Total execution time: 0.0206
DEBUG - 2018-07-09 11:24:16 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:16 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:16 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:16 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:16 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:16 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:16 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:16 --> Total execution time: 0.0206
DEBUG - 2018-07-09 11:24:19 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:19 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:19 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:19 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:19 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:19 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:19 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:19 --> Total execution time: 0.0209
DEBUG - 2018-07-09 11:24:22 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:22 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:22 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:22 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:22 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:22 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:22 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:22 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:22 --> Total execution time: 0.0201
DEBUG - 2018-07-09 11:24:25 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:25 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:25 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:25 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:25 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:25 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:25 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:25 --> Total execution time: 0.0207
DEBUG - 2018-07-09 11:24:27 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:27 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:27 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:27 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:27 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:27 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:27 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:27 --> Total execution time: 0.0206
DEBUG - 2018-07-09 11:24:30 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:30 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:30 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:30 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:30 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:30 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:30 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:30 --> Total execution time: 0.0203
DEBUG - 2018-07-09 11:24:32 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:32 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:32 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:32 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:32 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:32 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:32 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:32 --> Total execution time: 0.0204
DEBUG - 2018-07-09 11:24:35 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:35 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:35 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:35 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:35 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:35 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:35 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:35 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:35 --> Total execution time: 0.0207
DEBUG - 2018-07-09 11:24:38 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:38 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:38 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:38 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:38 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:38 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:38 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:38 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:38 --> Total execution time: 0.0210
DEBUG - 2018-07-09 11:24:40 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:40 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:40 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:40 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:40 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:40 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:40 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:40 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:40 --> Total execution time: 0.0200
DEBUG - 2018-07-09 11:24:43 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:43 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:43 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:43 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:43 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:43 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:43 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:43 --> Total execution time: 0.0206
DEBUG - 2018-07-09 11:24:45 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:45 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:45 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:45 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:45 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:45 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:45 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:45 --> Total execution time: 0.0205
DEBUG - 2018-07-09 11:24:48 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:48 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:48 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:48 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:48 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:48 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:48 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:48 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:48 --> Total execution time: 0.0204
DEBUG - 2018-07-09 11:24:51 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:51 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:51 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:51 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:51 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:51 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:51 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:51 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:51 --> Total execution time: 0.0202
DEBUG - 2018-07-09 11:24:53 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:53 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:53 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:53 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:53 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:53 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:53 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:53 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:53 --> Total execution time: 0.0206
DEBUG - 2018-07-09 11:24:56 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:56 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:56 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:56 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:56 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:56 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:56 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:56 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:56 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:56 --> Total execution time: 0.0211
DEBUG - 2018-07-09 11:24:59 --> Config Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:24:59 --> URI Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Router Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Output Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Security Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Input Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:24:59 --> Language Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Loader Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:24:59 --> Controller Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:24:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:24:59 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Model Class Initialized
DEBUG - 2018-07-09 11:24:59 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:24:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:24:59 --> Final output sent to browser
DEBUG - 2018-07-09 11:24:59 --> Total execution time: 0.0209
DEBUG - 2018-07-09 11:25:01 --> Config Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:25:01 --> URI Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Router Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Output Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Security Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Input Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:25:01 --> Language Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Loader Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:25:01 --> Controller Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:25:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:25:01 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:01 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:25:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:25:01 --> Final output sent to browser
DEBUG - 2018-07-09 11:25:01 --> Total execution time: 0.0283
DEBUG - 2018-07-09 11:25:04 --> Config Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:25:04 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:25:04 --> URI Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Router Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Output Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Security Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Input Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:25:04 --> Language Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Loader Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:25:04 --> Controller Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:25:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:25:04 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:04 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:25:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:25:04 --> Final output sent to browser
DEBUG - 2018-07-09 11:25:04 --> Total execution time: 0.0197
DEBUG - 2018-07-09 11:25:07 --> Config Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:25:07 --> URI Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Router Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Output Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Security Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Input Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:25:07 --> Language Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Loader Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:25:07 --> Controller Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:25:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:25:07 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:07 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:25:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:25:07 --> Final output sent to browser
DEBUG - 2018-07-09 11:25:07 --> Total execution time: 0.0213
DEBUG - 2018-07-09 11:25:09 --> Config Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:25:09 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:25:09 --> URI Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Router Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Output Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Security Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Input Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:25:09 --> Language Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Loader Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:25:09 --> Controller Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:25:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:25:09 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:09 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:25:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:25:09 --> Final output sent to browser
DEBUG - 2018-07-09 11:25:09 --> Total execution time: 0.0207
DEBUG - 2018-07-09 11:25:12 --> Config Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:25:12 --> URI Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Router Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Output Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Security Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Input Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:25:12 --> Language Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Loader Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:25:12 --> Controller Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:25:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:25:12 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:12 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:25:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:25:12 --> Final output sent to browser
DEBUG - 2018-07-09 11:25:12 --> Total execution time: 0.0205
DEBUG - 2018-07-09 11:25:15 --> Config Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:25:15 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:25:15 --> URI Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Router Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Output Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Security Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Input Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:25:15 --> Language Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Loader Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:25:15 --> Controller Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:25:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:25:15 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:15 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:25:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:25:15 --> Final output sent to browser
DEBUG - 2018-07-09 11:25:15 --> Total execution time: 0.0208
DEBUG - 2018-07-09 11:25:18 --> Config Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:25:18 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:25:18 --> URI Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Router Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Output Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Security Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Input Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:25:18 --> Language Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Loader Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:25:18 --> Controller Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:25:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:25:18 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Model Class Initialized
DEBUG - 2018-07-09 11:25:18 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:25:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:25:18 --> Final output sent to browser
DEBUG - 2018-07-09 11:25:18 --> Total execution time: 0.0208
DEBUG - 2018-07-09 11:39:22 --> Config Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Hooks Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Utf8 Class Initialized
DEBUG - 2018-07-09 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 11:39:22 --> URI Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Router Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Output Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Security Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Input Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 11:39:22 --> Language Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Loader Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Helper loaded: date_helper
DEBUG - 2018-07-09 11:39:22 --> Controller Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Database Driver Class Initialized
ERROR - 2018-07-09 11:39:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 11:39:22 --> Model Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Model Class Initialized
DEBUG - 2018-07-09 11:39:22 --> Helper loaded: url_helper
DEBUG - 2018-07-09 11:39:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 11:39:22 --> Final output sent to browser
DEBUG - 2018-07-09 11:39:22 --> Total execution time: 0.0206
DEBUG - 2018-07-09 15:36:05 --> Config Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Hooks Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Utf8 Class Initialized
DEBUG - 2018-07-09 15:36:05 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 15:36:05 --> URI Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Router Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Output Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Security Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Input Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 15:36:05 --> Language Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Loader Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Helper loaded: date_helper
DEBUG - 2018-07-09 15:36:05 --> Controller Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Database Driver Class Initialized
ERROR - 2018-07-09 15:36:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 15:36:05 --> Model Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Model Class Initialized
DEBUG - 2018-07-09 15:36:05 --> Helper loaded: url_helper
DEBUG - 2018-07-09 15:36:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 15:36:05 --> Final output sent to browser
DEBUG - 2018-07-09 15:36:05 --> Total execution time: 0.0256
DEBUG - 2018-07-09 16:02:39 --> Config Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Hooks Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Utf8 Class Initialized
DEBUG - 2018-07-09 16:02:39 --> UTF-8 Support Enabled
DEBUG - 2018-07-09 16:02:39 --> URI Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Router Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Output Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Security Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Input Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-09 16:02:39 --> Language Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Loader Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Helper loaded: date_helper
DEBUG - 2018-07-09 16:02:39 --> Controller Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Database Driver Class Initialized
ERROR - 2018-07-09 16:02:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-09 16:02:39 --> Model Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Model Class Initialized
DEBUG - 2018-07-09 16:02:39 --> Helper loaded: url_helper
DEBUG - 2018-07-09 16:02:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-09 16:02:39 --> Final output sent to browser
DEBUG - 2018-07-09 16:02:39 --> Total execution time: 0.0214
