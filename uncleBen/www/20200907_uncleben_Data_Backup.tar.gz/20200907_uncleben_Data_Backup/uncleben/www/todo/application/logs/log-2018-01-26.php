<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-01-26 09:39:08 --> Config Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Hooks Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Utf8 Class Initialized
DEBUG - 2018-01-26 09:39:08 --> UTF-8 Support Enabled
DEBUG - 2018-01-26 09:39:08 --> URI Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Router Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Output Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Security Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Input Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-26 09:39:08 --> Language Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Loader Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Helper loaded: date_helper
DEBUG - 2018-01-26 09:39:08 --> Controller Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Database Driver Class Initialized
ERROR - 2018-01-26 09:39:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-26 09:39:08 --> Model Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Model Class Initialized
DEBUG - 2018-01-26 09:39:08 --> Helper loaded: url_helper
DEBUG - 2018-01-26 09:39:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-26 09:39:08 --> Final output sent to browser
DEBUG - 2018-01-26 09:39:08 --> Total execution time: 0.0367
DEBUG - 2018-01-26 09:40:25 --> Config Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Hooks Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Utf8 Class Initialized
DEBUG - 2018-01-26 09:40:25 --> UTF-8 Support Enabled
DEBUG - 2018-01-26 09:40:25 --> URI Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Router Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Output Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Security Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Input Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-26 09:40:25 --> Language Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Loader Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Helper loaded: date_helper
DEBUG - 2018-01-26 09:40:25 --> Controller Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Database Driver Class Initialized
ERROR - 2018-01-26 09:40:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-26 09:40:25 --> Model Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Model Class Initialized
DEBUG - 2018-01-26 09:40:25 --> Helper loaded: url_helper
DEBUG - 2018-01-26 09:40:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-26 09:40:25 --> Final output sent to browser
DEBUG - 2018-01-26 09:40:25 --> Total execution time: 0.0207
DEBUG - 2018-01-26 21:16:55 --> Config Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Hooks Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Utf8 Class Initialized
DEBUG - 2018-01-26 21:16:55 --> UTF-8 Support Enabled
DEBUG - 2018-01-26 21:16:55 --> URI Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Router Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Output Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Security Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Input Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-26 21:16:55 --> Language Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Loader Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Helper loaded: date_helper
DEBUG - 2018-01-26 21:16:55 --> Controller Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Database Driver Class Initialized
ERROR - 2018-01-26 21:16:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-26 21:16:55 --> Model Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Model Class Initialized
DEBUG - 2018-01-26 21:16:55 --> Helper loaded: url_helper
DEBUG - 2018-01-26 21:16:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-26 21:16:55 --> Final output sent to browser
DEBUG - 2018-01-26 21:16:55 --> Total execution time: 0.0286
