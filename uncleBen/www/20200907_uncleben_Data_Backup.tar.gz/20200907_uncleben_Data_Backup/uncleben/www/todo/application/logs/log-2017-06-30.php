<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-06-30 05:39:25 --> Config Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:39:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:39:25 --> URI Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Router Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Output Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Security Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Input Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:39:25 --> Language Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Loader Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:39:25 --> Controller Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:39:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:39:25 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:25 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:39:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:39:25 --> Final output sent to browser
DEBUG - 2017-06-30 05:39:25 --> Total execution time: 0.0489
DEBUG - 2017-06-30 05:39:29 --> Config Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:39:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:39:29 --> URI Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Router Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Output Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Security Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Input Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:39:29 --> Language Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Loader Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:39:29 --> Controller Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:39:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:39:29 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:29 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:39:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:39:29 --> Final output sent to browser
DEBUG - 2017-06-30 05:39:29 --> Total execution time: 0.0342
DEBUG - 2017-06-30 05:39:32 --> Config Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:39:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:39:32 --> URI Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Router Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Output Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Security Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Input Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:39:32 --> Language Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Loader Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:39:32 --> Controller Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:39:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:39:32 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:32 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:39:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:39:32 --> Final output sent to browser
DEBUG - 2017-06-30 05:39:32 --> Total execution time: 0.0340
DEBUG - 2017-06-30 05:39:36 --> Config Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:39:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:39:36 --> URI Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Router Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Output Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Security Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Input Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:39:36 --> Language Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Loader Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:39:36 --> Controller Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:39:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:39:36 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Model Class Initialized
DEBUG - 2017-06-30 05:39:36 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:39:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:39:36 --> Final output sent to browser
DEBUG - 2017-06-30 05:39:36 --> Total execution time: 0.0347
DEBUG - 2017-06-30 05:50:24 --> Config Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:50:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:50:24 --> URI Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Router Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Output Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Security Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Input Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:50:24 --> Language Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Loader Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:50:24 --> Controller Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:50:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:50:24 --> Model Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Model Class Initialized
DEBUG - 2017-06-30 05:50:24 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:50:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:50:24 --> Final output sent to browser
DEBUG - 2017-06-30 05:50:24 --> Total execution time: 0.0345
DEBUG - 2017-06-30 05:50:38 --> Config Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:50:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:50:38 --> URI Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Router Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Output Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Security Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Input Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:50:38 --> Language Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Loader Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:50:38 --> Controller Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:50:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:50:38 --> Model Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Model Class Initialized
DEBUG - 2017-06-30 05:50:38 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:50:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:50:38 --> Final output sent to browser
DEBUG - 2017-06-30 05:50:38 --> Total execution time: 0.0350
DEBUG - 2017-06-30 05:51:02 --> Config Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:51:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:51:02 --> URI Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Router Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Output Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Security Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Input Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:51:02 --> Language Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Loader Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:51:02 --> Controller Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:51:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:51:02 --> Model Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Model Class Initialized
DEBUG - 2017-06-30 05:51:02 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:51:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:51:02 --> Final output sent to browser
DEBUG - 2017-06-30 05:51:02 --> Total execution time: 0.0329
DEBUG - 2017-06-30 05:53:25 --> Config Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:53:25 --> URI Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Router Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Output Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Security Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Input Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:53:25 --> Language Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Loader Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:53:25 --> Controller Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:53:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:53:25 --> Model Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Model Class Initialized
DEBUG - 2017-06-30 05:53:25 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:53:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:53:25 --> Final output sent to browser
DEBUG - 2017-06-30 05:53:25 --> Total execution time: 0.0339
DEBUG - 2017-06-30 05:53:50 --> Config Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:53:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:53:50 --> URI Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Router Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Output Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Security Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Input Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:53:50 --> Language Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Loader Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:53:50 --> Controller Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:53:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:53:50 --> Model Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Model Class Initialized
DEBUG - 2017-06-30 05:53:50 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:53:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:53:50 --> Final output sent to browser
DEBUG - 2017-06-30 05:53:50 --> Total execution time: 0.0341
DEBUG - 2017-06-30 05:54:07 --> Config Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:54:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:54:07 --> URI Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Router Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Output Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Security Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Input Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:54:07 --> Language Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Loader Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:54:07 --> Controller Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:54:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:54:07 --> Model Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Model Class Initialized
DEBUG - 2017-06-30 05:54:07 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:54:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:54:07 --> Final output sent to browser
DEBUG - 2017-06-30 05:54:07 --> Total execution time: 0.0336
DEBUG - 2017-06-30 05:54:15 --> Config Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:54:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:54:15 --> URI Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Router Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Output Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Security Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Input Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:54:15 --> Language Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Loader Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:54:15 --> Controller Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:54:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:54:15 --> Model Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Model Class Initialized
DEBUG - 2017-06-30 05:54:15 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:54:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:54:15 --> Final output sent to browser
DEBUG - 2017-06-30 05:54:15 --> Total execution time: 0.0345
DEBUG - 2017-06-30 05:56:37 --> Config Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:56:37 --> URI Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Router Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Output Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Security Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Input Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:56:37 --> Language Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Loader Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:56:37 --> Controller Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:56:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:56:37 --> Model Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Model Class Initialized
DEBUG - 2017-06-30 05:56:37 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:56:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:56:37 --> Final output sent to browser
DEBUG - 2017-06-30 05:56:37 --> Total execution time: 0.0331
DEBUG - 2017-06-30 05:58:47 --> Config Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:58:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:58:47 --> URI Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Router Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Output Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Security Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Input Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:58:47 --> Language Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Loader Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:58:47 --> Controller Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:58:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:58:47 --> Model Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Model Class Initialized
DEBUG - 2017-06-30 05:58:47 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:58:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:58:47 --> Final output sent to browser
DEBUG - 2017-06-30 05:58:47 --> Total execution time: 0.0342
DEBUG - 2017-06-30 05:58:57 --> Config Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Hooks Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Utf8 Class Initialized
DEBUG - 2017-06-30 05:58:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 05:58:57 --> URI Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Router Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Output Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Security Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Input Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 05:58:57 --> Language Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Loader Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Helper loaded: date_helper
DEBUG - 2017-06-30 05:58:57 --> Controller Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Database Driver Class Initialized
ERROR - 2017-06-30 05:58:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 05:58:57 --> Model Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Model Class Initialized
DEBUG - 2017-06-30 05:58:57 --> Helper loaded: url_helper
DEBUG - 2017-06-30 05:58:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 05:58:57 --> Final output sent to browser
DEBUG - 2017-06-30 05:58:57 --> Total execution time: 0.0341
DEBUG - 2017-06-30 06:06:09 --> Config Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:06:09 --> URI Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Router Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Output Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Security Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Input Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:06:09 --> Language Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Loader Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:06:09 --> Controller Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:06:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:06:09 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:09 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:06:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:06:09 --> Final output sent to browser
DEBUG - 2017-06-30 06:06:09 --> Total execution time: 0.0335
DEBUG - 2017-06-30 06:06:15 --> Config Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:06:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:06:15 --> URI Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Router Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Output Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Security Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Input Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:06:15 --> Language Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Loader Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:06:15 --> Controller Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:06:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:06:15 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:15 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:06:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:06:15 --> Final output sent to browser
DEBUG - 2017-06-30 06:06:15 --> Total execution time: 0.0332
DEBUG - 2017-06-30 06:06:20 --> Config Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:06:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:06:20 --> URI Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Router Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Output Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Security Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Input Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:06:20 --> Language Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Loader Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:06:20 --> Controller Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:06:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:06:20 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:20 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:06:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:06:20 --> Final output sent to browser
DEBUG - 2017-06-30 06:06:20 --> Total execution time: 0.0333
DEBUG - 2017-06-30 06:06:51 --> Config Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:06:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:06:51 --> URI Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Router Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Output Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Security Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Input Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:06:51 --> Language Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Loader Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:06:51 --> Controller Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:06:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:06:51 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Model Class Initialized
DEBUG - 2017-06-30 06:06:51 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:06:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:06:51 --> Final output sent to browser
DEBUG - 2017-06-30 06:06:51 --> Total execution time: 0.0330
DEBUG - 2017-06-30 06:07:04 --> Config Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:07:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:07:04 --> URI Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Router Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Output Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Security Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Input Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:07:04 --> Language Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Loader Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:07:04 --> Controller Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:07:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:07:04 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:04 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:07:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:07:04 --> Final output sent to browser
DEBUG - 2017-06-30 06:07:04 --> Total execution time: 0.0328
DEBUG - 2017-06-30 06:07:28 --> Config Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:07:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:07:28 --> URI Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Router Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Output Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Security Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Input Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:07:28 --> Language Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Loader Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:07:28 --> Controller Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:07:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:07:28 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:28 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:07:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:07:28 --> Final output sent to browser
DEBUG - 2017-06-30 06:07:28 --> Total execution time: 0.0339
DEBUG - 2017-06-30 06:07:40 --> Config Class Initialized
DEBUG - 2017-06-30 06:07:40 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:07:40 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:07:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:07:40 --> URI Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Router Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Output Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Security Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Input Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:07:41 --> Language Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Loader Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:07:41 --> Controller Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:07:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:07:41 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:41 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:07:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:07:41 --> Final output sent to browser
DEBUG - 2017-06-30 06:07:41 --> Total execution time: 0.0331
DEBUG - 2017-06-30 06:07:52 --> Config Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:07:52 --> URI Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Router Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Output Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Security Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Input Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:07:52 --> Language Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Loader Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:07:52 --> Controller Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:07:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:07:52 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:52 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:07:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:07:52 --> Final output sent to browser
DEBUG - 2017-06-30 06:07:52 --> Total execution time: 0.0333
DEBUG - 2017-06-30 06:07:56 --> Config Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:07:56 --> URI Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Router Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Output Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Security Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Input Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:07:56 --> Language Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Loader Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:07:56 --> Controller Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:07:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:07:56 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Model Class Initialized
DEBUG - 2017-06-30 06:07:56 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:07:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:07:56 --> Final output sent to browser
DEBUG - 2017-06-30 06:07:56 --> Total execution time: 0.0332
DEBUG - 2017-06-30 06:08:05 --> Config Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:08:05 --> URI Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Router Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Output Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Security Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Input Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:08:05 --> Language Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Loader Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:08:05 --> Controller Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:08:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:08:05 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:05 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:08:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:08:05 --> Final output sent to browser
DEBUG - 2017-06-30 06:08:05 --> Total execution time: 0.0327
DEBUG - 2017-06-30 06:08:12 --> Config Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:08:12 --> URI Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Router Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Output Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Security Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Input Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:08:12 --> Language Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Loader Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:08:12 --> Controller Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:08:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:08:12 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:12 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:08:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:08:12 --> Final output sent to browser
DEBUG - 2017-06-30 06:08:12 --> Total execution time: 0.0330
DEBUG - 2017-06-30 06:08:17 --> Config Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:08:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:08:17 --> URI Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Router Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Output Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Security Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Input Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:08:17 --> Language Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Loader Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:08:17 --> Controller Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:08:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:08:17 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:17 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:08:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:08:17 --> Final output sent to browser
DEBUG - 2017-06-30 06:08:17 --> Total execution time: 0.0331
DEBUG - 2017-06-30 06:08:19 --> Config Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:08:19 --> URI Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Router Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Output Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Security Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Input Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:08:19 --> Language Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Loader Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:08:19 --> Controller Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:08:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:08:19 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Model Class Initialized
DEBUG - 2017-06-30 06:08:19 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:08:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:08:19 --> Final output sent to browser
DEBUG - 2017-06-30 06:08:19 --> Total execution time: 0.0323
DEBUG - 2017-06-30 06:10:59 --> Config Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:10:59 --> URI Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Router Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Output Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Security Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Input Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:10:59 --> Language Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Loader Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:10:59 --> Controller Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:10:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:10:59 --> Model Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Model Class Initialized
DEBUG - 2017-06-30 06:10:59 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:10:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:10:59 --> Final output sent to browser
DEBUG - 2017-06-30 06:10:59 --> Total execution time: 0.0332
DEBUG - 2017-06-30 06:12:53 --> Config Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:12:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:12:53 --> URI Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Router Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Output Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Security Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Input Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:12:53 --> Language Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Loader Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:12:53 --> Controller Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:12:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:12:53 --> Model Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Model Class Initialized
DEBUG - 2017-06-30 06:12:53 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:12:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:12:53 --> Final output sent to browser
DEBUG - 2017-06-30 06:12:53 --> Total execution time: 0.0342
DEBUG - 2017-06-30 06:13:45 --> Config Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:13:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:13:45 --> URI Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Router Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Output Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Security Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Input Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:13:45 --> Language Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Loader Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:13:45 --> Controller Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:13:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:13:45 --> Model Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Model Class Initialized
DEBUG - 2017-06-30 06:13:45 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:13:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:13:45 --> Final output sent to browser
DEBUG - 2017-06-30 06:13:45 --> Total execution time: 0.0344
DEBUG - 2017-06-30 06:14:06 --> Config Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:14:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:14:06 --> URI Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Router Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Output Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Security Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Input Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:14:06 --> Language Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Loader Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:14:06 --> Controller Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:14:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:14:06 --> Model Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Model Class Initialized
DEBUG - 2017-06-30 06:14:06 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:14:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:14:06 --> Final output sent to browser
DEBUG - 2017-06-30 06:14:06 --> Total execution time: 0.0339
DEBUG - 2017-06-30 06:14:53 --> Config Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:14:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:14:53 --> URI Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Router Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Output Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Security Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Input Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:14:53 --> Language Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Loader Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:14:53 --> Controller Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:14:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:14:53 --> Model Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Model Class Initialized
DEBUG - 2017-06-30 06:14:53 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:14:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:14:53 --> Final output sent to browser
DEBUG - 2017-06-30 06:14:53 --> Total execution time: 0.0348
DEBUG - 2017-06-30 06:16:46 --> Config Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:16:46 --> URI Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Router Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Output Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Security Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Input Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:16:46 --> Language Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Loader Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:16:46 --> Controller Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:16:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:16:46 --> Model Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Model Class Initialized
DEBUG - 2017-06-30 06:16:46 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:16:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:16:46 --> Final output sent to browser
DEBUG - 2017-06-30 06:16:46 --> Total execution time: 0.0341
DEBUG - 2017-06-30 06:16:49 --> Config Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:16:49 --> URI Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Router Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Output Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Security Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Input Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:16:49 --> Language Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Loader Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:16:49 --> Controller Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:16:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:16:49 --> Model Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Model Class Initialized
DEBUG - 2017-06-30 06:16:49 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:16:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:16:49 --> Final output sent to browser
DEBUG - 2017-06-30 06:16:49 --> Total execution time: 0.0345
DEBUG - 2017-06-30 06:17:16 --> Config Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:17:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:17:16 --> URI Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Router Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Output Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Security Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Input Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:17:16 --> Language Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Loader Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:17:16 --> Controller Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:17:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:17:16 --> Model Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Model Class Initialized
DEBUG - 2017-06-30 06:17:16 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:17:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:17:16 --> Final output sent to browser
DEBUG - 2017-06-30 06:17:16 --> Total execution time: 0.0326
DEBUG - 2017-06-30 06:27:51 --> Config Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:27:51 --> URI Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Router Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Output Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Security Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Input Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:27:51 --> Language Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Loader Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:27:51 --> Controller Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:27:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:27:51 --> Model Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Model Class Initialized
DEBUG - 2017-06-30 06:27:51 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:27:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:27:51 --> Final output sent to browser
DEBUG - 2017-06-30 06:27:51 --> Total execution time: 0.0341
DEBUG - 2017-06-30 06:28:38 --> Config Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:28:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:28:38 --> URI Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Router Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Output Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Security Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Input Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:28:38 --> Language Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Loader Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:28:38 --> Controller Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:28:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:28:38 --> Model Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Model Class Initialized
DEBUG - 2017-06-30 06:28:38 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:28:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:28:38 --> Final output sent to browser
DEBUG - 2017-06-30 06:28:38 --> Total execution time: 0.0337
DEBUG - 2017-06-30 06:57:53 --> Config Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:57:53 --> URI Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Router Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Output Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Security Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Input Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:57:53 --> Language Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Loader Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:57:53 --> Controller Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:57:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:57:53 --> Model Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Model Class Initialized
DEBUG - 2017-06-30 06:57:53 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:57:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:57:53 --> Final output sent to browser
DEBUG - 2017-06-30 06:57:53 --> Total execution time: 0.0339
DEBUG - 2017-06-30 06:59:03 --> Config Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Hooks Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Utf8 Class Initialized
DEBUG - 2017-06-30 06:59:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 06:59:03 --> URI Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Router Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Output Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Security Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Input Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 06:59:03 --> Language Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Loader Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Helper loaded: date_helper
DEBUG - 2017-06-30 06:59:03 --> Controller Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Database Driver Class Initialized
ERROR - 2017-06-30 06:59:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 06:59:03 --> Model Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Model Class Initialized
DEBUG - 2017-06-30 06:59:03 --> Helper loaded: url_helper
DEBUG - 2017-06-30 06:59:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 06:59:03 --> Final output sent to browser
DEBUG - 2017-06-30 06:59:03 --> Total execution time: 0.0341
DEBUG - 2017-06-30 07:07:03 --> Config Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:07:03 --> URI Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Router Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Output Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Security Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Input Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:07:03 --> Language Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Loader Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:07:03 --> Controller Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:07:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:07:03 --> Model Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Model Class Initialized
DEBUG - 2017-06-30 07:07:03 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:07:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:07:03 --> Final output sent to browser
DEBUG - 2017-06-30 07:07:03 --> Total execution time: 0.0346
DEBUG - 2017-06-30 07:07:52 --> Config Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:07:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:07:52 --> URI Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Router Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Output Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Security Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Input Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:07:52 --> Language Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Loader Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:07:52 --> Controller Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:07:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:07:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:07:52 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:07:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:07:52 --> Final output sent to browser
DEBUG - 2017-06-30 07:07:52 --> Total execution time: 0.0336
DEBUG - 2017-06-30 07:08:47 --> Config Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:08:47 --> URI Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Router Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Output Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Security Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Input Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:08:47 --> Language Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Loader Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:08:47 --> Controller Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:08:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:08:47 --> Model Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Model Class Initialized
DEBUG - 2017-06-30 07:08:47 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:08:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:08:47 --> Final output sent to browser
DEBUG - 2017-06-30 07:08:47 --> Total execution time: 0.0337
DEBUG - 2017-06-30 07:08:52 --> Config Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:08:52 --> URI Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Router Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Output Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Security Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Input Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:08:52 --> Language Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Loader Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:08:52 --> Controller Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:08:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:08:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:08:52 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:08:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:08:52 --> Final output sent to browser
DEBUG - 2017-06-30 07:08:52 --> Total execution time: 0.0325
DEBUG - 2017-06-30 07:08:59 --> Config Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:08:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:08:59 --> URI Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Router Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Output Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Security Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Input Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:08:59 --> Language Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Loader Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:08:59 --> Controller Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:08:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:08:59 --> Model Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Model Class Initialized
DEBUG - 2017-06-30 07:08:59 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:08:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:08:59 --> Final output sent to browser
DEBUG - 2017-06-30 07:08:59 --> Total execution time: 0.0323
DEBUG - 2017-06-30 07:09:59 --> Config Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:09:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:09:59 --> URI Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Router Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Output Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Security Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Input Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:09:59 --> Language Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Loader Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:09:59 --> Controller Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:09:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:09:59 --> Model Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Model Class Initialized
DEBUG - 2017-06-30 07:09:59 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:09:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:09:59 --> Final output sent to browser
DEBUG - 2017-06-30 07:09:59 --> Total execution time: 0.0367
DEBUG - 2017-06-30 07:11:09 --> Config Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:11:09 --> URI Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Router Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Output Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Security Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Input Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:11:09 --> Language Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Loader Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:11:09 --> Controller Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:11:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:11:09 --> Model Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Model Class Initialized
DEBUG - 2017-06-30 07:11:09 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:11:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:11:09 --> Final output sent to browser
DEBUG - 2017-06-30 07:11:09 --> Total execution time: 0.0323
DEBUG - 2017-06-30 07:15:38 --> Config Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:15:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:15:38 --> URI Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Router Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Output Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Security Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Input Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:15:38 --> Language Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Loader Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:15:38 --> Controller Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:15:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:15:38 --> Model Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Model Class Initialized
DEBUG - 2017-06-30 07:15:38 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:15:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:15:38 --> Final output sent to browser
DEBUG - 2017-06-30 07:15:38 --> Total execution time: 0.0324
DEBUG - 2017-06-30 07:15:44 --> Config Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:15:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:15:44 --> URI Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Router Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Output Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Security Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Input Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:15:44 --> Language Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Loader Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:15:44 --> Controller Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:15:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:15:44 --> Model Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Model Class Initialized
DEBUG - 2017-06-30 07:15:44 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:15:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:15:44 --> Final output sent to browser
DEBUG - 2017-06-30 07:15:44 --> Total execution time: 0.0327
DEBUG - 2017-06-30 07:16:01 --> Config Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:16:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:16:01 --> URI Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Router Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Output Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Security Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Input Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:16:01 --> Language Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Loader Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:16:01 --> Controller Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:16:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:16:01 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:01 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:16:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:16:01 --> Final output sent to browser
DEBUG - 2017-06-30 07:16:01 --> Total execution time: 0.0342
DEBUG - 2017-06-30 07:16:30 --> Config Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:16:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:16:30 --> URI Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Router Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Output Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Security Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Input Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:16:30 --> Language Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Loader Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:16:30 --> Controller Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:16:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:16:30 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:30 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:16:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:16:30 --> Final output sent to browser
DEBUG - 2017-06-30 07:16:30 --> Total execution time: 0.0326
DEBUG - 2017-06-30 07:16:34 --> Config Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:16:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:16:34 --> URI Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Router Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Output Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Security Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Input Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:16:34 --> Language Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Loader Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:16:34 --> Controller Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:16:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:16:34 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:34 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:16:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:16:34 --> Final output sent to browser
DEBUG - 2017-06-30 07:16:34 --> Total execution time: 0.0324
DEBUG - 2017-06-30 07:16:46 --> Config Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:16:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:16:46 --> URI Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Router Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Output Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Security Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Input Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:16:46 --> Language Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Loader Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:16:46 --> Controller Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:16:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:16:46 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Model Class Initialized
DEBUG - 2017-06-30 07:16:46 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:16:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:16:46 --> Final output sent to browser
DEBUG - 2017-06-30 07:16:46 --> Total execution time: 0.0331
DEBUG - 2017-06-30 07:17:04 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:04 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:04 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:04 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:04 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:04 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:04 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:04 --> Total execution time: 0.0326
DEBUG - 2017-06-30 07:17:11 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:11 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:11 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:11 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:11 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:11 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:11 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:11 --> Total execution time: 0.0322
DEBUG - 2017-06-30 07:17:18 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:18 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:18 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:18 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:18 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:18 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:18 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:18 --> Total execution time: 0.0326
DEBUG - 2017-06-30 07:17:25 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:25 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:25 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:25 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:25 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:25 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:25 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:25 --> Total execution time: 0.0323
DEBUG - 2017-06-30 07:17:31 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:31 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:31 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:31 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:31 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:31 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:31 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:31 --> Total execution time: 0.0324
DEBUG - 2017-06-30 07:17:43 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:43 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:43 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:43 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:43 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:43 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:43 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:43 --> Total execution time: 0.0327
DEBUG - 2017-06-30 07:17:48 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:48 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:48 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:48 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:48 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:48 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:48 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:48 --> Total execution time: 0.0315
DEBUG - 2017-06-30 07:17:52 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:52 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:52 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:52 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:52 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:52 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:52 --> Total execution time: 0.0325
DEBUG - 2017-06-30 07:17:56 --> Config Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:17:56 --> URI Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Router Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Output Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Security Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Input Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:17:56 --> Language Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Loader Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:17:56 --> Controller Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:17:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:17:56 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Model Class Initialized
DEBUG - 2017-06-30 07:17:56 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:17:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:17:56 --> Final output sent to browser
DEBUG - 2017-06-30 07:17:56 --> Total execution time: 0.0319
DEBUG - 2017-06-30 07:18:10 --> Config Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:18:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:18:10 --> URI Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Router Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Output Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Security Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Input Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:18:10 --> Language Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Loader Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:18:10 --> Controller Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:18:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:18:10 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:10 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:18:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:18:10 --> Final output sent to browser
DEBUG - 2017-06-30 07:18:10 --> Total execution time: 0.0322
DEBUG - 2017-06-30 07:18:14 --> Config Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:18:14 --> URI Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Router Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Output Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Security Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Input Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:18:14 --> Language Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Loader Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:18:14 --> Controller Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:18:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:18:14 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:14 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:18:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:18:14 --> Final output sent to browser
DEBUG - 2017-06-30 07:18:14 --> Total execution time: 0.0333
DEBUG - 2017-06-30 07:18:18 --> Config Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:18:18 --> URI Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Router Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Output Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Security Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Input Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:18:18 --> Language Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Loader Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:18:18 --> Controller Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:18:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:18:18 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:18 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:18:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:18:18 --> Final output sent to browser
DEBUG - 2017-06-30 07:18:18 --> Total execution time: 0.0337
DEBUG - 2017-06-30 07:18:28 --> Config Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:18:28 --> URI Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Router Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Output Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Security Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Input Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:18:28 --> Language Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Loader Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:18:28 --> Controller Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:18:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:18:28 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:28 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:18:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:18:28 --> Final output sent to browser
DEBUG - 2017-06-30 07:18:28 --> Total execution time: 0.0330
DEBUG - 2017-06-30 07:18:35 --> Config Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:18:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:18:35 --> URI Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Router Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Output Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Security Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Input Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:18:35 --> Language Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Loader Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:18:35 --> Controller Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:18:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:18:35 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Model Class Initialized
DEBUG - 2017-06-30 07:18:35 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:18:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:18:35 --> Final output sent to browser
DEBUG - 2017-06-30 07:18:35 --> Total execution time: 0.0328
DEBUG - 2017-06-30 07:20:46 --> Config Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:20:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:20:46 --> URI Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Router Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Output Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Security Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Input Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:20:46 --> Language Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Loader Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:20:46 --> Controller Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:20:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:20:46 --> Model Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Model Class Initialized
DEBUG - 2017-06-30 07:20:46 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:20:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:20:46 --> Final output sent to browser
DEBUG - 2017-06-30 07:20:46 --> Total execution time: 0.0344
DEBUG - 2017-06-30 07:20:51 --> Config Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:20:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:20:51 --> URI Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Router Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Output Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Security Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Input Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:20:51 --> Language Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Loader Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:20:51 --> Controller Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:20:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:20:51 --> Model Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Model Class Initialized
DEBUG - 2017-06-30 07:20:51 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:20:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:20:51 --> Final output sent to browser
DEBUG - 2017-06-30 07:20:51 --> Total execution time: 0.0333
DEBUG - 2017-06-30 07:22:06 --> Config Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:22:06 --> URI Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Router Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Output Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Security Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Input Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:22:06 --> Language Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Loader Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:22:06 --> Controller Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:22:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:22:06 --> Model Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Model Class Initialized
DEBUG - 2017-06-30 07:22:06 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:22:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:22:06 --> Final output sent to browser
DEBUG - 2017-06-30 07:22:06 --> Total execution time: 0.0327
DEBUG - 2017-06-30 07:22:10 --> Config Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:22:10 --> URI Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Router Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Output Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Security Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Input Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:22:10 --> Language Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Loader Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:22:10 --> Controller Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:22:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:22:10 --> Model Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Model Class Initialized
DEBUG - 2017-06-30 07:22:10 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:22:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:22:10 --> Final output sent to browser
DEBUG - 2017-06-30 07:22:10 --> Total execution time: 0.0333
DEBUG - 2017-06-30 07:23:04 --> Config Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:23:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:23:04 --> URI Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Router Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Output Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Security Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Input Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:23:04 --> Language Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Loader Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:23:04 --> Controller Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:23:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:23:04 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:04 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:23:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:23:04 --> Final output sent to browser
DEBUG - 2017-06-30 07:23:04 --> Total execution time: 0.0331
DEBUG - 2017-06-30 07:23:06 --> Config Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:23:06 --> URI Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Router Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Output Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Security Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Input Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:23:06 --> Language Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Loader Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:23:06 --> Controller Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:23:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:23:06 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:06 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:23:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:23:06 --> Final output sent to browser
DEBUG - 2017-06-30 07:23:06 --> Total execution time: 0.0333
DEBUG - 2017-06-30 07:23:25 --> Config Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:23:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:23:25 --> URI Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Router Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Output Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Security Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Input Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:23:25 --> Language Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Loader Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:23:25 --> Controller Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:23:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:23:25 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:25 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:23:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:23:25 --> Final output sent to browser
DEBUG - 2017-06-30 07:23:25 --> Total execution time: 0.0330
DEBUG - 2017-06-30 07:23:44 --> Config Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:23:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:23:44 --> URI Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Router Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Output Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Security Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Input Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:23:44 --> Language Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Loader Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:23:44 --> Controller Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:23:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:23:44 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:44 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:23:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:23:44 --> Final output sent to browser
DEBUG - 2017-06-30 07:23:44 --> Total execution time: 0.0326
DEBUG - 2017-06-30 07:23:52 --> Config Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:23:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:23:52 --> URI Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Router Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Output Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Security Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Input Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:23:52 --> Language Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Loader Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:23:52 --> Controller Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:23:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:23:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:52 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:23:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:23:53 --> Final output sent to browser
DEBUG - 2017-06-30 07:23:53 --> Total execution time: 0.0336
DEBUG - 2017-06-30 07:23:58 --> Config Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:23:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:23:58 --> URI Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Router Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Output Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Security Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Input Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:23:58 --> Language Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Loader Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:23:58 --> Controller Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:23:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:23:58 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Model Class Initialized
DEBUG - 2017-06-30 07:23:58 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:23:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:23:58 --> Final output sent to browser
DEBUG - 2017-06-30 07:23:58 --> Total execution time: 0.0325
DEBUG - 2017-06-30 07:24:06 --> Config Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:24:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:24:06 --> URI Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Router Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Output Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Security Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Input Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:24:06 --> Language Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Loader Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:24:06 --> Controller Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:24:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:24:06 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:06 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:24:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:24:06 --> Final output sent to browser
DEBUG - 2017-06-30 07:24:06 --> Total execution time: 0.0337
DEBUG - 2017-06-30 07:24:16 --> Config Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:24:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:24:16 --> URI Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Router Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Output Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Security Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Input Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:24:16 --> Language Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Loader Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:24:16 --> Controller Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:24:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:24:16 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:16 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:24:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:24:16 --> Final output sent to browser
DEBUG - 2017-06-30 07:24:16 --> Total execution time: 0.0332
DEBUG - 2017-06-30 07:24:24 --> Config Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:24:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:24:24 --> URI Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Router Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Output Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Security Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Input Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:24:24 --> Language Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Loader Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:24:24 --> Controller Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:24:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:24:24 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:24 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:24:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:24:24 --> Final output sent to browser
DEBUG - 2017-06-30 07:24:24 --> Total execution time: 0.0327
DEBUG - 2017-06-30 07:24:31 --> Config Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:24:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:24:31 --> URI Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Router Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Output Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Security Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Input Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:24:31 --> Language Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Loader Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:24:31 --> Controller Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:24:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:24:31 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:31 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:24:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:24:31 --> Final output sent to browser
DEBUG - 2017-06-30 07:24:31 --> Total execution time: 0.0331
DEBUG - 2017-06-30 07:24:38 --> Config Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:24:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:24:38 --> URI Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Router Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Output Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Security Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Input Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:24:38 --> Language Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Loader Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:24:38 --> Controller Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:24:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:24:38 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:38 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:24:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:24:38 --> Final output sent to browser
DEBUG - 2017-06-30 07:24:38 --> Total execution time: 0.0328
DEBUG - 2017-06-30 07:24:44 --> Config Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:24:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:24:44 --> URI Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Router Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Output Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Security Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Input Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:24:44 --> Language Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Loader Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:24:44 --> Controller Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:24:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:24:44 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:44 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:24:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:24:44 --> Final output sent to browser
DEBUG - 2017-06-30 07:24:44 --> Total execution time: 0.0326
DEBUG - 2017-06-30 07:24:54 --> Config Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:24:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:24:54 --> URI Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Router Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Output Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Security Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Input Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:24:54 --> Language Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Loader Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:24:54 --> Controller Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:24:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:24:54 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Model Class Initialized
DEBUG - 2017-06-30 07:24:54 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:24:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:24:54 --> Final output sent to browser
DEBUG - 2017-06-30 07:24:54 --> Total execution time: 0.0330
DEBUG - 2017-06-30 07:25:09 --> Config Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:25:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:25:09 --> URI Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Router Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Output Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Security Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Input Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:25:09 --> Language Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Loader Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:25:09 --> Controller Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:25:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:25:09 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:09 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:25:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:25:09 --> Final output sent to browser
DEBUG - 2017-06-30 07:25:09 --> Total execution time: 0.0330
DEBUG - 2017-06-30 07:25:21 --> Config Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:25:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:25:21 --> URI Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Router Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Output Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Security Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Input Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:25:21 --> Language Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Loader Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:25:21 --> Controller Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:25:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:25:21 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:21 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:25:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:25:21 --> Final output sent to browser
DEBUG - 2017-06-30 07:25:21 --> Total execution time: 0.0330
DEBUG - 2017-06-30 07:25:26 --> Config Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:25:26 --> URI Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Router Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Output Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Security Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Input Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:25:26 --> Language Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Loader Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:25:26 --> Controller Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:25:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:25:26 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:26 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:25:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:25:26 --> Final output sent to browser
DEBUG - 2017-06-30 07:25:26 --> Total execution time: 0.0330
DEBUG - 2017-06-30 07:25:37 --> Config Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:25:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:25:37 --> URI Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Router Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Output Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Security Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Input Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:25:37 --> Language Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Loader Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:25:37 --> Controller Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:25:37 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Model Class Initialized
DEBUG - 2017-06-30 07:25:37 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:25:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:25:37 --> Final output sent to browser
DEBUG - 2017-06-30 07:25:37 --> Total execution time: 0.0347
DEBUG - 2017-06-30 07:28:50 --> Config Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:28:50 --> URI Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Router Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Output Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Security Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Input Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:28:50 --> Language Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Loader Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:28:50 --> Controller Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:28:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:28:50 --> Model Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Model Class Initialized
DEBUG - 2017-06-30 07:28:50 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:28:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:28:50 --> Final output sent to browser
DEBUG - 2017-06-30 07:28:50 --> Total execution time: 0.0339
DEBUG - 2017-06-30 07:28:51 --> Config Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:28:51 --> URI Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Router Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Output Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Security Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Input Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:28:51 --> Language Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Loader Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:28:51 --> Controller Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:28:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:28:51 --> Model Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Model Class Initialized
DEBUG - 2017-06-30 07:28:51 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:28:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:28:51 --> Final output sent to browser
DEBUG - 2017-06-30 07:28:51 --> Total execution time: 0.0336
DEBUG - 2017-06-30 07:29:32 --> Config Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:29:32 --> URI Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Router Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Output Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Security Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Input Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:29:32 --> Language Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Loader Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:29:32 --> Controller Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:29:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:29:32 --> Model Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Model Class Initialized
DEBUG - 2017-06-30 07:29:32 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:29:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:29:32 --> Final output sent to browser
DEBUG - 2017-06-30 07:29:32 --> Total execution time: 0.0328
DEBUG - 2017-06-30 07:29:34 --> Config Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Hooks Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Utf8 Class Initialized
DEBUG - 2017-06-30 07:29:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 07:29:34 --> URI Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Router Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Output Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Security Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Input Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 07:29:34 --> Language Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Loader Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Helper loaded: date_helper
DEBUG - 2017-06-30 07:29:34 --> Controller Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Database Driver Class Initialized
ERROR - 2017-06-30 07:29:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 07:29:34 --> Model Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Model Class Initialized
DEBUG - 2017-06-30 07:29:34 --> Helper loaded: url_helper
DEBUG - 2017-06-30 07:29:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 07:29:34 --> Final output sent to browser
DEBUG - 2017-06-30 07:29:34 --> Total execution time: 0.0335
DEBUG - 2017-06-30 08:34:05 --> Config Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Hooks Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Utf8 Class Initialized
DEBUG - 2017-06-30 08:34:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 08:34:05 --> URI Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Router Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Output Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Security Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Input Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 08:34:05 --> Language Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Loader Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Helper loaded: date_helper
DEBUG - 2017-06-30 08:34:05 --> Controller Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Database Driver Class Initialized
ERROR - 2017-06-30 08:34:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 08:34:05 --> Model Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Model Class Initialized
DEBUG - 2017-06-30 08:34:05 --> Helper loaded: url_helper
DEBUG - 2017-06-30 08:34:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 08:34:05 --> Final output sent to browser
DEBUG - 2017-06-30 08:34:05 --> Total execution time: 0.0348
DEBUG - 2017-06-30 08:34:43 --> Config Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Hooks Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Utf8 Class Initialized
DEBUG - 2017-06-30 08:34:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 08:34:43 --> URI Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Router Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Output Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Security Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Input Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 08:34:43 --> Language Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Loader Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Helper loaded: date_helper
DEBUG - 2017-06-30 08:34:43 --> Controller Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Database Driver Class Initialized
ERROR - 2017-06-30 08:34:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 08:34:43 --> Model Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Model Class Initialized
DEBUG - 2017-06-30 08:34:43 --> Helper loaded: url_helper
DEBUG - 2017-06-30 08:34:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 08:34:43 --> Final output sent to browser
DEBUG - 2017-06-30 08:34:43 --> Total execution time: 0.0347
DEBUG - 2017-06-30 08:35:12 --> Config Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Hooks Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Utf8 Class Initialized
DEBUG - 2017-06-30 08:35:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 08:35:12 --> URI Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Router Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Output Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Security Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Input Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 08:35:12 --> Language Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Loader Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Helper loaded: date_helper
DEBUG - 2017-06-30 08:35:12 --> Controller Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Database Driver Class Initialized
ERROR - 2017-06-30 08:35:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 08:35:12 --> Model Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Model Class Initialized
DEBUG - 2017-06-30 08:35:12 --> Helper loaded: url_helper
DEBUG - 2017-06-30 08:35:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 08:35:12 --> Final output sent to browser
DEBUG - 2017-06-30 08:35:12 --> Total execution time: 0.0346
DEBUG - 2017-06-30 08:36:58 --> Config Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Hooks Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Utf8 Class Initialized
DEBUG - 2017-06-30 08:36:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 08:36:58 --> URI Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Router Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Output Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Security Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Input Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 08:36:58 --> Language Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Loader Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Helper loaded: date_helper
DEBUG - 2017-06-30 08:36:58 --> Controller Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Database Driver Class Initialized
ERROR - 2017-06-30 08:36:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 08:36:58 --> Model Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Model Class Initialized
DEBUG - 2017-06-30 08:36:58 --> Helper loaded: url_helper
DEBUG - 2017-06-30 08:36:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 08:36:58 --> Final output sent to browser
DEBUG - 2017-06-30 08:36:58 --> Total execution time: 0.0344
DEBUG - 2017-06-30 09:03:57 --> Config Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Hooks Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Utf8 Class Initialized
DEBUG - 2017-06-30 09:03:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 09:03:57 --> URI Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Router Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Output Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Security Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Input Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 09:03:57 --> Language Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Loader Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Helper loaded: date_helper
DEBUG - 2017-06-30 09:03:57 --> Controller Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Database Driver Class Initialized
ERROR - 2017-06-30 09:03:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 09:03:57 --> Model Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Model Class Initialized
DEBUG - 2017-06-30 09:03:57 --> Helper loaded: url_helper
DEBUG - 2017-06-30 09:03:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 09:03:57 --> Final output sent to browser
DEBUG - 2017-06-30 09:03:57 --> Total execution time: 0.0344
DEBUG - 2017-06-30 12:09:01 --> Config Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Hooks Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Utf8 Class Initialized
DEBUG - 2017-06-30 12:09:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 12:09:01 --> URI Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Router Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Output Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Security Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Input Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 12:09:01 --> Language Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Loader Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Helper loaded: date_helper
DEBUG - 2017-06-30 12:09:01 --> Controller Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Database Driver Class Initialized
ERROR - 2017-06-30 12:09:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 12:09:01 --> Model Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Model Class Initialized
DEBUG - 2017-06-30 12:09:01 --> Helper loaded: url_helper
DEBUG - 2017-06-30 12:09:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 12:09:01 --> Final output sent to browser
DEBUG - 2017-06-30 12:09:01 --> Total execution time: 0.0393
DEBUG - 2017-06-30 12:09:42 --> Config Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Hooks Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Utf8 Class Initialized
DEBUG - 2017-06-30 12:09:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 12:09:42 --> URI Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Router Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Output Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Security Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Input Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 12:09:42 --> Language Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Loader Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Helper loaded: date_helper
DEBUG - 2017-06-30 12:09:42 --> Controller Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Database Driver Class Initialized
ERROR - 2017-06-30 12:09:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 12:09:42 --> Model Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Model Class Initialized
DEBUG - 2017-06-30 12:09:42 --> Helper loaded: url_helper
DEBUG - 2017-06-30 12:09:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 12:09:42 --> Final output sent to browser
DEBUG - 2017-06-30 12:09:42 --> Total execution time: 0.0358
DEBUG - 2017-06-30 13:39:50 --> Config Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Hooks Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Utf8 Class Initialized
DEBUG - 2017-06-30 13:39:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 13:39:50 --> URI Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Router Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Output Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Security Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Input Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 13:39:50 --> Language Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Loader Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Helper loaded: date_helper
DEBUG - 2017-06-30 13:39:50 --> Controller Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Database Driver Class Initialized
ERROR - 2017-06-30 13:39:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 13:39:50 --> Model Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Model Class Initialized
DEBUG - 2017-06-30 13:39:50 --> Helper loaded: url_helper
DEBUG - 2017-06-30 13:39:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 13:39:50 --> Final output sent to browser
DEBUG - 2017-06-30 13:39:50 --> Total execution time: 0.0357
DEBUG - 2017-06-30 13:39:54 --> Config Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Hooks Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Utf8 Class Initialized
DEBUG - 2017-06-30 13:39:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 13:39:54 --> URI Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Router Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Output Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Security Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Input Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 13:39:54 --> Language Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Loader Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Helper loaded: date_helper
DEBUG - 2017-06-30 13:39:54 --> Controller Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Database Driver Class Initialized
ERROR - 2017-06-30 13:39:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 13:39:54 --> Model Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Model Class Initialized
DEBUG - 2017-06-30 13:39:54 --> Helper loaded: url_helper
DEBUG - 2017-06-30 13:39:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 13:39:54 --> Final output sent to browser
DEBUG - 2017-06-30 13:39:54 --> Total execution time: 0.0347
DEBUG - 2017-06-30 13:40:01 --> Config Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Hooks Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Utf8 Class Initialized
DEBUG - 2017-06-30 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 13:40:01 --> URI Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Router Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Output Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Security Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Input Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 13:40:01 --> Language Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Loader Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Helper loaded: date_helper
DEBUG - 2017-06-30 13:40:01 --> Controller Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Database Driver Class Initialized
ERROR - 2017-06-30 13:40:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 13:40:01 --> Model Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Model Class Initialized
DEBUG - 2017-06-30 13:40:01 --> Helper loaded: url_helper
DEBUG - 2017-06-30 13:40:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 13:40:01 --> Final output sent to browser
DEBUG - 2017-06-30 13:40:01 --> Total execution time: 0.1103
DEBUG - 2017-06-30 13:42:07 --> Config Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Hooks Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Utf8 Class Initialized
DEBUG - 2017-06-30 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 13:42:07 --> URI Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Router Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Output Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Security Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Input Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 13:42:07 --> Language Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Loader Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Helper loaded: date_helper
DEBUG - 2017-06-30 13:42:07 --> Controller Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Database Driver Class Initialized
ERROR - 2017-06-30 13:42:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 13:42:07 --> Model Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Model Class Initialized
DEBUG - 2017-06-30 13:42:07 --> Helper loaded: url_helper
DEBUG - 2017-06-30 13:42:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 13:42:07 --> Final output sent to browser
DEBUG - 2017-06-30 13:42:07 --> Total execution time: 0.0360
DEBUG - 2017-06-30 13:42:11 --> Config Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Hooks Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Utf8 Class Initialized
DEBUG - 2017-06-30 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 13:42:11 --> URI Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Router Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Output Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Security Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Input Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 13:42:11 --> Language Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Loader Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Helper loaded: date_helper
DEBUG - 2017-06-30 13:42:11 --> Controller Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Database Driver Class Initialized
ERROR - 2017-06-30 13:42:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 13:42:11 --> Model Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Model Class Initialized
DEBUG - 2017-06-30 13:42:11 --> Helper loaded: url_helper
DEBUG - 2017-06-30 13:42:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 13:42:11 --> Final output sent to browser
DEBUG - 2017-06-30 13:42:11 --> Total execution time: 0.0355
DEBUG - 2017-06-30 13:43:07 --> Config Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Hooks Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Utf8 Class Initialized
DEBUG - 2017-06-30 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 13:43:07 --> URI Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Router Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Output Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Security Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Input Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 13:43:07 --> Language Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Loader Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Helper loaded: date_helper
DEBUG - 2017-06-30 13:43:07 --> Controller Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Database Driver Class Initialized
ERROR - 2017-06-30 13:43:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 13:43:07 --> Model Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Model Class Initialized
DEBUG - 2017-06-30 13:43:07 --> Helper loaded: url_helper
DEBUG - 2017-06-30 13:43:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-06-30 13:43:07 --> Final output sent to browser
DEBUG - 2017-06-30 13:43:07 --> Total execution time: 0.0351
DEBUG - 2017-06-30 23:41:38 --> Config Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Hooks Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Utf8 Class Initialized
DEBUG - 2017-06-30 23:41:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 23:41:38 --> URI Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Router Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Output Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Security Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Input Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-06-30 23:41:38 --> Language Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Loader Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Helper loaded: date_helper
DEBUG - 2017-06-30 23:41:38 --> Controller Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Database Driver Class Initialized
ERROR - 2017-06-30 23:41:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-06-30 23:41:38 --> Model Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Model Class Initialized
DEBUG - 2017-06-30 23:41:38 --> Helper loaded: url_helper
DEBUG - 2017-06-30 23:41:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-06-30 23:41:38 --> Final output sent to browser
DEBUG - 2017-06-30 23:41:38 --> Total execution time: 0.0243
