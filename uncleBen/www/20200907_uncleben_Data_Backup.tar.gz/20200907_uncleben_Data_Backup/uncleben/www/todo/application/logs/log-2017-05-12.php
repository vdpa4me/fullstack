<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-12 05:29:25 --> Config Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Hooks Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Utf8 Class Initialized
DEBUG - 2017-05-12 05:29:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 05:29:25 --> URI Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Router Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Output Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Security Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Input Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-12 05:29:25 --> Language Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Loader Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Helper loaded: date_helper
DEBUG - 2017-05-12 05:29:25 --> Controller Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Database Driver Class Initialized
ERROR - 2017-05-12 05:29:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-12 05:29:25 --> Model Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Model Class Initialized
DEBUG - 2017-05-12 05:29:25 --> Helper loaded: url_helper
DEBUG - 2017-05-12 05:29:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-05-12 05:29:25 --> Final output sent to browser
DEBUG - 2017-05-12 05:29:25 --> Total execution time: 0.0424
DEBUG - 2017-05-12 06:04:47 --> Config Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Hooks Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Utf8 Class Initialized
DEBUG - 2017-05-12 06:04:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 06:04:47 --> URI Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Router Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Output Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Security Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Input Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-12 06:04:47 --> Language Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Loader Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Helper loaded: date_helper
DEBUG - 2017-05-12 06:04:47 --> Controller Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Database Driver Class Initialized
ERROR - 2017-05-12 06:04:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-12 06:04:47 --> Model Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Model Class Initialized
DEBUG - 2017-05-12 06:04:47 --> Helper loaded: url_helper
DEBUG - 2017-05-12 06:04:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-12 06:04:47 --> Final output sent to browser
DEBUG - 2017-05-12 06:04:47 --> Total execution time: 0.0444
DEBUG - 2017-05-12 10:19:09 --> Config Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Utf8 Class Initialized
DEBUG - 2017-05-12 10:19:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 10:19:09 --> URI Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Router Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Output Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Security Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Input Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-12 10:19:09 --> Language Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Loader Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Helper loaded: date_helper
DEBUG - 2017-05-12 10:19:09 --> Controller Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Database Driver Class Initialized
ERROR - 2017-05-12 10:19:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-12 10:19:09 --> Model Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Model Class Initialized
DEBUG - 2017-05-12 10:19:09 --> Helper loaded: url_helper
DEBUG - 2017-05-12 10:19:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-12 10:19:09 --> Final output sent to browser
DEBUG - 2017-05-12 10:19:09 --> Total execution time: 0.0358
DEBUG - 2017-05-12 10:19:15 --> Config Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Utf8 Class Initialized
DEBUG - 2017-05-12 10:19:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 10:19:15 --> URI Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Router Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Output Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Security Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Input Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-12 10:19:15 --> Language Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Loader Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Helper loaded: date_helper
DEBUG - 2017-05-12 10:19:15 --> Controller Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Database Driver Class Initialized
ERROR - 2017-05-12 10:19:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-12 10:19:15 --> Model Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Model Class Initialized
DEBUG - 2017-05-12 10:19:15 --> Helper loaded: url_helper
DEBUG - 2017-05-12 10:19:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-12 10:19:15 --> Final output sent to browser
DEBUG - 2017-05-12 10:19:15 --> Total execution time: 0.0336
DEBUG - 2017-05-12 10:19:29 --> Config Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Hooks Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Utf8 Class Initialized
DEBUG - 2017-05-12 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-12 10:19:29 --> URI Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Router Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Output Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Security Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Input Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-12 10:19:29 --> Language Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Loader Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Helper loaded: date_helper
DEBUG - 2017-05-12 10:19:29 --> Controller Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Database Driver Class Initialized
ERROR - 2017-05-12 10:19:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-12 10:19:29 --> Model Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Model Class Initialized
DEBUG - 2017-05-12 10:19:29 --> Helper loaded: url_helper
DEBUG - 2017-05-12 10:19:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-12 10:19:29 --> Final output sent to browser
DEBUG - 2017-05-12 10:19:29 --> Total execution time: 0.0308
