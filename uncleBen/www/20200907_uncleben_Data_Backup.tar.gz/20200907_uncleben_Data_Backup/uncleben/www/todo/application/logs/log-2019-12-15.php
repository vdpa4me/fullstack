<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-12-15 01:24:21 --> Config Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Hooks Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Utf8 Class Initialized
DEBUG - 2019-12-15 01:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-12-15 01:24:21 --> URI Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Router Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Output Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Security Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Input Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-15 01:24:21 --> Language Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Loader Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Helper loaded: date_helper
DEBUG - 2019-12-15 01:24:21 --> Controller Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Database Driver Class Initialized
ERROR - 2019-12-15 01:24:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-15 01:24:21 --> Model Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Model Class Initialized
DEBUG - 2019-12-15 01:24:21 --> Helper loaded: url_helper
DEBUG - 2019-12-15 01:24:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-15 01:24:21 --> Final output sent to browser
DEBUG - 2019-12-15 01:24:21 --> Total execution time: 0.1840
DEBUG - 2019-12-15 05:54:51 --> Config Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Hooks Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Utf8 Class Initialized
DEBUG - 2019-12-15 05:54:51 --> UTF-8 Support Enabled
DEBUG - 2019-12-15 05:54:51 --> URI Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Router Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Output Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Security Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Input Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-15 05:54:51 --> Language Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Loader Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Helper loaded: date_helper
DEBUG - 2019-12-15 05:54:51 --> Controller Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Database Driver Class Initialized
ERROR - 2019-12-15 05:54:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-15 05:54:51 --> Model Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Model Class Initialized
DEBUG - 2019-12-15 05:54:51 --> Helper loaded: url_helper
DEBUG - 2019-12-15 05:54:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-15 05:54:51 --> Final output sent to browser
DEBUG - 2019-12-15 05:54:51 --> Total execution time: 0.1932
DEBUG - 2019-12-15 15:26:09 --> Config Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Hooks Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Utf8 Class Initialized
DEBUG - 2019-12-15 15:26:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-15 15:26:09 --> URI Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Router Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Output Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Security Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Input Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-15 15:26:09 --> Language Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Loader Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Helper loaded: date_helper
DEBUG - 2019-12-15 15:26:09 --> Controller Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Database Driver Class Initialized
ERROR - 2019-12-15 15:26:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-15 15:26:09 --> Model Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Model Class Initialized
DEBUG - 2019-12-15 15:26:09 --> Helper loaded: url_helper
DEBUG - 2019-12-15 15:26:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-15 15:26:09 --> Final output sent to browser
DEBUG - 2019-12-15 15:26:09 --> Total execution time: 0.1557
DEBUG - 2019-12-15 23:36:07 --> Config Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Hooks Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Utf8 Class Initialized
DEBUG - 2019-12-15 23:36:07 --> UTF-8 Support Enabled
DEBUG - 2019-12-15 23:36:07 --> URI Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Router Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Output Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Security Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Input Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-15 23:36:07 --> Language Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Loader Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Helper loaded: date_helper
DEBUG - 2019-12-15 23:36:07 --> Controller Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Database Driver Class Initialized
ERROR - 2019-12-15 23:36:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-15 23:36:07 --> Model Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Model Class Initialized
DEBUG - 2019-12-15 23:36:07 --> Helper loaded: url_helper
DEBUG - 2019-12-15 23:36:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-15 23:36:07 --> Final output sent to browser
DEBUG - 2019-12-15 23:36:07 --> Total execution time: 0.1362
