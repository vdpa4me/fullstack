<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-11-21 03:49:47 --> Config Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Hooks Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Utf8 Class Initialized
DEBUG - 2019-11-21 03:49:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 03:49:47 --> URI Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Router Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Output Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Security Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Input Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-21 03:49:47 --> Language Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Loader Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Helper loaded: date_helper
DEBUG - 2019-11-21 03:49:47 --> Controller Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Database Driver Class Initialized
ERROR - 2019-11-21 03:49:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-21 03:49:47 --> Model Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Model Class Initialized
DEBUG - 2019-11-21 03:49:47 --> Helper loaded: url_helper
DEBUG - 2019-11-21 03:49:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-21 03:49:47 --> Final output sent to browser
DEBUG - 2019-11-21 03:49:47 --> Total execution time: 0.2077
DEBUG - 2019-11-21 07:08:16 --> Config Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Hooks Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Utf8 Class Initialized
DEBUG - 2019-11-21 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 07:08:16 --> URI Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Router Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Output Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Security Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Input Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-21 07:08:16 --> Language Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Loader Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Helper loaded: date_helper
DEBUG - 2019-11-21 07:08:16 --> Controller Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Database Driver Class Initialized
ERROR - 2019-11-21 07:08:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-21 07:08:16 --> Model Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Model Class Initialized
DEBUG - 2019-11-21 07:08:16 --> Helper loaded: url_helper
DEBUG - 2019-11-21 07:08:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-21 07:08:16 --> Final output sent to browser
DEBUG - 2019-11-21 07:08:16 --> Total execution time: 0.1803
DEBUG - 2019-11-21 22:02:25 --> Config Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Hooks Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Utf8 Class Initialized
DEBUG - 2019-11-21 22:02:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 22:02:25 --> URI Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Router Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Output Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Security Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Input Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-21 22:02:25 --> Language Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Loader Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Helper loaded: date_helper
DEBUG - 2019-11-21 22:02:25 --> Controller Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Database Driver Class Initialized
ERROR - 2019-11-21 22:02:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-21 22:02:25 --> Model Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Model Class Initialized
DEBUG - 2019-11-21 22:02:25 --> Helper loaded: url_helper
DEBUG - 2019-11-21 22:02:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-21 22:02:25 --> Final output sent to browser
DEBUG - 2019-11-21 22:02:25 --> Total execution time: 0.2403
