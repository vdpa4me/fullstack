<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-01-17 08:44:38 --> Config Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Hooks Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Utf8 Class Initialized
DEBUG - 2018-01-17 08:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-01-17 08:44:38 --> URI Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Router Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Output Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Security Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Input Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-17 08:44:38 --> Language Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Loader Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Helper loaded: date_helper
DEBUG - 2018-01-17 08:44:38 --> Controller Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Database Driver Class Initialized
ERROR - 2018-01-17 08:44:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-17 08:44:38 --> Model Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Model Class Initialized
DEBUG - 2018-01-17 08:44:38 --> Helper loaded: url_helper
DEBUG - 2018-01-17 08:44:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-17 08:44:38 --> Final output sent to browser
DEBUG - 2018-01-17 08:44:38 --> Total execution time: 0.0458
