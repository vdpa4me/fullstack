<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-03-30 00:42:47 --> Config Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Hooks Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Utf8 Class Initialized
DEBUG - 2017-03-30 00:42:47 --> UTF-8 Support Enabled
DEBUG - 2017-03-30 00:42:47 --> URI Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Router Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Output Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Security Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Input Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-30 00:42:47 --> Language Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Loader Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Helper loaded: date_helper
DEBUG - 2017-03-30 00:42:47 --> Controller Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Database Driver Class Initialized
ERROR - 2017-03-30 00:42:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-30 00:42:47 --> Model Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Model Class Initialized
DEBUG - 2017-03-30 00:42:47 --> Helper loaded: url_helper
DEBUG - 2017-03-30 00:42:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-30 00:42:47 --> Final output sent to browser
DEBUG - 2017-03-30 00:42:47 --> Total execution time: 0.0280
DEBUG - 2017-03-30 06:54:04 --> Config Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Hooks Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Utf8 Class Initialized
DEBUG - 2017-03-30 06:54:04 --> UTF-8 Support Enabled
DEBUG - 2017-03-30 06:54:04 --> URI Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Router Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Output Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Security Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Input Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-30 06:54:04 --> Language Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Loader Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Helper loaded: date_helper
DEBUG - 2017-03-30 06:54:04 --> Controller Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Database Driver Class Initialized
ERROR - 2017-03-30 06:54:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-30 06:54:04 --> Model Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Model Class Initialized
DEBUG - 2017-03-30 06:54:04 --> Helper loaded: url_helper
DEBUG - 2017-03-30 06:54:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-03-30 06:54:04 --> Final output sent to browser
DEBUG - 2017-03-30 06:54:04 --> Total execution time: 0.0433
DEBUG - 2017-03-30 06:54:29 --> Config Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Hooks Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Utf8 Class Initialized
DEBUG - 2017-03-30 06:54:29 --> UTF-8 Support Enabled
DEBUG - 2017-03-30 06:54:29 --> URI Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Router Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Output Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Security Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Input Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-30 06:54:29 --> Language Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Loader Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Helper loaded: date_helper
DEBUG - 2017-03-30 06:54:29 --> Controller Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Database Driver Class Initialized
ERROR - 2017-03-30 06:54:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-30 06:54:29 --> Model Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Model Class Initialized
DEBUG - 2017-03-30 06:54:29 --> Helper loaded: url_helper
DEBUG - 2017-03-30 06:54:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-03-30 06:54:29 --> Final output sent to browser
DEBUG - 2017-03-30 06:54:29 --> Total execution time: 0.0303
DEBUG - 2017-03-30 06:55:21 --> Config Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Hooks Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Utf8 Class Initialized
DEBUG - 2017-03-30 06:55:21 --> UTF-8 Support Enabled
DEBUG - 2017-03-30 06:55:21 --> URI Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Router Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Output Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Security Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Input Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-30 06:55:21 --> Language Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Loader Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Helper loaded: date_helper
DEBUG - 2017-03-30 06:55:21 --> Controller Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Database Driver Class Initialized
ERROR - 2017-03-30 06:55:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-30 06:55:21 --> Model Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Model Class Initialized
DEBUG - 2017-03-30 06:55:21 --> Helper loaded: url_helper
DEBUG - 2017-03-30 06:55:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-03-30 06:55:21 --> Final output sent to browser
DEBUG - 2017-03-30 06:55:21 --> Total execution time: 0.0302
DEBUG - 2017-03-30 06:55:34 --> Config Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Hooks Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Utf8 Class Initialized
DEBUG - 2017-03-30 06:55:34 --> UTF-8 Support Enabled
DEBUG - 2017-03-30 06:55:34 --> URI Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Router Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Output Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Security Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Input Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-30 06:55:34 --> Language Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Loader Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Helper loaded: date_helper
DEBUG - 2017-03-30 06:55:34 --> Controller Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Database Driver Class Initialized
ERROR - 2017-03-30 06:55:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-30 06:55:34 --> Model Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Model Class Initialized
DEBUG - 2017-03-30 06:55:34 --> Helper loaded: url_helper
DEBUG - 2017-03-30 06:55:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-03-30 06:55:34 --> Final output sent to browser
DEBUG - 2017-03-30 06:55:34 --> Total execution time: 0.0292
DEBUG - 2017-03-30 19:29:51 --> Config Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Hooks Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Utf8 Class Initialized
DEBUG - 2017-03-30 19:29:51 --> UTF-8 Support Enabled
DEBUG - 2017-03-30 19:29:51 --> URI Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Router Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Output Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Security Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Input Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-30 19:29:51 --> Language Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Loader Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Helper loaded: date_helper
DEBUG - 2017-03-30 19:29:51 --> Controller Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Database Driver Class Initialized
ERROR - 2017-03-30 19:29:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-30 19:29:51 --> Model Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Model Class Initialized
DEBUG - 2017-03-30 19:29:51 --> Helper loaded: url_helper
DEBUG - 2017-03-30 19:29:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-30 19:29:51 --> Final output sent to browser
DEBUG - 2017-03-30 19:29:51 --> Total execution time: 0.0293
