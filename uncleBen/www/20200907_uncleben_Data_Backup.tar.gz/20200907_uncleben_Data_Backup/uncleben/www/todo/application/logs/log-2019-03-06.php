<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-03-06 18:41:54 --> Config Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Hooks Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Utf8 Class Initialized
DEBUG - 2019-03-06 18:41:54 --> UTF-8 Support Enabled
DEBUG - 2019-03-06 18:41:54 --> URI Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Router Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Output Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Security Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Input Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-06 18:41:54 --> Language Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Loader Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Helper loaded: date_helper
DEBUG - 2019-03-06 18:41:54 --> Controller Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Database Driver Class Initialized
ERROR - 2019-03-06 18:41:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-06 18:41:54 --> Model Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Model Class Initialized
DEBUG - 2019-03-06 18:41:54 --> Helper loaded: url_helper
DEBUG - 2019-03-06 18:41:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-06 18:41:54 --> Final output sent to browser
DEBUG - 2019-03-06 18:41:54 --> Total execution time: 0.0495
