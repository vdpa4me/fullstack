<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-01-19 07:02:22 --> Config Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Hooks Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Utf8 Class Initialized
DEBUG - 2018-01-19 07:02:22 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 07:02:22 --> URI Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Router Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Output Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Security Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Input Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 07:02:22 --> Language Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Loader Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Helper loaded: date_helper
DEBUG - 2018-01-19 07:02:22 --> Controller Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Database Driver Class Initialized
ERROR - 2018-01-19 07:02:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 07:02:22 --> Model Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Model Class Initialized
DEBUG - 2018-01-19 07:02:22 --> Helper loaded: url_helper
DEBUG - 2018-01-19 07:02:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-19 07:02:22 --> Final output sent to browser
DEBUG - 2018-01-19 07:02:22 --> Total execution time: 0.0469
DEBUG - 2018-01-19 14:57:02 --> Config Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Utf8 Class Initialized
DEBUG - 2018-01-19 14:57:02 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 14:57:02 --> URI Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Router Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Output Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Security Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Input Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 14:57:02 --> Language Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Loader Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Helper loaded: date_helper
DEBUG - 2018-01-19 14:57:02 --> Controller Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Database Driver Class Initialized
ERROR - 2018-01-19 14:57:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 14:57:02 --> Model Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Model Class Initialized
DEBUG - 2018-01-19 14:57:02 --> Helper loaded: url_helper
DEBUG - 2018-01-19 14:57:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 14:57:02 --> Final output sent to browser
DEBUG - 2018-01-19 14:57:02 --> Total execution time: 0.0703
DEBUG - 2018-01-19 14:57:09 --> Config Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Utf8 Class Initialized
DEBUG - 2018-01-19 14:57:09 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 14:57:09 --> URI Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Router Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Output Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Security Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Input Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 14:57:09 --> Language Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Loader Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Helper loaded: date_helper
DEBUG - 2018-01-19 14:57:09 --> Controller Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Database Driver Class Initialized
ERROR - 2018-01-19 14:57:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 14:57:09 --> Model Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Model Class Initialized
DEBUG - 2018-01-19 14:57:09 --> Helper loaded: url_helper
DEBUG - 2018-01-19 14:57:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 14:57:09 --> Final output sent to browser
DEBUG - 2018-01-19 14:57:09 --> Total execution time: 0.0476
DEBUG - 2018-01-19 14:58:07 --> Config Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Hooks Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Utf8 Class Initialized
DEBUG - 2018-01-19 14:58:07 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 14:58:07 --> URI Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Router Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Output Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Security Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Input Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 14:58:07 --> Language Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Loader Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Helper loaded: date_helper
DEBUG - 2018-01-19 14:58:07 --> Controller Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Database Driver Class Initialized
ERROR - 2018-01-19 14:58:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 14:58:07 --> Model Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Model Class Initialized
DEBUG - 2018-01-19 14:58:07 --> Helper loaded: url_helper
DEBUG - 2018-01-19 14:58:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 14:58:07 --> Final output sent to browser
DEBUG - 2018-01-19 14:58:07 --> Total execution time: 0.0456
DEBUG - 2018-01-19 15:00:01 --> Config Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Utf8 Class Initialized
DEBUG - 2018-01-19 15:00:01 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 15:00:01 --> URI Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Router Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Output Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Security Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Input Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 15:00:01 --> Language Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Loader Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Helper loaded: date_helper
DEBUG - 2018-01-19 15:00:01 --> Controller Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Database Driver Class Initialized
ERROR - 2018-01-19 15:00:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 15:00:01 --> Model Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Model Class Initialized
DEBUG - 2018-01-19 15:00:01 --> Helper loaded: url_helper
DEBUG - 2018-01-19 15:00:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 15:00:01 --> Final output sent to browser
DEBUG - 2018-01-19 15:00:01 --> Total execution time: 0.1772
DEBUG - 2018-01-19 15:00:03 --> Config Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Utf8 Class Initialized
DEBUG - 2018-01-19 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 15:00:03 --> URI Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Router Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Output Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Security Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Input Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 15:00:03 --> Language Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Loader Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Helper loaded: date_helper
DEBUG - 2018-01-19 15:00:03 --> Controller Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Database Driver Class Initialized
ERROR - 2018-01-19 15:00:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 15:00:03 --> Model Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Model Class Initialized
DEBUG - 2018-01-19 15:00:03 --> Helper loaded: url_helper
DEBUG - 2018-01-19 15:00:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 15:00:03 --> Final output sent to browser
DEBUG - 2018-01-19 15:00:03 --> Total execution time: 0.0600
DEBUG - 2018-01-19 15:00:10 --> Config Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Utf8 Class Initialized
DEBUG - 2018-01-19 15:00:10 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 15:00:10 --> URI Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Router Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Output Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Security Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Input Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 15:00:10 --> Language Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Loader Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Helper loaded: date_helper
DEBUG - 2018-01-19 15:00:10 --> Controller Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Database Driver Class Initialized
ERROR - 2018-01-19 15:00:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 15:00:10 --> Model Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Model Class Initialized
DEBUG - 2018-01-19 15:00:10 --> Helper loaded: url_helper
DEBUG - 2018-01-19 15:00:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 15:00:10 --> Final output sent to browser
DEBUG - 2018-01-19 15:00:10 --> Total execution time: 0.0534
DEBUG - 2018-01-19 15:10:23 --> Config Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Utf8 Class Initialized
DEBUG - 2018-01-19 15:10:23 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 15:10:23 --> URI Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Router Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Output Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Security Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Input Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 15:10:23 --> Language Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Loader Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Helper loaded: date_helper
DEBUG - 2018-01-19 15:10:23 --> Controller Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Database Driver Class Initialized
ERROR - 2018-01-19 15:10:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 15:10:23 --> Model Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Model Class Initialized
DEBUG - 2018-01-19 15:10:23 --> Helper loaded: url_helper
DEBUG - 2018-01-19 15:10:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 15:10:23 --> Final output sent to browser
DEBUG - 2018-01-19 15:10:23 --> Total execution time: 0.0461
DEBUG - 2018-01-19 15:10:45 --> Config Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Utf8 Class Initialized
DEBUG - 2018-01-19 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 15:10:45 --> URI Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Router Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Output Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Security Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Input Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 15:10:45 --> Language Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Loader Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Helper loaded: date_helper
DEBUG - 2018-01-19 15:10:45 --> Controller Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Database Driver Class Initialized
ERROR - 2018-01-19 15:10:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 15:10:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Model Class Initialized
DEBUG - 2018-01-19 15:10:45 --> Helper loaded: url_helper
DEBUG - 2018-01-19 15:10:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 15:10:45 --> Final output sent to browser
DEBUG - 2018-01-19 15:10:45 --> Total execution time: 0.0464
DEBUG - 2018-01-19 15:36:32 --> Config Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Hooks Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Utf8 Class Initialized
DEBUG - 2018-01-19 15:36:32 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 15:36:32 --> URI Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Router Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Output Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Security Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Input Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 15:36:32 --> Language Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Loader Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Helper loaded: date_helper
DEBUG - 2018-01-19 15:36:32 --> Controller Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Database Driver Class Initialized
ERROR - 2018-01-19 15:36:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 15:36:32 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Model Class Initialized
DEBUG - 2018-01-19 15:36:32 --> Helper loaded: url_helper
DEBUG - 2018-01-19 15:36:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 15:36:32 --> Final output sent to browser
DEBUG - 2018-01-19 15:36:32 --> Total execution time: 0.0469
DEBUG - 2018-01-19 16:41:24 --> Config Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Utf8 Class Initialized
DEBUG - 2018-01-19 16:41:24 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 16:41:24 --> URI Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Router Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Output Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Security Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Input Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 16:41:24 --> Language Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Loader Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Helper loaded: date_helper
DEBUG - 2018-01-19 16:41:24 --> Controller Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Database Driver Class Initialized
ERROR - 2018-01-19 16:41:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 16:41:24 --> Model Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Model Class Initialized
DEBUG - 2018-01-19 16:41:24 --> Helper loaded: url_helper
DEBUG - 2018-01-19 16:41:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 16:41:24 --> Final output sent to browser
DEBUG - 2018-01-19 16:41:24 --> Total execution time: 0.0535
DEBUG - 2018-01-19 16:45:19 --> Config Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Utf8 Class Initialized
DEBUG - 2018-01-19 16:45:19 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 16:45:19 --> URI Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Router Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Output Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Security Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Input Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 16:45:19 --> Language Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Loader Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Helper loaded: date_helper
DEBUG - 2018-01-19 16:45:19 --> Controller Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Database Driver Class Initialized
ERROR - 2018-01-19 16:45:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 16:45:19 --> Model Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Model Class Initialized
DEBUG - 2018-01-19 16:45:19 --> Helper loaded: url_helper
DEBUG - 2018-01-19 16:45:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 16:45:19 --> Final output sent to browser
DEBUG - 2018-01-19 16:45:19 --> Total execution time: 0.0462
DEBUG - 2018-01-19 16:53:40 --> Config Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Utf8 Class Initialized
DEBUG - 2018-01-19 16:53:40 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 16:53:40 --> URI Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Router Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Output Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Security Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Input Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 16:53:40 --> Language Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Loader Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Helper loaded: date_helper
DEBUG - 2018-01-19 16:53:40 --> Controller Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Database Driver Class Initialized
ERROR - 2018-01-19 16:53:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 16:53:40 --> Model Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Model Class Initialized
DEBUG - 2018-01-19 16:53:40 --> Helper loaded: url_helper
DEBUG - 2018-01-19 16:53:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 16:53:40 --> Final output sent to browser
DEBUG - 2018-01-19 16:53:40 --> Total execution time: 0.0458
DEBUG - 2018-01-19 16:53:48 --> Config Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Hooks Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Utf8 Class Initialized
DEBUG - 2018-01-19 16:53:48 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 16:53:48 --> URI Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Router Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Output Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Security Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Input Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 16:53:48 --> Language Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Loader Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Helper loaded: date_helper
DEBUG - 2018-01-19 16:53:48 --> Controller Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Database Driver Class Initialized
ERROR - 2018-01-19 16:53:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 16:53:48 --> Model Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Model Class Initialized
DEBUG - 2018-01-19 16:53:48 --> Helper loaded: url_helper
DEBUG - 2018-01-19 16:53:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 16:53:48 --> Final output sent to browser
DEBUG - 2018-01-19 16:53:48 --> Total execution time: 0.0434
DEBUG - 2018-01-19 17:02:19 --> Config Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Hooks Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Utf8 Class Initialized
DEBUG - 2018-01-19 17:02:19 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 17:02:19 --> URI Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Router Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Output Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Security Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Input Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 17:02:19 --> Language Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Loader Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Helper loaded: date_helper
DEBUG - 2018-01-19 17:02:19 --> Controller Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Database Driver Class Initialized
ERROR - 2018-01-19 17:02:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 17:02:19 --> Model Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Model Class Initialized
DEBUG - 2018-01-19 17:02:19 --> Helper loaded: url_helper
DEBUG - 2018-01-19 17:02:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 17:02:19 --> Final output sent to browser
DEBUG - 2018-01-19 17:02:19 --> Total execution time: 0.0465
DEBUG - 2018-01-19 18:45:59 --> Config Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Hooks Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Utf8 Class Initialized
DEBUG - 2018-01-19 18:45:59 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 18:45:59 --> URI Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Router Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Output Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Security Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Input Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 18:45:59 --> Language Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Loader Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Helper loaded: date_helper
DEBUG - 2018-01-19 18:45:59 --> Controller Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Database Driver Class Initialized
ERROR - 2018-01-19 18:45:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 18:45:59 --> Model Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Model Class Initialized
DEBUG - 2018-01-19 18:45:59 --> Helper loaded: url_helper
DEBUG - 2018-01-19 18:45:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 18:45:59 --> Final output sent to browser
DEBUG - 2018-01-19 18:45:59 --> Total execution time: 0.0542
DEBUG - 2018-01-19 18:47:18 --> Config Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Hooks Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Utf8 Class Initialized
DEBUG - 2018-01-19 18:47:18 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 18:47:18 --> URI Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Router Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Output Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Security Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Input Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 18:47:18 --> Language Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Loader Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Helper loaded: date_helper
DEBUG - 2018-01-19 18:47:18 --> Controller Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Database Driver Class Initialized
ERROR - 2018-01-19 18:47:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 18:47:18 --> Model Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Model Class Initialized
DEBUG - 2018-01-19 18:47:18 --> Helper loaded: url_helper
DEBUG - 2018-01-19 18:47:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 18:47:18 --> Final output sent to browser
DEBUG - 2018-01-19 18:47:18 --> Total execution time: 0.0466
DEBUG - 2018-01-19 19:22:58 --> Config Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Hooks Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Utf8 Class Initialized
DEBUG - 2018-01-19 19:22:58 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 19:22:58 --> URI Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Router Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Output Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Security Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Input Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 19:22:58 --> Language Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Loader Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Helper loaded: date_helper
DEBUG - 2018-01-19 19:22:58 --> Controller Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Database Driver Class Initialized
ERROR - 2018-01-19 19:22:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 19:22:58 --> Model Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Model Class Initialized
DEBUG - 2018-01-19 19:22:58 --> Helper loaded: url_helper
DEBUG - 2018-01-19 19:22:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 19:22:58 --> Final output sent to browser
DEBUG - 2018-01-19 19:22:58 --> Total execution time: 0.0531
DEBUG - 2018-01-19 19:24:08 --> Config Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Hooks Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Utf8 Class Initialized
DEBUG - 2018-01-19 19:24:08 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 19:24:08 --> URI Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Router Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Output Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Security Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Input Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 19:24:08 --> Language Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Loader Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Helper loaded: date_helper
DEBUG - 2018-01-19 19:24:08 --> Controller Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Database Driver Class Initialized
ERROR - 2018-01-19 19:24:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 19:24:08 --> Model Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Model Class Initialized
DEBUG - 2018-01-19 19:24:08 --> Helper loaded: url_helper
DEBUG - 2018-01-19 19:24:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 19:24:09 --> Final output sent to browser
DEBUG - 2018-01-19 19:24:09 --> Total execution time: 0.0437
DEBUG - 2018-01-19 19:30:01 --> Config Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Hooks Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Utf8 Class Initialized
DEBUG - 2018-01-19 19:30:01 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 19:30:01 --> URI Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Router Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Output Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Security Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Input Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 19:30:01 --> Language Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Loader Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Helper loaded: date_helper
DEBUG - 2018-01-19 19:30:01 --> Controller Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Database Driver Class Initialized
ERROR - 2018-01-19 19:30:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 19:30:01 --> Model Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Model Class Initialized
DEBUG - 2018-01-19 19:30:01 --> Helper loaded: url_helper
DEBUG - 2018-01-19 19:30:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 19:30:01 --> Final output sent to browser
DEBUG - 2018-01-19 19:30:01 --> Total execution time: 0.0463
DEBUG - 2018-01-19 19:31:07 --> Config Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Hooks Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Utf8 Class Initialized
DEBUG - 2018-01-19 19:31:07 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 19:31:07 --> URI Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Router Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Output Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Security Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Input Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 19:31:07 --> Language Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Loader Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Helper loaded: date_helper
DEBUG - 2018-01-19 19:31:07 --> Controller Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Database Driver Class Initialized
ERROR - 2018-01-19 19:31:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 19:31:07 --> Model Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Model Class Initialized
DEBUG - 2018-01-19 19:31:07 --> Helper loaded: url_helper
DEBUG - 2018-01-19 19:31:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 19:31:07 --> Final output sent to browser
DEBUG - 2018-01-19 19:31:07 --> Total execution time: 0.0463
DEBUG - 2018-01-19 19:35:37 --> Config Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Hooks Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Utf8 Class Initialized
DEBUG - 2018-01-19 19:35:37 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 19:35:37 --> URI Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Router Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Output Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Security Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Input Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 19:35:37 --> Language Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Loader Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Helper loaded: date_helper
DEBUG - 2018-01-19 19:35:37 --> Controller Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Database Driver Class Initialized
ERROR - 2018-01-19 19:35:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 19:35:37 --> Model Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Model Class Initialized
DEBUG - 2018-01-19 19:35:37 --> Helper loaded: url_helper
DEBUG - 2018-01-19 19:35:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 19:35:37 --> Final output sent to browser
DEBUG - 2018-01-19 19:35:37 --> Total execution time: 0.0476
DEBUG - 2018-01-19 19:37:44 --> Config Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Hooks Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Utf8 Class Initialized
DEBUG - 2018-01-19 19:37:44 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 19:37:44 --> URI Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Router Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Output Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Security Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Input Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 19:37:44 --> Language Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Loader Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Helper loaded: date_helper
DEBUG - 2018-01-19 19:37:44 --> Controller Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Database Driver Class Initialized
ERROR - 2018-01-19 19:37:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 19:37:44 --> Model Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Model Class Initialized
DEBUG - 2018-01-19 19:37:44 --> Helper loaded: url_helper
DEBUG - 2018-01-19 19:37:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 19:37:44 --> Final output sent to browser
DEBUG - 2018-01-19 19:37:44 --> Total execution time: 0.0467
DEBUG - 2018-01-19 19:54:48 --> Config Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Hooks Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Utf8 Class Initialized
DEBUG - 2018-01-19 19:54:48 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 19:54:48 --> URI Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Router Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Output Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Security Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Input Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 19:54:48 --> Language Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Loader Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Helper loaded: date_helper
DEBUG - 2018-01-19 19:54:48 --> Controller Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Database Driver Class Initialized
ERROR - 2018-01-19 19:54:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 19:54:48 --> Model Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Model Class Initialized
DEBUG - 2018-01-19 19:54:48 --> Helper loaded: url_helper
DEBUG - 2018-01-19 19:54:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 19:54:48 --> Final output sent to browser
DEBUG - 2018-01-19 19:54:48 --> Total execution time: 0.0471
DEBUG - 2018-01-19 21:53:09 --> Config Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Hooks Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Utf8 Class Initialized
DEBUG - 2018-01-19 21:53:09 --> UTF-8 Support Enabled
DEBUG - 2018-01-19 21:53:09 --> URI Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Router Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Output Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Security Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Input Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-19 21:53:09 --> Language Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Loader Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Helper loaded: date_helper
DEBUG - 2018-01-19 21:53:09 --> Controller Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Database Driver Class Initialized
ERROR - 2018-01-19 21:53:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-19 21:53:09 --> Model Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Model Class Initialized
DEBUG - 2018-01-19 21:53:09 --> Helper loaded: url_helper
DEBUG - 2018-01-19 21:53:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-19 21:53:09 --> Final output sent to browser
DEBUG - 2018-01-19 21:53:09 --> Total execution time: 0.0539
