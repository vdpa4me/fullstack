<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-01-30 00:56:00 --> Config Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Hooks Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Utf8 Class Initialized
DEBUG - 2018-01-30 00:56:00 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 00:56:00 --> URI Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Router Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Output Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Security Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Input Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 00:56:00 --> Language Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Loader Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Helper loaded: date_helper
DEBUG - 2018-01-30 00:56:00 --> Controller Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Database Driver Class Initialized
ERROR - 2018-01-30 00:56:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 00:56:00 --> Model Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Model Class Initialized
DEBUG - 2018-01-30 00:56:00 --> Helper loaded: url_helper
DEBUG - 2018-01-30 00:56:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-30 00:56:00 --> Final output sent to browser
DEBUG - 2018-01-30 00:56:00 --> Total execution time: 0.0280
DEBUG - 2018-01-30 08:55:23 --> Config Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Hooks Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Utf8 Class Initialized
DEBUG - 2018-01-30 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 08:55:23 --> URI Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Router Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Output Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Security Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Input Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 08:55:23 --> Language Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Loader Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Helper loaded: date_helper
DEBUG - 2018-01-30 08:55:23 --> Controller Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Database Driver Class Initialized
ERROR - 2018-01-30 08:55:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 08:55:23 --> Model Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Model Class Initialized
DEBUG - 2018-01-30 08:55:23 --> Helper loaded: url_helper
DEBUG - 2018-01-30 08:55:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-30 08:55:23 --> Final output sent to browser
DEBUG - 2018-01-30 08:55:23 --> Total execution time: 0.0273
DEBUG - 2018-01-30 19:42:20 --> Config Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Hooks Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Utf8 Class Initialized
DEBUG - 2018-01-30 19:42:20 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 19:42:20 --> URI Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Router Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Output Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Security Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Input Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 19:42:20 --> Language Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Loader Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Helper loaded: date_helper
DEBUG - 2018-01-30 19:42:20 --> Controller Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Database Driver Class Initialized
ERROR - 2018-01-30 19:42:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 19:42:20 --> Model Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Model Class Initialized
DEBUG - 2018-01-30 19:42:20 --> Helper loaded: url_helper
DEBUG - 2018-01-30 19:42:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 19:42:20 --> Final output sent to browser
DEBUG - 2018-01-30 19:42:20 --> Total execution time: 0.0863
DEBUG - 2018-01-30 20:28:22 --> Config Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Hooks Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Utf8 Class Initialized
DEBUG - 2018-01-30 20:28:22 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 20:28:22 --> URI Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Router Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Output Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Security Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Input Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 20:28:22 --> Language Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Loader Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Helper loaded: date_helper
DEBUG - 2018-01-30 20:28:22 --> Controller Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Database Driver Class Initialized
ERROR - 2018-01-30 20:28:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 20:28:22 --> Model Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Model Class Initialized
DEBUG - 2018-01-30 20:28:22 --> Helper loaded: url_helper
DEBUG - 2018-01-30 20:28:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-30 20:28:22 --> Final output sent to browser
DEBUG - 2018-01-30 20:28:22 --> Total execution time: 0.0270
DEBUG - 2018-01-30 21:34:48 --> Config Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Hooks Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Utf8 Class Initialized
DEBUG - 2018-01-30 21:34:48 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 21:34:48 --> URI Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Router Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Output Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Security Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Input Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 21:34:48 --> Language Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Loader Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Helper loaded: date_helper
DEBUG - 2018-01-30 21:34:48 --> Controller Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Database Driver Class Initialized
ERROR - 2018-01-30 21:34:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 21:34:48 --> Model Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Model Class Initialized
DEBUG - 2018-01-30 21:34:48 --> Helper loaded: url_helper
DEBUG - 2018-01-30 21:34:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 21:34:48 --> Final output sent to browser
DEBUG - 2018-01-30 21:34:48 --> Total execution time: 0.0529
DEBUG - 2018-01-30 21:50:05 --> Config Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Hooks Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Utf8 Class Initialized
DEBUG - 2018-01-30 21:50:05 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 21:50:05 --> URI Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Router Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Output Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Security Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Input Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 21:50:05 --> Language Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Loader Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Helper loaded: date_helper
DEBUG - 2018-01-30 21:50:05 --> Controller Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Database Driver Class Initialized
ERROR - 2018-01-30 21:50:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 21:50:05 --> Model Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Model Class Initialized
DEBUG - 2018-01-30 21:50:05 --> Helper loaded: url_helper
DEBUG - 2018-01-30 21:50:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 21:50:05 --> Final output sent to browser
DEBUG - 2018-01-30 21:50:05 --> Total execution time: 0.0446
DEBUG - 2018-01-30 22:03:59 --> Config Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Hooks Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Utf8 Class Initialized
DEBUG - 2018-01-30 22:03:59 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 22:03:59 --> URI Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Router Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Output Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Security Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Input Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 22:03:59 --> Language Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Loader Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Helper loaded: date_helper
DEBUG - 2018-01-30 22:03:59 --> Controller Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Database Driver Class Initialized
ERROR - 2018-01-30 22:03:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 22:03:59 --> Model Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Model Class Initialized
DEBUG - 2018-01-30 22:03:59 --> Helper loaded: url_helper
DEBUG - 2018-01-30 22:03:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-30 22:03:59 --> Final output sent to browser
DEBUG - 2018-01-30 22:03:59 --> Total execution time: 0.0216
DEBUG - 2018-01-30 22:24:24 --> Config Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Hooks Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Utf8 Class Initialized
DEBUG - 2018-01-30 22:24:24 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 22:24:24 --> URI Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Router Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Output Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Security Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Input Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 22:24:24 --> Language Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Loader Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Helper loaded: date_helper
DEBUG - 2018-01-30 22:24:24 --> Controller Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Database Driver Class Initialized
ERROR - 2018-01-30 22:24:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 22:24:24 --> Model Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Model Class Initialized
DEBUG - 2018-01-30 22:24:24 --> Helper loaded: url_helper
DEBUG - 2018-01-30 22:24:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 22:24:24 --> Final output sent to browser
DEBUG - 2018-01-30 22:24:24 --> Total execution time: 0.0459
DEBUG - 2018-01-30 22:25:58 --> Config Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Hooks Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Utf8 Class Initialized
DEBUG - 2018-01-30 22:25:58 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 22:25:58 --> URI Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Router Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Output Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Security Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Input Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 22:25:58 --> Language Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Loader Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Helper loaded: date_helper
DEBUG - 2018-01-30 22:25:58 --> Controller Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Database Driver Class Initialized
ERROR - 2018-01-30 22:25:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 22:25:58 --> Model Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Model Class Initialized
DEBUG - 2018-01-30 22:25:58 --> Helper loaded: url_helper
DEBUG - 2018-01-30 22:25:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 22:25:58 --> Final output sent to browser
DEBUG - 2018-01-30 22:25:58 --> Total execution time: 0.0459
DEBUG - 2018-01-30 22:27:25 --> Config Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Hooks Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Utf8 Class Initialized
DEBUG - 2018-01-30 22:27:25 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 22:27:25 --> URI Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Router Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Output Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Security Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Input Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 22:27:25 --> Language Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Loader Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Helper loaded: date_helper
DEBUG - 2018-01-30 22:27:25 --> Controller Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Database Driver Class Initialized
ERROR - 2018-01-30 22:27:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 22:27:25 --> Model Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Model Class Initialized
DEBUG - 2018-01-30 22:27:25 --> Helper loaded: url_helper
DEBUG - 2018-01-30 22:27:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 22:27:25 --> Final output sent to browser
DEBUG - 2018-01-30 22:27:25 --> Total execution time: 0.0466
DEBUG - 2018-01-30 22:27:30 --> Config Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Hooks Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Utf8 Class Initialized
DEBUG - 2018-01-30 22:27:30 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 22:27:30 --> URI Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Router Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Output Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Security Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Input Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 22:27:30 --> Language Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Loader Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Helper loaded: date_helper
DEBUG - 2018-01-30 22:27:30 --> Controller Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Database Driver Class Initialized
ERROR - 2018-01-30 22:27:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 22:27:30 --> Model Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Model Class Initialized
DEBUG - 2018-01-30 22:27:30 --> Helper loaded: url_helper
DEBUG - 2018-01-30 22:27:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 22:27:30 --> Final output sent to browser
DEBUG - 2018-01-30 22:27:30 --> Total execution time: 0.0459
DEBUG - 2018-01-30 22:32:14 --> Config Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Hooks Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Utf8 Class Initialized
DEBUG - 2018-01-30 22:32:14 --> UTF-8 Support Enabled
DEBUG - 2018-01-30 22:32:14 --> URI Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Router Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Output Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Security Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Input Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-30 22:32:14 --> Language Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Loader Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Helper loaded: date_helper
DEBUG - 2018-01-30 22:32:14 --> Controller Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Database Driver Class Initialized
ERROR - 2018-01-30 22:32:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-30 22:32:14 --> Model Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Model Class Initialized
DEBUG - 2018-01-30 22:32:14 --> Helper loaded: url_helper
DEBUG - 2018-01-30 22:32:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-30 22:32:14 --> Final output sent to browser
DEBUG - 2018-01-30 22:32:14 --> Total execution time: 0.0461
