<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-04-21 01:38:14 --> Config Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Hooks Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Utf8 Class Initialized
DEBUG - 2020-04-21 01:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 01:38:14 --> URI Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Router Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Output Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Security Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Input Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 01:38:14 --> Language Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Loader Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Helper loaded: date_helper
DEBUG - 2020-04-21 01:38:14 --> Controller Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Database Driver Class Initialized
ERROR - 2020-04-21 01:38:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 01:38:14 --> Model Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Model Class Initialized
DEBUG - 2020-04-21 01:38:14 --> Helper loaded: url_helper
DEBUG - 2020-04-21 01:38:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 01:38:14 --> Final output sent to browser
DEBUG - 2020-04-21 01:38:14 --> Total execution time: 0.1884
DEBUG - 2020-04-21 01:44:31 --> Config Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Hooks Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Utf8 Class Initialized
DEBUG - 2020-04-21 01:44:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 01:44:31 --> URI Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Router Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Output Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Security Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Input Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 01:44:31 --> Language Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Loader Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Helper loaded: date_helper
DEBUG - 2020-04-21 01:44:31 --> Controller Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Database Driver Class Initialized
ERROR - 2020-04-21 01:44:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 01:44:31 --> Model Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Model Class Initialized
DEBUG - 2020-04-21 01:44:31 --> Helper loaded: url_helper
DEBUG - 2020-04-21 01:44:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 01:44:31 --> Final output sent to browser
DEBUG - 2020-04-21 01:44:31 --> Total execution time: 0.0805
DEBUG - 2020-04-21 04:16:17 --> Config Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Hooks Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Utf8 Class Initialized
DEBUG - 2020-04-21 04:16:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 04:16:17 --> URI Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Router Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Output Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Security Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Input Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 04:16:17 --> Language Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Loader Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Helper loaded: date_helper
DEBUG - 2020-04-21 04:16:17 --> Controller Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Database Driver Class Initialized
ERROR - 2020-04-21 04:16:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 04:16:17 --> Model Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Model Class Initialized
DEBUG - 2020-04-21 04:16:17 --> Helper loaded: url_helper
DEBUG - 2020-04-21 04:16:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 04:16:17 --> Final output sent to browser
DEBUG - 2020-04-21 04:16:17 --> Total execution time: 0.0976
DEBUG - 2020-04-21 16:11:35 --> Config Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Hooks Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Utf8 Class Initialized
DEBUG - 2020-04-21 16:11:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 16:11:35 --> URI Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Router Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Output Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Security Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Input Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 16:11:35 --> Language Class Initialized
DEBUG - 2020-04-21 16:11:35 --> Loader Class Initialized
DEBUG - 2020-04-21 16:11:36 --> Helper loaded: date_helper
DEBUG - 2020-04-21 16:11:36 --> Controller Class Initialized
DEBUG - 2020-04-21 16:11:36 --> Database Driver Class Initialized
ERROR - 2020-04-21 16:11:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 16:11:36 --> Model Class Initialized
DEBUG - 2020-04-21 16:11:36 --> Model Class Initialized
DEBUG - 2020-04-21 16:11:36 --> Helper loaded: url_helper
DEBUG - 2020-04-21 16:11:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 16:11:36 --> Final output sent to browser
DEBUG - 2020-04-21 16:11:36 --> Total execution time: 0.2053
DEBUG - 2020-04-21 19:59:15 --> Config Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Hooks Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Utf8 Class Initialized
DEBUG - 2020-04-21 19:59:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 19:59:15 --> URI Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Router Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Output Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Security Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Input Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 19:59:15 --> Language Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Loader Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Helper loaded: date_helper
DEBUG - 2020-04-21 19:59:15 --> Controller Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Database Driver Class Initialized
ERROR - 2020-04-21 19:59:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 19:59:15 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:15 --> Helper loaded: url_helper
DEBUG - 2020-04-21 19:59:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 19:59:15 --> Final output sent to browser
DEBUG - 2020-04-21 19:59:15 --> Total execution time: 0.1908
DEBUG - 2020-04-21 19:59:24 --> Config Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Hooks Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Utf8 Class Initialized
DEBUG - 2020-04-21 19:59:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 19:59:24 --> URI Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Router Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Output Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Security Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Input Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 19:59:24 --> Language Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Loader Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Helper loaded: date_helper
DEBUG - 2020-04-21 19:59:24 --> Controller Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Database Driver Class Initialized
ERROR - 2020-04-21 19:59:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 19:59:24 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:24 --> Helper loaded: url_helper
DEBUG - 2020-04-21 19:59:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 19:59:24 --> Final output sent to browser
DEBUG - 2020-04-21 19:59:24 --> Total execution time: 0.0992
DEBUG - 2020-04-21 19:59:39 --> Config Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Hooks Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Utf8 Class Initialized
DEBUG - 2020-04-21 19:59:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 19:59:39 --> URI Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Router Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Output Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Security Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Input Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 19:59:39 --> Language Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Loader Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Helper loaded: date_helper
DEBUG - 2020-04-21 19:59:39 --> Controller Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Database Driver Class Initialized
ERROR - 2020-04-21 19:59:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 19:59:39 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:39 --> Helper loaded: url_helper
DEBUG - 2020-04-21 19:59:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 19:59:39 --> Final output sent to browser
DEBUG - 2020-04-21 19:59:39 --> Total execution time: 0.0794
DEBUG - 2020-04-21 19:59:41 --> Config Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Hooks Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Utf8 Class Initialized
DEBUG - 2020-04-21 19:59:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 19:59:41 --> URI Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Router Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Output Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Security Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Input Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 19:59:41 --> Language Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Loader Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Helper loaded: date_helper
DEBUG - 2020-04-21 19:59:41 --> Controller Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Database Driver Class Initialized
ERROR - 2020-04-21 19:59:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 19:59:41 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:41 --> Helper loaded: url_helper
DEBUG - 2020-04-21 19:59:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 19:59:41 --> Final output sent to browser
DEBUG - 2020-04-21 19:59:41 --> Total execution time: 0.1095
DEBUG - 2020-04-21 19:59:42 --> Config Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Hooks Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Utf8 Class Initialized
DEBUG - 2020-04-21 19:59:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 19:59:42 --> URI Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Router Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Output Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Security Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Input Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 19:59:42 --> Language Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Loader Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Helper loaded: date_helper
DEBUG - 2020-04-21 19:59:42 --> Controller Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Database Driver Class Initialized
ERROR - 2020-04-21 19:59:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 19:59:42 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:42 --> Helper loaded: url_helper
DEBUG - 2020-04-21 19:59:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 19:59:42 --> Final output sent to browser
DEBUG - 2020-04-21 19:59:42 --> Total execution time: 0.1016
DEBUG - 2020-04-21 19:59:43 --> Config Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Hooks Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Utf8 Class Initialized
DEBUG - 2020-04-21 19:59:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 19:59:43 --> URI Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Router Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Output Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Security Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Input Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 19:59:43 --> Language Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Loader Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Helper loaded: date_helper
DEBUG - 2020-04-21 19:59:43 --> Controller Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Database Driver Class Initialized
ERROR - 2020-04-21 19:59:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 19:59:43 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:43 --> Helper loaded: url_helper
DEBUG - 2020-04-21 19:59:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 19:59:43 --> Final output sent to browser
DEBUG - 2020-04-21 19:59:43 --> Total execution time: 0.1129
DEBUG - 2020-04-21 19:59:44 --> Config Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Hooks Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Utf8 Class Initialized
DEBUG - 2020-04-21 19:59:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-21 19:59:44 --> URI Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Router Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Output Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Security Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Input Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-21 19:59:44 --> Language Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Loader Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Helper loaded: date_helper
DEBUG - 2020-04-21 19:59:44 --> Controller Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Database Driver Class Initialized
ERROR - 2020-04-21 19:59:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-21 19:59:44 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Model Class Initialized
DEBUG - 2020-04-21 19:59:44 --> Helper loaded: url_helper
DEBUG - 2020-04-21 19:59:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-21 19:59:44 --> Final output sent to browser
DEBUG - 2020-04-21 19:59:44 --> Total execution time: 0.0950
