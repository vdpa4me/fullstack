<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-27 00:45:25 --> Config Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Hooks Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Utf8 Class Initialized
DEBUG - 2017-11-27 00:45:25 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 00:45:25 --> URI Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Router Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Output Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Security Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Input Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 00:45:25 --> Language Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Loader Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Helper loaded: date_helper
DEBUG - 2017-11-27 00:45:25 --> Controller Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Database Driver Class Initialized
ERROR - 2017-11-27 00:45:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 00:45:25 --> Model Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Model Class Initialized
DEBUG - 2017-11-27 00:45:25 --> Helper loaded: url_helper
DEBUG - 2017-11-27 00:45:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 00:45:25 --> Final output sent to browser
DEBUG - 2017-11-27 00:45:25 --> Total execution time: 0.0347
DEBUG - 2017-11-27 00:45:27 --> Config Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Hooks Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Utf8 Class Initialized
DEBUG - 2017-11-27 00:45:27 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 00:45:27 --> URI Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Router Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Output Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Security Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Input Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 00:45:27 --> Language Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Loader Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Helper loaded: date_helper
DEBUG - 2017-11-27 00:45:27 --> Controller Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Database Driver Class Initialized
ERROR - 2017-11-27 00:45:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 00:45:27 --> Model Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Model Class Initialized
DEBUG - 2017-11-27 00:45:27 --> Helper loaded: url_helper
DEBUG - 2017-11-27 00:45:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 00:45:27 --> Final output sent to browser
DEBUG - 2017-11-27 00:45:27 --> Total execution time: 0.0200
DEBUG - 2017-11-27 07:28:16 --> Config Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Hooks Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Utf8 Class Initialized
DEBUG - 2017-11-27 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 07:28:16 --> URI Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Router Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Output Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Security Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Input Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 07:28:16 --> Language Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Loader Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Helper loaded: date_helper
DEBUG - 2017-11-27 07:28:16 --> Controller Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Database Driver Class Initialized
ERROR - 2017-11-27 07:28:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 07:28:16 --> Model Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Model Class Initialized
DEBUG - 2017-11-27 07:28:16 --> Helper loaded: url_helper
DEBUG - 2017-11-27 07:28:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 07:28:16 --> Final output sent to browser
DEBUG - 2017-11-27 07:28:16 --> Total execution time: 0.0573
DEBUG - 2017-11-27 16:22:09 --> Config Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Hooks Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Utf8 Class Initialized
DEBUG - 2017-11-27 16:22:09 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 16:22:09 --> URI Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Router Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Output Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Security Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Input Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 16:22:09 --> Language Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Loader Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Helper loaded: date_helper
DEBUG - 2017-11-27 16:22:09 --> Controller Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Database Driver Class Initialized
ERROR - 2017-11-27 16:22:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 16:22:09 --> Model Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Model Class Initialized
DEBUG - 2017-11-27 16:22:09 --> Helper loaded: url_helper
DEBUG - 2017-11-27 16:22:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 16:22:09 --> Final output sent to browser
DEBUG - 2017-11-27 16:22:09 --> Total execution time: 0.0342
DEBUG - 2017-11-27 16:22:19 --> Config Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Hooks Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Utf8 Class Initialized
DEBUG - 2017-11-27 16:22:19 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 16:22:19 --> URI Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Router Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Output Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Security Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Input Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 16:22:19 --> Language Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Loader Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Helper loaded: date_helper
DEBUG - 2017-11-27 16:22:19 --> Controller Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Database Driver Class Initialized
ERROR - 2017-11-27 16:22:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 16:22:19 --> Model Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Model Class Initialized
DEBUG - 2017-11-27 16:22:19 --> Helper loaded: url_helper
DEBUG - 2017-11-27 16:22:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 16:22:19 --> Final output sent to browser
DEBUG - 2017-11-27 16:22:19 --> Total execution time: 0.0203
DEBUG - 2017-11-27 18:23:17 --> Config Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Hooks Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Utf8 Class Initialized
DEBUG - 2017-11-27 18:23:17 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 18:23:17 --> URI Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Router Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Output Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Security Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Input Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 18:23:17 --> Language Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Loader Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Helper loaded: date_helper
DEBUG - 2017-11-27 18:23:17 --> Controller Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Database Driver Class Initialized
ERROR - 2017-11-27 18:23:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 18:23:17 --> Model Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Model Class Initialized
DEBUG - 2017-11-27 18:23:17 --> Helper loaded: url_helper
DEBUG - 2017-11-27 18:23:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 18:23:17 --> Final output sent to browser
DEBUG - 2017-11-27 18:23:17 --> Total execution time: 0.0325
DEBUG - 2017-11-27 18:23:32 --> Config Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Hooks Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Utf8 Class Initialized
DEBUG - 2017-11-27 18:23:32 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 18:23:32 --> URI Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Router Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Output Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Security Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Input Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 18:23:32 --> Language Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Loader Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Helper loaded: date_helper
DEBUG - 2017-11-27 18:23:32 --> Controller Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Database Driver Class Initialized
ERROR - 2017-11-27 18:23:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 18:23:32 --> Model Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Model Class Initialized
DEBUG - 2017-11-27 18:23:32 --> Helper loaded: url_helper
DEBUG - 2017-11-27 18:23:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 18:23:32 --> Final output sent to browser
DEBUG - 2017-11-27 18:23:32 --> Total execution time: 0.0200
DEBUG - 2017-11-27 21:15:17 --> Config Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Hooks Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Utf8 Class Initialized
DEBUG - 2017-11-27 21:15:17 --> UTF-8 Support Enabled
DEBUG - 2017-11-27 21:15:17 --> URI Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Router Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Output Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Security Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Input Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-27 21:15:17 --> Language Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Loader Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Helper loaded: date_helper
DEBUG - 2017-11-27 21:15:17 --> Controller Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Database Driver Class Initialized
ERROR - 2017-11-27 21:15:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-27 21:15:17 --> Model Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Model Class Initialized
DEBUG - 2017-11-27 21:15:17 --> Helper loaded: url_helper
DEBUG - 2017-11-27 21:15:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-27 21:15:17 --> Final output sent to browser
DEBUG - 2017-11-27 21:15:17 --> Total execution time: 0.0208
