<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-09-27 00:36:30 --> Config Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Hooks Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Utf8 Class Initialized
DEBUG - 2017-09-27 00:36:30 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 00:36:30 --> URI Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Router Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Output Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Security Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Input Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 00:36:30 --> Language Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Loader Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Helper loaded: date_helper
DEBUG - 2017-09-27 00:36:30 --> Controller Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Database Driver Class Initialized
ERROR - 2017-09-27 00:36:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 00:36:30 --> Model Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Model Class Initialized
DEBUG - 2017-09-27 00:36:30 --> Helper loaded: url_helper
DEBUG - 2017-09-27 00:36:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-27 00:36:30 --> Final output sent to browser
DEBUG - 2017-09-27 00:36:30 --> Total execution time: 0.0241
DEBUG - 2017-09-27 04:55:41 --> Config Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Hooks Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Utf8 Class Initialized
DEBUG - 2017-09-27 04:55:41 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 04:55:41 --> URI Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Router Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Output Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Security Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Input Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 04:55:41 --> Language Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Loader Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Helper loaded: date_helper
DEBUG - 2017-09-27 04:55:41 --> Controller Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Database Driver Class Initialized
ERROR - 2017-09-27 04:55:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 04:55:41 --> Model Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Model Class Initialized
DEBUG - 2017-09-27 04:55:41 --> Helper loaded: url_helper
DEBUG - 2017-09-27 04:55:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-27 04:55:41 --> Final output sent to browser
DEBUG - 2017-09-27 04:55:41 --> Total execution time: 0.0218
DEBUG - 2017-09-27 06:59:50 --> Config Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Hooks Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Utf8 Class Initialized
DEBUG - 2017-09-27 06:59:50 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 06:59:50 --> URI Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Router Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Output Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Security Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Input Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 06:59:50 --> Language Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Loader Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Helper loaded: date_helper
DEBUG - 2017-09-27 06:59:50 --> Controller Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Database Driver Class Initialized
ERROR - 2017-09-27 06:59:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 06:59:50 --> Model Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Model Class Initialized
DEBUG - 2017-09-27 06:59:50 --> Helper loaded: url_helper
DEBUG - 2017-09-27 06:59:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-27 06:59:50 --> Final output sent to browser
DEBUG - 2017-09-27 06:59:50 --> Total execution time: 0.0340
DEBUG - 2017-09-27 10:04:24 --> Config Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Hooks Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Utf8 Class Initialized
DEBUG - 2017-09-27 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 10:04:24 --> URI Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Router Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Output Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Security Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Input Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 10:04:24 --> Language Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Loader Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Helper loaded: date_helper
DEBUG - 2017-09-27 10:04:24 --> Controller Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Database Driver Class Initialized
ERROR - 2017-09-27 10:04:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 10:04:24 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:24 --> Helper loaded: url_helper
DEBUG - 2017-09-27 10:04:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-09-27 10:04:24 --> Final output sent to browser
DEBUG - 2017-09-27 10:04:24 --> Total execution time: 0.0386
DEBUG - 2017-09-27 10:04:33 --> Config Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Hooks Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Utf8 Class Initialized
DEBUG - 2017-09-27 10:04:33 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 10:04:33 --> URI Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Router Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Output Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Security Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Input Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 10:04:33 --> Language Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Loader Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Helper loaded: date_helper
DEBUG - 2017-09-27 10:04:33 --> Controller Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Database Driver Class Initialized
ERROR - 2017-09-27 10:04:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 10:04:33 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:33 --> Helper loaded: url_helper
DEBUG - 2017-09-27 10:04:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-09-27 10:04:33 --> Final output sent to browser
DEBUG - 2017-09-27 10:04:33 --> Total execution time: 0.0383
DEBUG - 2017-09-27 10:04:46 --> Config Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Hooks Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Utf8 Class Initialized
DEBUG - 2017-09-27 10:04:46 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 10:04:46 --> URI Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Router Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Output Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Security Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Input Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 10:04:46 --> Language Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Loader Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Helper loaded: date_helper
DEBUG - 2017-09-27 10:04:46 --> Controller Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Database Driver Class Initialized
ERROR - 2017-09-27 10:04:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 10:04:46 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:46 --> Helper loaded: url_helper
DEBUG - 2017-09-27 10:04:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-09-27 10:04:46 --> Final output sent to browser
DEBUG - 2017-09-27 10:04:46 --> Total execution time: 0.0374
DEBUG - 2017-09-27 10:04:51 --> Config Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Hooks Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Utf8 Class Initialized
DEBUG - 2017-09-27 10:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 10:04:51 --> URI Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Router Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Output Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Security Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Input Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 10:04:51 --> Language Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Loader Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Helper loaded: date_helper
DEBUG - 2017-09-27 10:04:51 --> Controller Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Database Driver Class Initialized
ERROR - 2017-09-27 10:04:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 10:04:51 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Model Class Initialized
DEBUG - 2017-09-27 10:04:51 --> Helper loaded: url_helper
DEBUG - 2017-09-27 10:04:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-09-27 10:04:52 --> Final output sent to browser
DEBUG - 2017-09-27 10:04:52 --> Total execution time: 0.0383
DEBUG - 2017-09-27 11:56:50 --> Config Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Hooks Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Utf8 Class Initialized
DEBUG - 2017-09-27 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 11:56:50 --> URI Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Router Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Output Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Security Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Input Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 11:56:50 --> Language Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Loader Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Helper loaded: date_helper
DEBUG - 2017-09-27 11:56:50 --> Controller Class Initialized
DEBUG - 2017-09-27 11:56:50 --> Database Driver Class Initialized
ERROR - 2017-09-27 11:56:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 11:56:51 --> Model Class Initialized
DEBUG - 2017-09-27 11:56:51 --> Model Class Initialized
DEBUG - 2017-09-27 11:56:51 --> Helper loaded: url_helper
DEBUG - 2017-09-27 11:56:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-27 11:56:51 --> Final output sent to browser
DEBUG - 2017-09-27 11:56:51 --> Total execution time: 0.0205
DEBUG - 2017-09-27 15:13:46 --> Config Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Hooks Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Utf8 Class Initialized
DEBUG - 2017-09-27 15:13:46 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 15:13:46 --> URI Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Router Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Output Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Security Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Input Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 15:13:46 --> Language Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Loader Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Helper loaded: date_helper
DEBUG - 2017-09-27 15:13:46 --> Controller Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Database Driver Class Initialized
ERROR - 2017-09-27 15:13:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 15:13:46 --> Model Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Model Class Initialized
DEBUG - 2017-09-27 15:13:46 --> Helper loaded: url_helper
DEBUG - 2017-09-27 15:13:46 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-27 15:13:46 --> Final output sent to browser
DEBUG - 2017-09-27 15:13:46 --> Total execution time: 0.0370
DEBUG - 2017-09-27 21:19:08 --> Config Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Hooks Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Utf8 Class Initialized
DEBUG - 2017-09-27 21:19:08 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 21:19:08 --> URI Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Router Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Output Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Security Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Input Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 21:19:08 --> Language Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Loader Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Helper loaded: date_helper
DEBUG - 2017-09-27 21:19:08 --> Controller Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Database Driver Class Initialized
ERROR - 2017-09-27 21:19:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 21:19:08 --> Model Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Model Class Initialized
DEBUG - 2017-09-27 21:19:08 --> Helper loaded: url_helper
DEBUG - 2017-09-27 21:19:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-27 21:19:08 --> Final output sent to browser
DEBUG - 2017-09-27 21:19:08 --> Total execution time: 0.0241
DEBUG - 2017-09-27 23:48:11 --> Config Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Hooks Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Utf8 Class Initialized
DEBUG - 2017-09-27 23:48:11 --> UTF-8 Support Enabled
DEBUG - 2017-09-27 23:48:11 --> URI Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Router Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Output Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Security Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Input Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-27 23:48:11 --> Language Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Loader Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Helper loaded: date_helper
DEBUG - 2017-09-27 23:48:11 --> Controller Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Database Driver Class Initialized
ERROR - 2017-09-27 23:48:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-27 23:48:11 --> Model Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Model Class Initialized
DEBUG - 2017-09-27 23:48:11 --> Helper loaded: url_helper
DEBUG - 2017-09-27 23:48:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-27 23:48:11 --> Final output sent to browser
DEBUG - 2017-09-27 23:48:11 --> Total execution time: 0.0205
