<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-26 08:37:08 --> Config Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Hooks Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Utf8 Class Initialized
DEBUG - 2018-08-26 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2018-08-26 08:37:08 --> URI Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Router Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Output Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Security Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Input Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-26 08:37:08 --> Language Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Loader Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Helper loaded: date_helper
DEBUG - 2018-08-26 08:37:08 --> Controller Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Database Driver Class Initialized
ERROR - 2018-08-26 08:37:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-26 08:37:08 --> Model Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Model Class Initialized
DEBUG - 2018-08-26 08:37:08 --> Helper loaded: url_helper
DEBUG - 2018-08-26 08:37:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-26 08:37:08 --> Final output sent to browser
DEBUG - 2018-08-26 08:37:08 --> Total execution time: 0.3282
DEBUG - 2018-08-26 10:02:20 --> Config Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Hooks Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Utf8 Class Initialized
DEBUG - 2018-08-26 10:02:20 --> UTF-8 Support Enabled
DEBUG - 2018-08-26 10:02:20 --> URI Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Router Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Output Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Security Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Input Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-26 10:02:20 --> Language Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Loader Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Helper loaded: date_helper
DEBUG - 2018-08-26 10:02:20 --> Controller Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Database Driver Class Initialized
ERROR - 2018-08-26 10:02:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-26 10:02:20 --> Model Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Model Class Initialized
DEBUG - 2018-08-26 10:02:20 --> Helper loaded: url_helper
DEBUG - 2018-08-26 10:02:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-26 10:02:20 --> Final output sent to browser
DEBUG - 2018-08-26 10:02:20 --> Total execution time: 0.0208
DEBUG - 2018-08-26 11:09:55 --> Config Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Hooks Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Utf8 Class Initialized
DEBUG - 2018-08-26 11:09:55 --> UTF-8 Support Enabled
DEBUG - 2018-08-26 11:09:55 --> URI Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Router Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Output Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Security Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Input Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-26 11:09:55 --> Language Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Loader Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Helper loaded: date_helper
DEBUG - 2018-08-26 11:09:55 --> Controller Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Database Driver Class Initialized
ERROR - 2018-08-26 11:09:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-26 11:09:55 --> Model Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Model Class Initialized
DEBUG - 2018-08-26 11:09:55 --> Helper loaded: url_helper
DEBUG - 2018-08-26 11:09:55 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-08-26 11:09:55 --> Final output sent to browser
DEBUG - 2018-08-26 11:09:55 --> Total execution time: 0.0231
