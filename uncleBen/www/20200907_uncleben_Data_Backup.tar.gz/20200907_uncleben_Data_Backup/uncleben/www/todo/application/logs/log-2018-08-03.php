<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-03 00:54:19 --> Config Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Hooks Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Utf8 Class Initialized
DEBUG - 2018-08-03 00:54:19 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 00:54:19 --> URI Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Router Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Output Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Security Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Input Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 00:54:19 --> Language Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Loader Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Helper loaded: date_helper
DEBUG - 2018-08-03 00:54:19 --> Controller Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Database Driver Class Initialized
ERROR - 2018-08-03 00:54:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 00:54:19 --> Model Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Model Class Initialized
DEBUG - 2018-08-03 00:54:19 --> Helper loaded: url_helper
DEBUG - 2018-08-03 00:54:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 00:54:19 --> Final output sent to browser
DEBUG - 2018-08-03 00:54:19 --> Total execution time: 0.0229
DEBUG - 2018-08-03 04:47:25 --> Config Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Hooks Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Utf8 Class Initialized
DEBUG - 2018-08-03 04:47:25 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 04:47:25 --> URI Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Router Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Output Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Security Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Input Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 04:47:25 --> Language Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Loader Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Helper loaded: date_helper
DEBUG - 2018-08-03 04:47:25 --> Controller Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Database Driver Class Initialized
ERROR - 2018-08-03 04:47:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 04:47:25 --> Model Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Model Class Initialized
DEBUG - 2018-08-03 04:47:25 --> Helper loaded: url_helper
DEBUG - 2018-08-03 04:47:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 04:47:25 --> Final output sent to browser
DEBUG - 2018-08-03 04:47:25 --> Total execution time: 0.0214
DEBUG - 2018-08-03 07:24:31 --> Config Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Hooks Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Utf8 Class Initialized
DEBUG - 2018-08-03 07:24:31 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 07:24:31 --> URI Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Router Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Output Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Security Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Input Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 07:24:31 --> Language Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Loader Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Helper loaded: date_helper
DEBUG - 2018-08-03 07:24:31 --> Controller Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Database Driver Class Initialized
ERROR - 2018-08-03 07:24:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 07:24:31 --> Model Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Model Class Initialized
DEBUG - 2018-08-03 07:24:31 --> Helper loaded: url_helper
DEBUG - 2018-08-03 07:24:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 07:24:31 --> Final output sent to browser
DEBUG - 2018-08-03 07:24:31 --> Total execution time: 0.0301
DEBUG - 2018-08-03 07:26:33 --> Config Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Hooks Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Utf8 Class Initialized
DEBUG - 2018-08-03 07:26:33 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 07:26:33 --> URI Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Router Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Output Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Security Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Input Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 07:26:33 --> Language Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Loader Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Helper loaded: date_helper
DEBUG - 2018-08-03 07:26:33 --> Controller Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Database Driver Class Initialized
ERROR - 2018-08-03 07:26:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 07:26:33 --> Model Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Model Class Initialized
DEBUG - 2018-08-03 07:26:33 --> Helper loaded: url_helper
DEBUG - 2018-08-03 07:26:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 07:26:33 --> Final output sent to browser
DEBUG - 2018-08-03 07:26:33 --> Total execution time: 0.0217
DEBUG - 2018-08-03 08:58:15 --> Config Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Hooks Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Utf8 Class Initialized
DEBUG - 2018-08-03 08:58:15 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 08:58:15 --> URI Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Router Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Output Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Security Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Input Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 08:58:15 --> Language Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Loader Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Helper loaded: date_helper
DEBUG - 2018-08-03 08:58:15 --> Controller Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Database Driver Class Initialized
ERROR - 2018-08-03 08:58:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 08:58:15 --> Model Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Model Class Initialized
DEBUG - 2018-08-03 08:58:15 --> Helper loaded: url_helper
DEBUG - 2018-08-03 08:58:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 08:58:15 --> Final output sent to browser
DEBUG - 2018-08-03 08:58:15 --> Total execution time: 0.0215
DEBUG - 2018-08-03 08:59:08 --> Config Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Hooks Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Utf8 Class Initialized
DEBUG - 2018-08-03 08:59:08 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 08:59:08 --> URI Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Router Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Output Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Security Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Input Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 08:59:08 --> Language Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Loader Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Helper loaded: date_helper
DEBUG - 2018-08-03 08:59:08 --> Controller Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Database Driver Class Initialized
ERROR - 2018-08-03 08:59:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 08:59:08 --> Model Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Model Class Initialized
DEBUG - 2018-08-03 08:59:08 --> Helper loaded: url_helper
DEBUG - 2018-08-03 08:59:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 08:59:08 --> Final output sent to browser
DEBUG - 2018-08-03 08:59:08 --> Total execution time: 0.0217
DEBUG - 2018-08-03 08:59:17 --> Config Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Hooks Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Utf8 Class Initialized
DEBUG - 2018-08-03 08:59:17 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 08:59:17 --> URI Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Router Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Output Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Security Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Input Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 08:59:17 --> Language Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Loader Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Helper loaded: date_helper
DEBUG - 2018-08-03 08:59:17 --> Controller Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Database Driver Class Initialized
ERROR - 2018-08-03 08:59:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 08:59:17 --> Model Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Model Class Initialized
DEBUG - 2018-08-03 08:59:17 --> Helper loaded: url_helper
DEBUG - 2018-08-03 08:59:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 08:59:17 --> Final output sent to browser
DEBUG - 2018-08-03 08:59:17 --> Total execution time: 0.0214
DEBUG - 2018-08-03 08:59:45 --> Config Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Utf8 Class Initialized
DEBUG - 2018-08-03 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 08:59:45 --> URI Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Router Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Output Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Security Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Input Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 08:59:45 --> Language Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Loader Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Helper loaded: date_helper
DEBUG - 2018-08-03 08:59:45 --> Controller Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Database Driver Class Initialized
ERROR - 2018-08-03 08:59:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 08:59:45 --> Model Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Model Class Initialized
DEBUG - 2018-08-03 08:59:45 --> Helper loaded: url_helper
DEBUG - 2018-08-03 08:59:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 08:59:45 --> Final output sent to browser
DEBUG - 2018-08-03 08:59:45 --> Total execution time: 0.0211
DEBUG - 2018-08-03 09:46:07 --> Config Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Utf8 Class Initialized
DEBUG - 2018-08-03 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 09:46:07 --> URI Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Router Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Output Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Security Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Input Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 09:46:07 --> Language Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Loader Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Helper loaded: date_helper
DEBUG - 2018-08-03 09:46:07 --> Controller Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Database Driver Class Initialized
ERROR - 2018-08-03 09:46:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 09:46:07 --> Model Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Model Class Initialized
DEBUG - 2018-08-03 09:46:07 --> Helper loaded: url_helper
DEBUG - 2018-08-03 09:46:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 09:46:07 --> Final output sent to browser
DEBUG - 2018-08-03 09:46:07 --> Total execution time: 0.0211
DEBUG - 2018-08-03 09:46:42 --> Config Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Hooks Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Utf8 Class Initialized
DEBUG - 2018-08-03 09:46:42 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 09:46:42 --> URI Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Router Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Output Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Security Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Input Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 09:46:42 --> Language Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Loader Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Helper loaded: date_helper
DEBUG - 2018-08-03 09:46:42 --> Controller Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Database Driver Class Initialized
ERROR - 2018-08-03 09:46:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 09:46:42 --> Model Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Model Class Initialized
DEBUG - 2018-08-03 09:46:42 --> Helper loaded: url_helper
DEBUG - 2018-08-03 09:46:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 09:46:42 --> Final output sent to browser
DEBUG - 2018-08-03 09:46:42 --> Total execution time: 0.0212
DEBUG - 2018-08-03 09:46:50 --> Config Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Hooks Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Utf8 Class Initialized
DEBUG - 2018-08-03 09:46:50 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 09:46:50 --> URI Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Router Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Output Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Security Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Input Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 09:46:50 --> Language Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Loader Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Helper loaded: date_helper
DEBUG - 2018-08-03 09:46:50 --> Controller Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Database Driver Class Initialized
ERROR - 2018-08-03 09:46:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 09:46:50 --> Model Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Model Class Initialized
DEBUG - 2018-08-03 09:46:50 --> Helper loaded: url_helper
DEBUG - 2018-08-03 09:46:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 09:46:50 --> Final output sent to browser
DEBUG - 2018-08-03 09:46:50 --> Total execution time: 0.0219
DEBUG - 2018-08-03 09:47:00 --> Config Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Hooks Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Utf8 Class Initialized
DEBUG - 2018-08-03 09:47:00 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 09:47:00 --> URI Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Router Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Output Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Security Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Input Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 09:47:00 --> Language Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Loader Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Helper loaded: date_helper
DEBUG - 2018-08-03 09:47:00 --> Controller Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Database Driver Class Initialized
ERROR - 2018-08-03 09:47:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 09:47:00 --> Model Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Model Class Initialized
DEBUG - 2018-08-03 09:47:00 --> Helper loaded: url_helper
DEBUG - 2018-08-03 09:47:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 09:47:00 --> Final output sent to browser
DEBUG - 2018-08-03 09:47:00 --> Total execution time: 0.0215
DEBUG - 2018-08-03 10:54:51 --> Config Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Hooks Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Utf8 Class Initialized
DEBUG - 2018-08-03 10:54:51 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 10:54:51 --> URI Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Router Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Output Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Security Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Input Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 10:54:51 --> Language Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Loader Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Helper loaded: date_helper
DEBUG - 2018-08-03 10:54:51 --> Controller Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Database Driver Class Initialized
ERROR - 2018-08-03 10:54:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 10:54:51 --> Model Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Model Class Initialized
DEBUG - 2018-08-03 10:54:51 --> Helper loaded: url_helper
DEBUG - 2018-08-03 10:54:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 10:54:51 --> Final output sent to browser
DEBUG - 2018-08-03 10:54:51 --> Total execution time: 0.0211
DEBUG - 2018-08-03 14:41:07 --> Config Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Hooks Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Utf8 Class Initialized
DEBUG - 2018-08-03 14:41:07 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 14:41:07 --> URI Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Router Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Output Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Security Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Input Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 14:41:07 --> Language Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Loader Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Helper loaded: date_helper
DEBUG - 2018-08-03 14:41:07 --> Controller Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Database Driver Class Initialized
ERROR - 2018-08-03 14:41:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 14:41:07 --> Model Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Model Class Initialized
DEBUG - 2018-08-03 14:41:07 --> Helper loaded: url_helper
DEBUG - 2018-08-03 14:41:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-08-03 14:41:07 --> Final output sent to browser
DEBUG - 2018-08-03 14:41:07 --> Total execution time: 0.0575
DEBUG - 2018-08-03 14:41:12 --> Config Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Hooks Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Utf8 Class Initialized
DEBUG - 2018-08-03 14:41:12 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 14:41:12 --> URI Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Router Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Output Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Security Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Input Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 14:41:12 --> Language Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Loader Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Helper loaded: date_helper
DEBUG - 2018-08-03 14:41:12 --> Controller Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Database Driver Class Initialized
ERROR - 2018-08-03 14:41:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 14:41:12 --> Model Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Model Class Initialized
DEBUG - 2018-08-03 14:41:12 --> Helper loaded: url_helper
DEBUG - 2018-08-03 14:41:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-08-03 14:41:13 --> Final output sent to browser
DEBUG - 2018-08-03 14:41:13 --> Total execution time: 0.0434
DEBUG - 2018-08-03 15:12:06 --> Config Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Hooks Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Utf8 Class Initialized
DEBUG - 2018-08-03 15:12:06 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 15:12:06 --> URI Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Router Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Output Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Security Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Input Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 15:12:06 --> Language Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Loader Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Helper loaded: date_helper
DEBUG - 2018-08-03 15:12:06 --> Controller Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Database Driver Class Initialized
ERROR - 2018-08-03 15:12:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 15:12:06 --> Model Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Model Class Initialized
DEBUG - 2018-08-03 15:12:06 --> Helper loaded: url_helper
DEBUG - 2018-08-03 15:12:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 15:12:06 --> Final output sent to browser
DEBUG - 2018-08-03 15:12:06 --> Total execution time: 0.0215
DEBUG - 2018-08-03 20:58:17 --> Config Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Hooks Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Utf8 Class Initialized
DEBUG - 2018-08-03 20:58:17 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 20:58:17 --> URI Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Router Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Output Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Security Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Input Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 20:58:17 --> Language Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Loader Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Helper loaded: date_helper
DEBUG - 2018-08-03 20:58:17 --> Controller Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Database Driver Class Initialized
ERROR - 2018-08-03 20:58:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 20:58:17 --> Model Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Model Class Initialized
DEBUG - 2018-08-03 20:58:17 --> Helper loaded: url_helper
DEBUG - 2018-08-03 20:58:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 20:58:17 --> Final output sent to browser
DEBUG - 2018-08-03 20:58:17 --> Total execution time: 0.0221
DEBUG - 2018-08-03 21:28:45 --> Config Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Hooks Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Utf8 Class Initialized
DEBUG - 2018-08-03 21:28:45 --> UTF-8 Support Enabled
DEBUG - 2018-08-03 21:28:45 --> URI Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Router Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Output Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Security Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Input Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-03 21:28:45 --> Language Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Loader Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Helper loaded: date_helper
DEBUG - 2018-08-03 21:28:45 --> Controller Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Database Driver Class Initialized
ERROR - 2018-08-03 21:28:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-03 21:28:45 --> Model Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Model Class Initialized
DEBUG - 2018-08-03 21:28:45 --> Helper loaded: url_helper
DEBUG - 2018-08-03 21:28:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-03 21:28:45 --> Final output sent to browser
DEBUG - 2018-08-03 21:28:45 --> Total execution time: 0.0203
