<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-09-15 12:31:45 --> Config Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Hooks Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Utf8 Class Initialized
DEBUG - 2019-09-15 12:31:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-15 12:31:45 --> URI Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Router Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Output Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Security Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Input Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-15 12:31:45 --> Language Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Loader Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Helper loaded: date_helper
DEBUG - 2019-09-15 12:31:45 --> Controller Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Database Driver Class Initialized
ERROR - 2019-09-15 12:31:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-15 12:31:45 --> Model Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Model Class Initialized
DEBUG - 2019-09-15 12:31:45 --> Helper loaded: url_helper
DEBUG - 2019-09-15 12:31:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-15 12:31:45 --> Final output sent to browser
DEBUG - 2019-09-15 12:31:45 --> Total execution time: 0.0462
DEBUG - 2019-09-15 17:19:33 --> Config Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Hooks Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Utf8 Class Initialized
DEBUG - 2019-09-15 17:19:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-15 17:19:33 --> URI Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Router Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Output Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Security Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Input Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-15 17:19:33 --> Language Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Loader Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Helper loaded: date_helper
DEBUG - 2019-09-15 17:19:33 --> Controller Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Database Driver Class Initialized
ERROR - 2019-09-15 17:19:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-15 17:19:33 --> Model Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Model Class Initialized
DEBUG - 2019-09-15 17:19:33 --> Helper loaded: url_helper
DEBUG - 2019-09-15 17:19:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-15 17:19:33 --> Final output sent to browser
DEBUG - 2019-09-15 17:19:33 --> Total execution time: 0.0382
DEBUG - 2019-09-15 19:22:54 --> Config Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Hooks Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Utf8 Class Initialized
DEBUG - 2019-09-15 19:22:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-15 19:22:54 --> URI Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Router Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Output Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Security Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Input Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-15 19:22:54 --> Language Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Loader Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Helper loaded: date_helper
DEBUG - 2019-09-15 19:22:54 --> Controller Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Database Driver Class Initialized
ERROR - 2019-09-15 19:22:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-15 19:22:54 --> Model Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Model Class Initialized
DEBUG - 2019-09-15 19:22:54 --> Helper loaded: url_helper
DEBUG - 2019-09-15 19:22:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-15 19:22:54 --> Final output sent to browser
DEBUG - 2019-09-15 19:22:54 --> Total execution time: 0.0233
