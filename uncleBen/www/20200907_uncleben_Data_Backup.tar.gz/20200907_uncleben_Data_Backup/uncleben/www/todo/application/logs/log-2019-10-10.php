<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-10-10 05:24:23 --> Config Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Hooks Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Utf8 Class Initialized
DEBUG - 2019-10-10 05:24:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 05:24:23 --> URI Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Router Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Output Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Security Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Input Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-10 05:24:23 --> Language Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Loader Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Helper loaded: date_helper
DEBUG - 2019-10-10 05:24:23 --> Controller Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Database Driver Class Initialized
ERROR - 2019-10-10 05:24:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-10 05:24:23 --> Model Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Model Class Initialized
DEBUG - 2019-10-10 05:24:23 --> Helper loaded: url_helper
DEBUG - 2019-10-10 05:24:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-10 05:24:23 --> Final output sent to browser
DEBUG - 2019-10-10 05:24:23 --> Total execution time: 0.2331
DEBUG - 2019-10-10 09:19:51 --> Config Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Hooks Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Utf8 Class Initialized
DEBUG - 2019-10-10 09:19:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 09:19:51 --> URI Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Router Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Output Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Security Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Input Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-10 09:19:51 --> Language Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Loader Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Helper loaded: date_helper
DEBUG - 2019-10-10 09:19:51 --> Controller Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Database Driver Class Initialized
ERROR - 2019-10-10 09:19:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-10 09:19:51 --> Model Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Model Class Initialized
DEBUG - 2019-10-10 09:19:51 --> Helper loaded: url_helper
DEBUG - 2019-10-10 09:19:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-10 09:19:51 --> Final output sent to browser
DEBUG - 2019-10-10 09:19:51 --> Total execution time: 0.1137
DEBUG - 2019-10-10 12:00:43 --> Config Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Hooks Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Utf8 Class Initialized
DEBUG - 2019-10-10 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:00:43 --> URI Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Router Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Output Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Security Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Input Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-10 12:00:43 --> Language Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Loader Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Helper loaded: date_helper
DEBUG - 2019-10-10 12:00:43 --> Controller Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Database Driver Class Initialized
ERROR - 2019-10-10 12:00:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-10 12:00:43 --> Model Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Model Class Initialized
DEBUG - 2019-10-10 12:00:43 --> Helper loaded: url_helper
DEBUG - 2019-10-10 12:00:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-10 12:00:43 --> Final output sent to browser
DEBUG - 2019-10-10 12:00:43 --> Total execution time: 0.1873
DEBUG - 2019-10-10 12:12:46 --> Config Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Hooks Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Utf8 Class Initialized
DEBUG - 2019-10-10 12:12:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:12:46 --> URI Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Router Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Output Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Security Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Input Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-10 12:12:46 --> Language Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Loader Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Helper loaded: date_helper
DEBUG - 2019-10-10 12:12:46 --> Controller Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Database Driver Class Initialized
ERROR - 2019-10-10 12:12:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-10 12:12:46 --> Model Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Model Class Initialized
DEBUG - 2019-10-10 12:12:46 --> Helper loaded: url_helper
DEBUG - 2019-10-10 12:12:46 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-10 12:12:46 --> Final output sent to browser
DEBUG - 2019-10-10 12:12:46 --> Total execution time: 0.1036
DEBUG - 2019-10-10 18:34:44 --> Config Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Hooks Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Utf8 Class Initialized
DEBUG - 2019-10-10 18:34:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:34:44 --> URI Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Router Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Output Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Security Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Input Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-10 18:34:44 --> Language Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Loader Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Helper loaded: date_helper
DEBUG - 2019-10-10 18:34:44 --> Controller Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Database Driver Class Initialized
ERROR - 2019-10-10 18:34:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-10 18:34:44 --> Model Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Model Class Initialized
DEBUG - 2019-10-10 18:34:44 --> Helper loaded: url_helper
DEBUG - 2019-10-10 18:34:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-10 18:34:44 --> Final output sent to browser
DEBUG - 2019-10-10 18:34:44 --> Total execution time: 0.1186
