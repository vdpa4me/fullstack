<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-18 00:23:23 --> Config Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Hooks Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Utf8 Class Initialized
DEBUG - 2017-11-18 00:23:23 --> UTF-8 Support Enabled
DEBUG - 2017-11-18 00:23:23 --> URI Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Router Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Output Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Security Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Input Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-18 00:23:23 --> Language Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Loader Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Helper loaded: date_helper
DEBUG - 2017-11-18 00:23:23 --> Controller Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Database Driver Class Initialized
ERROR - 2017-11-18 00:23:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-18 00:23:23 --> Model Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Model Class Initialized
DEBUG - 2017-11-18 00:23:23 --> Helper loaded: url_helper
DEBUG - 2017-11-18 00:23:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-18 00:23:23 --> Final output sent to browser
DEBUG - 2017-11-18 00:23:23 --> Total execution time: 0.0219
DEBUG - 2017-11-18 03:40:52 --> Config Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Hooks Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Utf8 Class Initialized
DEBUG - 2017-11-18 03:40:52 --> UTF-8 Support Enabled
DEBUG - 2017-11-18 03:40:52 --> URI Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Router Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Output Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Security Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Input Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-18 03:40:52 --> Language Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Loader Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Helper loaded: date_helper
DEBUG - 2017-11-18 03:40:52 --> Controller Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Database Driver Class Initialized
ERROR - 2017-11-18 03:40:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-18 03:40:52 --> Model Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Model Class Initialized
DEBUG - 2017-11-18 03:40:52 --> Helper loaded: url_helper
DEBUG - 2017-11-18 03:40:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-18 03:40:52 --> Final output sent to browser
DEBUG - 2017-11-18 03:40:52 --> Total execution time: 0.0203
DEBUG - 2017-11-18 03:40:53 --> Config Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Hooks Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Utf8 Class Initialized
DEBUG - 2017-11-18 03:40:53 --> UTF-8 Support Enabled
DEBUG - 2017-11-18 03:40:53 --> URI Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Router Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Output Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Security Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Input Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-18 03:40:53 --> Language Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Loader Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Helper loaded: date_helper
DEBUG - 2017-11-18 03:40:53 --> Controller Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Database Driver Class Initialized
ERROR - 2017-11-18 03:40:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-18 03:40:53 --> Model Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Model Class Initialized
DEBUG - 2017-11-18 03:40:53 --> Helper loaded: url_helper
DEBUG - 2017-11-18 03:40:53 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-11-18 03:40:53 --> Final output sent to browser
DEBUG - 2017-11-18 03:40:53 --> Total execution time: 0.0205
DEBUG - 2017-11-18 03:40:54 --> Config Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Hooks Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Utf8 Class Initialized
DEBUG - 2017-11-18 03:40:54 --> UTF-8 Support Enabled
DEBUG - 2017-11-18 03:40:54 --> URI Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Router Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Output Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Security Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Input Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-18 03:40:54 --> Language Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Loader Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Helper loaded: date_helper
DEBUG - 2017-11-18 03:40:54 --> Controller Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Database Driver Class Initialized
ERROR - 2017-11-18 03:40:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-18 03:40:54 --> Model Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Model Class Initialized
DEBUG - 2017-11-18 03:40:54 --> Helper loaded: url_helper
DEBUG - 2017-11-18 03:40:54 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-11-18 03:40:54 --> Final output sent to browser
DEBUG - 2017-11-18 03:40:54 --> Total execution time: 0.0237
DEBUG - 2017-11-18 05:20:25 --> Config Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Hooks Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Utf8 Class Initialized
DEBUG - 2017-11-18 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2017-11-18 05:20:25 --> URI Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Router Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Output Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Security Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Input Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-18 05:20:25 --> Language Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Loader Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Helper loaded: date_helper
DEBUG - 2017-11-18 05:20:25 --> Controller Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Database Driver Class Initialized
ERROR - 2017-11-18 05:20:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-18 05:20:25 --> Model Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Model Class Initialized
DEBUG - 2017-11-18 05:20:25 --> Helper loaded: url_helper
DEBUG - 2017-11-18 05:20:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-18 05:20:25 --> Final output sent to browser
DEBUG - 2017-11-18 05:20:25 --> Total execution time: 0.0376
DEBUG - 2017-11-18 17:07:01 --> Config Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Hooks Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Utf8 Class Initialized
DEBUG - 2017-11-18 17:07:01 --> UTF-8 Support Enabled
DEBUG - 2017-11-18 17:07:01 --> URI Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Router Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Output Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Security Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Input Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-18 17:07:01 --> Language Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Loader Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Helper loaded: date_helper
DEBUG - 2017-11-18 17:07:01 --> Controller Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Database Driver Class Initialized
ERROR - 2017-11-18 17:07:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-18 17:07:01 --> Model Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Model Class Initialized
DEBUG - 2017-11-18 17:07:01 --> Helper loaded: url_helper
DEBUG - 2017-11-18 17:07:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-18 17:07:01 --> Final output sent to browser
DEBUG - 2017-11-18 17:07:01 --> Total execution time: 0.0565
