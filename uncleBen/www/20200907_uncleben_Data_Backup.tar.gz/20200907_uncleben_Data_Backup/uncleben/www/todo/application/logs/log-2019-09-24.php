<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-09-24 04:01:36 --> Config Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Hooks Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Utf8 Class Initialized
DEBUG - 2019-09-24 04:01:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 04:01:36 --> URI Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Router Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Output Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Security Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Input Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 04:01:36 --> Language Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Loader Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Helper loaded: date_helper
DEBUG - 2019-09-24 04:01:36 --> Controller Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Database Driver Class Initialized
ERROR - 2019-09-24 04:01:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 04:01:36 --> Model Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Model Class Initialized
DEBUG - 2019-09-24 04:01:36 --> Helper loaded: url_helper
DEBUG - 2019-09-24 04:01:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 04:01:36 --> Final output sent to browser
DEBUG - 2019-09-24 04:01:36 --> Total execution time: 0.0554
DEBUG - 2019-09-24 08:46:36 --> Config Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Hooks Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Utf8 Class Initialized
DEBUG - 2019-09-24 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 08:46:36 --> URI Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Router Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Output Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Security Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Input Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 08:46:36 --> Language Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Loader Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Helper loaded: date_helper
DEBUG - 2019-09-24 08:46:36 --> Controller Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Database Driver Class Initialized
ERROR - 2019-09-24 08:46:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 08:46:36 --> Model Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Model Class Initialized
DEBUG - 2019-09-24 08:46:36 --> Helper loaded: url_helper
DEBUG - 2019-09-24 08:46:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 08:46:36 --> Final output sent to browser
DEBUG - 2019-09-24 08:46:36 --> Total execution time: 0.0449
DEBUG - 2019-09-24 10:53:52 --> Config Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Hooks Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Utf8 Class Initialized
DEBUG - 2019-09-24 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 10:53:52 --> URI Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Router Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Output Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Security Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Input Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 10:53:52 --> Language Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Loader Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Helper loaded: date_helper
DEBUG - 2019-09-24 10:53:52 --> Controller Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Database Driver Class Initialized
ERROR - 2019-09-24 10:53:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 10:53:52 --> Model Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Model Class Initialized
DEBUG - 2019-09-24 10:53:52 --> Helper loaded: url_helper
DEBUG - 2019-09-24 10:53:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 10:53:52 --> Final output sent to browser
DEBUG - 2019-09-24 10:53:52 --> Total execution time: 0.0248
DEBUG - 2019-09-24 12:12:03 --> Config Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Hooks Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Utf8 Class Initialized
DEBUG - 2019-09-24 12:12:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 12:12:03 --> URI Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Router Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Output Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Security Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Input Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 12:12:03 --> Language Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Loader Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Helper loaded: date_helper
DEBUG - 2019-09-24 12:12:03 --> Controller Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Database Driver Class Initialized
ERROR - 2019-09-24 12:12:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 12:12:03 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Helper loaded: url_helper
DEBUG - 2019-09-24 12:12:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 12:12:03 --> Final output sent to browser
DEBUG - 2019-09-24 12:12:03 --> Total execution time: 0.0206
DEBUG - 2019-09-24 12:12:03 --> Config Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Hooks Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Utf8 Class Initialized
DEBUG - 2019-09-24 12:12:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 12:12:03 --> URI Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Router Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Output Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Security Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Input Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 12:12:03 --> Language Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Loader Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Helper loaded: date_helper
DEBUG - 2019-09-24 12:12:03 --> Controller Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Database Driver Class Initialized
ERROR - 2019-09-24 12:12:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 12:12:03 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:03 --> Helper loaded: url_helper
DEBUG - 2019-09-24 12:12:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 12:12:03 --> Final output sent to browser
DEBUG - 2019-09-24 12:12:03 --> Total execution time: 0.0203
DEBUG - 2019-09-24 12:12:11 --> Config Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Hooks Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Utf8 Class Initialized
DEBUG - 2019-09-24 12:12:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 12:12:11 --> URI Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Router Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Output Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Security Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Input Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 12:12:11 --> Language Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Loader Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Helper loaded: date_helper
DEBUG - 2019-09-24 12:12:11 --> Controller Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Database Driver Class Initialized
ERROR - 2019-09-24 12:12:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 12:12:11 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:11 --> Helper loaded: url_helper
DEBUG - 2019-09-24 12:12:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 12:12:11 --> Final output sent to browser
DEBUG - 2019-09-24 12:12:11 --> Total execution time: 0.0336
DEBUG - 2019-09-24 12:12:29 --> Config Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Hooks Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Utf8 Class Initialized
DEBUG - 2019-09-24 12:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 12:12:29 --> URI Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Router Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Output Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Security Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Input Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 12:12:29 --> Language Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Loader Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Helper loaded: date_helper
DEBUG - 2019-09-24 12:12:29 --> Controller Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Database Driver Class Initialized
ERROR - 2019-09-24 12:12:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 12:12:29 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:29 --> Helper loaded: url_helper
DEBUG - 2019-09-24 12:12:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 12:12:29 --> Final output sent to browser
DEBUG - 2019-09-24 12:12:29 --> Total execution time: 0.0321
DEBUG - 2019-09-24 12:12:45 --> Config Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Hooks Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Utf8 Class Initialized
DEBUG - 2019-09-24 12:12:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 12:12:45 --> URI Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Router Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Output Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Security Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Input Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 12:12:45 --> Language Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Loader Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Helper loaded: date_helper
DEBUG - 2019-09-24 12:12:45 --> Controller Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Database Driver Class Initialized
ERROR - 2019-09-24 12:12:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 12:12:45 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:45 --> Helper loaded: url_helper
DEBUG - 2019-09-24 12:12:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 12:12:45 --> Final output sent to browser
DEBUG - 2019-09-24 12:12:45 --> Total execution time: 0.0308
DEBUG - 2019-09-24 12:12:47 --> Config Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Hooks Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Utf8 Class Initialized
DEBUG - 2019-09-24 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 12:12:47 --> URI Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Router Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Output Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Security Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Input Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 12:12:47 --> Language Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Loader Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Helper loaded: date_helper
DEBUG - 2019-09-24 12:12:47 --> Controller Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Database Driver Class Initialized
ERROR - 2019-09-24 12:12:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 12:12:47 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:47 --> Helper loaded: url_helper
DEBUG - 2019-09-24 12:12:47 --> File loaded: application/views/todo/search_v.php
DEBUG - 2019-09-24 12:12:47 --> Final output sent to browser
DEBUG - 2019-09-24 12:12:47 --> Total execution time: 0.0253
DEBUG - 2019-09-24 12:12:55 --> Config Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Hooks Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Utf8 Class Initialized
DEBUG - 2019-09-24 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 12:12:55 --> URI Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Router Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Output Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Security Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Input Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 12:12:55 --> Language Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Loader Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Helper loaded: date_helper
DEBUG - 2019-09-24 12:12:55 --> Controller Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Database Driver Class Initialized
ERROR - 2019-09-24 12:12:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 12:12:55 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Model Class Initialized
DEBUG - 2019-09-24 12:12:55 --> Helper loaded: url_helper
DEBUG - 2019-09-24 12:12:55 --> File loaded: application/views/todo/search_v.php
DEBUG - 2019-09-24 12:12:55 --> Final output sent to browser
DEBUG - 2019-09-24 12:12:55 --> Total execution time: 0.0210
DEBUG - 2019-09-24 20:24:33 --> Config Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Hooks Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Utf8 Class Initialized
DEBUG - 2019-09-24 20:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 20:24:33 --> URI Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Router Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Output Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Security Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Input Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 20:24:33 --> Language Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Loader Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Helper loaded: date_helper
DEBUG - 2019-09-24 20:24:33 --> Controller Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Database Driver Class Initialized
ERROR - 2019-09-24 20:24:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 20:24:33 --> Model Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Model Class Initialized
DEBUG - 2019-09-24 20:24:33 --> Helper loaded: url_helper
DEBUG - 2019-09-24 20:24:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 20:24:33 --> Final output sent to browser
DEBUG - 2019-09-24 20:24:33 --> Total execution time: 0.0453
DEBUG - 2019-09-24 23:57:29 --> Config Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Hooks Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Utf8 Class Initialized
DEBUG - 2019-09-24 23:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-24 23:57:29 --> URI Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Router Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Output Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Security Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Input Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-24 23:57:29 --> Language Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Loader Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Helper loaded: date_helper
DEBUG - 2019-09-24 23:57:29 --> Controller Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Database Driver Class Initialized
ERROR - 2019-09-24 23:57:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-24 23:57:29 --> Model Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Model Class Initialized
DEBUG - 2019-09-24 23:57:29 --> Helper loaded: url_helper
DEBUG - 2019-09-24 23:57:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-24 23:57:29 --> Final output sent to browser
DEBUG - 2019-09-24 23:57:29 --> Total execution time: 0.0280
