<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-07-17 04:29:54 --> Config Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Utf8 Class Initialized
DEBUG - 2018-07-17 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 04:29:54 --> URI Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Router Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Output Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Security Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Input Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 04:29:54 --> Language Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Loader Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Helper loaded: date_helper
DEBUG - 2018-07-17 04:29:54 --> Controller Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Database Driver Class Initialized
ERROR - 2018-07-17 04:29:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 04:29:54 --> Model Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Model Class Initialized
DEBUG - 2018-07-17 04:29:54 --> Helper loaded: url_helper
DEBUG - 2018-07-17 04:29:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 04:29:54 --> Final output sent to browser
DEBUG - 2018-07-17 04:29:54 --> Total execution time: 0.0250
DEBUG - 2018-07-17 07:53:32 --> Config Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Hooks Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Utf8 Class Initialized
DEBUG - 2018-07-17 07:53:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 07:53:32 --> URI Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Router Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Output Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Security Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Input Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 07:53:32 --> Language Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Loader Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Helper loaded: date_helper
DEBUG - 2018-07-17 07:53:32 --> Controller Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Database Driver Class Initialized
ERROR - 2018-07-17 07:53:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 07:53:32 --> Model Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Model Class Initialized
DEBUG - 2018-07-17 07:53:32 --> Helper loaded: url_helper
DEBUG - 2018-07-17 07:53:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 07:53:32 --> Final output sent to browser
DEBUG - 2018-07-17 07:53:32 --> Total execution time: 0.0283
DEBUG - 2018-07-17 16:13:39 --> Config Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Hooks Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Utf8 Class Initialized
DEBUG - 2018-07-17 16:13:39 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 16:13:39 --> URI Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Router Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Output Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Security Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Input Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 16:13:39 --> Language Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Loader Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Helper loaded: date_helper
DEBUG - 2018-07-17 16:13:39 --> Controller Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Database Driver Class Initialized
ERROR - 2018-07-17 16:13:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 16:13:39 --> Model Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Model Class Initialized
DEBUG - 2018-07-17 16:13:39 --> Helper loaded: url_helper
DEBUG - 2018-07-17 16:13:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 16:13:39 --> Final output sent to browser
DEBUG - 2018-07-17 16:13:39 --> Total execution time: 0.0260
DEBUG - 2018-07-17 17:01:25 --> Config Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Hooks Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Utf8 Class Initialized
DEBUG - 2018-07-17 17:01:25 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 17:01:25 --> URI Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Router Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Output Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Security Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Input Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 17:01:25 --> Language Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Loader Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Helper loaded: date_helper
DEBUG - 2018-07-17 17:01:25 --> Controller Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Database Driver Class Initialized
ERROR - 2018-07-17 17:01:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 17:01:25 --> Model Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Model Class Initialized
DEBUG - 2018-07-17 17:01:25 --> Helper loaded: url_helper
DEBUG - 2018-07-17 17:01:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 17:01:25 --> Final output sent to browser
DEBUG - 2018-07-17 17:01:25 --> Total execution time: 0.0208
DEBUG - 2018-07-17 20:29:09 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:09 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:09 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:09 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:09 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:09 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:09 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 20:29:09 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:09 --> Total execution time: 0.0222
DEBUG - 2018-07-17 20:29:32 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:32 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:32 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:32 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:32 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:32 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 20:29:32 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:32 --> Total execution time: 0.0210
DEBUG - 2018-07-17 20:29:33 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:33 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:33 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:33 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:33 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:33 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:34 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-07-17 20:29:34 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:34 --> Total execution time: 0.0252
DEBUG - 2018-07-17 20:29:35 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:35 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:35 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:35 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:35 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:35 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:35 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:35 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-07-17 20:29:35 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:35 --> Total execution time: 0.0212
DEBUG - 2018-07-17 20:29:41 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:41 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:41 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:41 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:41 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:41 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:41 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:41 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-07-17 20:29:41 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:41 --> Total execution time: 0.0201
DEBUG - 2018-07-17 20:29:46 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:46 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:46 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:46 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:46 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:46 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:46 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:46 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-07-17 20:29:46 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:46 --> Total execution time: 0.0218
DEBUG - 2018-07-17 20:29:49 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:49 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:49 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:49 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:49 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:49 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:49 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:49 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 20:29:49 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:49 --> Total execution time: 0.0207
DEBUG - 2018-07-17 20:29:55 --> Config Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:29:55 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:29:55 --> URI Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Router Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Output Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Security Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Input Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:29:55 --> Language Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Loader Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:29:55 --> Controller Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:29:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:29:55 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Model Class Initialized
DEBUG - 2018-07-17 20:29:55 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:29:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 20:29:55 --> Final output sent to browser
DEBUG - 2018-07-17 20:29:55 --> Total execution time: 0.0210
DEBUG - 2018-07-17 20:30:00 --> Config Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:30:00 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:30:00 --> URI Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Router Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Output Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Security Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Input Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:30:00 --> Language Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Loader Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:30:00 --> Controller Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:30:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:30:00 --> Model Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Model Class Initialized
DEBUG - 2018-07-17 20:30:00 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:30:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-17 20:30:00 --> Final output sent to browser
DEBUG - 2018-07-17 20:30:00 --> Total execution time: 0.0212
DEBUG - 2018-07-17 20:30:04 --> Config Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Hooks Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Utf8 Class Initialized
DEBUG - 2018-07-17 20:30:04 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 20:30:04 --> URI Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Router Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Output Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Security Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Input Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-17 20:30:04 --> Language Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Loader Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Helper loaded: date_helper
DEBUG - 2018-07-17 20:30:04 --> Controller Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Database Driver Class Initialized
ERROR - 2018-07-17 20:30:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-17 20:30:04 --> Model Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Model Class Initialized
DEBUG - 2018-07-17 20:30:04 --> Helper loaded: url_helper
DEBUG - 2018-07-17 20:30:04 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-07-17 20:30:04 --> Final output sent to browser
DEBUG - 2018-07-17 20:30:04 --> Total execution time: 0.0212
