<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-10-03 02:57:34 --> Config Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Hooks Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Utf8 Class Initialized
DEBUG - 2018-10-03 02:57:34 --> UTF-8 Support Enabled
DEBUG - 2018-10-03 02:57:34 --> URI Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Router Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Output Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Security Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Input Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-03 02:57:34 --> Language Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Loader Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Helper loaded: date_helper
DEBUG - 2018-10-03 02:57:34 --> Controller Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Database Driver Class Initialized
ERROR - 2018-10-03 02:57:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-03 02:57:34 --> Model Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Model Class Initialized
DEBUG - 2018-10-03 02:57:34 --> Helper loaded: url_helper
DEBUG - 2018-10-03 02:57:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-03 02:57:34 --> Final output sent to browser
DEBUG - 2018-10-03 02:57:34 --> Total execution time: 0.0872
DEBUG - 2018-10-03 04:32:28 --> Config Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Hooks Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Utf8 Class Initialized
DEBUG - 2018-10-03 04:32:28 --> UTF-8 Support Enabled
DEBUG - 2018-10-03 04:32:28 --> URI Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Router Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Output Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Security Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Input Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-03 04:32:28 --> Language Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Loader Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Helper loaded: date_helper
DEBUG - 2018-10-03 04:32:28 --> Controller Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Database Driver Class Initialized
ERROR - 2018-10-03 04:32:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-03 04:32:28 --> Model Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Model Class Initialized
DEBUG - 2018-10-03 04:32:28 --> Helper loaded: url_helper
DEBUG - 2018-10-03 04:32:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-03 04:32:28 --> Final output sent to browser
DEBUG - 2018-10-03 04:32:28 --> Total execution time: 0.0575
DEBUG - 2018-10-03 08:29:49 --> Config Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Hooks Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Utf8 Class Initialized
DEBUG - 2018-10-03 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2018-10-03 08:29:49 --> URI Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Router Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Output Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Security Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Input Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-03 08:29:49 --> Language Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Loader Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Helper loaded: date_helper
DEBUG - 2018-10-03 08:29:49 --> Controller Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Database Driver Class Initialized
ERROR - 2018-10-03 08:29:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-03 08:29:49 --> Model Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Model Class Initialized
DEBUG - 2018-10-03 08:29:49 --> Helper loaded: url_helper
DEBUG - 2018-10-03 08:29:49 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-03 08:29:49 --> Final output sent to browser
DEBUG - 2018-10-03 08:29:49 --> Total execution time: 0.0386
DEBUG - 2018-10-03 16:45:58 --> Config Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Hooks Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Utf8 Class Initialized
DEBUG - 2018-10-03 16:45:58 --> UTF-8 Support Enabled
DEBUG - 2018-10-03 16:45:58 --> URI Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Router Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Output Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Security Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Input Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-03 16:45:58 --> Language Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Loader Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Helper loaded: date_helper
DEBUG - 2018-10-03 16:45:58 --> Controller Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Database Driver Class Initialized
ERROR - 2018-10-03 16:45:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-03 16:45:58 --> Model Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Model Class Initialized
DEBUG - 2018-10-03 16:45:58 --> Helper loaded: url_helper
DEBUG - 2018-10-03 16:45:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-03 16:45:58 --> Final output sent to browser
DEBUG - 2018-10-03 16:45:58 --> Total execution time: 0.0380
DEBUG - 2018-10-03 19:33:38 --> Config Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Hooks Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Utf8 Class Initialized
DEBUG - 2018-10-03 19:33:38 --> UTF-8 Support Enabled
DEBUG - 2018-10-03 19:33:38 --> URI Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Router Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Output Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Security Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Input Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-03 19:33:38 --> Language Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Loader Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Helper loaded: date_helper
DEBUG - 2018-10-03 19:33:38 --> Controller Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Database Driver Class Initialized
ERROR - 2018-10-03 19:33:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-03 19:33:38 --> Model Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Model Class Initialized
DEBUG - 2018-10-03 19:33:38 --> Helper loaded: url_helper
DEBUG - 2018-10-03 19:33:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-03 19:33:38 --> Final output sent to browser
DEBUG - 2018-10-03 19:33:38 --> Total execution time: 0.0331
DEBUG - 2018-10-03 21:29:32 --> Config Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Hooks Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Utf8 Class Initialized
DEBUG - 2018-10-03 21:29:32 --> UTF-8 Support Enabled
DEBUG - 2018-10-03 21:29:32 --> URI Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Router Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Output Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Security Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Input Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-03 21:29:32 --> Language Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Loader Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Helper loaded: date_helper
DEBUG - 2018-10-03 21:29:32 --> Controller Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Database Driver Class Initialized
ERROR - 2018-10-03 21:29:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-03 21:29:32 --> Model Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Model Class Initialized
DEBUG - 2018-10-03 21:29:32 --> Helper loaded: url_helper
DEBUG - 2018-10-03 21:29:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-03 21:29:32 --> Final output sent to browser
DEBUG - 2018-10-03 21:29:32 --> Total execution time: 0.0222
