<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-06-11 02:08:53 --> Config Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Hooks Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Utf8 Class Initialized
DEBUG - 2020-06-11 02:08:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-11 02:08:53 --> URI Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Router Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Output Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Security Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Input Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-11 02:08:53 --> Language Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Loader Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Helper loaded: date_helper
DEBUG - 2020-06-11 02:08:53 --> Controller Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Database Driver Class Initialized
ERROR - 2020-06-11 02:08:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-11 02:08:53 --> Model Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Model Class Initialized
DEBUG - 2020-06-11 02:08:53 --> Helper loaded: url_helper
DEBUG - 2020-06-11 02:08:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-11 02:08:53 --> Final output sent to browser
DEBUG - 2020-06-11 02:08:53 --> Total execution time: 0.0899
DEBUG - 2020-06-11 14:00:14 --> Config Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Hooks Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Utf8 Class Initialized
DEBUG - 2020-06-11 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-11 14:00:14 --> URI Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Router Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Output Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Security Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Input Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-11 14:00:14 --> Language Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Loader Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Helper loaded: date_helper
DEBUG - 2020-06-11 14:00:14 --> Controller Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Database Driver Class Initialized
ERROR - 2020-06-11 14:00:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-11 14:00:14 --> Model Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Model Class Initialized
DEBUG - 2020-06-11 14:00:14 --> Helper loaded: url_helper
DEBUG - 2020-06-11 14:00:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-11 14:00:14 --> Final output sent to browser
DEBUG - 2020-06-11 14:00:14 --> Total execution time: 0.2041
DEBUG - 2020-06-11 22:08:00 --> Config Class Initialized
DEBUG - 2020-06-11 22:08:00 --> Hooks Class Initialized
DEBUG - 2020-06-11 22:08:00 --> Utf8 Class Initialized
DEBUG - 2020-06-11 22:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-11 22:08:00 --> URI Class Initialized
DEBUG - 2020-06-11 22:08:00 --> Router Class Initialized
DEBUG - 2020-06-11 22:08:00 --> Output Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Security Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Input Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-11 22:08:01 --> Language Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Loader Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Helper loaded: date_helper
DEBUG - 2020-06-11 22:08:01 --> Controller Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Database Driver Class Initialized
ERROR - 2020-06-11 22:08:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-11 22:08:01 --> Model Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Model Class Initialized
DEBUG - 2020-06-11 22:08:01 --> Helper loaded: url_helper
DEBUG - 2020-06-11 22:08:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-11 22:08:01 --> Final output sent to browser
DEBUG - 2020-06-11 22:08:01 --> Total execution time: 0.2134
DEBUG - 2020-06-11 22:29:36 --> Config Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Hooks Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Utf8 Class Initialized
DEBUG - 2020-06-11 22:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-11 22:29:36 --> URI Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Router Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Output Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Security Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Input Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-11 22:29:36 --> Language Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Loader Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Helper loaded: date_helper
DEBUG - 2020-06-11 22:29:36 --> Controller Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Database Driver Class Initialized
ERROR - 2020-06-11 22:29:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-11 22:29:36 --> Model Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Model Class Initialized
DEBUG - 2020-06-11 22:29:36 --> Helper loaded: url_helper
DEBUG - 2020-06-11 22:29:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-11 22:29:36 --> Final output sent to browser
DEBUG - 2020-06-11 22:29:36 --> Total execution time: 0.1092
DEBUG - 2020-06-11 22:33:14 --> Config Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Hooks Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Utf8 Class Initialized
DEBUG - 2020-06-11 22:33:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-11 22:33:14 --> URI Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Router Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Output Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Security Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Input Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-11 22:33:14 --> Language Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Loader Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Helper loaded: date_helper
DEBUG - 2020-06-11 22:33:14 --> Controller Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Database Driver Class Initialized
ERROR - 2020-06-11 22:33:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-11 22:33:14 --> Model Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Model Class Initialized
DEBUG - 2020-06-11 22:33:14 --> Helper loaded: url_helper
DEBUG - 2020-06-11 22:33:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-11 22:33:14 --> Final output sent to browser
DEBUG - 2020-06-11 22:33:14 --> Total execution time: 0.1034
DEBUG - 2020-06-11 22:36:37 --> Config Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Hooks Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Utf8 Class Initialized
DEBUG - 2020-06-11 22:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-11 22:36:37 --> URI Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Router Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Output Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Security Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Input Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-11 22:36:37 --> Language Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Loader Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Helper loaded: date_helper
DEBUG - 2020-06-11 22:36:37 --> Controller Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Database Driver Class Initialized
ERROR - 2020-06-11 22:36:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-11 22:36:37 --> Model Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Model Class Initialized
DEBUG - 2020-06-11 22:36:37 --> Helper loaded: url_helper
DEBUG - 2020-06-11 22:36:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-11 22:36:37 --> Final output sent to browser
DEBUG - 2020-06-11 22:36:37 --> Total execution time: 0.1013
