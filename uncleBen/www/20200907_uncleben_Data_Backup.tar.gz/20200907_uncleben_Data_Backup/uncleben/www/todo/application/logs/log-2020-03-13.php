<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-03-13 11:41:24 --> Config Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Hooks Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Utf8 Class Initialized
DEBUG - 2020-03-13 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-13 11:41:24 --> URI Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Router Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Output Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Security Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Input Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2020-03-13 11:41:24 --> Language Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Loader Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Helper loaded: date_helper
DEBUG - 2020-03-13 11:41:24 --> Controller Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Database Driver Class Initialized
ERROR - 2020-03-13 11:41:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-03-13 11:41:24 --> Model Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Model Class Initialized
DEBUG - 2020-03-13 11:41:24 --> Helper loaded: url_helper
DEBUG - 2020-03-13 11:41:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-03-13 11:41:24 --> Final output sent to browser
DEBUG - 2020-03-13 11:41:24 --> Total execution time: 0.2034
DEBUG - 2020-03-13 11:41:28 --> Config Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Hooks Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Utf8 Class Initialized
DEBUG - 2020-03-13 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-13 11:41:28 --> URI Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Router Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Output Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Security Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Input Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2020-03-13 11:41:28 --> Language Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Loader Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Helper loaded: date_helper
DEBUG - 2020-03-13 11:41:28 --> Controller Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Database Driver Class Initialized
ERROR - 2020-03-13 11:41:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-03-13 11:41:28 --> Model Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Model Class Initialized
DEBUG - 2020-03-13 11:41:28 --> Helper loaded: url_helper
DEBUG - 2020-03-13 11:41:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-03-13 11:41:28 --> Final output sent to browser
DEBUG - 2020-03-13 11:41:28 --> Total execution time: 0.0750
DEBUG - 2020-03-13 15:23:27 --> Config Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Hooks Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Utf8 Class Initialized
DEBUG - 2020-03-13 15:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-13 15:23:27 --> URI Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Router Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Output Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Security Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Input Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2020-03-13 15:23:27 --> Language Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Loader Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Helper loaded: date_helper
DEBUG - 2020-03-13 15:23:27 --> Controller Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Database Driver Class Initialized
ERROR - 2020-03-13 15:23:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-03-13 15:23:27 --> Model Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Model Class Initialized
DEBUG - 2020-03-13 15:23:27 --> Helper loaded: url_helper
DEBUG - 2020-03-13 15:23:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-03-13 15:23:27 --> Final output sent to browser
DEBUG - 2020-03-13 15:23:27 --> Total execution time: 0.1759
