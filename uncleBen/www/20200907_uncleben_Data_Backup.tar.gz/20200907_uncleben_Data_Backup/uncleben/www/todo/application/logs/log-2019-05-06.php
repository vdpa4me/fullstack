<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-06 05:58:43 --> Config Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Hooks Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Utf8 Class Initialized
DEBUG - 2019-05-06 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2019-05-06 05:58:43 --> URI Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Router Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Output Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Security Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Input Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-06 05:58:43 --> Language Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Loader Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Helper loaded: date_helper
DEBUG - 2019-05-06 05:58:43 --> Controller Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Database Driver Class Initialized
ERROR - 2019-05-06 05:58:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-06 05:58:43 --> Model Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Model Class Initialized
DEBUG - 2019-05-06 05:58:43 --> Helper loaded: url_helper
DEBUG - 2019-05-06 05:58:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-06 05:58:43 --> Final output sent to browser
DEBUG - 2019-05-06 05:58:43 --> Total execution time: 0.0374
DEBUG - 2019-05-06 10:08:16 --> Config Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Hooks Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Utf8 Class Initialized
DEBUG - 2019-05-06 10:08:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-06 10:08:16 --> URI Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Router Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Output Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Security Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Input Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-06 10:08:16 --> Language Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Loader Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Helper loaded: date_helper
DEBUG - 2019-05-06 10:08:16 --> Controller Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Database Driver Class Initialized
ERROR - 2019-05-06 10:08:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-06 10:08:16 --> Model Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Model Class Initialized
DEBUG - 2019-05-06 10:08:16 --> Helper loaded: url_helper
DEBUG - 2019-05-06 10:08:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-06 10:08:16 --> Final output sent to browser
DEBUG - 2019-05-06 10:08:16 --> Total execution time: 0.0346
DEBUG - 2019-05-06 15:28:24 --> Config Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Hooks Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Utf8 Class Initialized
DEBUG - 2019-05-06 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2019-05-06 15:28:24 --> URI Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Router Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Output Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Security Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Input Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-06 15:28:24 --> Language Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Loader Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Helper loaded: date_helper
DEBUG - 2019-05-06 15:28:24 --> Controller Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Database Driver Class Initialized
ERROR - 2019-05-06 15:28:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-06 15:28:24 --> Model Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Model Class Initialized
DEBUG - 2019-05-06 15:28:24 --> Helper loaded: url_helper
DEBUG - 2019-05-06 15:28:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-06 15:28:24 --> Final output sent to browser
DEBUG - 2019-05-06 15:28:24 --> Total execution time: 0.0334
