<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-11 00:54:27 --> Config Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Hooks Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Utf8 Class Initialized
DEBUG - 2018-12-11 00:54:27 --> UTF-8 Support Enabled
DEBUG - 2018-12-11 00:54:27 --> URI Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Router Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Output Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Security Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Input Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-11 00:54:27 --> Language Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Loader Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Helper loaded: date_helper
DEBUG - 2018-12-11 00:54:27 --> Controller Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Database Driver Class Initialized
ERROR - 2018-12-11 00:54:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-11 00:54:27 --> Model Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Model Class Initialized
DEBUG - 2018-12-11 00:54:27 --> Helper loaded: url_helper
DEBUG - 2018-12-11 00:54:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-11 00:54:27 --> Final output sent to browser
DEBUG - 2018-12-11 00:54:27 --> Total execution time: 0.0386
DEBUG - 2018-12-11 04:00:41 --> Config Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Hooks Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Utf8 Class Initialized
DEBUG - 2018-12-11 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2018-12-11 04:00:41 --> URI Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Router Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Output Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Security Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Input Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-11 04:00:41 --> Language Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Loader Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Helper loaded: date_helper
DEBUG - 2018-12-11 04:00:41 --> Controller Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Database Driver Class Initialized
ERROR - 2018-12-11 04:00:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-11 04:00:41 --> Model Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Model Class Initialized
DEBUG - 2018-12-11 04:00:41 --> Helper loaded: url_helper
DEBUG - 2018-12-11 04:00:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-11 04:00:41 --> Final output sent to browser
DEBUG - 2018-12-11 04:00:41 --> Total execution time: 0.0227
DEBUG - 2018-12-11 16:10:43 --> Config Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Hooks Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Utf8 Class Initialized
DEBUG - 2018-12-11 16:10:43 --> UTF-8 Support Enabled
DEBUG - 2018-12-11 16:10:43 --> URI Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Router Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Output Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Security Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Input Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-11 16:10:43 --> Language Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Loader Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Helper loaded: date_helper
DEBUG - 2018-12-11 16:10:43 --> Controller Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Database Driver Class Initialized
ERROR - 2018-12-11 16:10:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-11 16:10:43 --> Model Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Model Class Initialized
DEBUG - 2018-12-11 16:10:43 --> Helper loaded: url_helper
DEBUG - 2018-12-11 16:10:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-11 16:10:43 --> Final output sent to browser
DEBUG - 2018-12-11 16:10:43 --> Total execution time: 0.0441
DEBUG - 2018-12-11 17:22:18 --> Config Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Hooks Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Utf8 Class Initialized
DEBUG - 2018-12-11 17:22:18 --> UTF-8 Support Enabled
DEBUG - 2018-12-11 17:22:18 --> URI Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Router Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Output Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Security Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Input Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-11 17:22:18 --> Language Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Loader Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Helper loaded: date_helper
DEBUG - 2018-12-11 17:22:18 --> Controller Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Database Driver Class Initialized
ERROR - 2018-12-11 17:22:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-11 17:22:18 --> Model Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Model Class Initialized
DEBUG - 2018-12-11 17:22:18 --> Helper loaded: url_helper
DEBUG - 2018-12-11 17:22:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-11 17:22:18 --> Final output sent to browser
DEBUG - 2018-12-11 17:22:18 --> Total execution time: 0.0971
DEBUG - 2018-12-11 17:22:22 --> Config Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Hooks Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Utf8 Class Initialized
DEBUG - 2018-12-11 17:22:22 --> UTF-8 Support Enabled
DEBUG - 2018-12-11 17:22:22 --> URI Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Router Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Output Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Security Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Input Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-11 17:22:22 --> Language Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Loader Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Helper loaded: date_helper
DEBUG - 2018-12-11 17:22:22 --> Controller Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Database Driver Class Initialized
ERROR - 2018-12-11 17:22:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-11 17:22:22 --> Model Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Model Class Initialized
DEBUG - 2018-12-11 17:22:22 --> Helper loaded: url_helper
DEBUG - 2018-12-11 17:22:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-11 17:22:22 --> Final output sent to browser
DEBUG - 2018-12-11 17:22:22 --> Total execution time: 0.0539
DEBUG - 2018-12-11 18:28:18 --> Config Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Hooks Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Utf8 Class Initialized
DEBUG - 2018-12-11 18:28:18 --> UTF-8 Support Enabled
DEBUG - 2018-12-11 18:28:18 --> URI Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Router Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Output Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Security Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Input Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-11 18:28:18 --> Language Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Loader Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Helper loaded: date_helper
DEBUG - 2018-12-11 18:28:18 --> Controller Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Database Driver Class Initialized
ERROR - 2018-12-11 18:28:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-11 18:28:18 --> Model Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Model Class Initialized
DEBUG - 2018-12-11 18:28:18 --> Helper loaded: url_helper
DEBUG - 2018-12-11 18:28:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-11 18:28:18 --> Final output sent to browser
DEBUG - 2018-12-11 18:28:18 --> Total execution time: 0.0227
DEBUG - 2018-12-11 19:48:25 --> Config Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Hooks Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Utf8 Class Initialized
DEBUG - 2018-12-11 19:48:25 --> UTF-8 Support Enabled
DEBUG - 2018-12-11 19:48:25 --> URI Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Router Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Output Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Security Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Input Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-11 19:48:25 --> Language Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Loader Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Helper loaded: date_helper
DEBUG - 2018-12-11 19:48:25 --> Controller Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Database Driver Class Initialized
ERROR - 2018-12-11 19:48:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-11 19:48:25 --> Model Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Model Class Initialized
DEBUG - 2018-12-11 19:48:25 --> Helper loaded: url_helper
DEBUG - 2018-12-11 19:48:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-11 19:48:25 --> Final output sent to browser
DEBUG - 2018-12-11 19:48:25 --> Total execution time: 0.0317
