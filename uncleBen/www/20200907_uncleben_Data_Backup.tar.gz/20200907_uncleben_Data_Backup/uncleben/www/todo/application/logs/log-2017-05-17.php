<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-17 00:00:34 --> Config Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:00:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:00:34 --> URI Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Router Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Output Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Security Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Input Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:00:34 --> Language Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Loader Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:00:34 --> Controller Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:00:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:00:34 --> Model Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Model Class Initialized
DEBUG - 2017-05-17 00:00:34 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:00:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:00:34 --> Final output sent to browser
DEBUG - 2017-05-17 00:00:34 --> Total execution time: 0.0406
DEBUG - 2017-05-17 00:01:03 --> Config Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:01:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:01:03 --> URI Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Router Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Output Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Security Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Input Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:01:03 --> Language Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Loader Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:01:03 --> Controller Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:01:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:01:03 --> Model Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Model Class Initialized
DEBUG - 2017-05-17 00:01:03 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:01:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:01:03 --> Final output sent to browser
DEBUG - 2017-05-17 00:01:03 --> Total execution time: 0.0302
DEBUG - 2017-05-17 00:01:43 --> Config Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:01:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:01:43 --> URI Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Router Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Output Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Security Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Input Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:01:43 --> Language Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Loader Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:01:43 --> Controller Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:01:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:01:43 --> Model Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Model Class Initialized
DEBUG - 2017-05-17 00:01:43 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:01:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:01:43 --> Final output sent to browser
DEBUG - 2017-05-17 00:01:43 --> Total execution time: 0.0316
DEBUG - 2017-05-17 00:02:02 --> Config Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:02:02 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:02:02 --> URI Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Router Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Output Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Security Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Input Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:02:02 --> Language Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Loader Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:02:02 --> Controller Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:02:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:02:02 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:02 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:02:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:02:02 --> Final output sent to browser
DEBUG - 2017-05-17 00:02:02 --> Total execution time: 0.0305
DEBUG - 2017-05-17 00:02:08 --> Config Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:02:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:02:08 --> URI Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Router Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Output Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Security Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Input Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:02:08 --> Language Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Loader Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:02:08 --> Controller Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:02:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:02:08 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:08 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:02:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:02:08 --> Final output sent to browser
DEBUG - 2017-05-17 00:02:08 --> Total execution time: 0.0302
DEBUG - 2017-05-17 00:02:17 --> Config Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:02:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:02:17 --> URI Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Router Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Output Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Security Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Input Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:02:17 --> Language Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Loader Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:02:17 --> Controller Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:02:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:02:17 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:17 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:02:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:02:17 --> Final output sent to browser
DEBUG - 2017-05-17 00:02:17 --> Total execution time: 0.0306
DEBUG - 2017-05-17 00:02:34 --> Config Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:02:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:02:34 --> URI Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Router Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Output Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Security Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Input Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:02:34 --> Language Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Loader Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:02:34 --> Controller Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:02:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:02:34 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:34 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:02:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:02:34 --> Final output sent to browser
DEBUG - 2017-05-17 00:02:34 --> Total execution time: 0.0300
DEBUG - 2017-05-17 00:02:49 --> Config Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:02:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:02:49 --> URI Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Router Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Output Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Security Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Input Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:02:49 --> Language Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Loader Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:02:49 --> Controller Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:02:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:02:49 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Model Class Initialized
DEBUG - 2017-05-17 00:02:49 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:02:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:02:49 --> Final output sent to browser
DEBUG - 2017-05-17 00:02:49 --> Total execution time: 0.0305
DEBUG - 2017-05-17 00:03:01 --> Config Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:03:01 --> URI Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Router Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Output Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Security Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Input Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:03:01 --> Language Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Loader Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:03:01 --> Controller Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:03:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:03:01 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:01 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:03:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:03:01 --> Final output sent to browser
DEBUG - 2017-05-17 00:03:01 --> Total execution time: 0.0299
DEBUG - 2017-05-17 00:03:19 --> Config Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:03:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:03:19 --> URI Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Router Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Output Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Security Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Input Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:03:19 --> Language Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Loader Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:03:19 --> Controller Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:03:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:03:19 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:19 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:03:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:03:19 --> Final output sent to browser
DEBUG - 2017-05-17 00:03:19 --> Total execution time: 0.0299
DEBUG - 2017-05-17 00:03:26 --> Config Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:03:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:03:26 --> URI Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Router Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Output Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Security Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Input Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:03:26 --> Language Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Loader Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:03:26 --> Controller Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:03:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:03:26 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:26 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:03:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:03:26 --> Final output sent to browser
DEBUG - 2017-05-17 00:03:26 --> Total execution time: 0.0301
DEBUG - 2017-05-17 00:03:36 --> Config Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:03:36 --> URI Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Router Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Output Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Security Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Input Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:03:36 --> Language Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Loader Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:03:36 --> Controller Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:03:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:03:36 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:36 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:03:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:03:36 --> Final output sent to browser
DEBUG - 2017-05-17 00:03:36 --> Total execution time: 0.0301
DEBUG - 2017-05-17 00:03:48 --> Config Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:03:48 --> URI Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Router Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Output Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Security Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Input Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:03:48 --> Language Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Loader Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:03:48 --> Controller Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:03:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:03:48 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Model Class Initialized
DEBUG - 2017-05-17 00:03:48 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:03:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:03:48 --> Final output sent to browser
DEBUG - 2017-05-17 00:03:48 --> Total execution time: 0.0303
DEBUG - 2017-05-17 00:05:17 --> Config Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:05:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:05:17 --> URI Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Router Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Output Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Security Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Input Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:05:17 --> Language Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Loader Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:05:17 --> Controller Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:05:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:05:17 --> Model Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Model Class Initialized
DEBUG - 2017-05-17 00:05:17 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:05:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:05:17 --> Final output sent to browser
DEBUG - 2017-05-17 00:05:17 --> Total execution time: 0.0314
DEBUG - 2017-05-17 00:09:23 --> Config Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Hooks Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Utf8 Class Initialized
DEBUG - 2017-05-17 00:09:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 00:09:23 --> URI Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Router Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Output Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Security Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Input Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 00:09:23 --> Language Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Loader Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Helper loaded: date_helper
DEBUG - 2017-05-17 00:09:23 --> Controller Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Database Driver Class Initialized
ERROR - 2017-05-17 00:09:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 00:09:23 --> Model Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Model Class Initialized
DEBUG - 2017-05-17 00:09:23 --> Helper loaded: url_helper
DEBUG - 2017-05-17 00:09:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 00:09:23 --> Final output sent to browser
DEBUG - 2017-05-17 00:09:23 --> Total execution time: 0.0312
DEBUG - 2017-05-17 01:34:55 --> Config Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Hooks Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Utf8 Class Initialized
DEBUG - 2017-05-17 01:34:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 01:34:55 --> URI Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Router Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Output Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Security Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Input Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 01:34:55 --> Language Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Loader Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Helper loaded: date_helper
DEBUG - 2017-05-17 01:34:55 --> Controller Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Database Driver Class Initialized
ERROR - 2017-05-17 01:34:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 01:34:55 --> Model Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Model Class Initialized
DEBUG - 2017-05-17 01:34:55 --> Helper loaded: url_helper
DEBUG - 2017-05-17 01:34:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 01:34:55 --> Final output sent to browser
DEBUG - 2017-05-17 01:34:55 --> Total execution time: 0.0373
DEBUG - 2017-05-17 03:44:53 --> Config Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Hooks Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Utf8 Class Initialized
DEBUG - 2017-05-17 03:44:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 03:44:53 --> URI Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Router Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Output Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Security Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Input Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 03:44:53 --> Language Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Loader Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Helper loaded: date_helper
DEBUG - 2017-05-17 03:44:53 --> Controller Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Database Driver Class Initialized
ERROR - 2017-05-17 03:44:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 03:44:53 --> Model Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Model Class Initialized
DEBUG - 2017-05-17 03:44:53 --> Helper loaded: url_helper
DEBUG - 2017-05-17 03:44:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 03:44:53 --> Final output sent to browser
DEBUG - 2017-05-17 03:44:53 --> Total execution time: 0.0313
DEBUG - 2017-05-17 08:36:39 --> Config Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Hooks Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Utf8 Class Initialized
DEBUG - 2017-05-17 08:36:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 08:36:39 --> URI Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Router Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Output Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Security Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Input Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 08:36:39 --> Language Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Loader Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Helper loaded: date_helper
DEBUG - 2017-05-17 08:36:39 --> Controller Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Database Driver Class Initialized
ERROR - 2017-05-17 08:36:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 08:36:39 --> Model Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Model Class Initialized
DEBUG - 2017-05-17 08:36:39 --> Helper loaded: url_helper
DEBUG - 2017-05-17 08:36:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-05-17 08:36:39 --> Final output sent to browser
DEBUG - 2017-05-17 08:36:39 --> Total execution time: 0.0347
DEBUG - 2017-05-17 08:36:44 --> Config Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Hooks Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Utf8 Class Initialized
DEBUG - 2017-05-17 08:36:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 08:36:44 --> URI Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Router Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Output Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Security Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Input Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 08:36:44 --> Language Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Loader Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Helper loaded: date_helper
DEBUG - 2017-05-17 08:36:44 --> Controller Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Database Driver Class Initialized
ERROR - 2017-05-17 08:36:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 08:36:44 --> Model Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Model Class Initialized
DEBUG - 2017-05-17 08:36:44 --> Helper loaded: url_helper
DEBUG - 2017-05-17 08:36:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-05-17 08:36:44 --> Final output sent to browser
DEBUG - 2017-05-17 08:36:44 --> Total execution time: 0.0199
DEBUG - 2017-05-17 11:21:46 --> Config Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Hooks Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Utf8 Class Initialized
DEBUG - 2017-05-17 11:21:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-17 11:21:46 --> URI Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Router Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Output Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Security Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Input Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-17 11:21:46 --> Language Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Loader Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Helper loaded: date_helper
DEBUG - 2017-05-17 11:21:46 --> Controller Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Database Driver Class Initialized
ERROR - 2017-05-17 11:21:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-17 11:21:46 --> Model Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Model Class Initialized
DEBUG - 2017-05-17 11:21:46 --> Helper loaded: url_helper
DEBUG - 2017-05-17 11:21:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-17 11:21:46 --> Final output sent to browser
DEBUG - 2017-05-17 11:21:46 --> Total execution time: 0.0413
