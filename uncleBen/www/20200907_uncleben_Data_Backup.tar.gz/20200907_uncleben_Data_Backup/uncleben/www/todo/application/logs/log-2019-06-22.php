<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-06-22 05:07:26 --> Config Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Hooks Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Utf8 Class Initialized
DEBUG - 2019-06-22 05:07:26 --> UTF-8 Support Enabled
DEBUG - 2019-06-22 05:07:26 --> URI Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Router Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Output Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Security Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Input Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-22 05:07:26 --> Language Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Loader Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Helper loaded: date_helper
DEBUG - 2019-06-22 05:07:26 --> Controller Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Database Driver Class Initialized
ERROR - 2019-06-22 05:07:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-22 05:07:26 --> Model Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Model Class Initialized
DEBUG - 2019-06-22 05:07:26 --> Helper loaded: url_helper
DEBUG - 2019-06-22 05:07:26 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-22 05:07:26 --> Final output sent to browser
DEBUG - 2019-06-22 05:07:26 --> Total execution time: 0.0723
DEBUG - 2019-06-22 13:07:04 --> Config Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Hooks Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Utf8 Class Initialized
DEBUG - 2019-06-22 13:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-06-22 13:07:04 --> URI Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Router Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Output Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Security Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Input Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-22 13:07:04 --> Language Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Loader Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Helper loaded: date_helper
DEBUG - 2019-06-22 13:07:04 --> Controller Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Database Driver Class Initialized
ERROR - 2019-06-22 13:07:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-22 13:07:04 --> Model Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Model Class Initialized
DEBUG - 2019-06-22 13:07:04 --> Helper loaded: url_helper
DEBUG - 2019-06-22 13:07:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-22 13:07:04 --> Final output sent to browser
DEBUG - 2019-06-22 13:07:04 --> Total execution time: 0.0384
DEBUG - 2019-06-22 16:10:51 --> Config Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Hooks Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Utf8 Class Initialized
DEBUG - 2019-06-22 16:10:51 --> UTF-8 Support Enabled
DEBUG - 2019-06-22 16:10:51 --> URI Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Router Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Output Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Security Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Input Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-22 16:10:51 --> Language Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Loader Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Helper loaded: date_helper
DEBUG - 2019-06-22 16:10:51 --> Controller Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Database Driver Class Initialized
ERROR - 2019-06-22 16:10:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-22 16:10:51 --> Model Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Model Class Initialized
DEBUG - 2019-06-22 16:10:51 --> Helper loaded: url_helper
DEBUG - 2019-06-22 16:10:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-22 16:10:51 --> Final output sent to browser
DEBUG - 2019-06-22 16:10:51 --> Total execution time: 0.0334
