<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-01-22 17:28:56 --> Config Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Hooks Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Utf8 Class Initialized
DEBUG - 2018-01-22 17:28:56 --> UTF-8 Support Enabled
DEBUG - 2018-01-22 17:28:56 --> URI Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Router Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Output Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Security Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Input Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-22 17:28:56 --> Language Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Loader Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Helper loaded: date_helper
DEBUG - 2018-01-22 17:28:56 --> Controller Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Database Driver Class Initialized
ERROR - 2018-01-22 17:28:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-22 17:28:56 --> Model Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Model Class Initialized
DEBUG - 2018-01-22 17:28:56 --> Helper loaded: url_helper
DEBUG - 2018-01-22 17:28:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-22 17:28:56 --> Final output sent to browser
DEBUG - 2018-01-22 17:28:56 --> Total execution time: 0.0764
DEBUG - 2018-01-22 17:29:00 --> Config Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Hooks Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Utf8 Class Initialized
DEBUG - 2018-01-22 17:29:00 --> UTF-8 Support Enabled
DEBUG - 2018-01-22 17:29:00 --> URI Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Router Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Output Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Security Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Input Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-22 17:29:00 --> Language Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Loader Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Helper loaded: date_helper
DEBUG - 2018-01-22 17:29:00 --> Controller Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Database Driver Class Initialized
ERROR - 2018-01-22 17:29:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-22 17:29:00 --> Model Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Model Class Initialized
DEBUG - 2018-01-22 17:29:00 --> Helper loaded: url_helper
DEBUG - 2018-01-22 17:29:00 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-22 17:29:00 --> Final output sent to browser
DEBUG - 2018-01-22 17:29:00 --> Total execution time: 0.0432
DEBUG - 2018-01-22 17:29:03 --> Config Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Hooks Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Utf8 Class Initialized
DEBUG - 2018-01-22 17:29:03 --> UTF-8 Support Enabled
DEBUG - 2018-01-22 17:29:03 --> URI Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Router Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Output Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Security Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Input Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-22 17:29:03 --> Language Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Loader Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Helper loaded: date_helper
DEBUG - 2018-01-22 17:29:03 --> Controller Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Database Driver Class Initialized
ERROR - 2018-01-22 17:29:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-22 17:29:03 --> Model Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Model Class Initialized
DEBUG - 2018-01-22 17:29:03 --> Helper loaded: url_helper
DEBUG - 2018-01-22 17:29:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-22 17:29:03 --> Final output sent to browser
DEBUG - 2018-01-22 17:29:03 --> Total execution time: 0.0446
DEBUG - 2018-01-22 18:06:10 --> Config Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Hooks Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Utf8 Class Initialized
DEBUG - 2018-01-22 18:06:10 --> UTF-8 Support Enabled
DEBUG - 2018-01-22 18:06:10 --> URI Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Router Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Output Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Security Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Input Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-22 18:06:10 --> Language Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Loader Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Helper loaded: date_helper
DEBUG - 2018-01-22 18:06:10 --> Controller Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Database Driver Class Initialized
ERROR - 2018-01-22 18:06:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-22 18:06:10 --> Model Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Model Class Initialized
DEBUG - 2018-01-22 18:06:10 --> Helper loaded: url_helper
DEBUG - 2018-01-22 18:06:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-22 18:06:10 --> Final output sent to browser
DEBUG - 2018-01-22 18:06:10 --> Total execution time: 0.0483
DEBUG - 2018-01-22 18:08:49 --> Config Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Hooks Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Utf8 Class Initialized
DEBUG - 2018-01-22 18:08:49 --> UTF-8 Support Enabled
DEBUG - 2018-01-22 18:08:49 --> URI Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Router Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Output Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Security Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Input Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-22 18:08:49 --> Language Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Loader Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Helper loaded: date_helper
DEBUG - 2018-01-22 18:08:49 --> Controller Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Database Driver Class Initialized
ERROR - 2018-01-22 18:08:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-22 18:08:49 --> Model Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Model Class Initialized
DEBUG - 2018-01-22 18:08:49 --> Helper loaded: url_helper
DEBUG - 2018-01-22 18:08:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-01-22 18:08:49 --> Final output sent to browser
DEBUG - 2018-01-22 18:08:49 --> Total execution time: 0.0440
DEBUG - 2018-01-22 20:56:20 --> Config Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Hooks Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Utf8 Class Initialized
DEBUG - 2018-01-22 20:56:20 --> UTF-8 Support Enabled
DEBUG - 2018-01-22 20:56:20 --> URI Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Router Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Output Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Security Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Input Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-22 20:56:20 --> Language Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Loader Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Helper loaded: date_helper
DEBUG - 2018-01-22 20:56:20 --> Controller Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Database Driver Class Initialized
ERROR - 2018-01-22 20:56:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-22 20:56:20 --> Model Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Model Class Initialized
DEBUG - 2018-01-22 20:56:20 --> Helper loaded: url_helper
DEBUG - 2018-01-22 20:56:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-22 20:56:20 --> Final output sent to browser
DEBUG - 2018-01-22 20:56:20 --> Total execution time: 0.0258
