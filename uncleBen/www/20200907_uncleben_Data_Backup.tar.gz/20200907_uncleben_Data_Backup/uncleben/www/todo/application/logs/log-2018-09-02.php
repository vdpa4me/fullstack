<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-09-02 06:31:54 --> Config Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Hooks Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Utf8 Class Initialized
DEBUG - 2018-09-02 06:31:54 --> UTF-8 Support Enabled
DEBUG - 2018-09-02 06:31:54 --> URI Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Router Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Output Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Security Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Input Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-02 06:31:54 --> Language Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Loader Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Helper loaded: date_helper
DEBUG - 2018-09-02 06:31:54 --> Controller Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Database Driver Class Initialized
ERROR - 2018-09-02 06:31:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-02 06:31:54 --> Model Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Model Class Initialized
DEBUG - 2018-09-02 06:31:54 --> Helper loaded: url_helper
DEBUG - 2018-09-02 06:31:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-02 06:31:54 --> Final output sent to browser
DEBUG - 2018-09-02 06:31:54 --> Total execution time: 0.0316
DEBUG - 2018-09-02 08:10:14 --> Config Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Hooks Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Utf8 Class Initialized
DEBUG - 2018-09-02 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2018-09-02 08:10:14 --> URI Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Router Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Output Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Security Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Input Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-02 08:10:14 --> Language Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Loader Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Helper loaded: date_helper
DEBUG - 2018-09-02 08:10:14 --> Controller Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Database Driver Class Initialized
ERROR - 2018-09-02 08:10:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-02 08:10:14 --> Model Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Model Class Initialized
DEBUG - 2018-09-02 08:10:14 --> Helper loaded: url_helper
DEBUG - 2018-09-02 08:10:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-02 08:10:14 --> Final output sent to browser
DEBUG - 2018-09-02 08:10:14 --> Total execution time: 0.0511
DEBUG - 2018-09-02 08:32:19 --> Config Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Hooks Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Utf8 Class Initialized
DEBUG - 2018-09-02 08:32:19 --> UTF-8 Support Enabled
DEBUG - 2018-09-02 08:32:19 --> URI Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Router Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Output Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Security Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Input Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-02 08:32:19 --> Language Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Loader Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Helper loaded: date_helper
DEBUG - 2018-09-02 08:32:19 --> Controller Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Database Driver Class Initialized
ERROR - 2018-09-02 08:32:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-02 08:32:19 --> Model Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Model Class Initialized
DEBUG - 2018-09-02 08:32:19 --> Helper loaded: url_helper
DEBUG - 2018-09-02 08:32:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-02 08:32:19 --> Final output sent to browser
DEBUG - 2018-09-02 08:32:19 --> Total execution time: 0.0228
DEBUG - 2018-09-02 15:12:45 --> Config Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Hooks Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Utf8 Class Initialized
DEBUG - 2018-09-02 15:12:45 --> UTF-8 Support Enabled
DEBUG - 2018-09-02 15:12:45 --> URI Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Router Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Output Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Security Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Input Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-02 15:12:45 --> Language Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Loader Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Helper loaded: date_helper
DEBUG - 2018-09-02 15:12:45 --> Controller Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Database Driver Class Initialized
ERROR - 2018-09-02 15:12:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-02 15:12:45 --> Model Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Model Class Initialized
DEBUG - 2018-09-02 15:12:45 --> Helper loaded: url_helper
DEBUG - 2018-09-02 15:12:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-09-02 15:12:45 --> Final output sent to browser
DEBUG - 2018-09-02 15:12:45 --> Total execution time: 0.0599
DEBUG - 2018-09-02 15:12:53 --> Config Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Hooks Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Utf8 Class Initialized
DEBUG - 2018-09-02 15:12:53 --> UTF-8 Support Enabled
DEBUG - 2018-09-02 15:12:53 --> URI Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Router Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Output Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Security Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Input Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-02 15:12:53 --> Language Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Loader Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Helper loaded: date_helper
DEBUG - 2018-09-02 15:12:53 --> Controller Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Database Driver Class Initialized
ERROR - 2018-09-02 15:12:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-02 15:12:53 --> Model Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Model Class Initialized
DEBUG - 2018-09-02 15:12:53 --> Helper loaded: url_helper
DEBUG - 2018-09-02 15:12:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-09-02 15:12:53 --> Final output sent to browser
DEBUG - 2018-09-02 15:12:53 --> Total execution time: 0.0464
DEBUG - 2018-09-02 22:32:51 --> Config Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Hooks Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Utf8 Class Initialized
DEBUG - 2018-09-02 22:32:51 --> UTF-8 Support Enabled
DEBUG - 2018-09-02 22:32:51 --> URI Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Router Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Output Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Security Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Input Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-02 22:32:51 --> Language Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Loader Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Helper loaded: date_helper
DEBUG - 2018-09-02 22:32:51 --> Controller Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Database Driver Class Initialized
ERROR - 2018-09-02 22:32:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-02 22:32:51 --> Model Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Model Class Initialized
DEBUG - 2018-09-02 22:32:51 --> Helper loaded: url_helper
DEBUG - 2018-09-02 22:32:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-02 22:32:51 --> Final output sent to browser
DEBUG - 2018-09-02 22:32:51 --> Total execution time: 0.0252
