<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-01-29 06:12:54 --> Config Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Hooks Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Utf8 Class Initialized
DEBUG - 2019-01-29 06:12:54 --> UTF-8 Support Enabled
DEBUG - 2019-01-29 06:12:54 --> URI Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Router Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Output Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Security Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Input Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-29 06:12:54 --> Language Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Loader Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Helper loaded: date_helper
DEBUG - 2019-01-29 06:12:54 --> Controller Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Database Driver Class Initialized
ERROR - 2019-01-29 06:12:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-29 06:12:54 --> Model Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Model Class Initialized
DEBUG - 2019-01-29 06:12:54 --> Helper loaded: url_helper
DEBUG - 2019-01-29 06:12:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-01-29 06:12:54 --> Final output sent to browser
DEBUG - 2019-01-29 06:12:54 --> Total execution time: 0.0912
DEBUG - 2019-01-29 06:13:02 --> Config Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Hooks Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Utf8 Class Initialized
DEBUG - 2019-01-29 06:13:02 --> UTF-8 Support Enabled
DEBUG - 2019-01-29 06:13:02 --> URI Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Router Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Output Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Security Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Input Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-29 06:13:02 --> Language Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Loader Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Helper loaded: date_helper
DEBUG - 2019-01-29 06:13:02 --> Controller Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Database Driver Class Initialized
ERROR - 2019-01-29 06:13:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-29 06:13:02 --> Model Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Model Class Initialized
DEBUG - 2019-01-29 06:13:02 --> Helper loaded: url_helper
DEBUG - 2019-01-29 06:13:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-01-29 06:13:02 --> Final output sent to browser
DEBUG - 2019-01-29 06:13:02 --> Total execution time: 0.0542
DEBUG - 2019-01-29 08:12:43 --> Config Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Hooks Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Utf8 Class Initialized
DEBUG - 2019-01-29 08:12:43 --> UTF-8 Support Enabled
DEBUG - 2019-01-29 08:12:43 --> URI Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Router Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Output Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Security Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Input Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-29 08:12:43 --> Language Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Loader Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Helper loaded: date_helper
DEBUG - 2019-01-29 08:12:43 --> Controller Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Database Driver Class Initialized
ERROR - 2019-01-29 08:12:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-29 08:12:43 --> Model Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Model Class Initialized
DEBUG - 2019-01-29 08:12:43 --> Helper loaded: url_helper
DEBUG - 2019-01-29 08:12:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-29 08:12:43 --> Final output sent to browser
DEBUG - 2019-01-29 08:12:43 --> Total execution time: 0.0394
DEBUG - 2019-01-29 10:04:01 --> Config Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Hooks Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Utf8 Class Initialized
DEBUG - 2019-01-29 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2019-01-29 10:04:01 --> URI Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Router Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Output Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Security Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Input Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-29 10:04:01 --> Language Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Loader Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Helper loaded: date_helper
DEBUG - 2019-01-29 10:04:01 --> Controller Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Database Driver Class Initialized
ERROR - 2019-01-29 10:04:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-29 10:04:01 --> Model Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Model Class Initialized
DEBUG - 2019-01-29 10:04:01 --> Helper loaded: url_helper
DEBUG - 2019-01-29 10:04:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-29 10:04:01 --> Final output sent to browser
DEBUG - 2019-01-29 10:04:01 --> Total execution time: 0.0648
DEBUG - 2019-01-29 14:04:09 --> Config Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Hooks Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Utf8 Class Initialized
DEBUG - 2019-01-29 14:04:09 --> UTF-8 Support Enabled
DEBUG - 2019-01-29 14:04:09 --> URI Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Router Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Output Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Security Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Input Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-29 14:04:09 --> Language Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Loader Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Helper loaded: date_helper
DEBUG - 2019-01-29 14:04:09 --> Controller Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Database Driver Class Initialized
ERROR - 2019-01-29 14:04:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-29 14:04:09 --> Model Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Model Class Initialized
DEBUG - 2019-01-29 14:04:09 --> Helper loaded: url_helper
DEBUG - 2019-01-29 14:04:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-29 14:04:09 --> Final output sent to browser
DEBUG - 2019-01-29 14:04:09 --> Total execution time: 0.0477
DEBUG - 2019-01-29 16:09:44 --> Config Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Hooks Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Utf8 Class Initialized
DEBUG - 2019-01-29 16:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-01-29 16:09:44 --> URI Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Router Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Output Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Security Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Input Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-29 16:09:44 --> Language Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Loader Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Helper loaded: date_helper
DEBUG - 2019-01-29 16:09:44 --> Controller Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Database Driver Class Initialized
ERROR - 2019-01-29 16:09:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-29 16:09:44 --> Model Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Model Class Initialized
DEBUG - 2019-01-29 16:09:44 --> Helper loaded: url_helper
DEBUG - 2019-01-29 16:09:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-29 16:09:44 --> Final output sent to browser
DEBUG - 2019-01-29 16:09:44 --> Total execution time: 0.0310
