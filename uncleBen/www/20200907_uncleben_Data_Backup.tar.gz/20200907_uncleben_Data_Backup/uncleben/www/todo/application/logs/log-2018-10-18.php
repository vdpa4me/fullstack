<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-10-18 05:31:15 --> Config Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Hooks Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Utf8 Class Initialized
DEBUG - 2018-10-18 05:31:15 --> UTF-8 Support Enabled
DEBUG - 2018-10-18 05:31:15 --> URI Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Router Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Output Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Security Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Input Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-18 05:31:15 --> Language Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Loader Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Helper loaded: date_helper
DEBUG - 2018-10-18 05:31:15 --> Controller Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Database Driver Class Initialized
ERROR - 2018-10-18 05:31:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-18 05:31:15 --> Model Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Model Class Initialized
DEBUG - 2018-10-18 05:31:15 --> Helper loaded: url_helper
DEBUG - 2018-10-18 05:31:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-10-18 05:31:15 --> Final output sent to browser
DEBUG - 2018-10-18 05:31:15 --> Total execution time: 0.1098
DEBUG - 2018-10-18 05:31:16 --> Config Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Hooks Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Utf8 Class Initialized
DEBUG - 2018-10-18 05:31:16 --> UTF-8 Support Enabled
DEBUG - 2018-10-18 05:31:16 --> URI Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Router Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Output Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Security Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Input Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-18 05:31:16 --> Language Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Loader Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Helper loaded: date_helper
DEBUG - 2018-10-18 05:31:16 --> Controller Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Database Driver Class Initialized
ERROR - 2018-10-18 05:31:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-18 05:31:16 --> Model Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Model Class Initialized
DEBUG - 2018-10-18 05:31:16 --> Helper loaded: url_helper
DEBUG - 2018-10-18 05:31:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-18 05:31:16 --> Final output sent to browser
DEBUG - 2018-10-18 05:31:16 --> Total execution time: 0.0356
DEBUG - 2018-10-18 07:22:18 --> Config Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Hooks Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Utf8 Class Initialized
DEBUG - 2018-10-18 07:22:18 --> UTF-8 Support Enabled
DEBUG - 2018-10-18 07:22:18 --> URI Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Router Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Output Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Security Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Input Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-18 07:22:18 --> Language Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Loader Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Helper loaded: date_helper
DEBUG - 2018-10-18 07:22:18 --> Controller Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Database Driver Class Initialized
ERROR - 2018-10-18 07:22:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-18 07:22:18 --> Model Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Model Class Initialized
DEBUG - 2018-10-18 07:22:18 --> Helper loaded: url_helper
DEBUG - 2018-10-18 07:22:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-18 07:22:18 --> Final output sent to browser
DEBUG - 2018-10-18 07:22:18 --> Total execution time: 0.0407
DEBUG - 2018-10-18 17:14:27 --> Config Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Utf8 Class Initialized
DEBUG - 2018-10-18 17:14:27 --> UTF-8 Support Enabled
DEBUG - 2018-10-18 17:14:27 --> URI Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Router Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Output Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Security Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Input Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-18 17:14:27 --> Language Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Loader Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Helper loaded: date_helper
DEBUG - 2018-10-18 17:14:27 --> Controller Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Database Driver Class Initialized
ERROR - 2018-10-18 17:14:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-18 17:14:27 --> Model Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Model Class Initialized
DEBUG - 2018-10-18 17:14:27 --> Helper loaded: url_helper
DEBUG - 2018-10-18 17:14:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-18 17:14:27 --> Final output sent to browser
DEBUG - 2018-10-18 17:14:27 --> Total execution time: 0.0718
DEBUG - 2018-10-18 17:23:49 --> Config Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Hooks Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Utf8 Class Initialized
DEBUG - 2018-10-18 17:23:49 --> UTF-8 Support Enabled
DEBUG - 2018-10-18 17:23:49 --> URI Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Router Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Output Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Security Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Input Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-18 17:23:49 --> Language Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Loader Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Helper loaded: date_helper
DEBUG - 2018-10-18 17:23:49 --> Controller Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Database Driver Class Initialized
ERROR - 2018-10-18 17:23:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-18 17:23:49 --> Model Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Model Class Initialized
DEBUG - 2018-10-18 17:23:49 --> Helper loaded: url_helper
DEBUG - 2018-10-18 17:23:49 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-18 17:23:49 --> Final output sent to browser
DEBUG - 2018-10-18 17:23:49 --> Total execution time: 0.0271
