<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-17 01:09:24 --> Config Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Hooks Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Utf8 Class Initialized
DEBUG - 2019-05-17 01:09:24 --> UTF-8 Support Enabled
DEBUG - 2019-05-17 01:09:24 --> URI Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Router Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Output Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Security Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Input Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-17 01:09:24 --> Language Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Loader Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Helper loaded: date_helper
DEBUG - 2019-05-17 01:09:24 --> Controller Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Database Driver Class Initialized
ERROR - 2019-05-17 01:09:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-17 01:09:24 --> Model Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Model Class Initialized
DEBUG - 2019-05-17 01:09:24 --> Helper loaded: url_helper
DEBUG - 2019-05-17 01:09:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-17 01:09:24 --> Final output sent to browser
DEBUG - 2019-05-17 01:09:24 --> Total execution time: 0.0708
DEBUG - 2019-05-17 01:10:13 --> Config Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Hooks Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Utf8 Class Initialized
DEBUG - 2019-05-17 01:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-05-17 01:10:13 --> URI Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Router Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Output Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Security Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Input Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-17 01:10:13 --> Language Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Loader Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Helper loaded: date_helper
DEBUG - 2019-05-17 01:10:13 --> Controller Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Database Driver Class Initialized
ERROR - 2019-05-17 01:10:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-17 01:10:13 --> Model Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Model Class Initialized
DEBUG - 2019-05-17 01:10:13 --> Helper loaded: url_helper
DEBUG - 2019-05-17 01:10:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-17 01:10:13 --> Final output sent to browser
DEBUG - 2019-05-17 01:10:13 --> Total execution time: 0.0204
DEBUG - 2019-05-17 01:11:04 --> Config Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Hooks Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Utf8 Class Initialized
DEBUG - 2019-05-17 01:11:04 --> UTF-8 Support Enabled
DEBUG - 2019-05-17 01:11:04 --> URI Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Router Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Output Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Security Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Input Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-17 01:11:04 --> Language Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Loader Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Helper loaded: date_helper
DEBUG - 2019-05-17 01:11:04 --> Controller Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Database Driver Class Initialized
ERROR - 2019-05-17 01:11:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-17 01:11:04 --> Model Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Model Class Initialized
DEBUG - 2019-05-17 01:11:04 --> Helper loaded: url_helper
DEBUG - 2019-05-17 01:11:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-17 01:11:04 --> Final output sent to browser
DEBUG - 2019-05-17 01:11:04 --> Total execution time: 0.0364
DEBUG - 2019-05-17 06:27:12 --> Config Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Hooks Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Utf8 Class Initialized
DEBUG - 2019-05-17 06:27:12 --> UTF-8 Support Enabled
DEBUG - 2019-05-17 06:27:12 --> URI Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Router Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Output Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Security Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Input Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-17 06:27:12 --> Language Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Loader Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Helper loaded: date_helper
DEBUG - 2019-05-17 06:27:12 --> Controller Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Database Driver Class Initialized
ERROR - 2019-05-17 06:27:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-17 06:27:12 --> Model Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Model Class Initialized
DEBUG - 2019-05-17 06:27:12 --> Helper loaded: url_helper
DEBUG - 2019-05-17 06:27:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-17 06:27:12 --> Final output sent to browser
DEBUG - 2019-05-17 06:27:12 --> Total execution time: 0.0465
DEBUG - 2019-05-17 07:46:08 --> Config Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Hooks Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Utf8 Class Initialized
DEBUG - 2019-05-17 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2019-05-17 07:46:08 --> URI Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Router Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Output Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Security Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Input Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-17 07:46:08 --> Language Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Loader Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Helper loaded: date_helper
DEBUG - 2019-05-17 07:46:08 --> Controller Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Database Driver Class Initialized
ERROR - 2019-05-17 07:46:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-17 07:46:08 --> Model Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Model Class Initialized
DEBUG - 2019-05-17 07:46:08 --> Helper loaded: url_helper
DEBUG - 2019-05-17 07:46:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-17 07:46:08 --> Final output sent to browser
DEBUG - 2019-05-17 07:46:08 --> Total execution time: 0.0320
DEBUG - 2019-05-17 20:21:06 --> Config Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Hooks Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Utf8 Class Initialized
DEBUG - 2019-05-17 20:21:06 --> UTF-8 Support Enabled
DEBUG - 2019-05-17 20:21:06 --> URI Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Router Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Output Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Security Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Input Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-17 20:21:06 --> Language Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Loader Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Helper loaded: date_helper
DEBUG - 2019-05-17 20:21:06 --> Controller Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Database Driver Class Initialized
ERROR - 2019-05-17 20:21:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-17 20:21:06 --> Model Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Model Class Initialized
DEBUG - 2019-05-17 20:21:06 --> Helper loaded: url_helper
DEBUG - 2019-05-17 20:21:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-17 20:21:06 --> Final output sent to browser
DEBUG - 2019-05-17 20:21:06 --> Total execution time: 0.0603
