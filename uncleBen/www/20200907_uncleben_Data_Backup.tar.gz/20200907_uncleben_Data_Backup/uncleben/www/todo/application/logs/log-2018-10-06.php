<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-10-06 05:01:19 --> Config Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Hooks Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Utf8 Class Initialized
DEBUG - 2018-10-06 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2018-10-06 05:01:19 --> URI Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Router Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Output Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Security Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Input Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-06 05:01:19 --> Language Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Loader Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Helper loaded: date_helper
DEBUG - 2018-10-06 05:01:19 --> Controller Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Database Driver Class Initialized
ERROR - 2018-10-06 05:01:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-06 05:01:19 --> Model Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Model Class Initialized
DEBUG - 2018-10-06 05:01:19 --> Helper loaded: url_helper
DEBUG - 2018-10-06 05:01:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-10-06 05:01:19 --> Final output sent to browser
DEBUG - 2018-10-06 05:01:19 --> Total execution time: 0.1176
DEBUG - 2018-10-06 05:01:25 --> Config Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Hooks Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Utf8 Class Initialized
DEBUG - 2018-10-06 05:01:25 --> UTF-8 Support Enabled
DEBUG - 2018-10-06 05:01:25 --> URI Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Router Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Output Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Security Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Input Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-06 05:01:25 --> Language Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Loader Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Helper loaded: date_helper
DEBUG - 2018-10-06 05:01:25 --> Controller Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Database Driver Class Initialized
ERROR - 2018-10-06 05:01:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-06 05:01:25 --> Model Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Model Class Initialized
DEBUG - 2018-10-06 05:01:25 --> Helper loaded: url_helper
DEBUG - 2018-10-06 05:01:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-10-06 05:01:25 --> Final output sent to browser
DEBUG - 2018-10-06 05:01:25 --> Total execution time: 0.0453
DEBUG - 2018-10-06 07:59:02 --> Config Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Hooks Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Utf8 Class Initialized
DEBUG - 2018-10-06 07:59:02 --> UTF-8 Support Enabled
DEBUG - 2018-10-06 07:59:02 --> URI Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Router Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Output Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Security Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Input Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-06 07:59:02 --> Language Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Loader Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Helper loaded: date_helper
DEBUG - 2018-10-06 07:59:02 --> Controller Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Database Driver Class Initialized
ERROR - 2018-10-06 07:59:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-06 07:59:02 --> Model Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Model Class Initialized
DEBUG - 2018-10-06 07:59:02 --> Helper loaded: url_helper
DEBUG - 2018-10-06 07:59:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-06 07:59:02 --> Final output sent to browser
DEBUG - 2018-10-06 07:59:02 --> Total execution time: 0.0428
DEBUG - 2018-10-06 15:34:05 --> Config Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Hooks Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Utf8 Class Initialized
DEBUG - 2018-10-06 15:34:05 --> UTF-8 Support Enabled
DEBUG - 2018-10-06 15:34:05 --> URI Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Router Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Output Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Security Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Input Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-06 15:34:05 --> Language Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Loader Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Helper loaded: date_helper
DEBUG - 2018-10-06 15:34:05 --> Controller Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Database Driver Class Initialized
ERROR - 2018-10-06 15:34:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-06 15:34:05 --> Model Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Model Class Initialized
DEBUG - 2018-10-06 15:34:05 --> Helper loaded: url_helper
DEBUG - 2018-10-06 15:34:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-06 15:34:05 --> Final output sent to browser
DEBUG - 2018-10-06 15:34:05 --> Total execution time: 0.0593
