<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-02-13 04:39:21 --> Config Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Hooks Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Utf8 Class Initialized
DEBUG - 2017-02-13 04:39:21 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 04:39:21 --> URI Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Router Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Output Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Security Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Input Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-13 04:39:21 --> Language Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Loader Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Helper loaded: date_helper
DEBUG - 2017-02-13 04:39:21 --> Controller Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Database Driver Class Initialized
ERROR - 2017-02-13 04:39:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-13 04:39:21 --> Model Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Model Class Initialized
DEBUG - 2017-02-13 04:39:21 --> Helper loaded: url_helper
DEBUG - 2017-02-13 04:39:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-02-13 04:39:21 --> Final output sent to browser
DEBUG - 2017-02-13 04:39:21 --> Total execution time: 0.0373
