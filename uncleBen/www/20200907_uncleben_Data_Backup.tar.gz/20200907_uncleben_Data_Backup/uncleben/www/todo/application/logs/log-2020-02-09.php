<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-02-09 06:19:55 --> Config Class Initialized
DEBUG - 2020-02-09 06:19:55 --> Hooks Class Initialized
DEBUG - 2020-02-09 06:19:55 --> Utf8 Class Initialized
DEBUG - 2020-02-09 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 06:19:55 --> URI Class Initialized
DEBUG - 2020-02-09 06:19:55 --> Router Class Initialized
DEBUG - 2020-02-09 06:19:55 --> Output Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Security Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Input Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-09 06:19:56 --> Language Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Loader Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Helper loaded: date_helper
DEBUG - 2020-02-09 06:19:56 --> Controller Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Database Driver Class Initialized
ERROR - 2020-02-09 06:19:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-09 06:19:56 --> Model Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Model Class Initialized
DEBUG - 2020-02-09 06:19:56 --> Helper loaded: url_helper
DEBUG - 2020-02-09 06:19:56 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-09 06:19:56 --> Final output sent to browser
DEBUG - 2020-02-09 06:19:56 --> Total execution time: 0.1916
DEBUG - 2020-02-09 15:11:38 --> Config Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Hooks Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Utf8 Class Initialized
DEBUG - 2020-02-09 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2020-02-09 15:11:38 --> URI Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Router Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Output Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Security Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Input Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-09 15:11:38 --> Language Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Loader Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Helper loaded: date_helper
DEBUG - 2020-02-09 15:11:38 --> Controller Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Database Driver Class Initialized
ERROR - 2020-02-09 15:11:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-09 15:11:38 --> Model Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Model Class Initialized
DEBUG - 2020-02-09 15:11:38 --> Helper loaded: url_helper
DEBUG - 2020-02-09 15:11:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-09 15:11:38 --> Final output sent to browser
DEBUG - 2020-02-09 15:11:38 --> Total execution time: 0.1756
