<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-07-12 01:09:25 --> Config Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Hooks Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Utf8 Class Initialized
DEBUG - 2018-07-12 01:09:25 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 01:09:25 --> URI Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Router Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Output Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Security Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Input Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 01:09:25 --> Language Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Loader Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Helper loaded: date_helper
DEBUG - 2018-07-12 01:09:25 --> Controller Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Database Driver Class Initialized
ERROR - 2018-07-12 01:09:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 01:09:25 --> Model Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Model Class Initialized
DEBUG - 2018-07-12 01:09:25 --> Helper loaded: url_helper
DEBUG - 2018-07-12 01:09:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 01:09:25 --> Final output sent to browser
DEBUG - 2018-07-12 01:09:25 --> Total execution time: 0.0227
DEBUG - 2018-07-12 05:26:59 --> Config Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Hooks Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Utf8 Class Initialized
DEBUG - 2018-07-12 05:26:59 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 05:26:59 --> URI Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Router Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Output Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Security Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Input Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 05:26:59 --> Language Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Loader Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Helper loaded: date_helper
DEBUG - 2018-07-12 05:26:59 --> Controller Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Database Driver Class Initialized
ERROR - 2018-07-12 05:26:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 05:26:59 --> Model Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Model Class Initialized
DEBUG - 2018-07-12 05:26:59 --> Helper loaded: url_helper
DEBUG - 2018-07-12 05:26:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 05:26:59 --> Final output sent to browser
DEBUG - 2018-07-12 05:26:59 --> Total execution time: 0.0375
DEBUG - 2018-07-12 05:32:45 --> Config Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Hooks Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Utf8 Class Initialized
DEBUG - 2018-07-12 05:32:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 05:32:45 --> URI Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Router Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Output Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Security Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Input Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 05:32:45 --> Language Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Loader Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Helper loaded: date_helper
DEBUG - 2018-07-12 05:32:45 --> Controller Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Database Driver Class Initialized
ERROR - 2018-07-12 05:32:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 05:32:45 --> Model Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Model Class Initialized
DEBUG - 2018-07-12 05:32:45 --> Helper loaded: url_helper
DEBUG - 2018-07-12 05:32:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 05:32:45 --> Final output sent to browser
DEBUG - 2018-07-12 05:32:45 --> Total execution time: 0.0221
DEBUG - 2018-07-12 05:38:35 --> Config Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Utf8 Class Initialized
DEBUG - 2018-07-12 05:38:35 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 05:38:35 --> URI Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Router Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Output Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Security Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Input Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 05:38:35 --> Language Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Loader Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Helper loaded: date_helper
DEBUG - 2018-07-12 05:38:35 --> Controller Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Database Driver Class Initialized
ERROR - 2018-07-12 05:38:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 05:38:35 --> Model Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Model Class Initialized
DEBUG - 2018-07-12 05:38:35 --> Helper loaded: url_helper
DEBUG - 2018-07-12 05:38:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 05:38:35 --> Final output sent to browser
DEBUG - 2018-07-12 05:38:35 --> Total execution time: 0.0213
DEBUG - 2018-07-12 05:42:56 --> Config Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Hooks Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Utf8 Class Initialized
DEBUG - 2018-07-12 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 05:42:56 --> URI Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Router Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Output Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Security Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Input Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 05:42:56 --> Language Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Loader Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Helper loaded: date_helper
DEBUG - 2018-07-12 05:42:56 --> Controller Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Database Driver Class Initialized
ERROR - 2018-07-12 05:42:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 05:42:56 --> Model Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Model Class Initialized
DEBUG - 2018-07-12 05:42:56 --> Helper loaded: url_helper
DEBUG - 2018-07-12 05:42:56 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 05:42:56 --> Final output sent to browser
DEBUG - 2018-07-12 05:42:56 --> Total execution time: 0.0214
DEBUG - 2018-07-12 05:51:41 --> Config Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Hooks Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Utf8 Class Initialized
DEBUG - 2018-07-12 05:51:41 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 05:51:41 --> URI Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Router Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Output Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Security Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Input Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 05:51:41 --> Language Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Loader Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Helper loaded: date_helper
DEBUG - 2018-07-12 05:51:41 --> Controller Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Database Driver Class Initialized
ERROR - 2018-07-12 05:51:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 05:51:41 --> Model Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Model Class Initialized
DEBUG - 2018-07-12 05:51:41 --> Helper loaded: url_helper
DEBUG - 2018-07-12 05:51:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 05:51:41 --> Final output sent to browser
DEBUG - 2018-07-12 05:51:41 --> Total execution time: 0.0214
DEBUG - 2018-07-12 05:54:35 --> Config Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Hooks Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Utf8 Class Initialized
DEBUG - 2018-07-12 05:54:35 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 05:54:35 --> URI Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Router Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Output Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Security Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Input Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 05:54:35 --> Language Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Loader Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Helper loaded: date_helper
DEBUG - 2018-07-12 05:54:35 --> Controller Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Database Driver Class Initialized
ERROR - 2018-07-12 05:54:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 05:54:35 --> Model Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Model Class Initialized
DEBUG - 2018-07-12 05:54:35 --> Helper loaded: url_helper
DEBUG - 2018-07-12 05:54:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 05:54:35 --> Final output sent to browser
DEBUG - 2018-07-12 05:54:35 --> Total execution time: 0.0215
DEBUG - 2018-07-12 07:07:22 --> Config Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Hooks Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Utf8 Class Initialized
DEBUG - 2018-07-12 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 07:07:22 --> URI Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Router Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Output Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Security Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Input Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 07:07:22 --> Language Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Loader Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Helper loaded: date_helper
DEBUG - 2018-07-12 07:07:22 --> Controller Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Database Driver Class Initialized
ERROR - 2018-07-12 07:07:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 07:07:22 --> Model Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Model Class Initialized
DEBUG - 2018-07-12 07:07:22 --> Helper loaded: url_helper
DEBUG - 2018-07-12 07:07:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 07:07:22 --> Final output sent to browser
DEBUG - 2018-07-12 07:07:22 --> Total execution time: 0.0213
DEBUG - 2018-07-12 08:15:14 --> Config Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Hooks Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Utf8 Class Initialized
DEBUG - 2018-07-12 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 08:15:14 --> URI Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Router Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Output Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Security Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Input Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 08:15:14 --> Language Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Loader Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Helper loaded: date_helper
DEBUG - 2018-07-12 08:15:14 --> Controller Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Database Driver Class Initialized
ERROR - 2018-07-12 08:15:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 08:15:14 --> Model Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Model Class Initialized
DEBUG - 2018-07-12 08:15:14 --> Helper loaded: url_helper
DEBUG - 2018-07-12 08:15:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 08:15:14 --> Final output sent to browser
DEBUG - 2018-07-12 08:15:14 --> Total execution time: 0.0213
DEBUG - 2018-07-12 08:23:33 --> Config Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Hooks Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Utf8 Class Initialized
DEBUG - 2018-07-12 08:23:33 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 08:23:33 --> URI Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Router Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Output Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Security Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Input Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 08:23:33 --> Language Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Loader Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Helper loaded: date_helper
DEBUG - 2018-07-12 08:23:33 --> Controller Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Database Driver Class Initialized
ERROR - 2018-07-12 08:23:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 08:23:33 --> Model Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Model Class Initialized
DEBUG - 2018-07-12 08:23:33 --> Helper loaded: url_helper
DEBUG - 2018-07-12 08:23:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 08:23:33 --> Final output sent to browser
DEBUG - 2018-07-12 08:23:33 --> Total execution time: 0.0210
DEBUG - 2018-07-12 08:24:06 --> Config Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Hooks Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Utf8 Class Initialized
DEBUG - 2018-07-12 08:24:06 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 08:24:06 --> URI Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Router Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Output Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Security Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Input Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 08:24:06 --> Language Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Loader Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Helper loaded: date_helper
DEBUG - 2018-07-12 08:24:06 --> Controller Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Database Driver Class Initialized
ERROR - 2018-07-12 08:24:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 08:24:06 --> Model Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Model Class Initialized
DEBUG - 2018-07-12 08:24:06 --> Helper loaded: url_helper
DEBUG - 2018-07-12 08:24:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 08:24:06 --> Final output sent to browser
DEBUG - 2018-07-12 08:24:06 --> Total execution time: 0.0213
DEBUG - 2018-07-12 08:44:24 --> Config Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Hooks Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Utf8 Class Initialized
DEBUG - 2018-07-12 08:44:24 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 08:44:24 --> URI Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Router Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Output Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Security Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Input Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 08:44:24 --> Language Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Loader Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Helper loaded: date_helper
DEBUG - 2018-07-12 08:44:24 --> Controller Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Database Driver Class Initialized
ERROR - 2018-07-12 08:44:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 08:44:24 --> Model Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Model Class Initialized
DEBUG - 2018-07-12 08:44:24 --> Helper loaded: url_helper
DEBUG - 2018-07-12 08:44:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 08:44:24 --> Final output sent to browser
DEBUG - 2018-07-12 08:44:24 --> Total execution time: 0.0220
DEBUG - 2018-07-12 11:16:16 --> Config Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Hooks Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Utf8 Class Initialized
DEBUG - 2018-07-12 11:16:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 11:16:16 --> URI Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Router Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Output Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Security Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Input Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 11:16:16 --> Language Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Loader Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Helper loaded: date_helper
DEBUG - 2018-07-12 11:16:16 --> Controller Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Database Driver Class Initialized
ERROR - 2018-07-12 11:16:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 11:16:16 --> Model Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Model Class Initialized
DEBUG - 2018-07-12 11:16:16 --> Helper loaded: url_helper
DEBUG - 2018-07-12 11:16:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 11:16:16 --> Final output sent to browser
DEBUG - 2018-07-12 11:16:16 --> Total execution time: 0.0220
DEBUG - 2018-07-12 15:17:59 --> Config Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Hooks Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Utf8 Class Initialized
DEBUG - 2018-07-12 15:17:59 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 15:17:59 --> URI Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Router Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Output Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Security Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Input Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 15:17:59 --> Language Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Loader Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Helper loaded: date_helper
DEBUG - 2018-07-12 15:17:59 --> Controller Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Database Driver Class Initialized
ERROR - 2018-07-12 15:17:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 15:17:59 --> Model Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Model Class Initialized
DEBUG - 2018-07-12 15:17:59 --> Helper loaded: url_helper
DEBUG - 2018-07-12 15:17:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 15:17:59 --> Final output sent to browser
DEBUG - 2018-07-12 15:17:59 --> Total execution time: 0.0211
DEBUG - 2018-07-12 15:55:00 --> Config Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Hooks Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Utf8 Class Initialized
DEBUG - 2018-07-12 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 15:55:00 --> URI Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Router Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Output Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Security Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Input Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 15:55:00 --> Language Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Loader Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Helper loaded: date_helper
DEBUG - 2018-07-12 15:55:00 --> Controller Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Database Driver Class Initialized
ERROR - 2018-07-12 15:55:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 15:55:00 --> Model Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Model Class Initialized
DEBUG - 2018-07-12 15:55:00 --> Helper loaded: url_helper
DEBUG - 2018-07-12 15:55:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-07-12 15:55:01 --> Final output sent to browser
DEBUG - 2018-07-12 15:55:01 --> Total execution time: 0.0563
DEBUG - 2018-07-12 15:55:09 --> Config Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Hooks Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Utf8 Class Initialized
DEBUG - 2018-07-12 15:55:09 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 15:55:09 --> URI Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Router Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Output Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Security Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Input Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 15:55:09 --> Language Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Loader Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Helper loaded: date_helper
DEBUG - 2018-07-12 15:55:09 --> Controller Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Database Driver Class Initialized
ERROR - 2018-07-12 15:55:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 15:55:09 --> Model Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Model Class Initialized
DEBUG - 2018-07-12 15:55:09 --> Helper loaded: url_helper
DEBUG - 2018-07-12 15:55:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-07-12 15:55:09 --> Final output sent to browser
DEBUG - 2018-07-12 15:55:09 --> Total execution time: 0.0444
DEBUG - 2018-07-12 20:42:17 --> Config Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Hooks Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Utf8 Class Initialized
DEBUG - 2018-07-12 20:42:17 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 20:42:17 --> URI Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Router Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Output Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Security Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Input Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 20:42:17 --> Language Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Loader Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Helper loaded: date_helper
DEBUG - 2018-07-12 20:42:17 --> Controller Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Database Driver Class Initialized
ERROR - 2018-07-12 20:42:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 20:42:17 --> Model Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Model Class Initialized
DEBUG - 2018-07-12 20:42:17 --> Helper loaded: url_helper
DEBUG - 2018-07-12 20:42:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 20:42:17 --> Final output sent to browser
DEBUG - 2018-07-12 20:42:17 --> Total execution time: 0.0217
DEBUG - 2018-07-12 21:15:28 --> Config Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Hooks Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Utf8 Class Initialized
DEBUG - 2018-07-12 21:15:28 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 21:15:28 --> URI Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Router Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Output Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Security Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Input Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 21:15:28 --> Language Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Loader Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Helper loaded: date_helper
DEBUG - 2018-07-12 21:15:28 --> Controller Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Database Driver Class Initialized
ERROR - 2018-07-12 21:15:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 21:15:28 --> Model Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Model Class Initialized
DEBUG - 2018-07-12 21:15:28 --> Helper loaded: url_helper
DEBUG - 2018-07-12 21:15:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 21:15:28 --> Final output sent to browser
DEBUG - 2018-07-12 21:15:28 --> Total execution time: 0.0212
DEBUG - 2018-07-12 21:34:50 --> Config Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Hooks Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Utf8 Class Initialized
DEBUG - 2018-07-12 21:34:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 21:34:50 --> URI Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Router Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Output Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Security Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Input Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 21:34:50 --> Language Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Loader Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Helper loaded: date_helper
DEBUG - 2018-07-12 21:34:50 --> Controller Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Database Driver Class Initialized
ERROR - 2018-07-12 21:34:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 21:34:50 --> Model Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Model Class Initialized
DEBUG - 2018-07-12 21:34:50 --> Helper loaded: url_helper
DEBUG - 2018-07-12 21:34:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-12 21:34:50 --> Final output sent to browser
DEBUG - 2018-07-12 21:34:50 --> Total execution time: 0.0212
DEBUG - 2018-07-12 23:47:54 --> Config Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Hooks Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Utf8 Class Initialized
DEBUG - 2018-07-12 23:47:54 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 23:47:54 --> URI Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Router Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Output Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Security Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Input Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 23:47:54 --> Language Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Loader Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Helper loaded: date_helper
DEBUG - 2018-07-12 23:47:54 --> Controller Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Database Driver Class Initialized
ERROR - 2018-07-12 23:47:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 23:47:54 --> Model Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Model Class Initialized
DEBUG - 2018-07-12 23:47:54 --> Helper loaded: url_helper
DEBUG - 2018-07-12 23:47:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-07-12 23:47:54 --> Final output sent to browser
DEBUG - 2018-07-12 23:47:54 --> Total execution time: 0.0542
DEBUG - 2018-07-12 23:47:59 --> Config Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Hooks Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Utf8 Class Initialized
DEBUG - 2018-07-12 23:47:59 --> UTF-8 Support Enabled
DEBUG - 2018-07-12 23:47:59 --> URI Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Router Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Output Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Security Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Input Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-12 23:47:59 --> Language Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Loader Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Helper loaded: date_helper
DEBUG - 2018-07-12 23:47:59 --> Controller Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Database Driver Class Initialized
ERROR - 2018-07-12 23:47:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-12 23:47:59 --> Model Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Model Class Initialized
DEBUG - 2018-07-12 23:47:59 --> Helper loaded: url_helper
DEBUG - 2018-07-12 23:47:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-07-12 23:47:59 --> Final output sent to browser
DEBUG - 2018-07-12 23:47:59 --> Total execution time: 0.0459
