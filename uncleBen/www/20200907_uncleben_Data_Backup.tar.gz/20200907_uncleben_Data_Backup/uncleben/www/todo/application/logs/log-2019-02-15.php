<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-02-15 16:56:55 --> Config Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Hooks Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Utf8 Class Initialized
DEBUG - 2019-02-15 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-02-15 16:56:55 --> URI Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Router Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Output Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Security Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Input Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-15 16:56:55 --> Language Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Loader Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Helper loaded: date_helper
DEBUG - 2019-02-15 16:56:55 --> Controller Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Database Driver Class Initialized
ERROR - 2019-02-15 16:56:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-15 16:56:55 --> Model Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Model Class Initialized
DEBUG - 2019-02-15 16:56:55 --> Helper loaded: url_helper
DEBUG - 2019-02-15 16:56:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-15 16:56:55 --> Final output sent to browser
DEBUG - 2019-02-15 16:56:55 --> Total execution time: 0.0483
DEBUG - 2019-02-15 22:24:50 --> Config Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Hooks Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Utf8 Class Initialized
DEBUG - 2019-02-15 22:24:50 --> UTF-8 Support Enabled
DEBUG - 2019-02-15 22:24:50 --> URI Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Router Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Output Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Security Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Input Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-15 22:24:50 --> Language Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Loader Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Helper loaded: date_helper
DEBUG - 2019-02-15 22:24:50 --> Controller Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Database Driver Class Initialized
ERROR - 2019-02-15 22:24:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-15 22:24:50 --> Model Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Model Class Initialized
DEBUG - 2019-02-15 22:24:50 --> Helper loaded: url_helper
DEBUG - 2019-02-15 22:24:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-15 22:24:50 --> Final output sent to browser
DEBUG - 2019-02-15 22:24:50 --> Total execution time: 0.0538
DEBUG - 2019-02-15 23:43:21 --> Config Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Hooks Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Utf8 Class Initialized
DEBUG - 2019-02-15 23:43:21 --> UTF-8 Support Enabled
DEBUG - 2019-02-15 23:43:21 --> URI Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Router Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Output Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Security Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Input Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-15 23:43:21 --> Language Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Loader Class Initialized
DEBUG - 2019-02-15 23:43:21 --> Helper loaded: date_helper
DEBUG - 2019-02-15 23:43:21 --> Controller Class Initialized
DEBUG - 2019-02-15 23:43:22 --> Database Driver Class Initialized
ERROR - 2019-02-15 23:43:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-15 23:43:22 --> Model Class Initialized
DEBUG - 2019-02-15 23:43:22 --> Model Class Initialized
DEBUG - 2019-02-15 23:43:22 --> Helper loaded: url_helper
DEBUG - 2019-02-15 23:43:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-15 23:43:22 --> Final output sent to browser
DEBUG - 2019-02-15 23:43:22 --> Total execution time: 0.0293
