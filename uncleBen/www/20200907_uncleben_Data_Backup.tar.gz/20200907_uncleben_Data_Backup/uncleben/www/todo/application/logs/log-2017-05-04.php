<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-04 05:52:55 --> Config Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Hooks Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Utf8 Class Initialized
DEBUG - 2017-05-04 05:52:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 05:52:55 --> URI Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Router Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Output Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Security Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Input Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 05:52:55 --> Language Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Loader Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Helper loaded: date_helper
DEBUG - 2017-05-04 05:52:55 --> Controller Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Database Driver Class Initialized
ERROR - 2017-05-04 05:52:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 05:52:55 --> Model Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Model Class Initialized
DEBUG - 2017-05-04 05:52:55 --> Helper loaded: url_helper
DEBUG - 2017-05-04 05:52:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 05:52:55 --> Final output sent to browser
DEBUG - 2017-05-04 05:52:55 --> Total execution time: 0.0491
DEBUG - 2017-05-04 05:53:04 --> Config Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Hooks Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Utf8 Class Initialized
DEBUG - 2017-05-04 05:53:04 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 05:53:04 --> URI Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Router Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Output Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Security Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Input Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 05:53:04 --> Language Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Loader Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Helper loaded: date_helper
DEBUG - 2017-05-04 05:53:04 --> Controller Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Database Driver Class Initialized
ERROR - 2017-05-04 05:53:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 05:53:04 --> Model Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Model Class Initialized
DEBUG - 2017-05-04 05:53:04 --> Helper loaded: url_helper
DEBUG - 2017-05-04 05:53:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 05:53:04 --> Final output sent to browser
DEBUG - 2017-05-04 05:53:04 --> Total execution time: 0.0325
DEBUG - 2017-05-04 05:54:25 --> Config Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Hooks Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Utf8 Class Initialized
DEBUG - 2017-05-04 05:54:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 05:54:25 --> URI Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Router Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Output Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Security Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Input Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 05:54:25 --> Language Class Initialized
DEBUG - 2017-05-04 05:54:25 --> Loader Class Initialized
DEBUG - 2017-05-04 05:54:26 --> Helper loaded: date_helper
DEBUG - 2017-05-04 05:54:26 --> Controller Class Initialized
DEBUG - 2017-05-04 05:54:26 --> Database Driver Class Initialized
ERROR - 2017-05-04 05:54:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 05:54:26 --> Model Class Initialized
DEBUG - 2017-05-04 05:54:26 --> Model Class Initialized
DEBUG - 2017-05-04 05:54:26 --> Helper loaded: url_helper
DEBUG - 2017-05-04 05:54:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 05:54:26 --> Final output sent to browser
DEBUG - 2017-05-04 05:54:26 --> Total execution time: 0.0311
DEBUG - 2017-05-04 06:29:20 --> Config Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:29:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:29:20 --> URI Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Router Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Output Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Security Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Input Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:29:20 --> Language Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Loader Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Helper loaded: date_helper
DEBUG - 2017-05-04 06:29:20 --> Controller Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:29:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 06:29:20 --> Model Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Model Class Initialized
DEBUG - 2017-05-04 06:29:20 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:29:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 06:29:20 --> Final output sent to browser
DEBUG - 2017-05-04 06:29:20 --> Total execution time: 0.0317
DEBUG - 2017-05-04 06:32:28 --> Config Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:32:28 --> URI Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Router Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Output Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Security Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Input Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:32:28 --> Language Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Loader Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Helper loaded: date_helper
DEBUG - 2017-05-04 06:32:28 --> Controller Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:32:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 06:32:28 --> Model Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Model Class Initialized
DEBUG - 2017-05-04 06:32:28 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:32:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 06:32:28 --> Final output sent to browser
DEBUG - 2017-05-04 06:32:28 --> Total execution time: 0.0314
DEBUG - 2017-05-04 06:33:56 --> Config Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:33:56 --> URI Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Router Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Output Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Security Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Input Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:33:56 --> Language Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Loader Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Helper loaded: date_helper
DEBUG - 2017-05-04 06:33:56 --> Controller Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:33:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 06:33:56 --> Model Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Model Class Initialized
DEBUG - 2017-05-04 06:33:56 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:33:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 06:33:56 --> Final output sent to browser
DEBUG - 2017-05-04 06:33:56 --> Total execution time: 0.0321
DEBUG - 2017-05-04 06:34:35 --> Config Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:34:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:34:35 --> URI Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Router Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Output Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Security Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Input Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:34:35 --> Language Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Loader Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Helper loaded: date_helper
DEBUG - 2017-05-04 06:34:35 --> Controller Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:34:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 06:34:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Model Class Initialized
DEBUG - 2017-05-04 06:34:35 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:34:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 06:34:35 --> Final output sent to browser
DEBUG - 2017-05-04 06:34:35 --> Total execution time: 0.0318
DEBUG - 2017-05-04 06:36:02 --> Config Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Hooks Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Utf8 Class Initialized
DEBUG - 2017-05-04 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 06:36:02 --> URI Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Router Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Output Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Security Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Input Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 06:36:02 --> Language Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Loader Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Helper loaded: date_helper
DEBUG - 2017-05-04 06:36:02 --> Controller Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Database Driver Class Initialized
ERROR - 2017-05-04 06:36:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 06:36:02 --> Model Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Model Class Initialized
DEBUG - 2017-05-04 06:36:02 --> Helper loaded: url_helper
DEBUG - 2017-05-04 06:36:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 06:36:02 --> Final output sent to browser
DEBUG - 2017-05-04 06:36:02 --> Total execution time: 0.0312
DEBUG - 2017-05-04 07:13:07 --> Config Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:13:07 --> URI Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Router Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Output Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Security Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Input Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:13:07 --> Language Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Loader Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Helper loaded: date_helper
DEBUG - 2017-05-04 07:13:07 --> Controller Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:13:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 07:13:07 --> Model Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Model Class Initialized
DEBUG - 2017-05-04 07:13:07 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:13:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 07:13:07 --> Final output sent to browser
DEBUG - 2017-05-04 07:13:07 --> Total execution time: 0.0294
DEBUG - 2017-05-04 07:13:09 --> Config Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:13:09 --> URI Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Router Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Output Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Security Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Input Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:13:09 --> Language Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Loader Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Helper loaded: date_helper
DEBUG - 2017-05-04 07:13:09 --> Controller Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:13:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 07:13:09 --> Model Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Model Class Initialized
DEBUG - 2017-05-04 07:13:09 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:13:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 07:13:09 --> Final output sent to browser
DEBUG - 2017-05-04 07:13:09 --> Total execution time: 0.0293
DEBUG - 2017-05-04 07:18:08 --> Config Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:18:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:18:08 --> URI Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Router Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Output Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Security Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Input Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:18:08 --> Language Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Loader Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Helper loaded: date_helper
DEBUG - 2017-05-04 07:18:08 --> Controller Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:18:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 07:18:08 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:08 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:18:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 07:18:08 --> Final output sent to browser
DEBUG - 2017-05-04 07:18:08 --> Total execution time: 0.0296
DEBUG - 2017-05-04 07:18:10 --> Config Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:18:10 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:18:10 --> URI Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Router Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Output Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Security Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Input Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:18:10 --> Language Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Loader Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Helper loaded: date_helper
DEBUG - 2017-05-04 07:18:10 --> Controller Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:18:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 07:18:10 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:10 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:18:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 07:18:10 --> Final output sent to browser
DEBUG - 2017-05-04 07:18:10 --> Total execution time: 0.0301
DEBUG - 2017-05-04 07:18:11 --> Config Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:18:11 --> URI Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Router Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Output Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Security Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Input Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:18:11 --> Language Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Loader Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Helper loaded: date_helper
DEBUG - 2017-05-04 07:18:11 --> Controller Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:18:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 07:18:11 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:11 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:18:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 07:18:11 --> Final output sent to browser
DEBUG - 2017-05-04 07:18:11 --> Total execution time: 0.0296
DEBUG - 2017-05-04 07:18:15 --> Config Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:18:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:18:15 --> URI Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Router Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Output Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Security Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Input Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:18:15 --> Language Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Loader Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Helper loaded: date_helper
DEBUG - 2017-05-04 07:18:15 --> Controller Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:18:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 07:18:15 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:15 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:18:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 07:18:15 --> Final output sent to browser
DEBUG - 2017-05-04 07:18:15 --> Total execution time: 0.0299
DEBUG - 2017-05-04 07:18:17 --> Config Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Hooks Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Utf8 Class Initialized
DEBUG - 2017-05-04 07:18:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 07:18:17 --> URI Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Router Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Output Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Security Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Input Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 07:18:17 --> Language Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Loader Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Helper loaded: date_helper
DEBUG - 2017-05-04 07:18:17 --> Controller Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Database Driver Class Initialized
ERROR - 2017-05-04 07:18:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 07:18:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Model Class Initialized
DEBUG - 2017-05-04 07:18:17 --> Helper loaded: url_helper
DEBUG - 2017-05-04 07:18:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 07:18:17 --> Final output sent to browser
DEBUG - 2017-05-04 07:18:17 --> Total execution time: 0.0295
DEBUG - 2017-05-04 09:40:02 --> Config Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Hooks Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Utf8 Class Initialized
DEBUG - 2017-05-04 09:40:02 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 09:40:02 --> URI Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Router Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Output Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Security Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Input Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 09:40:02 --> Language Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Loader Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Helper loaded: date_helper
DEBUG - 2017-05-04 09:40:02 --> Controller Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Database Driver Class Initialized
ERROR - 2017-05-04 09:40:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 09:40:02 --> Model Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Model Class Initialized
DEBUG - 2017-05-04 09:40:02 --> Helper loaded: url_helper
DEBUG - 2017-05-04 09:40:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 09:40:02 --> Final output sent to browser
DEBUG - 2017-05-04 09:40:02 --> Total execution time: 0.0361
DEBUG - 2017-05-04 09:40:07 --> Config Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Hooks Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Utf8 Class Initialized
DEBUG - 2017-05-04 09:40:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 09:40:07 --> URI Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Router Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Output Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Security Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Input Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 09:40:07 --> Language Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Loader Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Helper loaded: date_helper
DEBUG - 2017-05-04 09:40:07 --> Controller Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Database Driver Class Initialized
ERROR - 2017-05-04 09:40:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 09:40:07 --> Model Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Model Class Initialized
DEBUG - 2017-05-04 09:40:07 --> Helper loaded: url_helper
DEBUG - 2017-05-04 09:40:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 09:40:07 --> Final output sent to browser
DEBUG - 2017-05-04 09:40:07 --> Total execution time: 0.0321
DEBUG - 2017-05-04 09:40:11 --> Config Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Hooks Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Utf8 Class Initialized
DEBUG - 2017-05-04 09:40:11 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 09:40:11 --> URI Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Router Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Output Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Security Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Input Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 09:40:11 --> Language Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Loader Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Helper loaded: date_helper
DEBUG - 2017-05-04 09:40:11 --> Controller Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Database Driver Class Initialized
ERROR - 2017-05-04 09:40:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 09:40:11 --> Model Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Model Class Initialized
DEBUG - 2017-05-04 09:40:11 --> Helper loaded: url_helper
DEBUG - 2017-05-04 09:40:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 09:40:11 --> Final output sent to browser
DEBUG - 2017-05-04 09:40:11 --> Total execution time: 0.0311
DEBUG - 2017-05-04 09:52:03 --> Config Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Hooks Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Utf8 Class Initialized
DEBUG - 2017-05-04 09:52:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-04 09:52:03 --> URI Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Router Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Output Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Security Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Input Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-04 09:52:03 --> Language Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Loader Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Helper loaded: date_helper
DEBUG - 2017-05-04 09:52:03 --> Controller Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Database Driver Class Initialized
ERROR - 2017-05-04 09:52:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-04 09:52:03 --> Model Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Model Class Initialized
DEBUG - 2017-05-04 09:52:03 --> Helper loaded: url_helper
DEBUG - 2017-05-04 09:52:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-04 09:52:03 --> Final output sent to browser
DEBUG - 2017-05-04 09:52:03 --> Total execution time: 0.0311
