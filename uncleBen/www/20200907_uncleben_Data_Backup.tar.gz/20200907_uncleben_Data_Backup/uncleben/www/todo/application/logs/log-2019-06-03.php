<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-06-03 00:02:30 --> Config Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Hooks Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Utf8 Class Initialized
DEBUG - 2019-06-03 00:02:30 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 00:02:30 --> URI Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Router Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Output Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Security Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Input Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 00:02:30 --> Language Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Loader Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Helper loaded: date_helper
DEBUG - 2019-06-03 00:02:30 --> Controller Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Database Driver Class Initialized
ERROR - 2019-06-03 00:02:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 00:02:30 --> Model Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Model Class Initialized
DEBUG - 2019-06-03 00:02:30 --> Helper loaded: url_helper
DEBUG - 2019-06-03 00:02:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 00:02:30 --> Final output sent to browser
DEBUG - 2019-06-03 00:02:30 --> Total execution time: 0.0595
DEBUG - 2019-06-03 00:09:36 --> Config Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Hooks Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Utf8 Class Initialized
DEBUG - 2019-06-03 00:09:36 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 00:09:36 --> URI Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Router Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Output Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Security Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Input Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 00:09:36 --> Language Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Loader Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Helper loaded: date_helper
DEBUG - 2019-06-03 00:09:36 --> Controller Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Database Driver Class Initialized
ERROR - 2019-06-03 00:09:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 00:09:36 --> Model Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Model Class Initialized
DEBUG - 2019-06-03 00:09:36 --> Helper loaded: url_helper
DEBUG - 2019-06-03 00:09:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 00:09:36 --> Final output sent to browser
DEBUG - 2019-06-03 00:09:36 --> Total execution time: 0.0315
DEBUG - 2019-06-03 09:22:47 --> Config Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:22:47 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:22:47 --> URI Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Router Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Output Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Security Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Input Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:22:47 --> Language Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Loader Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:22:47 --> Controller Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:22:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:22:47 --> Model Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Model Class Initialized
DEBUG - 2019-06-03 09:22:47 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:22:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:22:47 --> Final output sent to browser
DEBUG - 2019-06-03 09:22:47 --> Total execution time: 0.0513
DEBUG - 2019-06-03 09:22:49 --> Config Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:22:49 --> URI Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Router Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Output Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Security Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Input Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:22:49 --> Language Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Loader Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:22:49 --> Controller Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:22:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:22:49 --> Model Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Model Class Initialized
DEBUG - 2019-06-03 09:22:49 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:22:49 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:22:49 --> Final output sent to browser
DEBUG - 2019-06-03 09:22:49 --> Total execution time: 0.0212
DEBUG - 2019-06-03 09:23:08 --> Config Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:23:08 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:23:08 --> URI Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Router Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Output Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Security Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Input Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:23:08 --> Language Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Loader Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:23:08 --> Controller Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:23:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:23:08 --> Model Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Model Class Initialized
DEBUG - 2019-06-03 09:23:08 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:23:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:23:08 --> Final output sent to browser
DEBUG - 2019-06-03 09:23:08 --> Total execution time: 0.0294
DEBUG - 2019-06-03 09:23:11 --> Config Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:23:11 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:23:11 --> URI Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Router Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Output Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Security Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Input Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:23:11 --> Language Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Loader Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:23:11 --> Controller Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:23:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:23:11 --> Model Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Model Class Initialized
DEBUG - 2019-06-03 09:23:11 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:23:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:23:11 --> Final output sent to browser
DEBUG - 2019-06-03 09:23:11 --> Total execution time: 0.0211
DEBUG - 2019-06-03 09:23:12 --> Config Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:23:12 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:23:12 --> URI Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Router Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Output Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Security Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Input Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:23:12 --> Language Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Loader Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:23:12 --> Controller Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:23:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:23:12 --> Model Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Model Class Initialized
DEBUG - 2019-06-03 09:23:12 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:23:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:23:12 --> Final output sent to browser
DEBUG - 2019-06-03 09:23:12 --> Total execution time: 0.0324
DEBUG - 2019-06-03 09:24:09 --> Config Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:24:09 --> URI Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Router Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Output Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Security Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Input Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:24:09 --> Language Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Loader Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:24:09 --> Controller Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:24:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:24:09 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:09 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:24:09 --> File loaded: application/views/todo/search_v.php
DEBUG - 2019-06-03 09:24:09 --> Final output sent to browser
DEBUG - 2019-06-03 09:24:09 --> Total execution time: 0.0221
DEBUG - 2019-06-03 09:24:15 --> Config Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:24:15 --> URI Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Router Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Output Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Security Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Input Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:24:15 --> Language Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Loader Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:24:15 --> Controller Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:24:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:24:15 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:15 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:24:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:24:15 --> Final output sent to browser
DEBUG - 2019-06-03 09:24:15 --> Total execution time: 0.0223
DEBUG - 2019-06-03 09:24:16 --> Config Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:24:16 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:24:16 --> URI Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Router Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Output Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Security Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Input Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:24:16 --> Language Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Loader Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:24:16 --> Controller Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:24:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:24:16 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:16 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:24:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:24:16 --> Final output sent to browser
DEBUG - 2019-06-03 09:24:16 --> Total execution time: 0.0251
DEBUG - 2019-06-03 09:24:18 --> Config Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:24:18 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:24:18 --> URI Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Router Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Output Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Security Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Input Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:24:18 --> Language Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Loader Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:24:18 --> Controller Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:24:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:24:18 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:24:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:24:18 --> Final output sent to browser
DEBUG - 2019-06-03 09:24:18 --> Total execution time: 0.0242
DEBUG - 2019-06-03 09:24:18 --> Config Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Hooks Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Utf8 Class Initialized
DEBUG - 2019-06-03 09:24:18 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 09:24:18 --> URI Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Router Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Output Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Security Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Input Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 09:24:18 --> Language Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Loader Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Helper loaded: date_helper
DEBUG - 2019-06-03 09:24:18 --> Controller Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Database Driver Class Initialized
ERROR - 2019-06-03 09:24:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 09:24:18 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Model Class Initialized
DEBUG - 2019-06-03 09:24:18 --> Helper loaded: url_helper
DEBUG - 2019-06-03 09:24:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 09:24:18 --> Final output sent to browser
DEBUG - 2019-06-03 09:24:18 --> Total execution time: 0.0198
DEBUG - 2019-06-03 10:56:24 --> Config Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Utf8 Class Initialized
DEBUG - 2019-06-03 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 10:56:24 --> URI Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Router Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Output Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Security Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Input Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 10:56:24 --> Language Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Loader Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Helper loaded: date_helper
DEBUG - 2019-06-03 10:56:24 --> Controller Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Database Driver Class Initialized
ERROR - 2019-06-03 10:56:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 10:56:24 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:24 --> Helper loaded: url_helper
DEBUG - 2019-06-03 10:56:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 10:56:24 --> Final output sent to browser
DEBUG - 2019-06-03 10:56:24 --> Total execution time: 0.0216
DEBUG - 2019-06-03 10:56:26 --> Config Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Utf8 Class Initialized
DEBUG - 2019-06-03 10:56:26 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 10:56:26 --> URI Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Router Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Output Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Security Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Input Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 10:56:26 --> Language Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Loader Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Helper loaded: date_helper
DEBUG - 2019-06-03 10:56:26 --> Controller Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Database Driver Class Initialized
ERROR - 2019-06-03 10:56:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 10:56:26 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:26 --> Helper loaded: url_helper
DEBUG - 2019-06-03 10:56:26 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2019-06-03 10:56:26 --> Final output sent to browser
DEBUG - 2019-06-03 10:56:26 --> Total execution time: 0.0375
DEBUG - 2019-06-03 10:56:28 --> Config Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Utf8 Class Initialized
DEBUG - 2019-06-03 10:56:28 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 10:56:28 --> URI Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Router Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Output Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Security Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Input Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 10:56:28 --> Language Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Loader Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Helper loaded: date_helper
DEBUG - 2019-06-03 10:56:28 --> Controller Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Database Driver Class Initialized
ERROR - 2019-06-03 10:56:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 10:56:28 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:28 --> Helper loaded: url_helper
DEBUG - 2019-06-03 10:56:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 10:56:28 --> Final output sent to browser
DEBUG - 2019-06-03 10:56:28 --> Total execution time: 0.0214
DEBUG - 2019-06-03 10:56:33 --> Config Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Hooks Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Utf8 Class Initialized
DEBUG - 2019-06-03 10:56:33 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 10:56:33 --> URI Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Router Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Output Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Security Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Input Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 10:56:33 --> Language Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Loader Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Helper loaded: date_helper
DEBUG - 2019-06-03 10:56:33 --> Controller Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Database Driver Class Initialized
ERROR - 2019-06-03 10:56:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 10:56:33 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Model Class Initialized
DEBUG - 2019-06-03 10:56:33 --> Helper loaded: url_helper
DEBUG - 2019-06-03 10:56:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 10:56:33 --> Final output sent to browser
DEBUG - 2019-06-03 10:56:33 --> Total execution time: 0.0219
DEBUG - 2019-06-03 15:14:29 --> Config Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Hooks Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Utf8 Class Initialized
DEBUG - 2019-06-03 15:14:29 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 15:14:29 --> URI Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Router Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Output Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Security Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Input Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 15:14:29 --> Language Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Loader Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Helper loaded: date_helper
DEBUG - 2019-06-03 15:14:29 --> Controller Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Database Driver Class Initialized
ERROR - 2019-06-03 15:14:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 15:14:29 --> Model Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Model Class Initialized
DEBUG - 2019-06-03 15:14:29 --> Helper loaded: url_helper
DEBUG - 2019-06-03 15:14:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 15:14:29 --> Final output sent to browser
DEBUG - 2019-06-03 15:14:29 --> Total execution time: 0.0470
DEBUG - 2019-06-03 22:16:41 --> Config Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Hooks Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Utf8 Class Initialized
DEBUG - 2019-06-03 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2019-06-03 22:16:41 --> URI Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Router Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Output Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Security Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Input Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-06-03 22:16:41 --> Language Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Loader Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Helper loaded: date_helper
DEBUG - 2019-06-03 22:16:41 --> Controller Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Database Driver Class Initialized
ERROR - 2019-06-03 22:16:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-06-03 22:16:41 --> Model Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Model Class Initialized
DEBUG - 2019-06-03 22:16:41 --> Helper loaded: url_helper
DEBUG - 2019-06-03 22:16:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-06-03 22:16:41 --> Final output sent to browser
DEBUG - 2019-06-03 22:16:41 --> Total execution time: 0.0340
