<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-15 00:55:19 --> Config Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Hooks Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Utf8 Class Initialized
DEBUG - 2017-10-15 00:55:19 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 00:55:19 --> URI Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Router Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Output Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Security Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Input Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 00:55:19 --> Language Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Loader Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Helper loaded: date_helper
DEBUG - 2017-10-15 00:55:19 --> Controller Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Database Driver Class Initialized
ERROR - 2017-10-15 00:55:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 00:55:19 --> Model Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Model Class Initialized
DEBUG - 2017-10-15 00:55:19 --> Helper loaded: url_helper
DEBUG - 2017-10-15 00:55:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 00:55:19 --> Final output sent to browser
DEBUG - 2017-10-15 00:55:19 --> Total execution time: 0.0211
DEBUG - 2017-10-15 02:57:36 --> Config Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Hooks Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Utf8 Class Initialized
DEBUG - 2017-10-15 02:57:36 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 02:57:36 --> URI Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Router Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Output Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Security Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Input Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 02:57:36 --> Language Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Loader Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Helper loaded: date_helper
DEBUG - 2017-10-15 02:57:36 --> Controller Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Database Driver Class Initialized
ERROR - 2017-10-15 02:57:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 02:57:36 --> Model Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Model Class Initialized
DEBUG - 2017-10-15 02:57:36 --> Helper loaded: url_helper
DEBUG - 2017-10-15 02:57:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 02:57:36 --> Final output sent to browser
DEBUG - 2017-10-15 02:57:36 --> Total execution time: 0.0200
DEBUG - 2017-10-15 04:40:19 --> Config Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Hooks Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Utf8 Class Initialized
DEBUG - 2017-10-15 04:40:19 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 04:40:19 --> URI Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Router Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Output Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Security Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Input Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 04:40:19 --> Language Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Loader Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Helper loaded: date_helper
DEBUG - 2017-10-15 04:40:19 --> Controller Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Database Driver Class Initialized
ERROR - 2017-10-15 04:40:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 04:40:19 --> Model Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Model Class Initialized
DEBUG - 2017-10-15 04:40:19 --> Helper loaded: url_helper
DEBUG - 2017-10-15 04:40:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 04:40:19 --> Final output sent to browser
DEBUG - 2017-10-15 04:40:19 --> Total execution time: 0.0203
DEBUG - 2017-10-15 06:12:59 --> Config Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Hooks Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Utf8 Class Initialized
DEBUG - 2017-10-15 06:12:59 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 06:12:59 --> URI Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Router Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Output Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Security Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Input Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 06:12:59 --> Language Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Loader Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Helper loaded: date_helper
DEBUG - 2017-10-15 06:12:59 --> Controller Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Database Driver Class Initialized
ERROR - 2017-10-15 06:12:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 06:12:59 --> Model Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Model Class Initialized
DEBUG - 2017-10-15 06:12:59 --> Helper loaded: url_helper
DEBUG - 2017-10-15 06:12:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 06:12:59 --> Final output sent to browser
DEBUG - 2017-10-15 06:12:59 --> Total execution time: 0.0253
DEBUG - 2017-10-15 07:56:59 --> Config Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Hooks Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Utf8 Class Initialized
DEBUG - 2017-10-15 07:56:59 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 07:56:59 --> URI Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Router Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Output Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Security Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Input Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 07:56:59 --> Language Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Loader Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Helper loaded: date_helper
DEBUG - 2017-10-15 07:56:59 --> Controller Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Database Driver Class Initialized
ERROR - 2017-10-15 07:56:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 07:56:59 --> Model Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Model Class Initialized
DEBUG - 2017-10-15 07:56:59 --> Helper loaded: url_helper
DEBUG - 2017-10-15 07:56:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 07:56:59 --> Final output sent to browser
DEBUG - 2017-10-15 07:56:59 --> Total execution time: 0.0199
DEBUG - 2017-10-15 11:49:05 --> Config Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Hooks Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Utf8 Class Initialized
DEBUG - 2017-10-15 11:49:05 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 11:49:05 --> URI Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Router Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Output Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Security Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Input Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 11:49:05 --> Language Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Loader Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Helper loaded: date_helper
DEBUG - 2017-10-15 11:49:05 --> Controller Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Database Driver Class Initialized
ERROR - 2017-10-15 11:49:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 11:49:05 --> Model Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Model Class Initialized
DEBUG - 2017-10-15 11:49:05 --> Helper loaded: url_helper
DEBUG - 2017-10-15 11:49:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 11:49:05 --> Final output sent to browser
DEBUG - 2017-10-15 11:49:05 --> Total execution time: 0.0206
DEBUG - 2017-10-15 14:56:33 --> Config Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Hooks Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Utf8 Class Initialized
DEBUG - 2017-10-15 14:56:33 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 14:56:33 --> URI Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Router Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Output Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Security Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Input Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 14:56:33 --> Language Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Loader Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Helper loaded: date_helper
DEBUG - 2017-10-15 14:56:33 --> Controller Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Database Driver Class Initialized
ERROR - 2017-10-15 14:56:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 14:56:33 --> Model Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Model Class Initialized
DEBUG - 2017-10-15 14:56:33 --> Helper loaded: url_helper
DEBUG - 2017-10-15 14:56:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 14:56:33 --> Final output sent to browser
DEBUG - 2017-10-15 14:56:33 --> Total execution time: 0.0205
DEBUG - 2017-10-15 18:27:20 --> Config Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Hooks Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Utf8 Class Initialized
DEBUG - 2017-10-15 18:27:20 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 18:27:20 --> URI Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Router Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Output Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Security Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Input Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 18:27:20 --> Language Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Loader Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Helper loaded: date_helper
DEBUG - 2017-10-15 18:27:20 --> Controller Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Database Driver Class Initialized
ERROR - 2017-10-15 18:27:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 18:27:20 --> Model Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Model Class Initialized
DEBUG - 2017-10-15 18:27:20 --> Helper loaded: url_helper
DEBUG - 2017-10-15 18:27:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 18:27:20 --> Final output sent to browser
DEBUG - 2017-10-15 18:27:20 --> Total execution time: 0.0207
DEBUG - 2017-10-15 21:57:17 --> Config Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Hooks Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Utf8 Class Initialized
DEBUG - 2017-10-15 21:57:17 --> UTF-8 Support Enabled
DEBUG - 2017-10-15 21:57:17 --> URI Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Router Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Output Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Security Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Input Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-15 21:57:17 --> Language Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Loader Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Helper loaded: date_helper
DEBUG - 2017-10-15 21:57:17 --> Controller Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Database Driver Class Initialized
ERROR - 2017-10-15 21:57:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-15 21:57:17 --> Model Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Model Class Initialized
DEBUG - 2017-10-15 21:57:17 --> Helper loaded: url_helper
DEBUG - 2017-10-15 21:57:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-15 21:57:17 --> Final output sent to browser
DEBUG - 2017-10-15 21:57:17 --> Total execution time: 0.0210
