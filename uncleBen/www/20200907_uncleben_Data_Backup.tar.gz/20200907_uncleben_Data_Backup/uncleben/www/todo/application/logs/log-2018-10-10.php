<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-10-10 16:29:30 --> Config Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Hooks Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Utf8 Class Initialized
DEBUG - 2018-10-10 16:29:30 --> UTF-8 Support Enabled
DEBUG - 2018-10-10 16:29:30 --> URI Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Router Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Output Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Security Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Input Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-10 16:29:30 --> Language Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Loader Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Helper loaded: date_helper
DEBUG - 2018-10-10 16:29:30 --> Controller Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Database Driver Class Initialized
ERROR - 2018-10-10 16:29:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-10 16:29:30 --> Model Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Model Class Initialized
DEBUG - 2018-10-10 16:29:30 --> Helper loaded: url_helper
DEBUG - 2018-10-10 16:29:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-10 16:29:30 --> Final output sent to browser
DEBUG - 2018-10-10 16:29:30 --> Total execution time: 0.0600
