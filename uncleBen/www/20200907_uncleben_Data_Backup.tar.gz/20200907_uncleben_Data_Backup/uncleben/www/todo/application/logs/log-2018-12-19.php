<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-19 02:43:28 --> Config Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Hooks Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Utf8 Class Initialized
DEBUG - 2018-12-19 02:43:28 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 02:43:28 --> URI Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Router Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Output Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Security Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Input Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 02:43:28 --> Language Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Loader Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Helper loaded: date_helper
DEBUG - 2018-12-19 02:43:28 --> Controller Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Database Driver Class Initialized
ERROR - 2018-12-19 02:43:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 02:43:28 --> Model Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Model Class Initialized
DEBUG - 2018-12-19 02:43:28 --> Helper loaded: url_helper
DEBUG - 2018-12-19 02:43:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 02:43:28 --> Final output sent to browser
DEBUG - 2018-12-19 02:43:28 --> Total execution time: 0.0766
DEBUG - 2018-12-19 11:15:36 --> Config Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Hooks Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Utf8 Class Initialized
DEBUG - 2018-12-19 11:15:36 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 11:15:36 --> URI Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Router Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Output Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Security Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Input Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 11:15:36 --> Language Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Loader Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Helper loaded: date_helper
DEBUG - 2018-12-19 11:15:36 --> Controller Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Database Driver Class Initialized
ERROR - 2018-12-19 11:15:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 11:15:36 --> Model Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Model Class Initialized
DEBUG - 2018-12-19 11:15:36 --> Helper loaded: url_helper
DEBUG - 2018-12-19 11:15:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 11:15:36 --> Final output sent to browser
DEBUG - 2018-12-19 11:15:36 --> Total execution time: 0.0441
DEBUG - 2018-12-19 11:43:01 --> Config Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Hooks Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Utf8 Class Initialized
DEBUG - 2018-12-19 11:43:01 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 11:43:01 --> URI Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Router Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Output Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Security Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Input Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 11:43:01 --> Language Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Loader Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Helper loaded: date_helper
DEBUG - 2018-12-19 11:43:01 --> Controller Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Database Driver Class Initialized
ERROR - 2018-12-19 11:43:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 11:43:01 --> Model Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Model Class Initialized
DEBUG - 2018-12-19 11:43:01 --> Helper loaded: url_helper
DEBUG - 2018-12-19 11:43:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 11:43:01 --> Final output sent to browser
DEBUG - 2018-12-19 11:43:01 --> Total execution time: 0.0234
DEBUG - 2018-12-19 13:13:30 --> Config Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Hooks Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Utf8 Class Initialized
DEBUG - 2018-12-19 13:13:30 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 13:13:30 --> URI Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Router Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Output Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Security Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Input Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 13:13:30 --> Language Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Loader Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Helper loaded: date_helper
DEBUG - 2018-12-19 13:13:30 --> Controller Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Database Driver Class Initialized
ERROR - 2018-12-19 13:13:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 13:13:30 --> Model Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Model Class Initialized
DEBUG - 2018-12-19 13:13:30 --> Helper loaded: url_helper
DEBUG - 2018-12-19 13:13:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 13:13:30 --> Final output sent to browser
DEBUG - 2018-12-19 13:13:30 --> Total execution time: 0.0326
DEBUG - 2018-12-19 14:37:02 --> Config Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Hooks Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Utf8 Class Initialized
DEBUG - 2018-12-19 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 14:37:02 --> URI Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Router Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Output Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Security Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Input Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 14:37:02 --> Language Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Loader Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Helper loaded: date_helper
DEBUG - 2018-12-19 14:37:02 --> Controller Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Database Driver Class Initialized
ERROR - 2018-12-19 14:37:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 14:37:02 --> Model Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Model Class Initialized
DEBUG - 2018-12-19 14:37:02 --> Helper loaded: url_helper
DEBUG - 2018-12-19 14:37:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 14:37:02 --> Final output sent to browser
DEBUG - 2018-12-19 14:37:02 --> Total execution time: 0.1214
DEBUG - 2018-12-19 15:52:09 --> Config Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Hooks Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Utf8 Class Initialized
DEBUG - 2018-12-19 15:52:09 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 15:52:09 --> URI Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Router Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Output Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Security Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Input Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 15:52:09 --> Language Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Loader Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Helper loaded: date_helper
DEBUG - 2018-12-19 15:52:09 --> Controller Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Database Driver Class Initialized
ERROR - 2018-12-19 15:52:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 15:52:09 --> Model Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Model Class Initialized
DEBUG - 2018-12-19 15:52:09 --> Helper loaded: url_helper
DEBUG - 2018-12-19 15:52:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 15:52:09 --> Final output sent to browser
DEBUG - 2018-12-19 15:52:09 --> Total execution time: 0.2549
DEBUG - 2018-12-19 16:50:13 --> Config Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Hooks Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Utf8 Class Initialized
DEBUG - 2018-12-19 16:50:13 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 16:50:13 --> URI Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Router Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Output Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Security Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Input Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 16:50:13 --> Language Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Loader Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Helper loaded: date_helper
DEBUG - 2018-12-19 16:50:13 --> Controller Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Database Driver Class Initialized
ERROR - 2018-12-19 16:50:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 16:50:13 --> Model Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Model Class Initialized
DEBUG - 2018-12-19 16:50:13 --> Helper loaded: url_helper
DEBUG - 2018-12-19 16:50:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 16:50:13 --> Final output sent to browser
DEBUG - 2018-12-19 16:50:13 --> Total execution time: 0.1185
DEBUG - 2018-12-19 18:29:00 --> Config Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Hooks Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Utf8 Class Initialized
DEBUG - 2018-12-19 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2018-12-19 18:29:00 --> URI Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Router Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Output Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Security Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Input Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-19 18:29:00 --> Language Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Loader Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Helper loaded: date_helper
DEBUG - 2018-12-19 18:29:00 --> Controller Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Database Driver Class Initialized
ERROR - 2018-12-19 18:29:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-19 18:29:00 --> Model Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Model Class Initialized
DEBUG - 2018-12-19 18:29:00 --> Helper loaded: url_helper
DEBUG - 2018-12-19 18:29:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-19 18:29:00 --> Final output sent to browser
DEBUG - 2018-12-19 18:29:00 --> Total execution time: 0.0240
