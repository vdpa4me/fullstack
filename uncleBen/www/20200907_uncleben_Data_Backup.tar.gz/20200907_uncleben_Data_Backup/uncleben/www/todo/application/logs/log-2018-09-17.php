<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-09-17 00:40:14 --> Config Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Hooks Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Utf8 Class Initialized
DEBUG - 2018-09-17 00:40:14 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 00:40:14 --> URI Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Router Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Output Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Security Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Input Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-17 00:40:14 --> Language Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Loader Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Helper loaded: date_helper
DEBUG - 2018-09-17 00:40:14 --> Controller Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Database Driver Class Initialized
ERROR - 2018-09-17 00:40:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-17 00:40:14 --> Model Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Model Class Initialized
DEBUG - 2018-09-17 00:40:14 --> Helper loaded: url_helper
DEBUG - 2018-09-17 00:40:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-17 00:40:14 --> Final output sent to browser
DEBUG - 2018-09-17 00:40:14 --> Total execution time: 0.0405
DEBUG - 2018-09-17 03:55:53 --> Config Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Hooks Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Utf8 Class Initialized
DEBUG - 2018-09-17 03:55:53 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 03:55:53 --> URI Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Router Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Output Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Security Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Input Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-17 03:55:53 --> Language Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Loader Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Helper loaded: date_helper
DEBUG - 2018-09-17 03:55:53 --> Controller Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Database Driver Class Initialized
ERROR - 2018-09-17 03:55:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-17 03:55:53 --> Model Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Model Class Initialized
DEBUG - 2018-09-17 03:55:53 --> Helper loaded: url_helper
DEBUG - 2018-09-17 03:55:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-17 03:55:53 --> Final output sent to browser
DEBUG - 2018-09-17 03:55:53 --> Total execution time: 0.0230
DEBUG - 2018-09-17 20:29:23 --> Config Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Hooks Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Utf8 Class Initialized
DEBUG - 2018-09-17 20:29:23 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 20:29:23 --> URI Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Router Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Output Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Security Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Input Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-17 20:29:23 --> Language Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Loader Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Helper loaded: date_helper
DEBUG - 2018-09-17 20:29:23 --> Controller Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Database Driver Class Initialized
ERROR - 2018-09-17 20:29:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-17 20:29:23 --> Model Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Model Class Initialized
DEBUG - 2018-09-17 20:29:23 --> Helper loaded: url_helper
DEBUG - 2018-09-17 20:29:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-17 20:29:23 --> Final output sent to browser
DEBUG - 2018-09-17 20:29:23 --> Total execution time: 0.0389
