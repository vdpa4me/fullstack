<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-03-18 01:01:11 --> Config Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:01:11 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:01:11 --> URI Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Router Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Output Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Security Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Input Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:01:11 --> Language Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Loader Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:01:11 --> Controller Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:01:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:01:11 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:11 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:01:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:01:11 --> Final output sent to browser
DEBUG - 2019-03-18 01:01:11 --> Total execution time: 0.1105
DEBUG - 2019-03-18 01:01:16 --> Config Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:01:16 --> URI Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Router Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Output Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Security Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Input Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:01:16 --> Language Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Loader Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:01:16 --> Controller Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:01:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:01:16 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:16 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:01:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:01:16 --> Final output sent to browser
DEBUG - 2019-03-18 01:01:16 --> Total execution time: 0.0776
DEBUG - 2019-03-18 01:01:21 --> Config Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:01:21 --> URI Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Router Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Output Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Security Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Input Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:01:21 --> Language Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Loader Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:01:21 --> Controller Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:01:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:01:21 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:21 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:01:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:01:21 --> Final output sent to browser
DEBUG - 2019-03-18 01:01:21 --> Total execution time: 0.0490
DEBUG - 2019-03-18 01:01:28 --> Config Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:01:28 --> URI Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Router Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Output Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Security Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Input Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:01:28 --> Language Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Loader Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:01:28 --> Controller Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:01:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:01:28 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Model Class Initialized
DEBUG - 2019-03-18 01:01:28 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:01:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:01:28 --> Final output sent to browser
DEBUG - 2019-03-18 01:01:28 --> Total execution time: 0.0466
DEBUG - 2019-03-18 01:02:47 --> Config Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:02:47 --> URI Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Router Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Output Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Security Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Input Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:02:47 --> Language Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Loader Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:02:47 --> Controller Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:02:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:02:47 --> Model Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Model Class Initialized
DEBUG - 2019-03-18 01:02:47 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:02:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:02:47 --> Final output sent to browser
DEBUG - 2019-03-18 01:02:47 --> Total execution time: 0.0632
DEBUG - 2019-03-18 01:06:09 --> Config Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:06:09 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:06:09 --> URI Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Router Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Output Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Security Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Input Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:06:09 --> Language Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Loader Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:06:09 --> Controller Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:06:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:06:09 --> Model Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Model Class Initialized
DEBUG - 2019-03-18 01:06:09 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:06:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:06:10 --> Final output sent to browser
DEBUG - 2019-03-18 01:06:10 --> Total execution time: 0.0693
DEBUG - 2019-03-18 01:10:17 --> Config Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:10:17 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:10:17 --> URI Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Router Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Output Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Security Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Input Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:10:17 --> Language Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Loader Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:10:17 --> Controller Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:10:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:10:17 --> Model Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Model Class Initialized
DEBUG - 2019-03-18 01:10:17 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:10:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:10:17 --> Final output sent to browser
DEBUG - 2019-03-18 01:10:17 --> Total execution time: 0.0473
DEBUG - 2019-03-18 01:10:50 --> Config Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Hooks Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Utf8 Class Initialized
DEBUG - 2019-03-18 01:10:50 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 01:10:50 --> URI Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Router Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Output Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Security Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Input Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 01:10:50 --> Language Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Loader Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Helper loaded: date_helper
DEBUG - 2019-03-18 01:10:50 --> Controller Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Database Driver Class Initialized
ERROR - 2019-03-18 01:10:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 01:10:50 --> Model Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Model Class Initialized
DEBUG - 2019-03-18 01:10:50 --> Helper loaded: url_helper
DEBUG - 2019-03-18 01:10:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-18 01:10:50 --> Final output sent to browser
DEBUG - 2019-03-18 01:10:50 --> Total execution time: 0.0593
DEBUG - 2019-03-18 03:02:30 --> Config Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Hooks Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Utf8 Class Initialized
DEBUG - 2019-03-18 03:02:30 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 03:02:30 --> URI Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Router Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Output Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Security Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Input Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 03:02:30 --> Language Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Loader Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Helper loaded: date_helper
DEBUG - 2019-03-18 03:02:30 --> Controller Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Database Driver Class Initialized
ERROR - 2019-03-18 03:02:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 03:02:30 --> Model Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Model Class Initialized
DEBUG - 2019-03-18 03:02:30 --> Helper loaded: url_helper
DEBUG - 2019-03-18 03:02:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-18 03:02:30 --> Final output sent to browser
DEBUG - 2019-03-18 03:02:30 --> Total execution time: 0.0400
DEBUG - 2019-03-18 13:01:05 --> Config Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Hooks Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Utf8 Class Initialized
DEBUG - 2019-03-18 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-03-18 13:01:05 --> URI Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Router Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Output Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Security Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Input Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-18 13:01:05 --> Language Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Loader Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Helper loaded: date_helper
DEBUG - 2019-03-18 13:01:05 --> Controller Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Database Driver Class Initialized
ERROR - 2019-03-18 13:01:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-18 13:01:05 --> Model Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Model Class Initialized
DEBUG - 2019-03-18 13:01:05 --> Helper loaded: url_helper
DEBUG - 2019-03-18 13:01:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-18 13:01:05 --> Final output sent to browser
DEBUG - 2019-03-18 13:01:05 --> Total execution time: 0.0597
