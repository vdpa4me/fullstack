<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-11-29 05:03:14 --> Config Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Hooks Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Utf8 Class Initialized
DEBUG - 2019-11-29 05:03:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-29 05:03:14 --> URI Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Router Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Output Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Security Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Input Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-29 05:03:14 --> Language Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Loader Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Helper loaded: date_helper
DEBUG - 2019-11-29 05:03:14 --> Controller Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Database Driver Class Initialized
ERROR - 2019-11-29 05:03:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-29 05:03:14 --> Model Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Model Class Initialized
DEBUG - 2019-11-29 05:03:14 --> Helper loaded: url_helper
DEBUG - 2019-11-29 05:03:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-29 05:03:14 --> Final output sent to browser
DEBUG - 2019-11-29 05:03:14 --> Total execution time: 0.0997
DEBUG - 2019-11-29 15:54:44 --> Config Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Hooks Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Utf8 Class Initialized
DEBUG - 2019-11-29 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-29 15:54:44 --> URI Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Router Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Output Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Security Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Input Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-29 15:54:44 --> Language Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Loader Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Helper loaded: date_helper
DEBUG - 2019-11-29 15:54:44 --> Controller Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Database Driver Class Initialized
ERROR - 2019-11-29 15:54:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-29 15:54:44 --> Model Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Model Class Initialized
DEBUG - 2019-11-29 15:54:44 --> Helper loaded: url_helper
DEBUG - 2019-11-29 15:54:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-29 15:54:44 --> Final output sent to browser
DEBUG - 2019-11-29 15:54:44 --> Total execution time: 0.1922
DEBUG - 2019-11-29 16:09:13 --> Config Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Hooks Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Utf8 Class Initialized
DEBUG - 2019-11-29 16:09:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-29 16:09:13 --> URI Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Router Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Output Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Security Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Input Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-29 16:09:13 --> Language Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Loader Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Helper loaded: date_helper
DEBUG - 2019-11-29 16:09:13 --> Controller Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Database Driver Class Initialized
ERROR - 2019-11-29 16:09:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-29 16:09:13 --> Model Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Model Class Initialized
DEBUG - 2019-11-29 16:09:13 --> Helper loaded: url_helper
DEBUG - 2019-11-29 16:09:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-29 16:09:13 --> Final output sent to browser
DEBUG - 2019-11-29 16:09:13 --> Total execution time: 0.0859
DEBUG - 2019-11-29 20:57:32 --> Config Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Hooks Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Utf8 Class Initialized
DEBUG - 2019-11-29 20:57:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-29 20:57:32 --> URI Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Router Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Output Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Security Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Input Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-29 20:57:32 --> Language Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Loader Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Helper loaded: date_helper
DEBUG - 2019-11-29 20:57:32 --> Controller Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Database Driver Class Initialized
ERROR - 2019-11-29 20:57:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-29 20:57:32 --> Model Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Model Class Initialized
DEBUG - 2019-11-29 20:57:32 --> Helper loaded: url_helper
DEBUG - 2019-11-29 20:57:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-29 20:57:32 --> Final output sent to browser
DEBUG - 2019-11-29 20:57:32 --> Total execution time: 0.0914
