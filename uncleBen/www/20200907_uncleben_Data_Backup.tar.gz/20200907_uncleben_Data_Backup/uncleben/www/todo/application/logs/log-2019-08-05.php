<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-08-05 08:41:13 --> Config Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Hooks Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Utf8 Class Initialized
DEBUG - 2019-08-05 08:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-08-05 08:41:13 --> URI Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Router Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Output Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Security Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Input Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-05 08:41:13 --> Language Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Loader Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Helper loaded: date_helper
DEBUG - 2019-08-05 08:41:13 --> Controller Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Database Driver Class Initialized
ERROR - 2019-08-05 08:41:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-05 08:41:13 --> Model Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Model Class Initialized
DEBUG - 2019-08-05 08:41:13 --> Helper loaded: url_helper
DEBUG - 2019-08-05 08:41:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-05 08:41:13 --> Final output sent to browser
DEBUG - 2019-08-05 08:41:13 --> Total execution time: 0.0472
DEBUG - 2019-08-05 10:10:19 --> Config Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Hooks Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Utf8 Class Initialized
DEBUG - 2019-08-05 10:10:19 --> UTF-8 Support Enabled
DEBUG - 2019-08-05 10:10:19 --> URI Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Router Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Output Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Security Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Input Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-05 10:10:19 --> Language Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Loader Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Helper loaded: date_helper
DEBUG - 2019-08-05 10:10:19 --> Controller Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Database Driver Class Initialized
ERROR - 2019-08-05 10:10:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-05 10:10:19 --> Model Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Model Class Initialized
DEBUG - 2019-08-05 10:10:19 --> Helper loaded: url_helper
DEBUG - 2019-08-05 10:10:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-05 10:10:19 --> Final output sent to browser
DEBUG - 2019-08-05 10:10:19 --> Total execution time: 0.0231
