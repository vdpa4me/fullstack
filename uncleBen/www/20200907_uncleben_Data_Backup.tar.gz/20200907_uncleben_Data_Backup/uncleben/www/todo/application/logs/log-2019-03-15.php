<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-03-15 05:02:41 --> Config Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Hooks Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Utf8 Class Initialized
DEBUG - 2019-03-15 05:02:41 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 05:02:41 --> URI Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Router Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Output Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Security Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Input Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-15 05:02:41 --> Language Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Loader Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Helper loaded: date_helper
DEBUG - 2019-03-15 05:02:41 --> Controller Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Database Driver Class Initialized
ERROR - 2019-03-15 05:02:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-15 05:02:41 --> Model Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Model Class Initialized
DEBUG - 2019-03-15 05:02:41 --> Helper loaded: url_helper
DEBUG - 2019-03-15 05:02:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-15 05:02:41 --> Final output sent to browser
DEBUG - 2019-03-15 05:02:41 --> Total execution time: 0.0598
DEBUG - 2019-03-15 06:27:17 --> Config Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Hooks Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Utf8 Class Initialized
DEBUG - 2019-03-15 06:27:17 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 06:27:17 --> URI Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Router Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Output Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Security Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Input Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-15 06:27:17 --> Language Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Loader Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Helper loaded: date_helper
DEBUG - 2019-03-15 06:27:17 --> Controller Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Database Driver Class Initialized
ERROR - 2019-03-15 06:27:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-15 06:27:17 --> Model Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Model Class Initialized
DEBUG - 2019-03-15 06:27:17 --> Helper loaded: url_helper
DEBUG - 2019-03-15 06:27:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-15 06:27:17 --> Final output sent to browser
DEBUG - 2019-03-15 06:27:17 --> Total execution time: 0.0393
DEBUG - 2019-03-15 11:42:42 --> Config Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Hooks Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Utf8 Class Initialized
DEBUG - 2019-03-15 11:42:42 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 11:42:42 --> URI Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Router Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Output Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Security Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Input Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-15 11:42:42 --> Language Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Loader Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Helper loaded: date_helper
DEBUG - 2019-03-15 11:42:42 --> Controller Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Database Driver Class Initialized
ERROR - 2019-03-15 11:42:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-15 11:42:42 --> Model Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Model Class Initialized
DEBUG - 2019-03-15 11:42:42 --> Helper loaded: url_helper
DEBUG - 2019-03-15 11:42:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-15 11:42:42 --> Final output sent to browser
DEBUG - 2019-03-15 11:42:42 --> Total execution time: 0.0387
DEBUG - 2019-03-15 15:58:55 --> Config Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Hooks Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Utf8 Class Initialized
DEBUG - 2019-03-15 15:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 15:58:55 --> URI Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Router Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Output Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Security Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Input Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-15 15:58:55 --> Language Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Loader Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Helper loaded: date_helper
DEBUG - 2019-03-15 15:58:55 --> Controller Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Database Driver Class Initialized
ERROR - 2019-03-15 15:58:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-15 15:58:55 --> Model Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Model Class Initialized
DEBUG - 2019-03-15 15:58:55 --> Helper loaded: url_helper
DEBUG - 2019-03-15 15:58:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-15 15:58:55 --> Final output sent to browser
DEBUG - 2019-03-15 15:58:55 --> Total execution time: 0.0306
