<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-11-24 07:11:35 --> Config Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Hooks Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Utf8 Class Initialized
DEBUG - 2019-11-24 07:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-24 07:11:35 --> URI Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Router Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Output Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Security Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Input Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-24 07:11:35 --> Language Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Loader Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Helper loaded: date_helper
DEBUG - 2019-11-24 07:11:35 --> Controller Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Database Driver Class Initialized
ERROR - 2019-11-24 07:11:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-24 07:11:35 --> Model Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Model Class Initialized
DEBUG - 2019-11-24 07:11:35 --> Helper loaded: url_helper
DEBUG - 2019-11-24 07:11:35 --> File loaded: application/views/todo/search_v.php
DEBUG - 2019-11-24 07:11:35 --> Final output sent to browser
DEBUG - 2019-11-24 07:11:35 --> Total execution time: 0.1894
DEBUG - 2019-11-24 08:31:40 --> Config Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Hooks Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Utf8 Class Initialized
DEBUG - 2019-11-24 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-24 08:31:40 --> URI Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Router Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Output Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Security Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Input Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-24 08:31:40 --> Language Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Loader Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Helper loaded: date_helper
DEBUG - 2019-11-24 08:31:40 --> Controller Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Database Driver Class Initialized
ERROR - 2019-11-24 08:31:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-24 08:31:40 --> Model Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Model Class Initialized
DEBUG - 2019-11-24 08:31:40 --> Helper loaded: url_helper
DEBUG - 2019-11-24 08:31:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-24 08:31:40 --> Final output sent to browser
DEBUG - 2019-11-24 08:31:40 --> Total execution time: 0.1107
DEBUG - 2019-11-24 10:41:54 --> Config Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Hooks Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Utf8 Class Initialized
DEBUG - 2019-11-24 10:41:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-24 10:41:54 --> URI Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Router Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Output Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Security Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Input Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-24 10:41:54 --> Language Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Loader Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Helper loaded: date_helper
DEBUG - 2019-11-24 10:41:54 --> Controller Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Database Driver Class Initialized
ERROR - 2019-11-24 10:41:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-24 10:41:54 --> Model Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Model Class Initialized
DEBUG - 2019-11-24 10:41:54 --> Helper loaded: url_helper
DEBUG - 2019-11-24 10:41:54 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2019-11-24 10:41:54 --> Final output sent to browser
DEBUG - 2019-11-24 10:41:54 --> Total execution time: 0.1140
DEBUG - 2019-11-24 10:53:39 --> Config Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Hooks Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Utf8 Class Initialized
DEBUG - 2019-11-24 10:53:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-24 10:53:39 --> URI Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Router Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Output Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Security Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Input Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-24 10:53:39 --> Language Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Loader Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Helper loaded: date_helper
DEBUG - 2019-11-24 10:53:39 --> Controller Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Database Driver Class Initialized
ERROR - 2019-11-24 10:53:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-24 10:53:39 --> Model Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Model Class Initialized
DEBUG - 2019-11-24 10:53:39 --> Helper loaded: url_helper
DEBUG - 2019-11-24 10:53:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-24 10:53:39 --> Final output sent to browser
DEBUG - 2019-11-24 10:53:39 --> Total execution time: 0.1099
DEBUG - 2019-11-24 12:51:34 --> Config Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Hooks Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Utf8 Class Initialized
DEBUG - 2019-11-24 12:51:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-24 12:51:34 --> URI Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Router Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Output Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Security Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Input Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-24 12:51:34 --> Language Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Loader Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Helper loaded: date_helper
DEBUG - 2019-11-24 12:51:34 --> Controller Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Database Driver Class Initialized
ERROR - 2019-11-24 12:51:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-24 12:51:34 --> Model Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Model Class Initialized
DEBUG - 2019-11-24 12:51:34 --> Helper loaded: url_helper
DEBUG - 2019-11-24 12:51:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-24 12:51:34 --> Final output sent to browser
DEBUG - 2019-11-24 12:51:34 --> Total execution time: 0.0910
