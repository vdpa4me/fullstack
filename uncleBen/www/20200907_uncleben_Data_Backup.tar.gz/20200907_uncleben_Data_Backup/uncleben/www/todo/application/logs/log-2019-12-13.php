<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-12-13 17:42:53 --> Config Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Hooks Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Utf8 Class Initialized
DEBUG - 2019-12-13 17:42:53 --> UTF-8 Support Enabled
DEBUG - 2019-12-13 17:42:53 --> URI Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Router Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Output Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Security Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Input Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-13 17:42:53 --> Language Class Initialized
DEBUG - 2019-12-13 17:42:53 --> Loader Class Initialized
DEBUG - 2019-12-13 17:42:54 --> Helper loaded: date_helper
DEBUG - 2019-12-13 17:42:54 --> Controller Class Initialized
DEBUG - 2019-12-13 17:42:54 --> Database Driver Class Initialized
ERROR - 2019-12-13 17:42:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-13 17:42:54 --> Model Class Initialized
DEBUG - 2019-12-13 17:42:54 --> Model Class Initialized
DEBUG - 2019-12-13 17:42:54 --> Helper loaded: url_helper
DEBUG - 2019-12-13 17:42:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-13 17:42:54 --> Final output sent to browser
DEBUG - 2019-12-13 17:42:54 --> Total execution time: 0.2290
DEBUG - 2019-12-13 22:28:11 --> Config Class Initialized
DEBUG - 2019-12-13 22:28:11 --> Hooks Class Initialized
DEBUG - 2019-12-13 22:28:11 --> Utf8 Class Initialized
DEBUG - 2019-12-13 22:28:11 --> UTF-8 Support Enabled
DEBUG - 2019-12-13 22:28:11 --> URI Class Initialized
DEBUG - 2019-12-13 22:28:11 --> Router Class Initialized
DEBUG - 2019-12-13 22:28:11 --> Output Class Initialized
DEBUG - 2019-12-13 22:28:11 --> Security Class Initialized
DEBUG - 2019-12-13 22:28:11 --> Input Class Initialized
DEBUG - 2019-12-13 22:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-13 22:28:11 --> Language Class Initialized
DEBUG - 2019-12-13 22:28:12 --> Loader Class Initialized
DEBUG - 2019-12-13 22:28:12 --> Helper loaded: date_helper
DEBUG - 2019-12-13 22:28:12 --> Controller Class Initialized
DEBUG - 2019-12-13 22:28:12 --> Database Driver Class Initialized
ERROR - 2019-12-13 22:28:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-13 22:28:12 --> Model Class Initialized
DEBUG - 2019-12-13 22:28:12 --> Model Class Initialized
DEBUG - 2019-12-13 22:28:12 --> Helper loaded: url_helper
DEBUG - 2019-12-13 22:28:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-13 22:28:12 --> Final output sent to browser
DEBUG - 2019-12-13 22:28:12 --> Total execution time: 0.1645
