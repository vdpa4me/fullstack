<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-03-27 07:21:10 --> Config Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Hooks Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Utf8 Class Initialized
DEBUG - 2020-03-27 07:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-27 07:21:10 --> URI Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Router Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Output Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Security Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Input Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2020-03-27 07:21:10 --> Language Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Loader Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Helper loaded: date_helper
DEBUG - 2020-03-27 07:21:10 --> Controller Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Database Driver Class Initialized
ERROR - 2020-03-27 07:21:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-03-27 07:21:10 --> Model Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Model Class Initialized
DEBUG - 2020-03-27 07:21:10 --> Helper loaded: url_helper
DEBUG - 2020-03-27 07:21:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-03-27 07:21:10 --> Final output sent to browser
DEBUG - 2020-03-27 07:21:10 --> Total execution time: 0.1664
