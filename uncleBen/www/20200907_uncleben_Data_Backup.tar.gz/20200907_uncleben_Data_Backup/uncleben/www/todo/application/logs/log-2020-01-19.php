<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-01-19 00:35:52 --> Config Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Hooks Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Utf8 Class Initialized
DEBUG - 2020-01-19 00:35:52 --> UTF-8 Support Enabled
DEBUG - 2020-01-19 00:35:52 --> URI Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Router Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Output Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Security Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Input Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2020-01-19 00:35:52 --> Language Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Loader Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Helper loaded: date_helper
DEBUG - 2020-01-19 00:35:52 --> Controller Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Database Driver Class Initialized
ERROR - 2020-01-19 00:35:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-01-19 00:35:52 --> Model Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Model Class Initialized
DEBUG - 2020-01-19 00:35:52 --> Helper loaded: url_helper
DEBUG - 2020-01-19 00:35:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-01-19 00:35:53 --> Final output sent to browser
DEBUG - 2020-01-19 00:35:53 --> Total execution time: 0.2071
DEBUG - 2020-01-19 00:35:55 --> Config Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Hooks Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Utf8 Class Initialized
DEBUG - 2020-01-19 00:35:55 --> UTF-8 Support Enabled
DEBUG - 2020-01-19 00:35:55 --> URI Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Router Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Output Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Security Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Input Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2020-01-19 00:35:55 --> Language Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Loader Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Helper loaded: date_helper
DEBUG - 2020-01-19 00:35:55 --> Controller Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Database Driver Class Initialized
ERROR - 2020-01-19 00:35:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-01-19 00:35:55 --> Model Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Model Class Initialized
DEBUG - 2020-01-19 00:35:55 --> Helper loaded: url_helper
DEBUG - 2020-01-19 00:35:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-01-19 00:35:55 --> Final output sent to browser
DEBUG - 2020-01-19 00:35:55 --> Total execution time: 0.0765
DEBUG - 2020-01-19 09:53:55 --> Config Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Hooks Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Utf8 Class Initialized
DEBUG - 2020-01-19 09:53:55 --> UTF-8 Support Enabled
DEBUG - 2020-01-19 09:53:55 --> URI Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Router Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Output Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Security Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Input Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2020-01-19 09:53:55 --> Language Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Loader Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Helper loaded: date_helper
DEBUG - 2020-01-19 09:53:55 --> Controller Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Database Driver Class Initialized
ERROR - 2020-01-19 09:53:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-01-19 09:53:55 --> Model Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Model Class Initialized
DEBUG - 2020-01-19 09:53:55 --> Helper loaded: url_helper
DEBUG - 2020-01-19 09:53:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-01-19 09:53:55 --> Final output sent to browser
DEBUG - 2020-01-19 09:53:55 --> Total execution time: 0.2129
DEBUG - 2020-01-19 21:54:38 --> Config Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Hooks Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Utf8 Class Initialized
DEBUG - 2020-01-19 21:54:38 --> UTF-8 Support Enabled
DEBUG - 2020-01-19 21:54:38 --> URI Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Router Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Output Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Security Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Input Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2020-01-19 21:54:38 --> Language Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Loader Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Helper loaded: date_helper
DEBUG - 2020-01-19 21:54:38 --> Controller Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Database Driver Class Initialized
ERROR - 2020-01-19 21:54:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-01-19 21:54:38 --> Model Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Model Class Initialized
DEBUG - 2020-01-19 21:54:38 --> Helper loaded: url_helper
DEBUG - 2020-01-19 21:54:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-01-19 21:54:38 --> Final output sent to browser
DEBUG - 2020-01-19 21:54:38 --> Total execution time: 0.1843
