<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-03-28 00:55:31 --> Config Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Hooks Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Utf8 Class Initialized
DEBUG - 2019-03-28 00:55:31 --> UTF-8 Support Enabled
DEBUG - 2019-03-28 00:55:31 --> URI Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Router Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Output Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Security Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Input Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-28 00:55:31 --> Language Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Loader Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Helper loaded: date_helper
DEBUG - 2019-03-28 00:55:31 --> Controller Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Database Driver Class Initialized
ERROR - 2019-03-28 00:55:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-28 00:55:31 --> Model Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Model Class Initialized
DEBUG - 2019-03-28 00:55:31 --> Helper loaded: url_helper
DEBUG - 2019-03-28 00:55:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-28 00:55:31 --> Final output sent to browser
DEBUG - 2019-03-28 00:55:31 --> Total execution time: 0.0406
DEBUG - 2019-03-28 01:13:49 --> Config Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Hooks Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Utf8 Class Initialized
DEBUG - 2019-03-28 01:13:49 --> UTF-8 Support Enabled
DEBUG - 2019-03-28 01:13:49 --> URI Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Router Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Output Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Security Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Input Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-28 01:13:49 --> Language Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Loader Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Helper loaded: date_helper
DEBUG - 2019-03-28 01:13:49 --> Controller Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Database Driver Class Initialized
ERROR - 2019-03-28 01:13:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-28 01:13:49 --> Model Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Model Class Initialized
DEBUG - 2019-03-28 01:13:49 --> Helper loaded: url_helper
DEBUG - 2019-03-28 01:13:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-28 01:13:49 --> Final output sent to browser
DEBUG - 2019-03-28 01:13:49 --> Total execution time: 0.0939
DEBUG - 2019-03-28 12:38:53 --> Config Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Hooks Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Utf8 Class Initialized
DEBUG - 2019-03-28 12:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-03-28 12:38:53 --> URI Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Router Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Output Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Security Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Input Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-28 12:38:53 --> Language Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Loader Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Helper loaded: date_helper
DEBUG - 2019-03-28 12:38:53 --> Controller Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Database Driver Class Initialized
ERROR - 2019-03-28 12:38:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-28 12:38:53 --> Model Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Model Class Initialized
DEBUG - 2019-03-28 12:38:53 --> Helper loaded: url_helper
DEBUG - 2019-03-28 12:38:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-28 12:38:53 --> Final output sent to browser
DEBUG - 2019-03-28 12:38:53 --> Total execution time: 0.0482
DEBUG - 2019-03-28 22:11:20 --> Config Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Hooks Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Utf8 Class Initialized
DEBUG - 2019-03-28 22:11:20 --> UTF-8 Support Enabled
DEBUG - 2019-03-28 22:11:20 --> URI Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Router Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Output Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Security Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Input Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-28 22:11:20 --> Language Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Loader Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Helper loaded: date_helper
DEBUG - 2019-03-28 22:11:20 --> Controller Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Database Driver Class Initialized
ERROR - 2019-03-28 22:11:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-28 22:11:20 --> Model Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Model Class Initialized
DEBUG - 2019-03-28 22:11:20 --> Helper loaded: url_helper
DEBUG - 2019-03-28 22:11:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-03-28 22:11:20 --> Final output sent to browser
DEBUG - 2019-03-28 22:11:20 --> Total execution time: 0.1124
