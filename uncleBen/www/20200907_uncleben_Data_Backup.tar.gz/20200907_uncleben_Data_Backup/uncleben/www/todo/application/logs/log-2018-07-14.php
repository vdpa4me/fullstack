<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-07-14 09:23:30 --> Config Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Hooks Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Utf8 Class Initialized
DEBUG - 2018-07-14 09:23:30 --> UTF-8 Support Enabled
DEBUG - 2018-07-14 09:23:30 --> URI Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Router Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Output Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Security Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Input Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-14 09:23:30 --> Language Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Loader Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Helper loaded: date_helper
DEBUG - 2018-07-14 09:23:30 --> Controller Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Database Driver Class Initialized
ERROR - 2018-07-14 09:23:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-14 09:23:30 --> Model Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Model Class Initialized
DEBUG - 2018-07-14 09:23:30 --> Helper loaded: url_helper
DEBUG - 2018-07-14 09:23:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-14 09:23:30 --> Final output sent to browser
DEBUG - 2018-07-14 09:23:30 --> Total execution time: 0.0342
DEBUG - 2018-07-14 12:15:13 --> Config Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Hooks Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Utf8 Class Initialized
DEBUG - 2018-07-14 12:15:13 --> UTF-8 Support Enabled
DEBUG - 2018-07-14 12:15:13 --> URI Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Router Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Output Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Security Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Input Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-14 12:15:13 --> Language Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Loader Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Helper loaded: date_helper
DEBUG - 2018-07-14 12:15:13 --> Controller Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Database Driver Class Initialized
ERROR - 2018-07-14 12:15:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-14 12:15:13 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:13 --> Helper loaded: url_helper
DEBUG - 2018-07-14 12:15:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-14 12:15:13 --> Final output sent to browser
DEBUG - 2018-07-14 12:15:13 --> Total execution time: 0.0210
DEBUG - 2018-07-14 12:15:14 --> Config Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Hooks Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Utf8 Class Initialized
DEBUG - 2018-07-14 12:15:14 --> UTF-8 Support Enabled
DEBUG - 2018-07-14 12:15:14 --> URI Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Router Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Output Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Security Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Input Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-14 12:15:14 --> Language Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Loader Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Helper loaded: date_helper
DEBUG - 2018-07-14 12:15:14 --> Controller Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Database Driver Class Initialized
ERROR - 2018-07-14 12:15:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-14 12:15:14 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:14 --> Helper loaded: url_helper
DEBUG - 2018-07-14 12:15:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-14 12:15:14 --> Final output sent to browser
DEBUG - 2018-07-14 12:15:14 --> Total execution time: 0.0204
DEBUG - 2018-07-14 12:15:15 --> Config Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Hooks Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Utf8 Class Initialized
DEBUG - 2018-07-14 12:15:15 --> UTF-8 Support Enabled
DEBUG - 2018-07-14 12:15:15 --> URI Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Router Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Output Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Security Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Input Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-14 12:15:15 --> Language Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Loader Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Helper loaded: date_helper
DEBUG - 2018-07-14 12:15:15 --> Controller Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Database Driver Class Initialized
ERROR - 2018-07-14 12:15:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-14 12:15:15 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:15 --> Helper loaded: url_helper
DEBUG - 2018-07-14 12:15:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-14 12:15:15 --> Final output sent to browser
DEBUG - 2018-07-14 12:15:15 --> Total execution time: 0.0213
DEBUG - 2018-07-14 12:15:16 --> Config Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Hooks Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Utf8 Class Initialized
DEBUG - 2018-07-14 12:15:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-14 12:15:16 --> URI Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Router Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Output Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Security Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Input Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-14 12:15:16 --> Language Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Loader Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Helper loaded: date_helper
DEBUG - 2018-07-14 12:15:16 --> Controller Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Database Driver Class Initialized
ERROR - 2018-07-14 12:15:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-14 12:15:16 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Helper loaded: url_helper
DEBUG - 2018-07-14 12:15:16 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-07-14 12:15:16 --> Final output sent to browser
DEBUG - 2018-07-14 12:15:16 --> Total execution time: 0.0258
DEBUG - 2018-07-14 12:15:16 --> Config Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Hooks Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Utf8 Class Initialized
DEBUG - 2018-07-14 12:15:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-14 12:15:16 --> URI Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Router Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Output Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Security Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Input Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-14 12:15:16 --> Language Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Loader Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Helper loaded: date_helper
DEBUG - 2018-07-14 12:15:16 --> Controller Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Database Driver Class Initialized
ERROR - 2018-07-14 12:15:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-14 12:15:16 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Model Class Initialized
DEBUG - 2018-07-14 12:15:16 --> Helper loaded: url_helper
DEBUG - 2018-07-14 12:15:16 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-07-14 12:15:16 --> Final output sent to browser
DEBUG - 2018-07-14 12:15:16 --> Total execution time: 0.0209
