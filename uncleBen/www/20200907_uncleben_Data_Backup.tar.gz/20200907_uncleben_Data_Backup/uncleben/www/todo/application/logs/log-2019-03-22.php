<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-03-22 05:10:26 --> Config Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Hooks Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Utf8 Class Initialized
DEBUG - 2019-03-22 05:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-03-22 05:10:26 --> URI Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Router Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Output Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Security Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Input Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-22 05:10:26 --> Language Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Loader Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Helper loaded: date_helper
DEBUG - 2019-03-22 05:10:26 --> Controller Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Database Driver Class Initialized
ERROR - 2019-03-22 05:10:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-22 05:10:26 --> Model Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Model Class Initialized
DEBUG - 2019-03-22 05:10:26 --> Helper loaded: url_helper
DEBUG - 2019-03-22 05:10:26 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-22 05:10:26 --> Final output sent to browser
DEBUG - 2019-03-22 05:10:26 --> Total execution time: 0.0609
DEBUG - 2019-03-22 17:02:03 --> Config Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Hooks Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Utf8 Class Initialized
DEBUG - 2019-03-22 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2019-03-22 17:02:03 --> URI Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Router Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Output Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Security Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Input Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-22 17:02:03 --> Language Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Loader Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Helper loaded: date_helper
DEBUG - 2019-03-22 17:02:03 --> Controller Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Database Driver Class Initialized
ERROR - 2019-03-22 17:02:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-03-22 17:02:03 --> Model Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Model Class Initialized
DEBUG - 2019-03-22 17:02:03 --> Helper loaded: url_helper
DEBUG - 2019-03-22 17:02:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-03-22 17:02:03 --> Final output sent to browser
DEBUG - 2019-03-22 17:02:03 --> Total execution time: 0.0652
