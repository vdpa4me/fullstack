<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-02-04 11:30:38 --> Config Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Hooks Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Utf8 Class Initialized
DEBUG - 2019-02-04 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-02-04 11:30:38 --> URI Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Router Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Output Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Security Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Input Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-04 11:30:38 --> Language Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Loader Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Helper loaded: date_helper
DEBUG - 2019-02-04 11:30:38 --> Controller Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Database Driver Class Initialized
ERROR - 2019-02-04 11:30:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-04 11:30:38 --> Model Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Model Class Initialized
DEBUG - 2019-02-04 11:30:38 --> Helper loaded: url_helper
DEBUG - 2019-02-04 11:30:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-04 11:30:38 --> Final output sent to browser
DEBUG - 2019-02-04 11:30:38 --> Total execution time: 0.0513
DEBUG - 2019-02-04 15:12:18 --> Config Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Hooks Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Utf8 Class Initialized
DEBUG - 2019-02-04 15:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-02-04 15:12:18 --> URI Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Router Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Output Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Security Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Input Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-04 15:12:18 --> Language Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Loader Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Helper loaded: date_helper
DEBUG - 2019-02-04 15:12:18 --> Controller Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Database Driver Class Initialized
ERROR - 2019-02-04 15:12:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-04 15:12:18 --> Model Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Model Class Initialized
DEBUG - 2019-02-04 15:12:18 --> Helper loaded: url_helper
DEBUG - 2019-02-04 15:12:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-04 15:12:18 --> Final output sent to browser
DEBUG - 2019-02-04 15:12:18 --> Total execution time: 0.0310
DEBUG - 2019-02-04 23:32:14 --> Config Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Hooks Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Utf8 Class Initialized
DEBUG - 2019-02-04 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2019-02-04 23:32:14 --> URI Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Router Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Output Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Security Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Input Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-04 23:32:14 --> Language Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Loader Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Helper loaded: date_helper
DEBUG - 2019-02-04 23:32:14 --> Controller Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Database Driver Class Initialized
ERROR - 2019-02-04 23:32:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-04 23:32:14 --> Model Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Model Class Initialized
DEBUG - 2019-02-04 23:32:14 --> Helper loaded: url_helper
DEBUG - 2019-02-04 23:32:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-04 23:32:14 --> Final output sent to browser
DEBUG - 2019-02-04 23:32:14 --> Total execution time: 0.0521
