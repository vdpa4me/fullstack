<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-06 06:48:43 --> Config Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Hooks Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Utf8 Class Initialized
DEBUG - 2018-12-06 06:48:43 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 06:48:43 --> URI Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Router Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Output Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Security Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Input Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 06:48:43 --> Language Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Loader Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Helper loaded: date_helper
DEBUG - 2018-12-06 06:48:43 --> Controller Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Database Driver Class Initialized
ERROR - 2018-12-06 06:48:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 06:48:43 --> Model Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Model Class Initialized
DEBUG - 2018-12-06 06:48:43 --> Helper loaded: url_helper
DEBUG - 2018-12-06 06:48:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-06 06:48:43 --> Final output sent to browser
DEBUG - 2018-12-06 06:48:43 --> Total execution time: 0.0437
DEBUG - 2018-12-06 10:25:17 --> Config Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Hooks Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Utf8 Class Initialized
DEBUG - 2018-12-06 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 10:25:17 --> URI Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Router Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Output Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Security Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Input Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 10:25:17 --> Language Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Loader Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Helper loaded: date_helper
DEBUG - 2018-12-06 10:25:17 --> Controller Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Database Driver Class Initialized
ERROR - 2018-12-06 10:25:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 10:25:17 --> Model Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Model Class Initialized
DEBUG - 2018-12-06 10:25:17 --> Helper loaded: url_helper
DEBUG - 2018-12-06 10:25:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 10:25:17 --> Final output sent to browser
DEBUG - 2018-12-06 10:25:17 --> Total execution time: 0.0791
DEBUG - 2018-12-06 15:52:08 --> Config Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Hooks Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Utf8 Class Initialized
DEBUG - 2018-12-06 15:52:08 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 15:52:08 --> URI Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Router Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Output Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Security Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Input Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 15:52:08 --> Language Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Loader Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Helper loaded: date_helper
DEBUG - 2018-12-06 15:52:08 --> Controller Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Database Driver Class Initialized
ERROR - 2018-12-06 15:52:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 15:52:08 --> Model Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Model Class Initialized
DEBUG - 2018-12-06 15:52:08 --> Helper loaded: url_helper
DEBUG - 2018-12-06 15:52:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 15:52:08 --> Final output sent to browser
DEBUG - 2018-12-06 15:52:08 --> Total execution time: 0.0479
DEBUG - 2018-12-06 15:54:26 --> Config Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Hooks Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Utf8 Class Initialized
DEBUG - 2018-12-06 15:54:26 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 15:54:26 --> URI Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Router Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Output Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Security Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Input Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 15:54:26 --> Language Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Loader Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Helper loaded: date_helper
DEBUG - 2018-12-06 15:54:26 --> Controller Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Database Driver Class Initialized
ERROR - 2018-12-06 15:54:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 15:54:26 --> Model Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Model Class Initialized
DEBUG - 2018-12-06 15:54:26 --> Helper loaded: url_helper
DEBUG - 2018-12-06 15:54:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 15:54:26 --> Final output sent to browser
DEBUG - 2018-12-06 15:54:26 --> Total execution time: 0.0474
DEBUG - 2018-12-06 16:00:52 --> Config Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Hooks Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Utf8 Class Initialized
DEBUG - 2018-12-06 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 16:00:52 --> URI Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Router Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Output Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Security Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Input Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 16:00:52 --> Language Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Loader Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Helper loaded: date_helper
DEBUG - 2018-12-06 16:00:52 --> Controller Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Database Driver Class Initialized
ERROR - 2018-12-06 16:00:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 16:00:52 --> Model Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Model Class Initialized
DEBUG - 2018-12-06 16:00:52 --> Helper loaded: url_helper
DEBUG - 2018-12-06 16:00:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 16:00:52 --> Final output sent to browser
DEBUG - 2018-12-06 16:00:52 --> Total execution time: 0.0463
DEBUG - 2018-12-06 16:05:04 --> Config Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Hooks Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Utf8 Class Initialized
DEBUG - 2018-12-06 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 16:05:04 --> URI Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Router Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Output Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Security Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Input Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 16:05:04 --> Language Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Loader Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Helper loaded: date_helper
DEBUG - 2018-12-06 16:05:04 --> Controller Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Database Driver Class Initialized
ERROR - 2018-12-06 16:05:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 16:05:04 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:04 --> Helper loaded: url_helper
DEBUG - 2018-12-06 16:05:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 16:05:04 --> Final output sent to browser
DEBUG - 2018-12-06 16:05:04 --> Total execution time: 0.0486
DEBUG - 2018-12-06 16:05:16 --> Config Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Hooks Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Utf8 Class Initialized
DEBUG - 2018-12-06 16:05:16 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 16:05:16 --> URI Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Router Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Output Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Security Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Input Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 16:05:16 --> Language Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Loader Class Initialized
DEBUG - 2018-12-06 16:05:16 --> Helper loaded: date_helper
DEBUG - 2018-12-06 16:05:16 --> Controller Class Initialized
DEBUG - 2018-12-06 16:05:17 --> Database Driver Class Initialized
ERROR - 2018-12-06 16:05:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 16:05:17 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:17 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:17 --> Helper loaded: url_helper
DEBUG - 2018-12-06 16:05:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 16:05:17 --> Final output sent to browser
DEBUG - 2018-12-06 16:05:17 --> Total execution time: 0.0449
DEBUG - 2018-12-06 16:05:23 --> Config Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Hooks Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Utf8 Class Initialized
DEBUG - 2018-12-06 16:05:23 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 16:05:23 --> URI Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Router Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Output Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Security Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Input Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 16:05:23 --> Language Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Loader Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Helper loaded: date_helper
DEBUG - 2018-12-06 16:05:23 --> Controller Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Database Driver Class Initialized
ERROR - 2018-12-06 16:05:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 16:05:23 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:23 --> Helper loaded: url_helper
DEBUG - 2018-12-06 16:05:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 16:05:23 --> Final output sent to browser
DEBUG - 2018-12-06 16:05:23 --> Total execution time: 0.0470
DEBUG - 2018-12-06 16:05:36 --> Config Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Hooks Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Utf8 Class Initialized
DEBUG - 2018-12-06 16:05:36 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 16:05:36 --> URI Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Router Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Output Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Security Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Input Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 16:05:36 --> Language Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Loader Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Helper loaded: date_helper
DEBUG - 2018-12-06 16:05:36 --> Controller Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Database Driver Class Initialized
ERROR - 2018-12-06 16:05:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 16:05:36 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Model Class Initialized
DEBUG - 2018-12-06 16:05:36 --> Helper loaded: url_helper
ERROR - 2018-12-06 16:05:36 --> Severity: Warning  --> strstr(): Empty needle /home/hosting_users/uncleben/www/todo/application/views/todo/yumi_v.php 142
DEBUG - 2018-12-06 16:05:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 16:05:36 --> Final output sent to browser
DEBUG - 2018-12-06 16:05:36 --> Total execution time: 0.0489
DEBUG - 2018-12-06 16:16:26 --> Config Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Hooks Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Utf8 Class Initialized
DEBUG - 2018-12-06 16:16:26 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 16:16:26 --> URI Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Router Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Output Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Security Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Input Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 16:16:26 --> Language Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Loader Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Helper loaded: date_helper
DEBUG - 2018-12-06 16:16:26 --> Controller Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Database Driver Class Initialized
ERROR - 2018-12-06 16:16:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 16:16:26 --> Model Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Model Class Initialized
DEBUG - 2018-12-06 16:16:26 --> Helper loaded: url_helper
DEBUG - 2018-12-06 16:16:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-06 16:16:26 --> Final output sent to browser
DEBUG - 2018-12-06 16:16:26 --> Total execution time: 0.0546
DEBUG - 2018-12-06 20:04:41 --> Config Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Hooks Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Utf8 Class Initialized
DEBUG - 2018-12-06 20:04:41 --> UTF-8 Support Enabled
DEBUG - 2018-12-06 20:04:41 --> URI Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Router Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Output Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Security Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Input Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-06 20:04:41 --> Language Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Loader Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Helper loaded: date_helper
DEBUG - 2018-12-06 20:04:41 --> Controller Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Database Driver Class Initialized
ERROR - 2018-12-06 20:04:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-06 20:04:41 --> Model Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Model Class Initialized
DEBUG - 2018-12-06 20:04:41 --> Helper loaded: url_helper
DEBUG - 2018-12-06 20:04:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-06 20:04:41 --> Final output sent to browser
DEBUG - 2018-12-06 20:04:41 --> Total execution time: 0.0377
