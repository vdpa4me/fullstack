<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-07-10 00:03:36 --> Config Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Hooks Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Utf8 Class Initialized
DEBUG - 2018-07-10 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2018-07-10 00:03:36 --> URI Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Router Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Output Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Security Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Input Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-10 00:03:36 --> Language Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Loader Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Helper loaded: date_helper
DEBUG - 2018-07-10 00:03:36 --> Controller Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Database Driver Class Initialized
ERROR - 2018-07-10 00:03:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-10 00:03:36 --> Model Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Model Class Initialized
DEBUG - 2018-07-10 00:03:36 --> Helper loaded: url_helper
DEBUG - 2018-07-10 00:03:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-10 00:03:36 --> Final output sent to browser
DEBUG - 2018-07-10 00:03:36 --> Total execution time: 0.0205
DEBUG - 2018-07-10 13:24:46 --> Config Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Hooks Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Utf8 Class Initialized
DEBUG - 2018-07-10 13:24:46 --> UTF-8 Support Enabled
DEBUG - 2018-07-10 13:24:46 --> URI Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Router Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Output Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Security Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Input Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-10 13:24:46 --> Language Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Loader Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Helper loaded: date_helper
DEBUG - 2018-07-10 13:24:46 --> Controller Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Database Driver Class Initialized
ERROR - 2018-07-10 13:24:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-10 13:24:46 --> Model Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Model Class Initialized
DEBUG - 2018-07-10 13:24:46 --> Helper loaded: url_helper
DEBUG - 2018-07-10 13:24:46 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-10 13:24:46 --> Final output sent to browser
DEBUG - 2018-07-10 13:24:46 --> Total execution time: 0.0362
DEBUG - 2018-07-10 19:15:28 --> Config Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Hooks Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Utf8 Class Initialized
DEBUG - 2018-07-10 19:15:28 --> UTF-8 Support Enabled
DEBUG - 2018-07-10 19:15:28 --> URI Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Router Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Output Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Security Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Input Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-10 19:15:28 --> Language Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Loader Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Helper loaded: date_helper
DEBUG - 2018-07-10 19:15:28 --> Controller Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Database Driver Class Initialized
ERROR - 2018-07-10 19:15:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-10 19:15:28 --> Model Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Model Class Initialized
DEBUG - 2018-07-10 19:15:28 --> Helper loaded: url_helper
DEBUG - 2018-07-10 19:15:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-10 19:15:28 --> Final output sent to browser
DEBUG - 2018-07-10 19:15:28 --> Total execution time: 0.0222
