<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-23 00:30:14 --> Config Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Hooks Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Utf8 Class Initialized
DEBUG - 2018-12-23 00:30:14 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 00:30:14 --> URI Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Router Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Output Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Security Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Input Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 00:30:14 --> Language Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Loader Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Helper loaded: date_helper
DEBUG - 2018-12-23 00:30:14 --> Controller Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Database Driver Class Initialized
ERROR - 2018-12-23 00:30:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 00:30:14 --> Model Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Model Class Initialized
DEBUG - 2018-12-23 00:30:14 --> Helper loaded: url_helper
DEBUG - 2018-12-23 00:30:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 00:30:14 --> Final output sent to browser
DEBUG - 2018-12-23 00:30:14 --> Total execution time: 0.0331
DEBUG - 2018-12-23 03:22:55 --> Config Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Hooks Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Utf8 Class Initialized
DEBUG - 2018-12-23 03:22:55 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 03:22:55 --> URI Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Router Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Output Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Security Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Input Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 03:22:55 --> Language Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Loader Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Helper loaded: date_helper
DEBUG - 2018-12-23 03:22:55 --> Controller Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Database Driver Class Initialized
ERROR - 2018-12-23 03:22:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 03:22:55 --> Model Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Model Class Initialized
DEBUG - 2018-12-23 03:22:55 --> Helper loaded: url_helper
DEBUG - 2018-12-23 03:22:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 03:22:55 --> Final output sent to browser
DEBUG - 2018-12-23 03:22:55 --> Total execution time: 0.0275
DEBUG - 2018-12-23 11:55:39 --> Config Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Hooks Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Utf8 Class Initialized
DEBUG - 2018-12-23 11:55:39 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 11:55:39 --> URI Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Router Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Output Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Security Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Input Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 11:55:39 --> Language Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Loader Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Helper loaded: date_helper
DEBUG - 2018-12-23 11:55:39 --> Controller Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Database Driver Class Initialized
ERROR - 2018-12-23 11:55:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 11:55:39 --> Model Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Model Class Initialized
DEBUG - 2018-12-23 11:55:39 --> Helper loaded: url_helper
DEBUG - 2018-12-23 11:55:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 11:55:39 --> Final output sent to browser
DEBUG - 2018-12-23 11:55:39 --> Total execution time: 0.0440
DEBUG - 2018-12-23 12:33:33 --> Config Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Hooks Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Utf8 Class Initialized
DEBUG - 2018-12-23 12:33:33 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 12:33:33 --> URI Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Router Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Output Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Security Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Input Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 12:33:33 --> Language Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Loader Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Helper loaded: date_helper
DEBUG - 2018-12-23 12:33:33 --> Controller Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Database Driver Class Initialized
ERROR - 2018-12-23 12:33:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 12:33:33 --> Model Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Model Class Initialized
DEBUG - 2018-12-23 12:33:33 --> Helper loaded: url_helper
DEBUG - 2018-12-23 12:33:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-23 12:33:34 --> Final output sent to browser
DEBUG - 2018-12-23 12:33:34 --> Total execution time: 0.0886
DEBUG - 2018-12-23 12:33:39 --> Config Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Hooks Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Utf8 Class Initialized
DEBUG - 2018-12-23 12:33:39 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 12:33:39 --> URI Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Router Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Output Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Security Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Input Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 12:33:39 --> Language Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Loader Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Helper loaded: date_helper
DEBUG - 2018-12-23 12:33:39 --> Controller Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Database Driver Class Initialized
ERROR - 2018-12-23 12:33:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 12:33:39 --> Model Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Model Class Initialized
DEBUG - 2018-12-23 12:33:39 --> Helper loaded: url_helper
DEBUG - 2018-12-23 12:33:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-23 12:33:39 --> Final output sent to browser
DEBUG - 2018-12-23 12:33:39 --> Total execution time: 0.0668
DEBUG - 2018-12-23 15:56:10 --> Config Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Hooks Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Utf8 Class Initialized
DEBUG - 2018-12-23 15:56:10 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 15:56:10 --> URI Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Router Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Output Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Security Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Input Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 15:56:10 --> Language Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Loader Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Helper loaded: date_helper
DEBUG - 2018-12-23 15:56:10 --> Controller Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Database Driver Class Initialized
ERROR - 2018-12-23 15:56:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 15:56:10 --> Model Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Model Class Initialized
DEBUG - 2018-12-23 15:56:10 --> Helper loaded: url_helper
DEBUG - 2018-12-23 15:56:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 15:56:10 --> Final output sent to browser
DEBUG - 2018-12-23 15:56:10 --> Total execution time: 0.0370
DEBUG - 2018-12-23 16:05:05 --> Config Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Hooks Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Utf8 Class Initialized
DEBUG - 2018-12-23 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 16:05:05 --> URI Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Router Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Output Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Security Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Input Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 16:05:05 --> Language Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Loader Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Helper loaded: date_helper
DEBUG - 2018-12-23 16:05:05 --> Controller Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Database Driver Class Initialized
ERROR - 2018-12-23 16:05:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 16:05:05 --> Model Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Model Class Initialized
DEBUG - 2018-12-23 16:05:05 --> Helper loaded: url_helper
ERROR - 2018-12-23 16:05:05 --> Severity: Warning  --> strstr(): Empty needle /home/hosting_users/uncleben/www/todo/application/views/todo/yumi_v.php 142
DEBUG - 2018-12-23 16:05:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-23 16:05:05 --> Final output sent to browser
DEBUG - 2018-12-23 16:05:05 --> Total execution time: 0.0592
DEBUG - 2018-12-23 16:20:43 --> Config Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Hooks Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Utf8 Class Initialized
DEBUG - 2018-12-23 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 16:20:43 --> URI Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Router Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Output Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Security Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Input Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 16:20:43 --> Language Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Loader Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Helper loaded: date_helper
DEBUG - 2018-12-23 16:20:43 --> Controller Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Database Driver Class Initialized
ERROR - 2018-12-23 16:20:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 16:20:43 --> Model Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Model Class Initialized
DEBUG - 2018-12-23 16:20:43 --> Helper loaded: url_helper
DEBUG - 2018-12-23 16:20:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 16:20:43 --> Final output sent to browser
DEBUG - 2018-12-23 16:20:43 --> Total execution time: 0.0310
DEBUG - 2018-12-23 17:22:19 --> Config Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Hooks Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Utf8 Class Initialized
DEBUG - 2018-12-23 17:22:19 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 17:22:19 --> URI Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Router Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Output Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Security Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Input Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 17:22:19 --> Language Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Loader Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Helper loaded: date_helper
DEBUG - 2018-12-23 17:22:19 --> Controller Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Database Driver Class Initialized
ERROR - 2018-12-23 17:22:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 17:22:19 --> Model Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Model Class Initialized
DEBUG - 2018-12-23 17:22:19 --> Helper loaded: url_helper
DEBUG - 2018-12-23 17:22:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 17:22:19 --> Final output sent to browser
DEBUG - 2018-12-23 17:22:19 --> Total execution time: 0.0350
DEBUG - 2018-12-23 17:25:01 --> Config Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Hooks Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Utf8 Class Initialized
DEBUG - 2018-12-23 17:25:01 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 17:25:01 --> URI Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Router Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Output Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Security Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Input Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 17:25:01 --> Language Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Loader Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Helper loaded: date_helper
DEBUG - 2018-12-23 17:25:01 --> Controller Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Database Driver Class Initialized
ERROR - 2018-12-23 17:25:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 17:25:01 --> Model Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Model Class Initialized
DEBUG - 2018-12-23 17:25:01 --> Helper loaded: url_helper
DEBUG - 2018-12-23 17:25:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 17:25:01 --> Final output sent to browser
DEBUG - 2018-12-23 17:25:01 --> Total execution time: 0.0204
DEBUG - 2018-12-23 18:38:55 --> Config Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Hooks Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Utf8 Class Initialized
DEBUG - 2018-12-23 18:38:55 --> UTF-8 Support Enabled
DEBUG - 2018-12-23 18:38:55 --> URI Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Router Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Output Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Security Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Input Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-23 18:38:55 --> Language Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Loader Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Helper loaded: date_helper
DEBUG - 2018-12-23 18:38:55 --> Controller Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Database Driver Class Initialized
ERROR - 2018-12-23 18:38:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-23 18:38:55 --> Model Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Model Class Initialized
DEBUG - 2018-12-23 18:38:55 --> Helper loaded: url_helper
DEBUG - 2018-12-23 18:38:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-23 18:38:55 --> Final output sent to browser
DEBUG - 2018-12-23 18:38:55 --> Total execution time: 0.0337
