<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-13 04:40:13 --> Config Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Utf8 Class Initialized
DEBUG - 2017-01-13 04:40:13 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 04:40:13 --> URI Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Router Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Output Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Security Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Input Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 04:40:13 --> Language Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Loader Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Helper loaded: date_helper
DEBUG - 2017-01-13 04:40:13 --> Controller Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Database Driver Class Initialized
ERROR - 2017-01-13 04:40:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 04:40:13 --> Model Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Model Class Initialized
DEBUG - 2017-01-13 04:40:13 --> Helper loaded: url_helper
DEBUG - 2017-01-13 04:40:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-13 04:40:13 --> Final output sent to browser
DEBUG - 2017-01-13 04:40:13 --> Total execution time: 0.0366
DEBUG - 2017-01-13 06:39:15 --> Config Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Hooks Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Utf8 Class Initialized
DEBUG - 2017-01-13 06:39:15 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 06:39:15 --> URI Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Router Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Output Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Security Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Input Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 06:39:15 --> Language Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Loader Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Helper loaded: date_helper
DEBUG - 2017-01-13 06:39:15 --> Controller Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Database Driver Class Initialized
ERROR - 2017-01-13 06:39:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 06:39:15 --> Model Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Model Class Initialized
DEBUG - 2017-01-13 06:39:15 --> Helper loaded: url_helper
DEBUG - 2017-01-13 06:39:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-13 06:39:15 --> Final output sent to browser
DEBUG - 2017-01-13 06:39:15 --> Total execution time: 0.0395
DEBUG - 2017-01-13 06:39:22 --> Config Class Initialized
DEBUG - 2017-01-13 06:39:22 --> Hooks Class Initialized
DEBUG - 2017-01-13 06:39:22 --> Utf8 Class Initialized
DEBUG - 2017-01-13 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 06:39:22 --> URI Class Initialized
DEBUG - 2017-01-13 06:39:22 --> Router Class Initialized
DEBUG - 2017-01-13 06:39:22 --> Output Class Initialized
DEBUG - 2017-01-13 06:39:22 --> Security Class Initialized
DEBUG - 2017-01-13 06:39:22 --> Input Class Initialized
DEBUG - 2017-01-13 06:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 06:39:22 --> Language Class Initialized
DEBUG - 2017-01-13 06:39:23 --> Loader Class Initialized
DEBUG - 2017-01-13 06:39:23 --> Helper loaded: date_helper
DEBUG - 2017-01-13 06:39:23 --> Controller Class Initialized
DEBUG - 2017-01-13 06:39:23 --> Database Driver Class Initialized
ERROR - 2017-01-13 06:39:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 06:39:23 --> Model Class Initialized
DEBUG - 2017-01-13 06:39:23 --> Model Class Initialized
DEBUG - 2017-01-13 06:39:23 --> Helper loaded: url_helper
DEBUG - 2017-01-13 06:39:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-13 06:39:23 --> Final output sent to browser
DEBUG - 2017-01-13 06:39:23 --> Total execution time: 0.0284
DEBUG - 2017-01-13 07:45:34 --> Config Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Hooks Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Utf8 Class Initialized
DEBUG - 2017-01-13 07:45:34 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 07:45:34 --> URI Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Router Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Output Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Security Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Input Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 07:45:34 --> Language Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Loader Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Helper loaded: date_helper
DEBUG - 2017-01-13 07:45:34 --> Controller Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Database Driver Class Initialized
ERROR - 2017-01-13 07:45:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 07:45:34 --> Model Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Model Class Initialized
DEBUG - 2017-01-13 07:45:34 --> Helper loaded: url_helper
DEBUG - 2017-01-13 07:45:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-13 07:45:34 --> Final output sent to browser
DEBUG - 2017-01-13 07:45:34 --> Total execution time: 0.0339
DEBUG - 2017-01-13 20:32:57 --> Config Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Hooks Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Utf8 Class Initialized
DEBUG - 2017-01-13 20:32:57 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 20:32:57 --> URI Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Router Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Output Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Security Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Input Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 20:32:57 --> Language Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Loader Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Helper loaded: date_helper
DEBUG - 2017-01-13 20:32:57 --> Controller Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Database Driver Class Initialized
ERROR - 2017-01-13 20:32:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 20:32:57 --> Model Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Model Class Initialized
DEBUG - 2017-01-13 20:32:57 --> Helper loaded: url_helper
DEBUG - 2017-01-13 20:32:57 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-13 20:32:57 --> Final output sent to browser
DEBUG - 2017-01-13 20:32:57 --> Total execution time: 0.0282
DEBUG - 2017-01-13 20:33:08 --> Config Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Hooks Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Utf8 Class Initialized
DEBUG - 2017-01-13 20:33:08 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 20:33:08 --> URI Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Router Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Output Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Security Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Input Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 20:33:08 --> Language Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Loader Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Helper loaded: date_helper
DEBUG - 2017-01-13 20:33:08 --> Controller Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Database Driver Class Initialized
ERROR - 2017-01-13 20:33:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 20:33:08 --> Model Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Model Class Initialized
DEBUG - 2017-01-13 20:33:08 --> Helper loaded: url_helper
DEBUG - 2017-01-13 20:33:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-13 20:33:08 --> Final output sent to browser
DEBUG - 2017-01-13 20:33:08 --> Total execution time: 0.0203
DEBUG - 2017-01-13 20:34:08 --> Config Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Hooks Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Utf8 Class Initialized
DEBUG - 2017-01-13 20:34:08 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 20:34:08 --> URI Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Router Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Output Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Security Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Input Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 20:34:08 --> Language Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Loader Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Helper loaded: date_helper
DEBUG - 2017-01-13 20:34:08 --> Controller Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Database Driver Class Initialized
ERROR - 2017-01-13 20:34:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 20:34:08 --> Model Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Model Class Initialized
DEBUG - 2017-01-13 20:34:08 --> Helper loaded: url_helper
DEBUG - 2017-01-13 20:34:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-13 20:34:08 --> Final output sent to browser
DEBUG - 2017-01-13 20:34:08 --> Total execution time: 0.0197
DEBUG - 2017-01-13 20:34:13 --> Config Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Hooks Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Utf8 Class Initialized
DEBUG - 2017-01-13 20:34:13 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 20:34:13 --> URI Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Router Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Output Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Security Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Input Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 20:34:13 --> Language Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Loader Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Helper loaded: date_helper
DEBUG - 2017-01-13 20:34:13 --> Controller Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Database Driver Class Initialized
ERROR - 2017-01-13 20:34:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 20:34:13 --> Model Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Model Class Initialized
DEBUG - 2017-01-13 20:34:13 --> Helper loaded: url_helper
DEBUG - 2017-01-13 20:34:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-13 20:34:13 --> Final output sent to browser
DEBUG - 2017-01-13 20:34:13 --> Total execution time: 0.0199
DEBUG - 2017-01-13 20:34:17 --> Config Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Hooks Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Utf8 Class Initialized
DEBUG - 2017-01-13 20:34:17 --> UTF-8 Support Enabled
DEBUG - 2017-01-13 20:34:17 --> URI Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Router Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Output Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Security Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Input Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-13 20:34:17 --> Language Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Loader Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Helper loaded: date_helper
DEBUG - 2017-01-13 20:34:17 --> Controller Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Database Driver Class Initialized
ERROR - 2017-01-13 20:34:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-13 20:34:17 --> Model Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Model Class Initialized
DEBUG - 2017-01-13 20:34:17 --> Helper loaded: url_helper
DEBUG - 2017-01-13 20:34:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-13 20:34:17 --> Final output sent to browser
DEBUG - 2017-01-13 20:34:17 --> Total execution time: 0.0195
