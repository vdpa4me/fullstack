<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-03 06:20:06 --> Config Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Hooks Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Utf8 Class Initialized
DEBUG - 2017-11-03 06:20:06 --> UTF-8 Support Enabled
DEBUG - 2017-11-03 06:20:06 --> URI Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Router Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Output Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Security Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Input Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-03 06:20:06 --> Language Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Loader Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Helper loaded: date_helper
DEBUG - 2017-11-03 06:20:06 --> Controller Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Database Driver Class Initialized
ERROR - 2017-11-03 06:20:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-03 06:20:06 --> Model Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Model Class Initialized
DEBUG - 2017-11-03 06:20:06 --> Helper loaded: url_helper
DEBUG - 2017-11-03 06:20:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-03 06:20:06 --> Final output sent to browser
DEBUG - 2017-11-03 06:20:06 --> Total execution time: 0.0275
DEBUG - 2017-11-03 13:37:37 --> Config Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Hooks Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Utf8 Class Initialized
DEBUG - 2017-11-03 13:37:37 --> UTF-8 Support Enabled
DEBUG - 2017-11-03 13:37:37 --> URI Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Router Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Output Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Security Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Input Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-03 13:37:37 --> Language Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Loader Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Helper loaded: date_helper
DEBUG - 2017-11-03 13:37:37 --> Controller Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Database Driver Class Initialized
ERROR - 2017-11-03 13:37:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-03 13:37:37 --> Model Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Model Class Initialized
DEBUG - 2017-11-03 13:37:37 --> Helper loaded: url_helper
DEBUG - 2017-11-03 13:37:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-03 13:37:37 --> Final output sent to browser
DEBUG - 2017-11-03 13:37:37 --> Total execution time: 0.0278
