<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-06-05 03:04:41 --> Config Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Hooks Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Utf8 Class Initialized
DEBUG - 2018-06-05 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2018-06-05 03:04:41 --> URI Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Router Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Output Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Security Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Input Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-05 03:04:41 --> Language Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Loader Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Helper loaded: date_helper
DEBUG - 2018-06-05 03:04:41 --> Controller Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Database Driver Class Initialized
ERROR - 2018-06-05 03:04:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-05 03:04:41 --> Model Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Model Class Initialized
DEBUG - 2018-06-05 03:04:41 --> Helper loaded: url_helper
DEBUG - 2018-06-05 03:04:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-06-05 03:04:41 --> Final output sent to browser
DEBUG - 2018-06-05 03:04:41 --> Total execution time: 0.0283
DEBUG - 2018-06-05 03:13:09 --> Config Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Hooks Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Utf8 Class Initialized
DEBUG - 2018-06-05 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2018-06-05 03:13:09 --> URI Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Router Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Output Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Security Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Input Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-05 03:13:09 --> Language Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Loader Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Helper loaded: date_helper
DEBUG - 2018-06-05 03:13:09 --> Controller Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Database Driver Class Initialized
ERROR - 2018-06-05 03:13:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-05 03:13:09 --> Model Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Model Class Initialized
DEBUG - 2018-06-05 03:13:09 --> Helper loaded: url_helper
DEBUG - 2018-06-05 03:13:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-06-05 03:13:09 --> Final output sent to browser
DEBUG - 2018-06-05 03:13:09 --> Total execution time: 0.0213
