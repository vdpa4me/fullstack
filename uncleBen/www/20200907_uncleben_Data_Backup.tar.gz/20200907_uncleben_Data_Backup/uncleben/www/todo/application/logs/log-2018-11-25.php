<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-11-25 04:59:45 --> Config Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Hooks Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Utf8 Class Initialized
DEBUG - 2018-11-25 04:59:45 --> UTF-8 Support Enabled
DEBUG - 2018-11-25 04:59:45 --> URI Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Router Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Output Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Security Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Input Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-25 04:59:45 --> Language Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Loader Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Helper loaded: date_helper
DEBUG - 2018-11-25 04:59:45 --> Controller Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Database Driver Class Initialized
ERROR - 2018-11-25 04:59:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-25 04:59:45 --> Model Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Model Class Initialized
DEBUG - 2018-11-25 04:59:45 --> Helper loaded: url_helper
DEBUG - 2018-11-25 04:59:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-11-25 04:59:45 --> Final output sent to browser
DEBUG - 2018-11-25 04:59:45 --> Total execution time: 0.0596
DEBUG - 2018-11-25 10:11:43 --> Config Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Hooks Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Utf8 Class Initialized
DEBUG - 2018-11-25 10:11:43 --> UTF-8 Support Enabled
DEBUG - 2018-11-25 10:11:43 --> URI Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Router Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Output Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Security Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Input Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-25 10:11:43 --> Language Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Loader Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Helper loaded: date_helper
DEBUG - 2018-11-25 10:11:43 --> Controller Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Database Driver Class Initialized
ERROR - 2018-11-25 10:11:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-25 10:11:43 --> Model Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Model Class Initialized
DEBUG - 2018-11-25 10:11:43 --> Helper loaded: url_helper
DEBUG - 2018-11-25 10:11:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-11-25 10:11:43 --> Final output sent to browser
DEBUG - 2018-11-25 10:11:43 --> Total execution time: 0.0480
