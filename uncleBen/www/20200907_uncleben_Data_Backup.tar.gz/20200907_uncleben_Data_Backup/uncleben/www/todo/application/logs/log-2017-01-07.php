<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-07 01:30:42 --> Config Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Hooks Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Utf8 Class Initialized
DEBUG - 2017-01-07 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 01:30:42 --> URI Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Router Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Output Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Security Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Input Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 01:30:42 --> Language Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Loader Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Helper loaded: date_helper
DEBUG - 2017-01-07 01:30:42 --> Controller Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Database Driver Class Initialized
ERROR - 2017-01-07 01:30:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 01:30:42 --> Model Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Model Class Initialized
DEBUG - 2017-01-07 01:30:42 --> Helper loaded: url_helper
DEBUG - 2017-01-07 01:30:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 01:30:42 --> Final output sent to browser
DEBUG - 2017-01-07 01:30:42 --> Total execution time: 0.0339
DEBUG - 2017-01-07 05:48:06 --> Config Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Hooks Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Utf8 Class Initialized
DEBUG - 2017-01-07 05:48:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 05:48:06 --> URI Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Router Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Output Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Security Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Input Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 05:48:06 --> Language Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Loader Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Helper loaded: date_helper
DEBUG - 2017-01-07 05:48:06 --> Controller Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Database Driver Class Initialized
ERROR - 2017-01-07 05:48:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 05:48:06 --> Model Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Model Class Initialized
DEBUG - 2017-01-07 05:48:06 --> Helper loaded: url_helper
DEBUG - 2017-01-07 05:48:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 05:48:06 --> Final output sent to browser
DEBUG - 2017-01-07 05:48:06 --> Total execution time: 0.0661
DEBUG - 2017-01-07 05:48:10 --> Config Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Hooks Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Utf8 Class Initialized
DEBUG - 2017-01-07 05:48:10 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 05:48:10 --> URI Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Router Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Output Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Security Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Input Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 05:48:10 --> Language Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Loader Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Helper loaded: date_helper
DEBUG - 2017-01-07 05:48:10 --> Controller Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Database Driver Class Initialized
ERROR - 2017-01-07 05:48:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 05:48:10 --> Model Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Model Class Initialized
DEBUG - 2017-01-07 05:48:10 --> Helper loaded: url_helper
DEBUG - 2017-01-07 05:48:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 05:48:10 --> Final output sent to browser
DEBUG - 2017-01-07 05:48:10 --> Total execution time: 0.0434
DEBUG - 2017-01-07 06:17:17 --> Config Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Hooks Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Utf8 Class Initialized
DEBUG - 2017-01-07 06:17:17 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 06:17:17 --> URI Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Router Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Output Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Security Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Input Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 06:17:17 --> Language Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Loader Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Helper loaded: date_helper
DEBUG - 2017-01-07 06:17:17 --> Controller Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Database Driver Class Initialized
ERROR - 2017-01-07 06:17:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 06:17:17 --> Model Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Model Class Initialized
DEBUG - 2017-01-07 06:17:17 --> Helper loaded: url_helper
DEBUG - 2017-01-07 06:17:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 06:17:17 --> Final output sent to browser
DEBUG - 2017-01-07 06:17:17 --> Total execution time: 0.0316
DEBUG - 2017-01-07 06:18:24 --> Config Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Hooks Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Utf8 Class Initialized
DEBUG - 2017-01-07 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 06:18:24 --> URI Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Router Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Output Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Security Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Input Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 06:18:24 --> Language Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Loader Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Helper loaded: date_helper
DEBUG - 2017-01-07 06:18:24 --> Controller Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Database Driver Class Initialized
ERROR - 2017-01-07 06:18:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 06:18:24 --> Model Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Model Class Initialized
DEBUG - 2017-01-07 06:18:24 --> Helper loaded: url_helper
DEBUG - 2017-01-07 06:18:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 06:18:24 --> Final output sent to browser
DEBUG - 2017-01-07 06:18:24 --> Total execution time: 0.0283
DEBUG - 2017-01-07 06:18:30 --> Config Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Hooks Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Utf8 Class Initialized
DEBUG - 2017-01-07 06:18:30 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 06:18:30 --> URI Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Router Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Output Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Security Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Input Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 06:18:30 --> Language Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Loader Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Helper loaded: date_helper
DEBUG - 2017-01-07 06:18:30 --> Controller Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Database Driver Class Initialized
ERROR - 2017-01-07 06:18:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 06:18:30 --> Model Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Model Class Initialized
DEBUG - 2017-01-07 06:18:30 --> Helper loaded: url_helper
DEBUG - 2017-01-07 06:18:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 06:18:30 --> Final output sent to browser
DEBUG - 2017-01-07 06:18:30 --> Total execution time: 0.0282
DEBUG - 2017-01-07 08:11:50 --> Config Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:11:50 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:11:50 --> URI Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Router Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Output Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Security Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Input Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:11:50 --> Language Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Loader Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:11:50 --> Controller Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:11:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:11:50 --> Model Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Model Class Initialized
DEBUG - 2017-01-07 08:11:50 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:11:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:11:50 --> Final output sent to browser
DEBUG - 2017-01-07 08:11:50 --> Total execution time: 0.0281
DEBUG - 2017-01-07 08:14:36 --> Config Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:14:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:14:36 --> URI Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Router Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Output Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Security Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Input Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:14:36 --> Language Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Loader Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:14:36 --> Controller Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:14:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:14:36 --> Model Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Model Class Initialized
DEBUG - 2017-01-07 08:14:36 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:14:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:14:36 --> Final output sent to browser
DEBUG - 2017-01-07 08:14:36 --> Total execution time: 0.0278
DEBUG - 2017-01-07 08:14:52 --> Config Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:14:52 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:14:52 --> URI Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Router Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Output Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Security Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Input Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:14:52 --> Language Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Loader Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:14:52 --> Controller Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:14:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:14:52 --> Model Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Model Class Initialized
DEBUG - 2017-01-07 08:14:52 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:14:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:14:52 --> Final output sent to browser
DEBUG - 2017-01-07 08:14:52 --> Total execution time: 0.0280
DEBUG - 2017-01-07 08:14:58 --> Config Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:14:58 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:14:58 --> URI Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Router Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Output Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Security Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Input Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:14:58 --> Language Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Loader Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:14:58 --> Controller Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:14:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:14:58 --> Model Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Model Class Initialized
DEBUG - 2017-01-07 08:14:58 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:14:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:14:58 --> Final output sent to browser
DEBUG - 2017-01-07 08:14:58 --> Total execution time: 0.0273
DEBUG - 2017-01-07 08:15:01 --> Config Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:15:01 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:15:01 --> URI Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Router Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Output Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Security Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Input Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:15:01 --> Language Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Loader Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:15:01 --> Controller Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:15:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:15:01 --> Model Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Model Class Initialized
DEBUG - 2017-01-07 08:15:01 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:15:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:15:01 --> Final output sent to browser
DEBUG - 2017-01-07 08:15:01 --> Total execution time: 0.0277
DEBUG - 2017-01-07 08:15:08 --> Config Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:15:08 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:15:08 --> URI Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Router Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Output Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Security Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Input Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:15:08 --> Language Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Loader Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:15:08 --> Controller Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:15:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:15:08 --> Model Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Model Class Initialized
DEBUG - 2017-01-07 08:15:08 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:15:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:15:08 --> Final output sent to browser
DEBUG - 2017-01-07 08:15:08 --> Total execution time: 0.0277
DEBUG - 2017-01-07 08:15:15 --> Config Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:15:15 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:15:15 --> URI Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Router Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Output Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Security Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Input Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:15:15 --> Language Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Loader Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:15:15 --> Controller Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:15:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:15:15 --> Model Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Model Class Initialized
DEBUG - 2017-01-07 08:15:15 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:15:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:15:15 --> Final output sent to browser
DEBUG - 2017-01-07 08:15:15 --> Total execution time: 0.0273
DEBUG - 2017-01-07 08:16:14 --> Config Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Hooks Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Utf8 Class Initialized
DEBUG - 2017-01-07 08:16:14 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 08:16:14 --> URI Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Router Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Output Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Security Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Input Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 08:16:14 --> Language Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Loader Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Helper loaded: date_helper
DEBUG - 2017-01-07 08:16:14 --> Controller Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Database Driver Class Initialized
ERROR - 2017-01-07 08:16:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 08:16:14 --> Model Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Model Class Initialized
DEBUG - 2017-01-07 08:16:14 --> Helper loaded: url_helper
DEBUG - 2017-01-07 08:16:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-07 08:16:14 --> Final output sent to browser
DEBUG - 2017-01-07 08:16:14 --> Total execution time: 0.0277
DEBUG - 2017-01-07 14:22:52 --> Config Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Hooks Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Utf8 Class Initialized
DEBUG - 2017-01-07 14:22:52 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 14:22:52 --> URI Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Router Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Output Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Security Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Input Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 14:22:52 --> Language Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Loader Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Helper loaded: date_helper
DEBUG - 2017-01-07 14:22:52 --> Controller Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Database Driver Class Initialized
ERROR - 2017-01-07 14:22:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 14:22:52 --> Model Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Model Class Initialized
DEBUG - 2017-01-07 14:22:52 --> Helper loaded: url_helper
DEBUG - 2017-01-07 14:22:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-07 14:22:52 --> Final output sent to browser
DEBUG - 2017-01-07 14:22:52 --> Total execution time: 0.0251
DEBUG - 2017-01-07 22:51:38 --> Config Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Hooks Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Utf8 Class Initialized
DEBUG - 2017-01-07 22:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-07 22:51:38 --> URI Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Router Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Output Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Security Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Input Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-07 22:51:38 --> Language Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Loader Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Helper loaded: date_helper
DEBUG - 2017-01-07 22:51:38 --> Controller Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Database Driver Class Initialized
ERROR - 2017-01-07 22:51:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-07 22:51:38 --> Model Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Model Class Initialized
DEBUG - 2017-01-07 22:51:38 --> Helper loaded: url_helper
DEBUG - 2017-01-07 22:51:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-07 22:51:38 --> Final output sent to browser
DEBUG - 2017-01-07 22:51:38 --> Total execution time: 0.0250
