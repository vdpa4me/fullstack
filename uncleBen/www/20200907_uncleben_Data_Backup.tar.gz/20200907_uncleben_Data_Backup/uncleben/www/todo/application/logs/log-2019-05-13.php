<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-13 01:11:32 --> Config Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Hooks Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Utf8 Class Initialized
DEBUG - 2019-05-13 01:11:32 --> UTF-8 Support Enabled
DEBUG - 2019-05-13 01:11:32 --> URI Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Router Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Output Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Security Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Input Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-13 01:11:32 --> Language Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Loader Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Helper loaded: date_helper
DEBUG - 2019-05-13 01:11:32 --> Controller Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Database Driver Class Initialized
ERROR - 2019-05-13 01:11:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-13 01:11:32 --> Model Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Model Class Initialized
DEBUG - 2019-05-13 01:11:32 --> Helper loaded: url_helper
DEBUG - 2019-05-13 01:11:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-13 01:11:32 --> Final output sent to browser
DEBUG - 2019-05-13 01:11:32 --> Total execution time: 0.0412
DEBUG - 2019-05-13 11:09:28 --> Config Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Hooks Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Utf8 Class Initialized
DEBUG - 2019-05-13 11:09:28 --> UTF-8 Support Enabled
DEBUG - 2019-05-13 11:09:28 --> URI Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Router Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Output Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Security Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Input Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-13 11:09:28 --> Language Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Loader Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Helper loaded: date_helper
DEBUG - 2019-05-13 11:09:28 --> Controller Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Database Driver Class Initialized
ERROR - 2019-05-13 11:09:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-13 11:09:28 --> Model Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Model Class Initialized
DEBUG - 2019-05-13 11:09:28 --> Helper loaded: url_helper
DEBUG - 2019-05-13 11:09:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-13 11:09:28 --> Final output sent to browser
DEBUG - 2019-05-13 11:09:28 --> Total execution time: 0.0529
DEBUG - 2019-05-13 15:08:26 --> Config Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Hooks Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Utf8 Class Initialized
DEBUG - 2019-05-13 15:08:26 --> UTF-8 Support Enabled
DEBUG - 2019-05-13 15:08:26 --> URI Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Router Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Output Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Security Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Input Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-13 15:08:26 --> Language Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Loader Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Helper loaded: date_helper
DEBUG - 2019-05-13 15:08:26 --> Controller Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Database Driver Class Initialized
ERROR - 2019-05-13 15:08:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-13 15:08:26 --> Model Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Model Class Initialized
DEBUG - 2019-05-13 15:08:26 --> Helper loaded: url_helper
DEBUG - 2019-05-13 15:08:26 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-13 15:08:26 --> Final output sent to browser
DEBUG - 2019-05-13 15:08:26 --> Total execution time: 0.0565
DEBUG - 2019-05-13 19:45:23 --> Config Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Hooks Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Utf8 Class Initialized
DEBUG - 2019-05-13 19:45:23 --> UTF-8 Support Enabled
DEBUG - 2019-05-13 19:45:23 --> URI Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Router Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Output Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Security Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Input Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-13 19:45:23 --> Language Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Loader Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Helper loaded: date_helper
DEBUG - 2019-05-13 19:45:23 --> Controller Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Database Driver Class Initialized
ERROR - 2019-05-13 19:45:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-13 19:45:23 --> Model Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Model Class Initialized
DEBUG - 2019-05-13 19:45:23 --> Helper loaded: url_helper
DEBUG - 2019-05-13 19:45:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-13 19:45:23 --> Final output sent to browser
DEBUG - 2019-05-13 19:45:23 --> Total execution time: 0.0380
DEBUG - 2019-05-13 19:47:06 --> Config Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Hooks Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Utf8 Class Initialized
DEBUG - 2019-05-13 19:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-05-13 19:47:06 --> URI Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Router Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Output Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Security Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Input Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-13 19:47:06 --> Language Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Loader Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Helper loaded: date_helper
DEBUG - 2019-05-13 19:47:06 --> Controller Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Database Driver Class Initialized
ERROR - 2019-05-13 19:47:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-13 19:47:06 --> Model Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Model Class Initialized
DEBUG - 2019-05-13 19:47:06 --> Helper loaded: url_helper
DEBUG - 2019-05-13 19:47:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-13 19:47:06 --> Final output sent to browser
DEBUG - 2019-05-13 19:47:06 --> Total execution time: 0.0313
DEBUG - 2019-05-13 23:39:25 --> Config Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Hooks Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Utf8 Class Initialized
DEBUG - 2019-05-13 23:39:25 --> UTF-8 Support Enabled
DEBUG - 2019-05-13 23:39:25 --> URI Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Router Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Output Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Security Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Input Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-13 23:39:25 --> Language Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Loader Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Helper loaded: date_helper
DEBUG - 2019-05-13 23:39:25 --> Controller Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Database Driver Class Initialized
ERROR - 2019-05-13 23:39:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-13 23:39:25 --> Model Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Model Class Initialized
DEBUG - 2019-05-13 23:39:25 --> Helper loaded: url_helper
DEBUG - 2019-05-13 23:39:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-13 23:39:25 --> Final output sent to browser
DEBUG - 2019-05-13 23:39:25 --> Total execution time: 0.0363
