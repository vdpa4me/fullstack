<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-29 00:00:39 --> Config Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Hooks Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Utf8 Class Initialized
DEBUG - 2018-08-29 00:00:39 --> UTF-8 Support Enabled
DEBUG - 2018-08-29 00:00:39 --> URI Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Router Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Output Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Security Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Input Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-29 00:00:39 --> Language Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Loader Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Helper loaded: date_helper
DEBUG - 2018-08-29 00:00:39 --> Controller Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Database Driver Class Initialized
ERROR - 2018-08-29 00:00:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-29 00:00:39 --> Model Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Model Class Initialized
DEBUG - 2018-08-29 00:00:39 --> Helper loaded: url_helper
DEBUG - 2018-08-29 00:00:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-29 00:00:39 --> Final output sent to browser
DEBUG - 2018-08-29 00:00:39 --> Total execution time: 0.0225
DEBUG - 2018-08-29 05:44:28 --> Config Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Hooks Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Utf8 Class Initialized
DEBUG - 2018-08-29 05:44:28 --> UTF-8 Support Enabled
DEBUG - 2018-08-29 05:44:28 --> URI Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Router Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Output Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Security Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Input Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-29 05:44:28 --> Language Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Loader Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Helper loaded: date_helper
DEBUG - 2018-08-29 05:44:28 --> Controller Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Database Driver Class Initialized
ERROR - 2018-08-29 05:44:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-29 05:44:28 --> Model Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Model Class Initialized
DEBUG - 2018-08-29 05:44:28 --> Helper loaded: url_helper
DEBUG - 2018-08-29 05:44:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-29 05:44:28 --> Final output sent to browser
DEBUG - 2018-08-29 05:44:28 --> Total execution time: 0.4410
DEBUG - 2018-08-29 08:22:37 --> Config Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Hooks Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Utf8 Class Initialized
DEBUG - 2018-08-29 08:22:37 --> UTF-8 Support Enabled
DEBUG - 2018-08-29 08:22:37 --> URI Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Router Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Output Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Security Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Input Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-29 08:22:37 --> Language Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Loader Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Helper loaded: date_helper
DEBUG - 2018-08-29 08:22:37 --> Controller Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Database Driver Class Initialized
ERROR - 2018-08-29 08:22:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-29 08:22:37 --> Model Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Model Class Initialized
DEBUG - 2018-08-29 08:22:37 --> Helper loaded: url_helper
DEBUG - 2018-08-29 08:22:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-29 08:22:37 --> Final output sent to browser
DEBUG - 2018-08-29 08:22:37 --> Total execution time: 0.0799
DEBUG - 2018-08-29 09:57:27 --> Config Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Hooks Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Utf8 Class Initialized
DEBUG - 2018-08-29 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2018-08-29 09:57:27 --> URI Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Router Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Output Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Security Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Input Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-29 09:57:27 --> Language Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Loader Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Helper loaded: date_helper
DEBUG - 2018-08-29 09:57:27 --> Controller Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Database Driver Class Initialized
ERROR - 2018-08-29 09:57:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-29 09:57:27 --> Model Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Model Class Initialized
DEBUG - 2018-08-29 09:57:27 --> Helper loaded: url_helper
DEBUG - 2018-08-29 09:57:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-29 09:57:27 --> Final output sent to browser
DEBUG - 2018-08-29 09:57:27 --> Total execution time: 0.0211
