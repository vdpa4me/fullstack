<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-25 03:15:17 --> Config Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Hooks Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Utf8 Class Initialized
DEBUG - 2017-01-25 03:15:17 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 03:15:17 --> URI Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Router Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Output Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Security Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Input Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 03:15:17 --> Language Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Loader Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Helper loaded: date_helper
DEBUG - 2017-01-25 03:15:17 --> Controller Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Database Driver Class Initialized
ERROR - 2017-01-25 03:15:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 03:15:17 --> Model Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Model Class Initialized
DEBUG - 2017-01-25 03:15:17 --> Helper loaded: url_helper
DEBUG - 2017-01-25 03:15:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-25 03:15:17 --> Final output sent to browser
DEBUG - 2017-01-25 03:15:17 --> Total execution time: 0.0395
DEBUG - 2017-01-25 03:15:27 --> Config Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Hooks Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Utf8 Class Initialized
DEBUG - 2017-01-25 03:15:27 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 03:15:27 --> URI Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Router Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Output Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Security Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Input Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 03:15:27 --> Language Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Loader Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Helper loaded: date_helper
DEBUG - 2017-01-25 03:15:27 --> Controller Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Database Driver Class Initialized
ERROR - 2017-01-25 03:15:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 03:15:27 --> Model Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Model Class Initialized
DEBUG - 2017-01-25 03:15:27 --> Helper loaded: url_helper
DEBUG - 2017-01-25 03:15:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-25 03:15:27 --> Final output sent to browser
DEBUG - 2017-01-25 03:15:27 --> Total execution time: 0.0284
DEBUG - 2017-01-25 05:11:06 --> Config Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Hooks Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Utf8 Class Initialized
DEBUG - 2017-01-25 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 05:11:06 --> URI Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Router Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Output Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Security Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Input Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 05:11:06 --> Language Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Loader Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Helper loaded: date_helper
DEBUG - 2017-01-25 05:11:06 --> Controller Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Database Driver Class Initialized
ERROR - 2017-01-25 05:11:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 05:11:06 --> Model Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Model Class Initialized
DEBUG - 2017-01-25 05:11:06 --> Helper loaded: url_helper
DEBUG - 2017-01-25 05:11:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-25 05:11:06 --> Final output sent to browser
DEBUG - 2017-01-25 05:11:06 --> Total execution time: 0.0326
DEBUG - 2017-01-25 05:11:16 --> Config Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Hooks Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Utf8 Class Initialized
DEBUG - 2017-01-25 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 05:11:16 --> URI Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Router Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Output Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Security Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Input Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 05:11:16 --> Language Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Loader Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Helper loaded: date_helper
DEBUG - 2017-01-25 05:11:16 --> Controller Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Database Driver Class Initialized
ERROR - 2017-01-25 05:11:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 05:11:16 --> Model Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Model Class Initialized
DEBUG - 2017-01-25 05:11:16 --> Helper loaded: url_helper
DEBUG - 2017-01-25 05:11:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-25 05:11:16 --> Final output sent to browser
DEBUG - 2017-01-25 05:11:16 --> Total execution time: 0.0283
DEBUG - 2017-01-25 13:47:48 --> Config Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Utf8 Class Initialized
DEBUG - 2017-01-25 13:47:48 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 13:47:48 --> URI Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Router Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Output Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Security Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Input Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 13:47:48 --> Language Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Loader Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Helper loaded: date_helper
DEBUG - 2017-01-25 13:47:48 --> Controller Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Database Driver Class Initialized
ERROR - 2017-01-25 13:47:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 13:47:48 --> Model Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Model Class Initialized
DEBUG - 2017-01-25 13:47:48 --> Helper loaded: url_helper
DEBUG - 2017-01-25 13:47:48 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-25 13:47:48 --> Final output sent to browser
DEBUG - 2017-01-25 13:47:48 --> Total execution time: 0.0291
DEBUG - 2017-01-25 13:47:52 --> Config Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Utf8 Class Initialized
DEBUG - 2017-01-25 13:47:52 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 13:47:52 --> URI Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Router Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Output Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Security Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Input Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 13:47:52 --> Language Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Loader Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Helper loaded: date_helper
DEBUG - 2017-01-25 13:47:52 --> Controller Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Database Driver Class Initialized
ERROR - 2017-01-25 13:47:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 13:47:52 --> Model Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Model Class Initialized
DEBUG - 2017-01-25 13:47:52 --> Helper loaded: url_helper
DEBUG - 2017-01-25 13:47:52 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-01-25 13:47:52 --> Final output sent to browser
DEBUG - 2017-01-25 13:47:52 --> Total execution time: 0.0211
DEBUG - 2017-01-25 13:48:03 --> Config Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Utf8 Class Initialized
DEBUG - 2017-01-25 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 13:48:03 --> URI Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Router Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Output Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Security Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Input Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 13:48:03 --> Language Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Loader Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Helper loaded: date_helper
DEBUG - 2017-01-25 13:48:03 --> Controller Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Database Driver Class Initialized
ERROR - 2017-01-25 13:48:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 13:48:03 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:03 --> Helper loaded: url_helper
DEBUG - 2017-01-25 13:48:03 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-01-25 13:48:03 --> Final output sent to browser
DEBUG - 2017-01-25 13:48:03 --> Total execution time: 0.0276
DEBUG - 2017-01-25 13:48:04 --> Config Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Utf8 Class Initialized
DEBUG - 2017-01-25 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 13:48:04 --> URI Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Router Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Output Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Security Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Input Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 13:48:04 --> Language Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Loader Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Helper loaded: date_helper
DEBUG - 2017-01-25 13:48:04 --> Controller Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Database Driver Class Initialized
ERROR - 2017-01-25 13:48:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 13:48:04 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:04 --> Helper loaded: url_helper
DEBUG - 2017-01-25 13:48:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-25 13:48:04 --> Final output sent to browser
DEBUG - 2017-01-25 13:48:04 --> Total execution time: 0.0201
DEBUG - 2017-01-25 13:48:05 --> Config Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Utf8 Class Initialized
DEBUG - 2017-01-25 13:48:05 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 13:48:05 --> URI Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Router Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Output Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Security Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Input Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 13:48:05 --> Language Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Loader Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Helper loaded: date_helper
DEBUG - 2017-01-25 13:48:05 --> Controller Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Database Driver Class Initialized
ERROR - 2017-01-25 13:48:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 13:48:05 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:05 --> Helper loaded: url_helper
DEBUG - 2017-01-25 13:48:05 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-01-25 13:48:05 --> Final output sent to browser
DEBUG - 2017-01-25 13:48:05 --> Total execution time: 0.0193
DEBUG - 2017-01-25 13:48:11 --> Config Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Hooks Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Utf8 Class Initialized
DEBUG - 2017-01-25 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2017-01-25 13:48:11 --> URI Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Router Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Output Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Security Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Input Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-25 13:48:11 --> Language Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Loader Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Helper loaded: date_helper
DEBUG - 2017-01-25 13:48:11 --> Controller Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Database Driver Class Initialized
ERROR - 2017-01-25 13:48:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-25 13:48:11 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Model Class Initialized
DEBUG - 2017-01-25 13:48:11 --> Helper loaded: url_helper
DEBUG - 2017-01-25 13:48:11 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-01-25 13:48:11 --> Final output sent to browser
DEBUG - 2017-01-25 13:48:11 --> Total execution time: 0.0203
