<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-15 00:10:42 --> Config Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Hooks Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Utf8 Class Initialized
DEBUG - 2018-12-15 00:10:42 --> UTF-8 Support Enabled
DEBUG - 2018-12-15 00:10:42 --> URI Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Router Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Output Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Security Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Input Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-15 00:10:42 --> Language Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Loader Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Helper loaded: date_helper
DEBUG - 2018-12-15 00:10:42 --> Controller Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Database Driver Class Initialized
ERROR - 2018-12-15 00:10:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-15 00:10:42 --> Model Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Model Class Initialized
DEBUG - 2018-12-15 00:10:42 --> Helper loaded: url_helper
DEBUG - 2018-12-15 00:10:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-15 00:10:43 --> Final output sent to browser
DEBUG - 2018-12-15 00:10:43 --> Total execution time: 0.0642
DEBUG - 2018-12-15 03:44:22 --> Config Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Hooks Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Utf8 Class Initialized
DEBUG - 2018-12-15 03:44:22 --> UTF-8 Support Enabled
DEBUG - 2018-12-15 03:44:22 --> URI Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Router Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Output Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Security Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Input Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-15 03:44:22 --> Language Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Loader Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Helper loaded: date_helper
DEBUG - 2018-12-15 03:44:22 --> Controller Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Database Driver Class Initialized
ERROR - 2018-12-15 03:44:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-15 03:44:22 --> Model Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Model Class Initialized
DEBUG - 2018-12-15 03:44:22 --> Helper loaded: url_helper
DEBUG - 2018-12-15 03:44:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-15 03:44:22 --> Final output sent to browser
DEBUG - 2018-12-15 03:44:22 --> Total execution time: 0.0566
DEBUG - 2018-12-15 12:20:30 --> Config Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Hooks Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Utf8 Class Initialized
DEBUG - 2018-12-15 12:20:30 --> UTF-8 Support Enabled
DEBUG - 2018-12-15 12:20:30 --> URI Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Router Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Output Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Security Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Input Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-15 12:20:30 --> Language Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Loader Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Helper loaded: date_helper
DEBUG - 2018-12-15 12:20:30 --> Controller Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Database Driver Class Initialized
ERROR - 2018-12-15 12:20:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-15 12:20:30 --> Model Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Model Class Initialized
DEBUG - 2018-12-15 12:20:30 --> Helper loaded: url_helper
DEBUG - 2018-12-15 12:20:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-15 12:20:30 --> Final output sent to browser
DEBUG - 2018-12-15 12:20:30 --> Total execution time: 0.0498
