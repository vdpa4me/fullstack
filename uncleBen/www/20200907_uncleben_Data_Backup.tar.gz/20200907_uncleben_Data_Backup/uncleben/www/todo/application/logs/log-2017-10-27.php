<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-27 00:36:25 --> Config Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Hooks Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Utf8 Class Initialized
DEBUG - 2017-10-27 00:36:25 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 00:36:25 --> URI Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Router Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Output Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Security Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Input Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 00:36:25 --> Language Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Loader Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Helper loaded: date_helper
DEBUG - 2017-10-27 00:36:25 --> Controller Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Database Driver Class Initialized
ERROR - 2017-10-27 00:36:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 00:36:25 --> Model Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Model Class Initialized
DEBUG - 2017-10-27 00:36:25 --> Helper loaded: url_helper
DEBUG - 2017-10-27 00:36:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 00:36:25 --> Final output sent to browser
DEBUG - 2017-10-27 00:36:25 --> Total execution time: 0.0747
DEBUG - 2017-10-27 01:47:52 --> Config Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Hooks Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Utf8 Class Initialized
DEBUG - 2017-10-27 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 01:47:52 --> URI Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Router Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Output Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Security Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Input Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 01:47:52 --> Language Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Loader Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Helper loaded: date_helper
DEBUG - 2017-10-27 01:47:52 --> Controller Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Database Driver Class Initialized
ERROR - 2017-10-27 01:47:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 01:47:52 --> Model Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Model Class Initialized
DEBUG - 2017-10-27 01:47:52 --> Helper loaded: url_helper
DEBUG - 2017-10-27 01:47:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 01:47:52 --> Final output sent to browser
DEBUG - 2017-10-27 01:47:52 --> Total execution time: 0.0200
DEBUG - 2017-10-27 06:41:17 --> Config Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Hooks Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Utf8 Class Initialized
DEBUG - 2017-10-27 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 06:41:17 --> URI Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Router Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Output Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Security Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Input Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 06:41:17 --> Language Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Loader Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Helper loaded: date_helper
DEBUG - 2017-10-27 06:41:17 --> Controller Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Database Driver Class Initialized
ERROR - 2017-10-27 06:41:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 06:41:17 --> Model Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Model Class Initialized
DEBUG - 2017-10-27 06:41:17 --> Helper loaded: url_helper
DEBUG - 2017-10-27 06:41:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 06:41:17 --> Final output sent to browser
DEBUG - 2017-10-27 06:41:17 --> Total execution time: 0.0258
DEBUG - 2017-10-27 06:51:55 --> Config Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Hooks Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Utf8 Class Initialized
DEBUG - 2017-10-27 06:51:55 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 06:51:55 --> URI Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Router Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Output Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Security Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Input Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 06:51:55 --> Language Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Loader Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Helper loaded: date_helper
DEBUG - 2017-10-27 06:51:55 --> Controller Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Database Driver Class Initialized
ERROR - 2017-10-27 06:51:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 06:51:55 --> Model Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Model Class Initialized
DEBUG - 2017-10-27 06:51:55 --> Helper loaded: url_helper
DEBUG - 2017-10-27 06:51:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 06:51:55 --> Final output sent to browser
DEBUG - 2017-10-27 06:51:55 --> Total execution time: 0.0196
DEBUG - 2017-10-27 07:30:51 --> Config Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Hooks Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Utf8 Class Initialized
DEBUG - 2017-10-27 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 07:30:51 --> URI Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Router Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Output Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Security Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Input Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 07:30:51 --> Language Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Loader Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Helper loaded: date_helper
DEBUG - 2017-10-27 07:30:51 --> Controller Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Database Driver Class Initialized
ERROR - 2017-10-27 07:30:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 07:30:51 --> Model Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Model Class Initialized
DEBUG - 2017-10-27 07:30:51 --> Helper loaded: url_helper
DEBUG - 2017-10-27 07:30:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 07:30:51 --> Final output sent to browser
DEBUG - 2017-10-27 07:30:51 --> Total execution time: 0.0321
DEBUG - 2017-10-27 14:22:22 --> Config Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Hooks Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Utf8 Class Initialized
DEBUG - 2017-10-27 14:22:22 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 14:22:22 --> URI Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Router Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Output Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Security Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Input Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 14:22:22 --> Language Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Loader Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Helper loaded: date_helper
DEBUG - 2017-10-27 14:22:22 --> Controller Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Database Driver Class Initialized
ERROR - 2017-10-27 14:22:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 14:22:22 --> Model Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Model Class Initialized
DEBUG - 2017-10-27 14:22:22 --> Helper loaded: url_helper
DEBUG - 2017-10-27 14:22:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 14:22:22 --> Final output sent to browser
DEBUG - 2017-10-27 14:22:22 --> Total execution time: 0.1440
DEBUG - 2017-10-27 15:11:38 --> Config Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Hooks Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Utf8 Class Initialized
DEBUG - 2017-10-27 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 15:11:38 --> URI Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Router Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Output Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Security Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Input Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 15:11:38 --> Language Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Loader Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Helper loaded: date_helper
DEBUG - 2017-10-27 15:11:38 --> Controller Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Database Driver Class Initialized
ERROR - 2017-10-27 15:11:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 15:11:38 --> Model Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Model Class Initialized
DEBUG - 2017-10-27 15:11:38 --> Helper loaded: url_helper
DEBUG - 2017-10-27 15:11:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 15:11:38 --> Final output sent to browser
DEBUG - 2017-10-27 15:11:38 --> Total execution time: 0.0200
DEBUG - 2017-10-27 23:15:27 --> Config Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Hooks Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Utf8 Class Initialized
DEBUG - 2017-10-27 23:15:27 --> UTF-8 Support Enabled
DEBUG - 2017-10-27 23:15:27 --> URI Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Router Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Output Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Security Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Input Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-27 23:15:27 --> Language Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Loader Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Helper loaded: date_helper
DEBUG - 2017-10-27 23:15:27 --> Controller Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Database Driver Class Initialized
ERROR - 2017-10-27 23:15:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-27 23:15:27 --> Model Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Model Class Initialized
DEBUG - 2017-10-27 23:15:27 --> Helper loaded: url_helper
DEBUG - 2017-10-27 23:15:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-27 23:15:27 --> Final output sent to browser
DEBUG - 2017-10-27 23:15:27 --> Total execution time: 0.0234
