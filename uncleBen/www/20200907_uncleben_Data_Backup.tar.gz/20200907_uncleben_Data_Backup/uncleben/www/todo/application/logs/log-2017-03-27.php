<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-03-27 01:24:16 --> Config Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Hooks Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Utf8 Class Initialized
DEBUG - 2017-03-27 01:24:16 --> UTF-8 Support Enabled
DEBUG - 2017-03-27 01:24:16 --> URI Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Router Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Output Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Security Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Input Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-27 01:24:16 --> Language Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Loader Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Helper loaded: date_helper
DEBUG - 2017-03-27 01:24:16 --> Controller Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Database Driver Class Initialized
ERROR - 2017-03-27 01:24:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-27 01:24:16 --> Model Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Model Class Initialized
DEBUG - 2017-03-27 01:24:16 --> Helper loaded: url_helper
DEBUG - 2017-03-27 01:24:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-03-27 01:24:16 --> Final output sent to browser
DEBUG - 2017-03-27 01:24:16 --> Total execution time: 0.0394
DEBUG - 2017-03-27 01:24:26 --> Config Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Hooks Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Utf8 Class Initialized
DEBUG - 2017-03-27 01:24:26 --> UTF-8 Support Enabled
DEBUG - 2017-03-27 01:24:26 --> URI Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Router Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Output Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Security Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Input Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-27 01:24:26 --> Language Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Loader Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Helper loaded: date_helper
DEBUG - 2017-03-27 01:24:26 --> Controller Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Database Driver Class Initialized
ERROR - 2017-03-27 01:24:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-27 01:24:26 --> Model Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Model Class Initialized
DEBUG - 2017-03-27 01:24:26 --> Helper loaded: url_helper
DEBUG - 2017-03-27 01:24:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-03-27 01:24:26 --> Final output sent to browser
DEBUG - 2017-03-27 01:24:26 --> Total execution time: 0.0296
