<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-02-08 05:49:20 --> Config Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Utf8 Class Initialized
DEBUG - 2017-02-08 05:49:20 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 05:49:20 --> URI Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Router Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Output Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Security Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Input Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 05:49:20 --> Language Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Loader Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Helper loaded: date_helper
DEBUG - 2017-02-08 05:49:20 --> Controller Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Database Driver Class Initialized
ERROR - 2017-02-08 05:49:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 05:49:20 --> Model Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Model Class Initialized
DEBUG - 2017-02-08 05:49:20 --> Helper loaded: url_helper
DEBUG - 2017-02-08 05:49:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-02-08 05:49:20 --> Final output sent to browser
DEBUG - 2017-02-08 05:49:20 --> Total execution time: 0.0415
DEBUG - 2017-02-08 12:00:00 --> Config Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:00:00 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:00:00 --> URI Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Router Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Output Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Input Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:00:00 --> Language Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Loader Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:00:00 --> Controller Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:00:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:00:00 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:00 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:00:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-02-08 12:00:00 --> Final output sent to browser
DEBUG - 2017-02-08 12:00:00 --> Total execution time: 0.0248
DEBUG - 2017-02-08 12:00:04 --> Config Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:00:04 --> URI Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Router Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Output Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Input Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:00:04 --> Language Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Loader Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:00:04 --> Controller Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:00:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:00:04 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:04 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:00:04 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-02-08 12:00:04 --> Final output sent to browser
DEBUG - 2017-02-08 12:00:04 --> Total execution time: 0.0251
DEBUG - 2017-02-08 12:00:12 --> Config Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:00:12 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:00:12 --> URI Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Router Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Output Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Security Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Input Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:00:12 --> Language Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Loader Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:00:12 --> Controller Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:00:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:00:12 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:12 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:00:12 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-02-08 12:00:12 --> Final output sent to browser
DEBUG - 2017-02-08 12:00:12 --> Total execution time: 0.0182
DEBUG - 2017-02-08 12:00:14 --> Config Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:00:14 --> URI Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Router Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Output Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Security Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Input Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:00:14 --> Language Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Loader Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:00:14 --> Controller Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:00:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:00:14 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:14 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:00:15 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-02-08 12:00:15 --> Final output sent to browser
DEBUG - 2017-02-08 12:00:15 --> Total execution time: 0.0207
DEBUG - 2017-02-08 12:00:16 --> Config Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:00:16 --> URI Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Router Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Output Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Security Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Input Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:00:16 --> Language Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Loader Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:00:16 --> Controller Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:00:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:00:16 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Model Class Initialized
DEBUG - 2017-02-08 12:00:16 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:00:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-02-08 12:00:16 --> Final output sent to browser
DEBUG - 2017-02-08 12:00:16 --> Total execution time: 0.0242
DEBUG - 2017-02-08 12:01:27 --> Config Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:27 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:01:27 --> URI Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Router Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Input Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:01:27 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Loader Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:01:27 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:01:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:01:27 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:27 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:01:27 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-02-08 12:01:27 --> Final output sent to browser
DEBUG - 2017-02-08 12:01:27 --> Total execution time: 0.0186
DEBUG - 2017-02-08 12:01:29 --> Config Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:29 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:01:29 --> URI Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Router Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Input Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:01:29 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Loader Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:01:29 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:01:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:01:29 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:29 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:01:29 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-02-08 12:01:29 --> Final output sent to browser
DEBUG - 2017-02-08 12:01:29 --> Total execution time: 0.0197
DEBUG - 2017-02-08 12:01:33 --> Config Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:33 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:01:33 --> URI Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Router Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Input Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:01:33 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Loader Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:01:33 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:01:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:01:33 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:33 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:01:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-02-08 12:01:33 --> Final output sent to browser
DEBUG - 2017-02-08 12:01:33 --> Total execution time: 0.0201
DEBUG - 2017-02-08 12:01:35 --> Config Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:35 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:01:35 --> URI Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Router Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Input Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:01:35 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Loader Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:01:35 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:01:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:01:35 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:35 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:01:35 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-02-08 12:01:35 --> Final output sent to browser
DEBUG - 2017-02-08 12:01:35 --> Total execution time: 0.0184
DEBUG - 2017-02-08 12:01:36 --> Config Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:36 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:01:36 --> URI Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Router Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Input Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:01:36 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Loader Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:01:36 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:01:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:01:36 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:36 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:01:36 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-02-08 12:01:36 --> Final output sent to browser
DEBUG - 2017-02-08 12:01:36 --> Total execution time: 0.0207
DEBUG - 2017-02-08 12:01:47 --> Config Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:47 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:01:47 --> URI Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Router Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Input Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-08 12:01:47 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Loader Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Helper loaded: date_helper
DEBUG - 2017-02-08 12:01:47 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Database Driver Class Initialized
ERROR - 2017-02-08 12:01:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-08 12:01:47 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Model Class Initialized
DEBUG - 2017-02-08 12:01:47 --> Helper loaded: url_helper
DEBUG - 2017-02-08 12:01:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-02-08 12:01:47 --> Final output sent to browser
DEBUG - 2017-02-08 12:01:47 --> Total execution time: 0.0202
