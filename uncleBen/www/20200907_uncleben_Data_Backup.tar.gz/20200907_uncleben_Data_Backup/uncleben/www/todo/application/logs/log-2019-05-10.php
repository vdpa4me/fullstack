<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-10 04:39:31 --> Config Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Hooks Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Utf8 Class Initialized
DEBUG - 2019-05-10 04:39:31 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 04:39:31 --> URI Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Router Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Output Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Security Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Input Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 04:39:31 --> Language Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Loader Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Helper loaded: date_helper
DEBUG - 2019-05-10 04:39:31 --> Controller Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Database Driver Class Initialized
ERROR - 2019-05-10 04:39:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 04:39:31 --> Model Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Model Class Initialized
DEBUG - 2019-05-10 04:39:31 --> Helper loaded: url_helper
DEBUG - 2019-05-10 04:39:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 04:39:31 --> Final output sent to browser
DEBUG - 2019-05-10 04:39:31 --> Total execution time: 0.0455
DEBUG - 2019-05-10 06:02:59 --> Config Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Hooks Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Utf8 Class Initialized
DEBUG - 2019-05-10 06:02:59 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 06:02:59 --> URI Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Router Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Output Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Security Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Input Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 06:02:59 --> Language Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Loader Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Helper loaded: date_helper
DEBUG - 2019-05-10 06:02:59 --> Controller Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Database Driver Class Initialized
ERROR - 2019-05-10 06:02:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 06:02:59 --> Model Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Model Class Initialized
DEBUG - 2019-05-10 06:02:59 --> Helper loaded: url_helper
DEBUG - 2019-05-10 06:02:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 06:02:59 --> Final output sent to browser
DEBUG - 2019-05-10 06:02:59 --> Total execution time: 0.0368
DEBUG - 2019-05-10 10:31:16 --> Config Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Hooks Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Utf8 Class Initialized
DEBUG - 2019-05-10 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 10:31:16 --> URI Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Router Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Output Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Security Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Input Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 10:31:16 --> Language Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Loader Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Helper loaded: date_helper
DEBUG - 2019-05-10 10:31:16 --> Controller Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Database Driver Class Initialized
ERROR - 2019-05-10 10:31:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 10:31:16 --> Model Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Model Class Initialized
DEBUG - 2019-05-10 10:31:16 --> Helper loaded: url_helper
DEBUG - 2019-05-10 10:31:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 10:31:16 --> Final output sent to browser
DEBUG - 2019-05-10 10:31:16 --> Total execution time: 0.0239
DEBUG - 2019-05-10 15:02:11 --> Config Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:02:11 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:02:11 --> URI Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Router Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Output Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Security Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Input Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:02:11 --> Language Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Loader Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:02:11 --> Controller Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:02:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:02:11 --> Model Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Model Class Initialized
DEBUG - 2019-05-10 15:02:11 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:02:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:02:11 --> Final output sent to browser
DEBUG - 2019-05-10 15:02:11 --> Total execution time: 0.0368
DEBUG - 2019-05-10 15:06:25 --> Config Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:06:25 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:06:25 --> URI Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Router Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Output Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Security Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Input Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:06:25 --> Language Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Loader Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:06:25 --> Controller Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:06:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:06:25 --> Model Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Model Class Initialized
DEBUG - 2019-05-10 15:06:25 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:06:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:06:25 --> Final output sent to browser
DEBUG - 2019-05-10 15:06:25 --> Total execution time: 0.0218
DEBUG - 2019-05-10 15:11:41 --> Config Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:11:41 --> URI Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Router Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Output Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Security Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Input Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:11:41 --> Language Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Loader Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:11:41 --> Controller Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:11:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:11:41 --> Model Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Model Class Initialized
DEBUG - 2019-05-10 15:11:41 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:11:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:11:41 --> Final output sent to browser
DEBUG - 2019-05-10 15:11:41 --> Total execution time: 0.0212
DEBUG - 2019-05-10 15:15:06 --> Config Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:15:06 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:15:06 --> URI Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Router Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Output Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Security Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Input Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:15:06 --> Language Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Loader Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:15:06 --> Controller Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:15:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:15:06 --> Model Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Model Class Initialized
DEBUG - 2019-05-10 15:15:06 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:15:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:15:06 --> Final output sent to browser
DEBUG - 2019-05-10 15:15:06 --> Total execution time: 0.0205
DEBUG - 2019-05-10 15:15:24 --> Config Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:15:24 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:15:24 --> URI Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Router Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Output Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Security Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Input Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:15:24 --> Language Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Loader Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:15:24 --> Controller Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:15:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:15:24 --> Model Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Model Class Initialized
DEBUG - 2019-05-10 15:15:24 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:15:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:15:24 --> Final output sent to browser
DEBUG - 2019-05-10 15:15:24 --> Total execution time: 0.0212
DEBUG - 2019-05-10 15:25:29 --> Config Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:25:29 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:25:29 --> URI Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Router Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Output Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Security Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Input Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:25:29 --> Language Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Loader Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:25:29 --> Controller Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:25:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:25:29 --> Model Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Model Class Initialized
DEBUG - 2019-05-10 15:25:29 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:25:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:25:29 --> Final output sent to browser
DEBUG - 2019-05-10 15:25:29 --> Total execution time: 0.0210
DEBUG - 2019-05-10 15:29:17 --> Config Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:29:17 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:29:17 --> URI Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Router Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Output Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Security Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Input Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:29:17 --> Language Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Loader Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:29:17 --> Controller Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:29:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:29:17 --> Model Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Model Class Initialized
DEBUG - 2019-05-10 15:29:17 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:29:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:29:17 --> Final output sent to browser
DEBUG - 2019-05-10 15:29:17 --> Total execution time: 0.0208
DEBUG - 2019-05-10 15:29:53 --> Config Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:29:53 --> URI Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Router Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Output Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Security Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Input Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:29:53 --> Language Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Loader Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:29:53 --> Controller Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:29:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:29:53 --> Model Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Model Class Initialized
DEBUG - 2019-05-10 15:29:53 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:29:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:29:53 --> Final output sent to browser
DEBUG - 2019-05-10 15:29:53 --> Total execution time: 0.0207
DEBUG - 2019-05-10 15:30:01 --> Config Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:30:01 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:30:01 --> URI Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Router Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Output Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Security Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Input Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:30:01 --> Language Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Loader Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:30:01 --> Controller Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:30:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:30:01 --> Model Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Model Class Initialized
DEBUG - 2019-05-10 15:30:01 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:30:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:30:01 --> Final output sent to browser
DEBUG - 2019-05-10 15:30:01 --> Total execution time: 0.0222
DEBUG - 2019-05-10 15:34:25 --> Config Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:34:25 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:34:25 --> URI Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Router Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Output Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Security Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Input Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:34:25 --> Language Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Loader Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:34:25 --> Controller Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:34:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:34:25 --> Model Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Model Class Initialized
DEBUG - 2019-05-10 15:34:25 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:34:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:34:25 --> Final output sent to browser
DEBUG - 2019-05-10 15:34:25 --> Total execution time: 0.0236
DEBUG - 2019-05-10 15:46:25 --> Config Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:46:25 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:46:25 --> URI Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Router Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Output Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Security Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Input Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:46:25 --> Language Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Loader Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:46:25 --> Controller Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:46:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:46:25 --> Model Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Model Class Initialized
DEBUG - 2019-05-10 15:46:25 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:46:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:46:25 --> Final output sent to browser
DEBUG - 2019-05-10 15:46:25 --> Total execution time: 0.0233
DEBUG - 2019-05-10 15:46:59 --> Config Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:46:59 --> URI Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Router Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Output Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Security Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Input Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:46:59 --> Language Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Loader Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:46:59 --> Controller Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:46:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:46:59 --> Model Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Model Class Initialized
DEBUG - 2019-05-10 15:46:59 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:46:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:46:59 --> Final output sent to browser
DEBUG - 2019-05-10 15:46:59 --> Total execution time: 0.0219
DEBUG - 2019-05-10 15:47:17 --> Config Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:47:17 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:47:17 --> URI Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Router Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Output Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Security Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Input Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:47:17 --> Language Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Loader Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:47:17 --> Controller Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:47:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:47:17 --> Model Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Model Class Initialized
DEBUG - 2019-05-10 15:47:17 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:47:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:47:17 --> Final output sent to browser
DEBUG - 2019-05-10 15:47:17 --> Total execution time: 0.0220
DEBUG - 2019-05-10 15:57:38 --> Config Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Hooks Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Utf8 Class Initialized
DEBUG - 2019-05-10 15:57:38 --> UTF-8 Support Enabled
DEBUG - 2019-05-10 15:57:38 --> URI Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Router Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Output Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Security Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Input Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-10 15:57:38 --> Language Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Loader Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Helper loaded: date_helper
DEBUG - 2019-05-10 15:57:38 --> Controller Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Database Driver Class Initialized
ERROR - 2019-05-10 15:57:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-10 15:57:38 --> Model Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Model Class Initialized
DEBUG - 2019-05-10 15:57:38 --> Helper loaded: url_helper
DEBUG - 2019-05-10 15:57:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-10 15:57:38 --> Final output sent to browser
DEBUG - 2019-05-10 15:57:38 --> Total execution time: 0.0305
