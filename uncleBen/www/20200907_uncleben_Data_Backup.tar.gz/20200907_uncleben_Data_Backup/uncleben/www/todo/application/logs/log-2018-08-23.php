<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-23 00:29:44 --> Config Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Hooks Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Utf8 Class Initialized
DEBUG - 2018-08-23 00:29:44 --> UTF-8 Support Enabled
DEBUG - 2018-08-23 00:29:44 --> URI Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Router Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Output Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Security Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Input Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-23 00:29:44 --> Language Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Loader Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Helper loaded: date_helper
DEBUG - 2018-08-23 00:29:44 --> Controller Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Database Driver Class Initialized
ERROR - 2018-08-23 00:29:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-23 00:29:44 --> Model Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Model Class Initialized
DEBUG - 2018-08-23 00:29:44 --> Helper loaded: url_helper
DEBUG - 2018-08-23 00:29:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-23 00:29:44 --> Final output sent to browser
DEBUG - 2018-08-23 00:29:44 --> Total execution time: 0.0222
DEBUG - 2018-08-23 00:32:18 --> Config Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Hooks Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Utf8 Class Initialized
DEBUG - 2018-08-23 00:32:18 --> UTF-8 Support Enabled
DEBUG - 2018-08-23 00:32:18 --> URI Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Router Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Output Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Security Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Input Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-23 00:32:18 --> Language Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Loader Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Helper loaded: date_helper
DEBUG - 2018-08-23 00:32:18 --> Controller Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Database Driver Class Initialized
ERROR - 2018-08-23 00:32:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-23 00:32:18 --> Model Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Model Class Initialized
DEBUG - 2018-08-23 00:32:18 --> Helper loaded: url_helper
DEBUG - 2018-08-23 00:32:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-23 00:32:18 --> Final output sent to browser
DEBUG - 2018-08-23 00:32:18 --> Total execution time: 0.0230
DEBUG - 2018-08-23 08:11:00 --> Config Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Hooks Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Utf8 Class Initialized
DEBUG - 2018-08-23 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2018-08-23 08:11:00 --> URI Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Router Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Output Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Security Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Input Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-23 08:11:00 --> Language Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Loader Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Helper loaded: date_helper
DEBUG - 2018-08-23 08:11:00 --> Controller Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Database Driver Class Initialized
ERROR - 2018-08-23 08:11:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-23 08:11:00 --> Model Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Model Class Initialized
DEBUG - 2018-08-23 08:11:00 --> Helper loaded: url_helper
DEBUG - 2018-08-23 08:11:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-23 08:11:00 --> Final output sent to browser
DEBUG - 2018-08-23 08:11:00 --> Total execution time: 0.1683
DEBUG - 2018-08-23 13:19:43 --> Config Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Hooks Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Utf8 Class Initialized
DEBUG - 2018-08-23 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2018-08-23 13:19:43 --> URI Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Router Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Output Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Security Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Input Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-23 13:19:43 --> Language Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Loader Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Helper loaded: date_helper
DEBUG - 2018-08-23 13:19:43 --> Controller Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Database Driver Class Initialized
ERROR - 2018-08-23 13:19:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-23 13:19:43 --> Model Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Model Class Initialized
DEBUG - 2018-08-23 13:19:43 --> Helper loaded: url_helper
DEBUG - 2018-08-23 13:19:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-23 13:19:43 --> Final output sent to browser
DEBUG - 2018-08-23 13:19:43 --> Total execution time: 0.0239
DEBUG - 2018-08-23 14:08:36 --> Config Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Hooks Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Utf8 Class Initialized
DEBUG - 2018-08-23 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2018-08-23 14:08:36 --> URI Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Router Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Output Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Security Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Input Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-23 14:08:36 --> Language Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Loader Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Helper loaded: date_helper
DEBUG - 2018-08-23 14:08:36 --> Controller Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Database Driver Class Initialized
ERROR - 2018-08-23 14:08:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-23 14:08:36 --> Model Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Model Class Initialized
DEBUG - 2018-08-23 14:08:36 --> Helper loaded: url_helper
DEBUG - 2018-08-23 14:08:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-23 14:08:36 --> Final output sent to browser
DEBUG - 2018-08-23 14:08:36 --> Total execution time: 0.0210
DEBUG - 2018-08-23 19:23:08 --> Config Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Utf8 Class Initialized
DEBUG - 2018-08-23 19:23:08 --> UTF-8 Support Enabled
DEBUG - 2018-08-23 19:23:08 --> URI Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Router Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Output Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Security Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Input Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-23 19:23:08 --> Language Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Loader Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Helper loaded: date_helper
DEBUG - 2018-08-23 19:23:08 --> Controller Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Database Driver Class Initialized
ERROR - 2018-08-23 19:23:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-23 19:23:08 --> Model Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Model Class Initialized
DEBUG - 2018-08-23 19:23:08 --> Helper loaded: url_helper
DEBUG - 2018-08-23 19:23:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-23 19:23:08 --> Final output sent to browser
DEBUG - 2018-08-23 19:23:08 --> Total execution time: 0.0210
DEBUG - 2018-08-23 19:25:52 --> Config Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Hooks Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Utf8 Class Initialized
DEBUG - 2018-08-23 19:25:52 --> UTF-8 Support Enabled
DEBUG - 2018-08-23 19:25:52 --> URI Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Router Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Output Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Security Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Input Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-23 19:25:52 --> Language Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Loader Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Helper loaded: date_helper
DEBUG - 2018-08-23 19:25:52 --> Controller Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Database Driver Class Initialized
ERROR - 2018-08-23 19:25:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-23 19:25:52 --> Model Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Model Class Initialized
DEBUG - 2018-08-23 19:25:52 --> Helper loaded: url_helper
DEBUG - 2018-08-23 19:25:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-23 19:25:52 --> Final output sent to browser
DEBUG - 2018-08-23 19:25:52 --> Total execution time: 0.0205
