<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-02-02 01:50:41 --> Config Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Hooks Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Utf8 Class Initialized
DEBUG - 2019-02-02 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-02-02 01:50:41 --> URI Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Router Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Output Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Security Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Input Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-02 01:50:41 --> Language Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Loader Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Helper loaded: date_helper
DEBUG - 2019-02-02 01:50:41 --> Controller Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Database Driver Class Initialized
ERROR - 2019-02-02 01:50:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-02 01:50:41 --> Model Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Model Class Initialized
DEBUG - 2019-02-02 01:50:41 --> Helper loaded: url_helper
DEBUG - 2019-02-02 01:50:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-02 01:50:41 --> Final output sent to browser
DEBUG - 2019-02-02 01:50:41 --> Total execution time: 0.0433
DEBUG - 2019-02-02 20:19:52 --> Config Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Hooks Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Utf8 Class Initialized
DEBUG - 2019-02-02 20:19:52 --> UTF-8 Support Enabled
DEBUG - 2019-02-02 20:19:52 --> URI Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Router Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Output Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Security Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Input Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-02-02 20:19:52 --> Language Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Loader Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Helper loaded: date_helper
DEBUG - 2019-02-02 20:19:52 --> Controller Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Database Driver Class Initialized
ERROR - 2019-02-02 20:19:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-02-02 20:19:52 --> Model Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Model Class Initialized
DEBUG - 2019-02-02 20:19:52 --> Helper loaded: url_helper
DEBUG - 2019-02-02 20:19:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-02-02 20:19:52 --> Final output sent to browser
DEBUG - 2019-02-02 20:19:52 --> Total execution time: 0.0467
