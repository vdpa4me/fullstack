<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-02-13 00:40:32 --> Config Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Hooks Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Utf8 Class Initialized
DEBUG - 2020-02-13 00:40:32 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 00:40:32 --> URI Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Router Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Output Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Security Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Input Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-13 00:40:32 --> Language Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Loader Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Helper loaded: date_helper
DEBUG - 2020-02-13 00:40:32 --> Controller Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Database Driver Class Initialized
ERROR - 2020-02-13 00:40:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-13 00:40:32 --> Model Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Model Class Initialized
DEBUG - 2020-02-13 00:40:32 --> Helper loaded: url_helper
DEBUG - 2020-02-13 00:40:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-13 00:40:32 --> Final output sent to browser
DEBUG - 2020-02-13 00:40:32 --> Total execution time: 0.2210
DEBUG - 2020-02-13 03:28:47 --> Config Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Hooks Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Utf8 Class Initialized
DEBUG - 2020-02-13 03:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 03:28:47 --> URI Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Router Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Output Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Security Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Input Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-13 03:28:47 --> Language Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Loader Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Helper loaded: date_helper
DEBUG - 2020-02-13 03:28:47 --> Controller Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Database Driver Class Initialized
ERROR - 2020-02-13 03:28:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-13 03:28:47 --> Model Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Model Class Initialized
DEBUG - 2020-02-13 03:28:47 --> Helper loaded: url_helper
DEBUG - 2020-02-13 03:28:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-13 03:28:47 --> Final output sent to browser
DEBUG - 2020-02-13 03:28:47 --> Total execution time: 0.1075
DEBUG - 2020-02-13 06:54:45 --> Config Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Hooks Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Utf8 Class Initialized
DEBUG - 2020-02-13 06:54:45 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 06:54:45 --> URI Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Router Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Output Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Security Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Input Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-13 06:54:45 --> Language Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Loader Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Helper loaded: date_helper
DEBUG - 2020-02-13 06:54:45 --> Controller Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Database Driver Class Initialized
ERROR - 2020-02-13 06:54:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-13 06:54:45 --> Model Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Model Class Initialized
DEBUG - 2020-02-13 06:54:45 --> Helper loaded: url_helper
DEBUG - 2020-02-13 06:54:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-13 06:54:45 --> Final output sent to browser
DEBUG - 2020-02-13 06:54:45 --> Total execution time: 0.1227
DEBUG - 2020-02-13 18:03:24 --> Config Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Hooks Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Utf8 Class Initialized
DEBUG - 2020-02-13 18:03:24 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 18:03:24 --> URI Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Router Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Output Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Security Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Input Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-13 18:03:24 --> Language Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Loader Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Helper loaded: date_helper
DEBUG - 2020-02-13 18:03:24 --> Controller Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Database Driver Class Initialized
ERROR - 2020-02-13 18:03:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-13 18:03:24 --> Model Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Model Class Initialized
DEBUG - 2020-02-13 18:03:24 --> Helper loaded: url_helper
DEBUG - 2020-02-13 18:03:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-13 18:03:24 --> Final output sent to browser
DEBUG - 2020-02-13 18:03:24 --> Total execution time: 0.2429
DEBUG - 2020-02-13 20:40:11 --> Config Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Hooks Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Utf8 Class Initialized
DEBUG - 2020-02-13 20:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-02-13 20:40:11 --> URI Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Router Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Output Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Security Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Input Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-13 20:40:11 --> Language Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Loader Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Helper loaded: date_helper
DEBUG - 2020-02-13 20:40:11 --> Controller Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Database Driver Class Initialized
ERROR - 2020-02-13 20:40:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-13 20:40:11 --> Model Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Model Class Initialized
DEBUG - 2020-02-13 20:40:11 --> Helper loaded: url_helper
DEBUG - 2020-02-13 20:40:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-13 20:40:11 --> Final output sent to browser
DEBUG - 2020-02-13 20:40:11 --> Total execution time: 0.0934
