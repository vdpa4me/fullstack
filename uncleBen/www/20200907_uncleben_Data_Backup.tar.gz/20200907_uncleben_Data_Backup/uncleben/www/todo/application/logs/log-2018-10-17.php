<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-10-17 05:27:00 --> Config Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Hooks Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Utf8 Class Initialized
DEBUG - 2018-10-17 05:27:00 --> UTF-8 Support Enabled
DEBUG - 2018-10-17 05:27:00 --> URI Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Router Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Output Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Security Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Input Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-17 05:27:00 --> Language Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Loader Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Helper loaded: date_helper
DEBUG - 2018-10-17 05:27:00 --> Controller Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Database Driver Class Initialized
ERROR - 2018-10-17 05:27:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-17 05:27:00 --> Model Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Model Class Initialized
DEBUG - 2018-10-17 05:27:00 --> Helper loaded: url_helper
DEBUG - 2018-10-17 05:27:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-17 05:27:00 --> Final output sent to browser
DEBUG - 2018-10-17 05:27:00 --> Total execution time: 0.0886
DEBUG - 2018-10-17 05:39:20 --> Config Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Hooks Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Utf8 Class Initialized
DEBUG - 2018-10-17 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2018-10-17 05:39:20 --> URI Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Router Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Output Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Security Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Input Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-17 05:39:20 --> Language Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Loader Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Helper loaded: date_helper
DEBUG - 2018-10-17 05:39:20 --> Controller Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Database Driver Class Initialized
ERROR - 2018-10-17 05:39:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-17 05:39:20 --> Model Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Model Class Initialized
DEBUG - 2018-10-17 05:39:20 --> Helper loaded: url_helper
DEBUG - 2018-10-17 05:39:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-10-17 05:39:20 --> Final output sent to browser
DEBUG - 2018-10-17 05:39:20 --> Total execution time: 0.0561
DEBUG - 2018-10-17 15:42:39 --> Config Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Hooks Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Utf8 Class Initialized
DEBUG - 2018-10-17 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2018-10-17 15:42:39 --> URI Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Router Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Output Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Security Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Input Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-17 15:42:39 --> Language Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Loader Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Helper loaded: date_helper
DEBUG - 2018-10-17 15:42:39 --> Controller Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Database Driver Class Initialized
ERROR - 2018-10-17 15:42:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-17 15:42:39 --> Model Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Model Class Initialized
DEBUG - 2018-10-17 15:42:39 --> Helper loaded: url_helper
DEBUG - 2018-10-17 15:42:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-10-17 15:42:39 --> Final output sent to browser
DEBUG - 2018-10-17 15:42:39 --> Total execution time: 0.0901
DEBUG - 2018-10-17 15:42:44 --> Config Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Hooks Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Utf8 Class Initialized
DEBUG - 2018-10-17 15:42:44 --> UTF-8 Support Enabled
DEBUG - 2018-10-17 15:42:44 --> URI Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Router Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Output Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Security Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Input Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-17 15:42:44 --> Language Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Loader Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Helper loaded: date_helper
DEBUG - 2018-10-17 15:42:44 --> Controller Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Database Driver Class Initialized
ERROR - 2018-10-17 15:42:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-17 15:42:44 --> Model Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Model Class Initialized
DEBUG - 2018-10-17 15:42:44 --> Helper loaded: url_helper
DEBUG - 2018-10-17 15:42:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-10-17 15:42:44 --> Final output sent to browser
DEBUG - 2018-10-17 15:42:44 --> Total execution time: 0.0535
DEBUG - 2018-10-17 16:11:49 --> Config Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Hooks Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Utf8 Class Initialized
DEBUG - 2018-10-17 16:11:49 --> UTF-8 Support Enabled
DEBUG - 2018-10-17 16:11:49 --> URI Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Router Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Output Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Security Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Input Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-17 16:11:49 --> Language Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Loader Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Helper loaded: date_helper
DEBUG - 2018-10-17 16:11:49 --> Controller Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Database Driver Class Initialized
ERROR - 2018-10-17 16:11:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-17 16:11:49 --> Model Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Model Class Initialized
DEBUG - 2018-10-17 16:11:49 --> Helper loaded: url_helper
DEBUG - 2018-10-17 16:11:49 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-10-17 16:11:49 --> Final output sent to browser
DEBUG - 2018-10-17 16:11:49 --> Total execution time: 0.0338
DEBUG - 2018-10-17 18:18:15 --> Config Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Hooks Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Utf8 Class Initialized
DEBUG - 2018-10-17 18:18:15 --> UTF-8 Support Enabled
DEBUG - 2018-10-17 18:18:15 --> URI Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Router Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Output Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Security Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Input Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-10-17 18:18:15 --> Language Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Loader Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Helper loaded: date_helper
DEBUG - 2018-10-17 18:18:15 --> Controller Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Database Driver Class Initialized
ERROR - 2018-10-17 18:18:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-10-17 18:18:15 --> Model Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Model Class Initialized
DEBUG - 2018-10-17 18:18:15 --> Helper loaded: url_helper
DEBUG - 2018-10-17 18:18:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-10-17 18:18:15 --> Final output sent to browser
DEBUG - 2018-10-17 18:18:15 --> Total execution time: 0.0932
