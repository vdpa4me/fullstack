<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-05 01:40:12 --> Config Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Hooks Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Utf8 Class Initialized
DEBUG - 2018-12-05 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 01:40:12 --> URI Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Router Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Output Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Security Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Input Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 01:40:12 --> Language Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Loader Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Helper loaded: date_helper
DEBUG - 2018-12-05 01:40:12 --> Controller Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Database Driver Class Initialized
ERROR - 2018-12-05 01:40:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 01:40:12 --> Model Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Model Class Initialized
DEBUG - 2018-12-05 01:40:12 --> Helper loaded: url_helper
DEBUG - 2018-12-05 01:40:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 01:40:12 --> Final output sent to browser
DEBUG - 2018-12-05 01:40:12 --> Total execution time: 0.0836
DEBUG - 2018-12-05 02:11:35 --> Config Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Hooks Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Utf8 Class Initialized
DEBUG - 2018-12-05 02:11:35 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 02:11:35 --> URI Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Router Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Output Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Security Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Input Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 02:11:35 --> Language Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Loader Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Helper loaded: date_helper
DEBUG - 2018-12-05 02:11:35 --> Controller Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Database Driver Class Initialized
ERROR - 2018-12-05 02:11:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 02:11:35 --> Model Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Model Class Initialized
DEBUG - 2018-12-05 02:11:35 --> Helper loaded: url_helper
DEBUG - 2018-12-05 02:11:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 02:11:35 --> Final output sent to browser
DEBUG - 2018-12-05 02:11:35 --> Total execution time: 0.0648
DEBUG - 2018-12-05 02:11:45 --> Config Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Hooks Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Utf8 Class Initialized
DEBUG - 2018-12-05 02:11:45 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 02:11:45 --> URI Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Router Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Output Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Security Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Input Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 02:11:45 --> Language Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Loader Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Helper loaded: date_helper
DEBUG - 2018-12-05 02:11:45 --> Controller Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Database Driver Class Initialized
ERROR - 2018-12-05 02:11:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 02:11:45 --> Model Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Model Class Initialized
DEBUG - 2018-12-05 02:11:45 --> Helper loaded: url_helper
DEBUG - 2018-12-05 02:11:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 02:11:45 --> Final output sent to browser
DEBUG - 2018-12-05 02:11:45 --> Total execution time: 0.0688
DEBUG - 2018-12-05 10:15:10 --> Config Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Hooks Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Utf8 Class Initialized
DEBUG - 2018-12-05 10:15:10 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 10:15:10 --> URI Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Router Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Output Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Security Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Input Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 10:15:10 --> Language Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Loader Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Helper loaded: date_helper
DEBUG - 2018-12-05 10:15:10 --> Controller Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Database Driver Class Initialized
ERROR - 2018-12-05 10:15:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 10:15:10 --> Model Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Model Class Initialized
DEBUG - 2018-12-05 10:15:10 --> Helper loaded: url_helper
DEBUG - 2018-12-05 10:15:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-05 10:15:10 --> Final output sent to browser
DEBUG - 2018-12-05 10:15:10 --> Total execution time: 0.0601
DEBUG - 2018-12-05 13:55:27 --> Config Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Hooks Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Utf8 Class Initialized
DEBUG - 2018-12-05 13:55:27 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 13:55:27 --> URI Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Router Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Output Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Security Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Input Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 13:55:27 --> Language Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Loader Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Helper loaded: date_helper
DEBUG - 2018-12-05 13:55:27 --> Controller Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Database Driver Class Initialized
ERROR - 2018-12-05 13:55:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 13:55:27 --> Model Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Model Class Initialized
DEBUG - 2018-12-05 13:55:27 --> Helper loaded: url_helper
DEBUG - 2018-12-05 13:55:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 13:55:27 --> Final output sent to browser
DEBUG - 2018-12-05 13:55:27 --> Total execution time: 0.0653
DEBUG - 2018-12-05 13:55:31 --> Config Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Hooks Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Utf8 Class Initialized
DEBUG - 2018-12-05 13:55:31 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 13:55:31 --> URI Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Router Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Output Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Security Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Input Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 13:55:31 --> Language Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Loader Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Helper loaded: date_helper
DEBUG - 2018-12-05 13:55:31 --> Controller Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Database Driver Class Initialized
ERROR - 2018-12-05 13:55:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 13:55:31 --> Model Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Model Class Initialized
DEBUG - 2018-12-05 13:55:31 --> Helper loaded: url_helper
DEBUG - 2018-12-05 13:55:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 13:55:31 --> Final output sent to browser
DEBUG - 2018-12-05 13:55:31 --> Total execution time: 0.0601
DEBUG - 2018-12-05 14:36:02 --> Config Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Hooks Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Utf8 Class Initialized
DEBUG - 2018-12-05 14:36:02 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 14:36:02 --> URI Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Router Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Output Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Security Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Input Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 14:36:02 --> Language Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Loader Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Helper loaded: date_helper
DEBUG - 2018-12-05 14:36:02 --> Controller Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Database Driver Class Initialized
ERROR - 2018-12-05 14:36:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 14:36:02 --> Model Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Model Class Initialized
DEBUG - 2018-12-05 14:36:02 --> Helper loaded: url_helper
DEBUG - 2018-12-05 14:36:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-05 14:36:02 --> Final output sent to browser
DEBUG - 2018-12-05 14:36:02 --> Total execution time: 0.0250
DEBUG - 2018-12-05 17:28:59 --> Config Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Hooks Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Utf8 Class Initialized
DEBUG - 2018-12-05 17:28:59 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 17:28:59 --> URI Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Router Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Output Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Security Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Input Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 17:28:59 --> Language Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Loader Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Helper loaded: date_helper
DEBUG - 2018-12-05 17:28:59 --> Controller Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Database Driver Class Initialized
ERROR - 2018-12-05 17:28:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 17:28:59 --> Model Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Model Class Initialized
DEBUG - 2018-12-05 17:28:59 --> Helper loaded: url_helper
DEBUG - 2018-12-05 17:28:59 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-12-05 17:28:59 --> Final output sent to browser
DEBUG - 2018-12-05 17:28:59 --> Total execution time: 0.0291
DEBUG - 2018-12-05 17:35:28 --> Config Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Hooks Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Utf8 Class Initialized
DEBUG - 2018-12-05 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 17:35:28 --> URI Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Router Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Output Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Security Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Input Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 17:35:28 --> Language Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Loader Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Helper loaded: date_helper
DEBUG - 2018-12-05 17:35:28 --> Controller Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Database Driver Class Initialized
ERROR - 2018-12-05 17:35:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 17:35:28 --> Model Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Model Class Initialized
DEBUG - 2018-12-05 17:35:28 --> Helper loaded: url_helper
DEBUG - 2018-12-05 17:35:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 17:35:28 --> Final output sent to browser
DEBUG - 2018-12-05 17:35:28 --> Total execution time: 0.0681
DEBUG - 2018-12-05 17:35:32 --> Config Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Hooks Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Utf8 Class Initialized
DEBUG - 2018-12-05 17:35:32 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 17:35:32 --> URI Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Router Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Output Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Security Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Input Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 17:35:32 --> Language Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Loader Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Helper loaded: date_helper
DEBUG - 2018-12-05 17:35:32 --> Controller Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Database Driver Class Initialized
ERROR - 2018-12-05 17:35:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 17:35:32 --> Model Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Model Class Initialized
DEBUG - 2018-12-05 17:35:32 --> Helper loaded: url_helper
DEBUG - 2018-12-05 17:35:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 17:35:32 --> Final output sent to browser
DEBUG - 2018-12-05 17:35:32 --> Total execution time: 0.0445
DEBUG - 2018-12-05 18:57:15 --> Config Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Hooks Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Utf8 Class Initialized
DEBUG - 2018-12-05 18:57:15 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 18:57:15 --> URI Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Router Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Output Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Security Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Input Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 18:57:15 --> Language Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Loader Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Helper loaded: date_helper
DEBUG - 2018-12-05 18:57:15 --> Controller Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Database Driver Class Initialized
ERROR - 2018-12-05 18:57:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 18:57:15 --> Model Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Model Class Initialized
DEBUG - 2018-12-05 18:57:15 --> Helper loaded: url_helper
DEBUG - 2018-12-05 18:57:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-05 18:57:15 --> Final output sent to browser
DEBUG - 2018-12-05 18:57:15 --> Total execution time: 0.0365
DEBUG - 2018-12-05 18:58:13 --> Config Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Hooks Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Utf8 Class Initialized
DEBUG - 2018-12-05 18:58:13 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 18:58:13 --> URI Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Router Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Output Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Security Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Input Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 18:58:13 --> Language Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Loader Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Helper loaded: date_helper
DEBUG - 2018-12-05 18:58:13 --> Controller Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Database Driver Class Initialized
ERROR - 2018-12-05 18:58:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 18:58:13 --> Model Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Model Class Initialized
DEBUG - 2018-12-05 18:58:13 --> Helper loaded: url_helper
DEBUG - 2018-12-05 18:58:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-05 18:58:13 --> Final output sent to browser
DEBUG - 2018-12-05 18:58:13 --> Total execution time: 0.0331
DEBUG - 2018-12-05 19:52:49 --> Config Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Hooks Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Utf8 Class Initialized
DEBUG - 2018-12-05 19:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 19:52:49 --> URI Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Router Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Output Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Security Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Input Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 19:52:49 --> Language Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Loader Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Helper loaded: date_helper
DEBUG - 2018-12-05 19:52:49 --> Controller Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Database Driver Class Initialized
ERROR - 2018-12-05 19:52:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 19:52:49 --> Model Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Model Class Initialized
DEBUG - 2018-12-05 19:52:49 --> Helper loaded: url_helper
DEBUG - 2018-12-05 19:52:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 19:52:49 --> Final output sent to browser
DEBUG - 2018-12-05 19:52:49 --> Total execution time: 0.0944
DEBUG - 2018-12-05 20:33:10 --> Config Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Hooks Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Utf8 Class Initialized
DEBUG - 2018-12-05 20:33:10 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 20:33:10 --> URI Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Router Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Output Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Security Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Input Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 20:33:10 --> Language Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Loader Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Helper loaded: date_helper
DEBUG - 2018-12-05 20:33:10 --> Controller Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Database Driver Class Initialized
ERROR - 2018-12-05 20:33:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 20:33:10 --> Model Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Model Class Initialized
DEBUG - 2018-12-05 20:33:10 --> Helper loaded: url_helper
DEBUG - 2018-12-05 20:33:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-05 20:33:10 --> Final output sent to browser
DEBUG - 2018-12-05 20:33:10 --> Total execution time: 0.0215
DEBUG - 2018-12-05 23:55:37 --> Config Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Hooks Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Utf8 Class Initialized
DEBUG - 2018-12-05 23:55:37 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 23:55:37 --> URI Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Router Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Output Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Security Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Input Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 23:55:37 --> Language Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Loader Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Helper loaded: date_helper
DEBUG - 2018-12-05 23:55:37 --> Controller Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Database Driver Class Initialized
ERROR - 2018-12-05 23:55:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 23:55:37 --> Model Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Model Class Initialized
DEBUG - 2018-12-05 23:55:37 --> Helper loaded: url_helper
DEBUG - 2018-12-05 23:55:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 23:55:37 --> Final output sent to browser
DEBUG - 2018-12-05 23:55:37 --> Total execution time: 0.0566
DEBUG - 2018-12-05 23:55:41 --> Config Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Hooks Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Utf8 Class Initialized
DEBUG - 2018-12-05 23:55:41 --> UTF-8 Support Enabled
DEBUG - 2018-12-05 23:55:41 --> URI Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Router Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Output Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Security Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Input Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-05 23:55:41 --> Language Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Loader Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Helper loaded: date_helper
DEBUG - 2018-12-05 23:55:41 --> Controller Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Database Driver Class Initialized
ERROR - 2018-12-05 23:55:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-05 23:55:41 --> Model Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Model Class Initialized
DEBUG - 2018-12-05 23:55:41 --> Helper loaded: url_helper
DEBUG - 2018-12-05 23:55:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-05 23:55:41 --> Final output sent to browser
DEBUG - 2018-12-05 23:55:41 --> Total execution time: 0.0509
