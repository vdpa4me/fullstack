<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-13 00:08:17 --> Config Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Hooks Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Utf8 Class Initialized
DEBUG - 2018-08-13 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2018-08-13 00:08:17 --> URI Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Router Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Output Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Security Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Input Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-13 00:08:17 --> Language Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Loader Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Helper loaded: date_helper
DEBUG - 2018-08-13 00:08:17 --> Controller Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Database Driver Class Initialized
ERROR - 2018-08-13 00:08:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-13 00:08:17 --> Model Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Model Class Initialized
DEBUG - 2018-08-13 00:08:17 --> Helper loaded: url_helper
DEBUG - 2018-08-13 00:08:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-13 00:08:17 --> Final output sent to browser
DEBUG - 2018-08-13 00:08:17 --> Total execution time: 0.0219
DEBUG - 2018-08-13 09:02:53 --> Config Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Hooks Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Utf8 Class Initialized
DEBUG - 2018-08-13 09:02:53 --> UTF-8 Support Enabled
DEBUG - 2018-08-13 09:02:53 --> URI Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Router Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Output Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Security Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Input Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-13 09:02:53 --> Language Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Loader Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Helper loaded: date_helper
DEBUG - 2018-08-13 09:02:53 --> Controller Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Database Driver Class Initialized
ERROR - 2018-08-13 09:02:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-13 09:02:53 --> Model Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Model Class Initialized
DEBUG - 2018-08-13 09:02:53 --> Helper loaded: url_helper
DEBUG - 2018-08-13 09:02:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-13 09:02:53 --> Final output sent to browser
DEBUG - 2018-08-13 09:02:53 --> Total execution time: 0.0281
DEBUG - 2018-08-13 09:05:24 --> Config Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Hooks Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Utf8 Class Initialized
DEBUG - 2018-08-13 09:05:24 --> UTF-8 Support Enabled
DEBUG - 2018-08-13 09:05:24 --> URI Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Router Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Output Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Security Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Input Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-13 09:05:24 --> Language Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Loader Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Helper loaded: date_helper
DEBUG - 2018-08-13 09:05:24 --> Controller Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Database Driver Class Initialized
ERROR - 2018-08-13 09:05:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-13 09:05:24 --> Model Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Model Class Initialized
DEBUG - 2018-08-13 09:05:24 --> Helper loaded: url_helper
DEBUG - 2018-08-13 09:05:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-13 09:05:24 --> Final output sent to browser
DEBUG - 2018-08-13 09:05:24 --> Total execution time: 0.0210
DEBUG - 2018-08-13 15:13:31 --> Config Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Hooks Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Utf8 Class Initialized
DEBUG - 2018-08-13 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2018-08-13 15:13:31 --> URI Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Router Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Output Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Security Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Input Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-13 15:13:31 --> Language Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Loader Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Helper loaded: date_helper
DEBUG - 2018-08-13 15:13:31 --> Controller Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Database Driver Class Initialized
ERROR - 2018-08-13 15:13:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-13 15:13:31 --> Model Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Model Class Initialized
DEBUG - 2018-08-13 15:13:31 --> Helper loaded: url_helper
DEBUG - 2018-08-13 15:13:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-13 15:13:31 --> Final output sent to browser
DEBUG - 2018-08-13 15:13:31 --> Total execution time: 0.0214
DEBUG - 2018-08-13 21:46:10 --> Config Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Hooks Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Utf8 Class Initialized
DEBUG - 2018-08-13 21:46:10 --> UTF-8 Support Enabled
DEBUG - 2018-08-13 21:46:10 --> URI Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Router Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Output Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Security Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Input Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-13 21:46:10 --> Language Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Loader Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Helper loaded: date_helper
DEBUG - 2018-08-13 21:46:10 --> Controller Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Database Driver Class Initialized
ERROR - 2018-08-13 21:46:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-13 21:46:10 --> Model Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Model Class Initialized
DEBUG - 2018-08-13 21:46:10 --> Helper loaded: url_helper
DEBUG - 2018-08-13 21:46:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-13 21:46:10 --> Final output sent to browser
DEBUG - 2018-08-13 21:46:10 --> Total execution time: 0.0219
DEBUG - 2018-08-13 21:48:40 --> Config Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Hooks Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Utf8 Class Initialized
DEBUG - 2018-08-13 21:48:40 --> UTF-8 Support Enabled
DEBUG - 2018-08-13 21:48:40 --> URI Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Router Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Output Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Security Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Input Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-13 21:48:40 --> Language Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Loader Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Helper loaded: date_helper
DEBUG - 2018-08-13 21:48:40 --> Controller Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Database Driver Class Initialized
ERROR - 2018-08-13 21:48:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-13 21:48:40 --> Model Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Model Class Initialized
DEBUG - 2018-08-13 21:48:40 --> Helper loaded: url_helper
DEBUG - 2018-08-13 21:48:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-13 21:48:40 --> Final output sent to browser
DEBUG - 2018-08-13 21:48:40 --> Total execution time: 0.0210
