<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-08-24 00:51:42 --> Config Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Hooks Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Utf8 Class Initialized
DEBUG - 2017-08-24 00:51:42 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 00:51:42 --> URI Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Router Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Output Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Security Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Input Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 00:51:42 --> Language Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Loader Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Helper loaded: date_helper
DEBUG - 2017-08-24 00:51:42 --> Controller Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Database Driver Class Initialized
ERROR - 2017-08-24 00:51:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 00:51:42 --> Model Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Model Class Initialized
DEBUG - 2017-08-24 00:51:42 --> Helper loaded: url_helper
DEBUG - 2017-08-24 00:51:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 00:51:42 --> Final output sent to browser
DEBUG - 2017-08-24 00:51:42 --> Total execution time: 0.0456
DEBUG - 2017-08-24 01:04:20 --> Config Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:04:20 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:04:20 --> URI Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Router Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Output Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Security Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Input Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:04:20 --> Language Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Loader Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:04:20 --> Controller Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:04:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:04:20 --> Model Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Model Class Initialized
DEBUG - 2017-08-24 01:04:20 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:04:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:04:20 --> Final output sent to browser
DEBUG - 2017-08-24 01:04:20 --> Total execution time: 0.0352
DEBUG - 2017-08-24 01:04:25 --> Config Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:04:25 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:04:25 --> URI Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Router Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Output Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Security Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Input Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:04:25 --> Language Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Loader Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:04:25 --> Controller Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:04:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:04:25 --> Model Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Model Class Initialized
DEBUG - 2017-08-24 01:04:25 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:04:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:04:25 --> Final output sent to browser
DEBUG - 2017-08-24 01:04:25 --> Total execution time: 0.0351
DEBUG - 2017-08-24 01:05:31 --> Config Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:05:31 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:05:31 --> URI Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Router Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Output Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Security Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Input Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:05:31 --> Language Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Loader Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:05:31 --> Controller Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:05:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:05:31 --> Model Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Model Class Initialized
DEBUG - 2017-08-24 01:05:31 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:05:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:05:31 --> Final output sent to browser
DEBUG - 2017-08-24 01:05:31 --> Total execution time: 0.0362
DEBUG - 2017-08-24 01:07:05 --> Config Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:07:05 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:07:05 --> URI Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Router Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Output Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Security Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Input Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:07:05 --> Language Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Loader Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:07:05 --> Controller Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:07:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:07:05 --> Model Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Model Class Initialized
DEBUG - 2017-08-24 01:07:05 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:07:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:07:05 --> Final output sent to browser
DEBUG - 2017-08-24 01:07:05 --> Total execution time: 0.0365
DEBUG - 2017-08-24 01:12:32 --> Config Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:12:32 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:12:32 --> URI Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Router Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Output Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Security Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Input Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:12:32 --> Language Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Loader Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:12:32 --> Controller Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:12:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:12:32 --> Model Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Model Class Initialized
DEBUG - 2017-08-24 01:12:32 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:12:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:12:32 --> Final output sent to browser
DEBUG - 2017-08-24 01:12:32 --> Total execution time: 0.0363
DEBUG - 2017-08-24 01:13:59 --> Config Class Initialized
DEBUG - 2017-08-24 01:13:59 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:13:59 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:13:59 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:13:59 --> URI Class Initialized
DEBUG - 2017-08-24 01:13:59 --> Router Class Initialized
DEBUG - 2017-08-24 01:13:59 --> Output Class Initialized
DEBUG - 2017-08-24 01:13:59 --> Security Class Initialized
DEBUG - 2017-08-24 01:13:59 --> Input Class Initialized
DEBUG - 2017-08-24 01:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:13:59 --> Language Class Initialized
DEBUG - 2017-08-24 01:14:00 --> Loader Class Initialized
DEBUG - 2017-08-24 01:14:00 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:14:00 --> Controller Class Initialized
DEBUG - 2017-08-24 01:14:00 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:14:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:14:00 --> Model Class Initialized
DEBUG - 2017-08-24 01:14:00 --> Model Class Initialized
DEBUG - 2017-08-24 01:14:00 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:14:00 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:14:00 --> Final output sent to browser
DEBUG - 2017-08-24 01:14:00 --> Total execution time: 0.0360
DEBUG - 2017-08-24 01:16:18 --> Config Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:16:18 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:16:18 --> URI Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Router Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Output Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Security Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Input Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:16:18 --> Language Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Loader Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:16:18 --> Controller Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:16:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:16:18 --> Model Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Model Class Initialized
DEBUG - 2017-08-24 01:16:18 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:16:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:16:18 --> Final output sent to browser
DEBUG - 2017-08-24 01:16:18 --> Total execution time: 0.0359
DEBUG - 2017-08-24 01:16:24 --> Config Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:16:24 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:16:24 --> URI Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Router Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Output Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Security Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Input Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:16:24 --> Language Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Loader Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:16:24 --> Controller Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:16:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:16:24 --> Model Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Model Class Initialized
DEBUG - 2017-08-24 01:16:24 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:16:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:16:24 --> Final output sent to browser
DEBUG - 2017-08-24 01:16:24 --> Total execution time: 0.0364
DEBUG - 2017-08-24 01:17:18 --> Config Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:17:18 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:17:18 --> URI Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Router Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Output Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Security Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Input Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:17:18 --> Language Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Loader Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:17:18 --> Controller Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:17:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:17:18 --> Model Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Model Class Initialized
DEBUG - 2017-08-24 01:17:18 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:17:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:17:18 --> Final output sent to browser
DEBUG - 2017-08-24 01:17:18 --> Total execution time: 0.0350
DEBUG - 2017-08-24 01:17:22 --> Config Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:17:22 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:17:22 --> URI Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Router Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Output Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Security Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Input Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:17:22 --> Language Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Loader Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:17:22 --> Controller Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:17:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:17:22 --> Model Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Model Class Initialized
DEBUG - 2017-08-24 01:17:22 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:17:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:17:22 --> Final output sent to browser
DEBUG - 2017-08-24 01:17:22 --> Total execution time: 0.0365
DEBUG - 2017-08-24 01:19:09 --> Config Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:19:09 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:19:09 --> URI Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Router Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Output Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Security Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Input Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:19:09 --> Language Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Loader Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:19:09 --> Controller Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:19:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:19:09 --> Model Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Model Class Initialized
DEBUG - 2017-08-24 01:19:09 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:19:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:19:09 --> Final output sent to browser
DEBUG - 2017-08-24 01:19:09 --> Total execution time: 0.0364
DEBUG - 2017-08-24 01:19:24 --> Config Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Hooks Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Utf8 Class Initialized
DEBUG - 2017-08-24 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 01:19:24 --> URI Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Router Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Output Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Security Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Input Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 01:19:24 --> Language Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Loader Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Helper loaded: date_helper
DEBUG - 2017-08-24 01:19:24 --> Controller Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Database Driver Class Initialized
ERROR - 2017-08-24 01:19:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 01:19:24 --> Model Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Model Class Initialized
DEBUG - 2017-08-24 01:19:24 --> Helper loaded: url_helper
DEBUG - 2017-08-24 01:19:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 01:19:24 --> Final output sent to browser
DEBUG - 2017-08-24 01:19:24 --> Total execution time: 0.0361
DEBUG - 2017-08-24 04:30:50 --> Config Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:30:50 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:30:50 --> URI Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Router Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Output Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Security Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Input Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:30:50 --> Language Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Loader Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:30:50 --> Controller Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:30:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:30:50 --> Model Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Model Class Initialized
DEBUG - 2017-08-24 04:30:50 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:30:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:30:50 --> Final output sent to browser
DEBUG - 2017-08-24 04:30:50 --> Total execution time: 0.0408
DEBUG - 2017-08-24 04:31:02 --> Config Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:31:02 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:31:02 --> URI Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Router Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Output Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Security Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Input Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:31:02 --> Language Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Loader Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:31:02 --> Controller Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:31:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:31:02 --> Model Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Model Class Initialized
DEBUG - 2017-08-24 04:31:02 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:31:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:31:02 --> Final output sent to browser
DEBUG - 2017-08-24 04:31:02 --> Total execution time: 0.0379
DEBUG - 2017-08-24 04:31:59 --> Config Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:31:59 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:31:59 --> URI Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Router Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Output Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Security Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Input Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:31:59 --> Language Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Loader Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:31:59 --> Controller Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:31:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:31:59 --> Model Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Model Class Initialized
DEBUG - 2017-08-24 04:31:59 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:31:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:31:59 --> Final output sent to browser
DEBUG - 2017-08-24 04:31:59 --> Total execution time: 0.0356
DEBUG - 2017-08-24 04:32:03 --> Config Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:32:03 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:32:03 --> URI Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Router Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Output Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Security Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Input Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:32:03 --> Language Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Loader Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:32:03 --> Controller Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:32:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:32:03 --> Model Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Model Class Initialized
DEBUG - 2017-08-24 04:32:03 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:32:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:32:03 --> Final output sent to browser
DEBUG - 2017-08-24 04:32:03 --> Total execution time: 0.0358
DEBUG - 2017-08-24 04:32:55 --> Config Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:32:55 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:32:55 --> URI Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Router Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Output Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Security Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Input Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:32:55 --> Language Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Loader Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:32:55 --> Controller Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:32:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:32:55 --> Model Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Model Class Initialized
DEBUG - 2017-08-24 04:32:55 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:32:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:32:55 --> Final output sent to browser
DEBUG - 2017-08-24 04:32:55 --> Total execution time: 0.0368
DEBUG - 2017-08-24 04:33:01 --> Config Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:33:01 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:33:01 --> URI Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Router Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Output Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Security Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Input Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:33:01 --> Language Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Loader Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:33:01 --> Controller Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:33:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:33:01 --> Model Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Model Class Initialized
DEBUG - 2017-08-24 04:33:01 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:33:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:33:01 --> Final output sent to browser
DEBUG - 2017-08-24 04:33:01 --> Total execution time: 0.0386
DEBUG - 2017-08-24 04:33:05 --> Config Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:33:05 --> URI Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Router Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Output Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Security Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Input Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:33:05 --> Language Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Loader Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:33:05 --> Controller Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:33:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:33:05 --> Model Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Model Class Initialized
DEBUG - 2017-08-24 04:33:05 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:33:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:33:05 --> Final output sent to browser
DEBUG - 2017-08-24 04:33:05 --> Total execution time: 0.0357
DEBUG - 2017-08-24 04:34:39 --> Config Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:34:39 --> URI Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Router Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Output Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Security Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Input Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:34:39 --> Language Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Loader Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:34:39 --> Controller Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:34:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:34:39 --> Model Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Model Class Initialized
DEBUG - 2017-08-24 04:34:39 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:34:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:34:39 --> Final output sent to browser
DEBUG - 2017-08-24 04:34:39 --> Total execution time: 0.0365
DEBUG - 2017-08-24 04:36:19 --> Config Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Hooks Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Utf8 Class Initialized
DEBUG - 2017-08-24 04:36:19 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 04:36:19 --> URI Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Router Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Output Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Security Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Input Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 04:36:19 --> Language Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Loader Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Helper loaded: date_helper
DEBUG - 2017-08-24 04:36:19 --> Controller Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Database Driver Class Initialized
ERROR - 2017-08-24 04:36:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 04:36:19 --> Model Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Model Class Initialized
DEBUG - 2017-08-24 04:36:19 --> Helper loaded: url_helper
DEBUG - 2017-08-24 04:36:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 04:36:19 --> Final output sent to browser
DEBUG - 2017-08-24 04:36:19 --> Total execution time: 0.0364
DEBUG - 2017-08-24 05:16:11 --> Config Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:16:11 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:16:11 --> URI Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Router Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Output Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Security Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Input Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:16:11 --> Language Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Loader Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:16:11 --> Controller Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:16:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:16:11 --> Model Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Model Class Initialized
DEBUG - 2017-08-24 05:16:11 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:16:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:16:11 --> Final output sent to browser
DEBUG - 2017-08-24 05:16:11 --> Total execution time: 0.0465
DEBUG - 2017-08-24 05:17:11 --> Config Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:17:11 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:17:11 --> URI Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Router Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Output Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Security Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Input Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:17:11 --> Language Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Loader Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:17:11 --> Controller Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:17:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:17:11 --> Model Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Model Class Initialized
DEBUG - 2017-08-24 05:17:11 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:17:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:17:11 --> Final output sent to browser
DEBUG - 2017-08-24 05:17:11 --> Total execution time: 0.0365
DEBUG - 2017-08-24 05:17:58 --> Config Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:17:58 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:17:58 --> URI Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Router Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Output Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Security Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Input Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:17:58 --> Language Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Loader Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:17:58 --> Controller Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:17:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:17:58 --> Model Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Model Class Initialized
DEBUG - 2017-08-24 05:17:58 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:17:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:17:58 --> Final output sent to browser
DEBUG - 2017-08-24 05:17:58 --> Total execution time: 0.0363
DEBUG - 2017-08-24 05:21:14 --> Config Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:21:14 --> URI Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Router Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Output Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Security Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Input Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:21:14 --> Language Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Loader Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:21:14 --> Controller Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:21:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:21:14 --> Model Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Model Class Initialized
DEBUG - 2017-08-24 05:21:14 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:21:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:21:14 --> Final output sent to browser
DEBUG - 2017-08-24 05:21:14 --> Total execution time: 0.0371
DEBUG - 2017-08-24 05:21:55 --> Config Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:21:55 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:21:55 --> URI Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Router Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Output Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Security Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Input Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:21:55 --> Language Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Loader Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:21:55 --> Controller Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:21:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:21:55 --> Model Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Model Class Initialized
DEBUG - 2017-08-24 05:21:55 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:21:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:21:55 --> Final output sent to browser
DEBUG - 2017-08-24 05:21:55 --> Total execution time: 0.0359
DEBUG - 2017-08-24 05:28:02 --> Config Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:28:02 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:28:02 --> URI Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Router Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Output Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Security Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Input Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:28:02 --> Language Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Loader Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:28:02 --> Controller Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:28:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:28:02 --> Model Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Model Class Initialized
DEBUG - 2017-08-24 05:28:02 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:28:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:28:02 --> Final output sent to browser
DEBUG - 2017-08-24 05:28:02 --> Total execution time: 0.0378
DEBUG - 2017-08-24 05:29:39 --> Config Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:29:39 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:29:39 --> URI Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Router Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Output Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Security Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Input Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:29:39 --> Language Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Loader Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:29:39 --> Controller Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:29:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:29:39 --> Model Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Model Class Initialized
DEBUG - 2017-08-24 05:29:39 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:29:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:29:39 --> Final output sent to browser
DEBUG - 2017-08-24 05:29:39 --> Total execution time: 0.0363
DEBUG - 2017-08-24 05:31:52 --> Config Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:31:52 --> URI Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Router Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Output Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Security Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Input Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:31:52 --> Language Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Loader Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:31:52 --> Controller Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:31:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:31:52 --> Model Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Model Class Initialized
DEBUG - 2017-08-24 05:31:52 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:31:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:31:52 --> Final output sent to browser
DEBUG - 2017-08-24 05:31:52 --> Total execution time: 0.0363
DEBUG - 2017-08-24 05:33:53 --> Config Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:33:53 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:33:53 --> URI Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Router Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Output Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Security Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Input Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:33:53 --> Language Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Loader Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:33:53 --> Controller Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:33:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:33:53 --> Model Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Model Class Initialized
DEBUG - 2017-08-24 05:33:53 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:33:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:33:53 --> Final output sent to browser
DEBUG - 2017-08-24 05:33:53 --> Total execution time: 0.0365
DEBUG - 2017-08-24 05:35:06 --> Config Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:35:06 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:35:06 --> URI Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Router Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Output Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Security Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Input Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:35:06 --> Language Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Loader Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:35:06 --> Controller Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:35:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:35:06 --> Model Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Model Class Initialized
DEBUG - 2017-08-24 05:35:06 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:35:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:35:06 --> Final output sent to browser
DEBUG - 2017-08-24 05:35:06 --> Total execution time: 0.0360
DEBUG - 2017-08-24 05:35:31 --> Config Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:35:31 --> URI Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Router Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Output Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Security Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Input Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:35:31 --> Language Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Loader Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:35:31 --> Controller Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:35:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:35:31 --> Model Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Model Class Initialized
DEBUG - 2017-08-24 05:35:31 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:35:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:35:31 --> Final output sent to browser
DEBUG - 2017-08-24 05:35:31 --> Total execution time: 0.0368
DEBUG - 2017-08-24 05:35:40 --> Config Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:35:40 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:35:40 --> URI Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Router Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Output Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Security Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Input Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:35:40 --> Language Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Loader Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:35:40 --> Controller Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:35:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:35:40 --> Model Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Model Class Initialized
DEBUG - 2017-08-24 05:35:40 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:35:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:35:40 --> Final output sent to browser
DEBUG - 2017-08-24 05:35:40 --> Total execution time: 0.0350
DEBUG - 2017-08-24 05:38:18 --> Config Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:38:18 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:38:18 --> URI Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Router Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Output Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Security Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Input Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:38:18 --> Language Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Loader Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:38:18 --> Controller Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:38:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:38:18 --> Model Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Model Class Initialized
DEBUG - 2017-08-24 05:38:18 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:38:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:38:18 --> Final output sent to browser
DEBUG - 2017-08-24 05:38:18 --> Total execution time: 0.0374
DEBUG - 2017-08-24 05:38:32 --> Config Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:38:32 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:38:32 --> URI Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Router Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Output Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Security Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Input Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:38:32 --> Language Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Loader Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:38:32 --> Controller Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:38:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:38:32 --> Model Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Model Class Initialized
DEBUG - 2017-08-24 05:38:32 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:38:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:38:32 --> Final output sent to browser
DEBUG - 2017-08-24 05:38:32 --> Total execution time: 0.0364
DEBUG - 2017-08-24 05:40:20 --> Config Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:40:20 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:40:20 --> URI Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Router Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Output Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Security Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Input Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:40:20 --> Language Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Loader Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:40:20 --> Controller Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:40:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:40:20 --> Model Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Model Class Initialized
DEBUG - 2017-08-24 05:40:20 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:40:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:40:20 --> Final output sent to browser
DEBUG - 2017-08-24 05:40:20 --> Total execution time: 0.0357
DEBUG - 2017-08-24 05:41:02 --> Config Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:41:02 --> URI Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Router Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Output Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Security Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Input Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:41:02 --> Language Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Loader Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:41:02 --> Controller Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:41:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:41:02 --> Model Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Model Class Initialized
DEBUG - 2017-08-24 05:41:02 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:41:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:41:02 --> Final output sent to browser
DEBUG - 2017-08-24 05:41:02 --> Total execution time: 0.0366
DEBUG - 2017-08-24 05:43:57 --> Config Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:43:57 --> URI Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Router Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Output Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Security Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Input Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:43:57 --> Language Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Loader Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:43:57 --> Controller Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:43:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:43:57 --> Model Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Model Class Initialized
DEBUG - 2017-08-24 05:43:57 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:43:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:43:57 --> Final output sent to browser
DEBUG - 2017-08-24 05:43:57 --> Total execution time: 0.0363
DEBUG - 2017-08-24 05:44:01 --> Config Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:44:01 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:44:01 --> URI Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Router Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Output Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Security Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Input Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:44:01 --> Language Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Loader Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:44:01 --> Controller Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:44:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:44:01 --> Model Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Model Class Initialized
DEBUG - 2017-08-24 05:44:01 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:44:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:44:01 --> Final output sent to browser
DEBUG - 2017-08-24 05:44:01 --> Total execution time: 0.0358
DEBUG - 2017-08-24 05:44:10 --> Config Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:44:10 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:44:10 --> URI Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Router Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Output Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Security Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Input Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:44:10 --> Language Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Loader Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:44:10 --> Controller Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:44:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:44:10 --> Model Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Model Class Initialized
DEBUG - 2017-08-24 05:44:10 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:44:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:44:10 --> Final output sent to browser
DEBUG - 2017-08-24 05:44:10 --> Total execution time: 0.0371
DEBUG - 2017-08-24 05:45:38 --> Config Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:45:38 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:45:38 --> URI Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Router Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Output Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Security Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Input Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:45:38 --> Language Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Loader Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:45:38 --> Controller Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:45:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:45:38 --> Model Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Model Class Initialized
DEBUG - 2017-08-24 05:45:38 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:45:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:45:38 --> Final output sent to browser
DEBUG - 2017-08-24 05:45:38 --> Total execution time: 0.0370
DEBUG - 2017-08-24 05:45:43 --> Config Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:45:43 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:45:43 --> URI Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Router Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Output Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Security Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Input Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:45:43 --> Language Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Loader Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:45:43 --> Controller Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:45:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:45:43 --> Model Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Model Class Initialized
DEBUG - 2017-08-24 05:45:43 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:45:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:45:43 --> Final output sent to browser
DEBUG - 2017-08-24 05:45:43 --> Total execution time: 0.0367
DEBUG - 2017-08-24 05:48:36 --> Config Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Hooks Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Utf8 Class Initialized
DEBUG - 2017-08-24 05:48:36 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 05:48:36 --> URI Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Router Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Output Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Security Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Input Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 05:48:36 --> Language Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Loader Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Helper loaded: date_helper
DEBUG - 2017-08-24 05:48:36 --> Controller Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Database Driver Class Initialized
ERROR - 2017-08-24 05:48:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 05:48:36 --> Model Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Model Class Initialized
DEBUG - 2017-08-24 05:48:36 --> Helper loaded: url_helper
DEBUG - 2017-08-24 05:48:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 05:48:36 --> Final output sent to browser
DEBUG - 2017-08-24 05:48:36 --> Total execution time: 0.0371
DEBUG - 2017-08-24 06:41:43 --> Config Class Initialized
DEBUG - 2017-08-24 06:41:43 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:41:43 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:41:43 --> URI Class Initialized
DEBUG - 2017-08-24 06:41:43 --> Router Class Initialized
DEBUG - 2017-08-24 06:41:43 --> Output Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Security Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Input Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:41:44 --> Language Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Loader Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:41:44 --> Controller Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:41:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:41:44 --> Model Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Model Class Initialized
DEBUG - 2017-08-24 06:41:44 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:41:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:41:44 --> Final output sent to browser
DEBUG - 2017-08-24 06:41:44 --> Total execution time: 0.0537
DEBUG - 2017-08-24 06:45:51 --> Config Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:45:51 --> URI Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Router Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Output Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Security Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Input Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:45:51 --> Language Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Loader Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:45:51 --> Controller Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:45:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:45:51 --> Model Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Model Class Initialized
DEBUG - 2017-08-24 06:45:51 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:45:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:45:51 --> Final output sent to browser
DEBUG - 2017-08-24 06:45:51 --> Total execution time: 0.0368
DEBUG - 2017-08-24 06:45:58 --> Config Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:45:58 --> URI Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Router Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Output Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Security Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Input Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:45:58 --> Language Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Loader Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:45:58 --> Controller Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:45:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:45:58 --> Model Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Model Class Initialized
DEBUG - 2017-08-24 06:45:58 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:45:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:45:58 --> Final output sent to browser
DEBUG - 2017-08-24 06:45:58 --> Total execution time: 0.0375
DEBUG - 2017-08-24 06:51:56 --> Config Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:51:56 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:51:56 --> URI Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Router Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Output Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Security Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Input Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:51:56 --> Language Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Loader Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:51:56 --> Controller Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:51:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:51:56 --> Model Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Model Class Initialized
DEBUG - 2017-08-24 06:51:56 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:51:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:51:56 --> Final output sent to browser
DEBUG - 2017-08-24 06:51:56 --> Total execution time: 0.0361
DEBUG - 2017-08-24 06:52:08 --> Config Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:52:08 --> URI Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Router Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Output Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Security Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Input Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:52:08 --> Language Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Loader Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:52:08 --> Controller Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:52:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:52:08 --> Model Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Model Class Initialized
DEBUG - 2017-08-24 06:52:08 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:52:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:52:08 --> Final output sent to browser
DEBUG - 2017-08-24 06:52:08 --> Total execution time: 0.0357
DEBUG - 2017-08-24 06:54:52 --> Config Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:54:52 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:54:52 --> URI Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Router Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Output Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Security Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Input Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:54:52 --> Language Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Loader Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:54:52 --> Controller Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:54:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:54:52 --> Model Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Model Class Initialized
DEBUG - 2017-08-24 06:54:52 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:54:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:54:52 --> Final output sent to browser
DEBUG - 2017-08-24 06:54:52 --> Total execution time: 0.0366
DEBUG - 2017-08-24 06:57:41 --> Config Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:57:41 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:57:41 --> URI Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Router Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Output Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Security Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Input Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:57:41 --> Language Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Loader Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:57:41 --> Controller Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:57:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2017-08-24 06:57:41 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:57:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:57:41 --> Final output sent to browser
DEBUG - 2017-08-24 06:57:41 --> Total execution time: 0.0368
DEBUG - 2017-08-24 06:58:11 --> Config Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Hooks Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Utf8 Class Initialized
DEBUG - 2017-08-24 06:58:11 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 06:58:11 --> URI Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Router Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Output Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Security Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Input Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 06:58:11 --> Language Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Loader Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Helper loaded: date_helper
DEBUG - 2017-08-24 06:58:11 --> Controller Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Database Driver Class Initialized
ERROR - 2017-08-24 06:58:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 06:58:11 --> Model Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Model Class Initialized
DEBUG - 2017-08-24 06:58:11 --> Helper loaded: url_helper
DEBUG - 2017-08-24 06:58:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 06:58:11 --> Final output sent to browser
DEBUG - 2017-08-24 06:58:11 --> Total execution time: 0.0373
DEBUG - 2017-08-24 07:04:26 --> Config Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:04:26 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:04:26 --> URI Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Router Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Output Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Security Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Input Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:04:26 --> Language Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Loader Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:04:26 --> Controller Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:04:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:04:26 --> Model Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Model Class Initialized
DEBUG - 2017-08-24 07:04:26 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:04:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:04:26 --> Final output sent to browser
DEBUG - 2017-08-24 07:04:26 --> Total execution time: 0.0383
DEBUG - 2017-08-24 07:04:32 --> Config Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:04:32 --> URI Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Router Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Output Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Security Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Input Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:04:32 --> Language Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Loader Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:04:32 --> Controller Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:04:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:04:32 --> Model Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Model Class Initialized
DEBUG - 2017-08-24 07:04:32 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:04:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:04:32 --> Final output sent to browser
DEBUG - 2017-08-24 07:04:32 --> Total execution time: 0.0386
DEBUG - 2017-08-24 07:04:38 --> Config Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:04:38 --> URI Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Router Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Output Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Security Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Input Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:04:38 --> Language Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Loader Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:04:38 --> Controller Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:04:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:04:38 --> Model Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Model Class Initialized
DEBUG - 2017-08-24 07:04:38 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:04:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:04:38 --> Final output sent to browser
DEBUG - 2017-08-24 07:04:38 --> Total execution time: 0.0384
DEBUG - 2017-08-24 07:54:11 --> Config Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:54:11 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:54:11 --> URI Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Router Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Output Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Security Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Input Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:54:11 --> Language Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Loader Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:54:11 --> Controller Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:54:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:54:11 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:11 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:54:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:54:11 --> Final output sent to browser
DEBUG - 2017-08-24 07:54:11 --> Total execution time: 0.0462
DEBUG - 2017-08-24 07:54:17 --> Config Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:54:17 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:54:17 --> URI Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Router Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Output Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Security Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Input Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:54:17 --> Language Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Loader Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:54:17 --> Controller Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:54:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:54:17 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:17 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:54:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:54:17 --> Final output sent to browser
DEBUG - 2017-08-24 07:54:17 --> Total execution time: 0.0366
DEBUG - 2017-08-24 07:54:22 --> Config Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:54:22 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:54:22 --> URI Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Router Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Output Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Security Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Input Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:54:22 --> Language Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Loader Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:54:22 --> Controller Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:54:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:54:22 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:22 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:54:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:54:22 --> Final output sent to browser
DEBUG - 2017-08-24 07:54:22 --> Total execution time: 0.0367
DEBUG - 2017-08-24 07:54:28 --> Config Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:54:28 --> URI Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Router Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Output Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Security Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Input Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:54:28 --> Language Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Loader Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:54:28 --> Controller Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:54:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:54:28 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Model Class Initialized
DEBUG - 2017-08-24 07:54:28 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:54:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:54:28 --> Final output sent to browser
DEBUG - 2017-08-24 07:54:28 --> Total execution time: 0.0368
DEBUG - 2017-08-24 07:55:02 --> Config Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Hooks Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Utf8 Class Initialized
DEBUG - 2017-08-24 07:55:02 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 07:55:02 --> URI Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Router Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Output Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Security Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Input Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 07:55:02 --> Language Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Loader Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Helper loaded: date_helper
DEBUG - 2017-08-24 07:55:02 --> Controller Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Database Driver Class Initialized
ERROR - 2017-08-24 07:55:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 07:55:02 --> Model Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Model Class Initialized
DEBUG - 2017-08-24 07:55:02 --> Helper loaded: url_helper
DEBUG - 2017-08-24 07:55:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 07:55:02 --> Final output sent to browser
DEBUG - 2017-08-24 07:55:02 --> Total execution time: 0.0385
DEBUG - 2017-08-24 08:42:10 --> Config Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Hooks Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Utf8 Class Initialized
DEBUG - 2017-08-24 08:42:10 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 08:42:10 --> URI Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Router Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Output Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Security Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Input Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 08:42:10 --> Language Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Loader Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Helper loaded: date_helper
DEBUG - 2017-08-24 08:42:10 --> Controller Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Database Driver Class Initialized
ERROR - 2017-08-24 08:42:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 08:42:10 --> Model Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Model Class Initialized
DEBUG - 2017-08-24 08:42:10 --> Helper loaded: url_helper
DEBUG - 2017-08-24 08:42:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 08:42:10 --> Final output sent to browser
DEBUG - 2017-08-24 08:42:10 --> Total execution time: 0.0416
DEBUG - 2017-08-24 08:42:19 --> Config Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Hooks Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Utf8 Class Initialized
DEBUG - 2017-08-24 08:42:19 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 08:42:19 --> URI Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Router Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Output Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Security Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Input Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 08:42:19 --> Language Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Loader Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Helper loaded: date_helper
DEBUG - 2017-08-24 08:42:19 --> Controller Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Database Driver Class Initialized
ERROR - 2017-08-24 08:42:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 08:42:19 --> Model Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Model Class Initialized
DEBUG - 2017-08-24 08:42:19 --> Helper loaded: url_helper
DEBUG - 2017-08-24 08:42:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 08:42:19 --> Final output sent to browser
DEBUG - 2017-08-24 08:42:19 --> Total execution time: 0.0372
DEBUG - 2017-08-24 09:34:20 --> Config Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:34:20 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:34:20 --> URI Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Router Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Output Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Security Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Input Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:34:20 --> Language Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Loader Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:34:20 --> Controller Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:34:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:34:20 --> Model Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Model Class Initialized
DEBUG - 2017-08-24 09:34:20 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:34:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:34:20 --> Final output sent to browser
DEBUG - 2017-08-24 09:34:20 --> Total execution time: 0.0442
DEBUG - 2017-08-24 09:35:39 --> Config Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:35:39 --> URI Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Router Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Output Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Security Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Input Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:35:39 --> Language Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Loader Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:35:39 --> Controller Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:35:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:35:39 --> Model Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Model Class Initialized
DEBUG - 2017-08-24 09:35:39 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:35:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:35:39 --> Final output sent to browser
DEBUG - 2017-08-24 09:35:39 --> Total execution time: 0.0375
DEBUG - 2017-08-24 09:37:49 --> Config Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:37:49 --> URI Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Router Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Output Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Security Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Input Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:37:49 --> Language Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Loader Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:37:49 --> Controller Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:37:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:37:49 --> Model Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Model Class Initialized
DEBUG - 2017-08-24 09:37:49 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:37:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:37:49 --> Final output sent to browser
DEBUG - 2017-08-24 09:37:49 --> Total execution time: 0.0393
DEBUG - 2017-08-24 09:37:54 --> Config Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:37:54 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:37:54 --> URI Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Router Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Output Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Security Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Input Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:37:54 --> Language Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Loader Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:37:54 --> Controller Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:37:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:37:54 --> Model Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Model Class Initialized
DEBUG - 2017-08-24 09:37:54 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:37:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:37:55 --> Final output sent to browser
DEBUG - 2017-08-24 09:37:55 --> Total execution time: 0.0389
DEBUG - 2017-08-24 09:38:42 --> Config Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:38:42 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:38:42 --> URI Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Router Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Output Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Security Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Input Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:38:42 --> Language Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Loader Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:38:42 --> Controller Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:38:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:38:42 --> Model Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Model Class Initialized
DEBUG - 2017-08-24 09:38:42 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:38:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:38:42 --> Final output sent to browser
DEBUG - 2017-08-24 09:38:42 --> Total execution time: 0.0408
DEBUG - 2017-08-24 09:39:11 --> Config Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:39:11 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:39:11 --> URI Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Router Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Output Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Security Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Input Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:39:11 --> Language Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Loader Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:39:11 --> Controller Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:39:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:39:11 --> Model Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Model Class Initialized
DEBUG - 2017-08-24 09:39:11 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:39:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:39:11 --> Final output sent to browser
DEBUG - 2017-08-24 09:39:11 --> Total execution time: 0.0372
DEBUG - 2017-08-24 09:39:13 --> Config Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:39:13 --> URI Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Router Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Output Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Security Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Input Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:39:13 --> Language Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Loader Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:39:13 --> Controller Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:39:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:39:13 --> Model Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Model Class Initialized
DEBUG - 2017-08-24 09:39:13 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:39:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:39:13 --> Final output sent to browser
DEBUG - 2017-08-24 09:39:13 --> Total execution time: 0.0365
DEBUG - 2017-08-24 09:42:24 --> Config Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:42:24 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:42:24 --> URI Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Router Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Output Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Security Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Input Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:42:24 --> Language Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Loader Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:42:24 --> Controller Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:42:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:42:24 --> Model Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Model Class Initialized
DEBUG - 2017-08-24 09:42:24 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:42:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:42:25 --> Final output sent to browser
DEBUG - 2017-08-24 09:42:25 --> Total execution time: 0.0369
DEBUG - 2017-08-24 09:42:59 --> Config Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:42:59 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:42:59 --> URI Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Router Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Output Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Security Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Input Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:42:59 --> Language Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Loader Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:42:59 --> Controller Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:42:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:42:59 --> Model Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Model Class Initialized
DEBUG - 2017-08-24 09:42:59 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:42:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:42:59 --> Final output sent to browser
DEBUG - 2017-08-24 09:42:59 --> Total execution time: 0.0375
DEBUG - 2017-08-24 09:47:09 --> Config Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:47:09 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:47:09 --> URI Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Router Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Output Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Security Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Input Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:47:09 --> Language Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Loader Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:47:09 --> Controller Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:47:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:47:09 --> Model Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Model Class Initialized
DEBUG - 2017-08-24 09:47:09 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:47:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:47:09 --> Final output sent to browser
DEBUG - 2017-08-24 09:47:09 --> Total execution time: 0.0369
DEBUG - 2017-08-24 09:50:42 --> Config Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:50:42 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:50:42 --> URI Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Router Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Output Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Security Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Input Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:50:42 --> Language Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Loader Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:50:42 --> Controller Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:50:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:50:42 --> Model Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Model Class Initialized
DEBUG - 2017-08-24 09:50:42 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:50:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:50:42 --> Final output sent to browser
DEBUG - 2017-08-24 09:50:42 --> Total execution time: 0.0380
DEBUG - 2017-08-24 09:51:56 --> Config Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:51:56 --> URI Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Router Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Output Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Security Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Input Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:51:56 --> Language Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Loader Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:51:56 --> Controller Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:51:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:51:56 --> Model Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Model Class Initialized
DEBUG - 2017-08-24 09:51:56 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:51:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:51:56 --> Final output sent to browser
DEBUG - 2017-08-24 09:51:56 --> Total execution time: 0.0369
DEBUG - 2017-08-24 09:58:49 --> Config Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Hooks Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Utf8 Class Initialized
DEBUG - 2017-08-24 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 09:58:49 --> URI Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Router Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Output Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Security Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Input Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 09:58:49 --> Language Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Loader Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Helper loaded: date_helper
DEBUG - 2017-08-24 09:58:49 --> Controller Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Database Driver Class Initialized
ERROR - 2017-08-24 09:58:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 09:58:49 --> Model Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Model Class Initialized
DEBUG - 2017-08-24 09:58:49 --> Helper loaded: url_helper
DEBUG - 2017-08-24 09:58:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 09:58:49 --> Final output sent to browser
DEBUG - 2017-08-24 09:58:49 --> Total execution time: 0.0362
DEBUG - 2017-08-24 10:02:03 --> Config Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Hooks Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Utf8 Class Initialized
DEBUG - 2017-08-24 10:02:03 --> UTF-8 Support Enabled
DEBUG - 2017-08-24 10:02:03 --> URI Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Router Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Output Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Security Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Input Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-24 10:02:03 --> Language Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Loader Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Helper loaded: date_helper
DEBUG - 2017-08-24 10:02:03 --> Controller Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Database Driver Class Initialized
ERROR - 2017-08-24 10:02:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-24 10:02:03 --> Model Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Model Class Initialized
DEBUG - 2017-08-24 10:02:03 --> Helper loaded: url_helper
DEBUG - 2017-08-24 10:02:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-24 10:02:03 --> Final output sent to browser
DEBUG - 2017-08-24 10:02:03 --> Total execution time: 0.0376
