<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-08-04 04:17:55 --> Config Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Hooks Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Utf8 Class Initialized
DEBUG - 2019-08-04 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-08-04 04:17:55 --> URI Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Router Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Output Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Security Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Input Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-04 04:17:55 --> Language Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Loader Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Helper loaded: date_helper
DEBUG - 2019-08-04 04:17:55 --> Controller Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Database Driver Class Initialized
ERROR - 2019-08-04 04:17:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-04 04:17:55 --> Model Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Model Class Initialized
DEBUG - 2019-08-04 04:17:55 --> Helper loaded: url_helper
DEBUG - 2019-08-04 04:17:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-04 04:17:55 --> Final output sent to browser
DEBUG - 2019-08-04 04:17:55 --> Total execution time: 0.0380
DEBUG - 2019-08-04 11:03:59 --> Config Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Hooks Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Utf8 Class Initialized
DEBUG - 2019-08-04 11:03:59 --> UTF-8 Support Enabled
DEBUG - 2019-08-04 11:03:59 --> URI Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Router Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Output Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Security Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Input Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-04 11:03:59 --> Language Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Loader Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Helper loaded: date_helper
DEBUG - 2019-08-04 11:03:59 --> Controller Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Database Driver Class Initialized
ERROR - 2019-08-04 11:03:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-04 11:03:59 --> Model Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Model Class Initialized
DEBUG - 2019-08-04 11:03:59 --> Helper loaded: url_helper
DEBUG - 2019-08-04 11:03:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-04 11:03:59 --> Final output sent to browser
DEBUG - 2019-08-04 11:03:59 --> Total execution time: 0.0539
DEBUG - 2019-08-04 18:58:56 --> Config Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Hooks Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Utf8 Class Initialized
DEBUG - 2019-08-04 18:58:56 --> UTF-8 Support Enabled
DEBUG - 2019-08-04 18:58:56 --> URI Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Router Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Output Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Security Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Input Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-04 18:58:56 --> Language Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Loader Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Helper loaded: date_helper
DEBUG - 2019-08-04 18:58:56 --> Controller Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Database Driver Class Initialized
ERROR - 2019-08-04 18:58:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-04 18:58:56 --> Model Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Model Class Initialized
DEBUG - 2019-08-04 18:58:56 --> Helper loaded: url_helper
DEBUG - 2019-08-04 18:58:56 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2019-08-04 18:58:56 --> Final output sent to browser
DEBUG - 2019-08-04 18:58:56 --> Total execution time: 0.0290
