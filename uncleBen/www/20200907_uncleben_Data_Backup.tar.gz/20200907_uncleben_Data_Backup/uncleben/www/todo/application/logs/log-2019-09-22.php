<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-09-22 04:48:53 --> Config Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Hooks Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Utf8 Class Initialized
DEBUG - 2019-09-22 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-22 04:48:53 --> URI Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Router Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Output Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Security Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Input Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-22 04:48:53 --> Language Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Loader Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Helper loaded: date_helper
DEBUG - 2019-09-22 04:48:53 --> Controller Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Database Driver Class Initialized
ERROR - 2019-09-22 04:48:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-22 04:48:53 --> Model Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Model Class Initialized
DEBUG - 2019-09-22 04:48:53 --> Helper loaded: url_helper
DEBUG - 2019-09-22 04:48:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-22 04:48:53 --> Final output sent to browser
DEBUG - 2019-09-22 04:48:53 --> Total execution time: 0.0424
DEBUG - 2019-09-22 11:14:15 --> Config Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Hooks Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Utf8 Class Initialized
DEBUG - 2019-09-22 11:14:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-22 11:14:15 --> URI Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Router Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Output Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Security Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Input Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-22 11:14:15 --> Language Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Loader Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Helper loaded: date_helper
DEBUG - 2019-09-22 11:14:15 --> Controller Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Database Driver Class Initialized
ERROR - 2019-09-22 11:14:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-22 11:14:15 --> Model Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Model Class Initialized
DEBUG - 2019-09-22 11:14:15 --> Helper loaded: url_helper
DEBUG - 2019-09-22 11:14:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-22 11:14:15 --> Final output sent to browser
DEBUG - 2019-09-22 11:14:15 --> Total execution time: 0.0402
DEBUG - 2019-09-22 11:53:05 --> Config Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Hooks Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Utf8 Class Initialized
DEBUG - 2019-09-22 11:53:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-22 11:53:05 --> URI Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Router Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Output Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Security Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Input Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-22 11:53:05 --> Language Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Loader Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Helper loaded: date_helper
DEBUG - 2019-09-22 11:53:05 --> Controller Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Database Driver Class Initialized
ERROR - 2019-09-22 11:53:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-22 11:53:05 --> Model Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Model Class Initialized
DEBUG - 2019-09-22 11:53:05 --> Helper loaded: url_helper
DEBUG - 2019-09-22 11:53:05 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2019-09-22 11:53:05 --> Final output sent to browser
DEBUG - 2019-09-22 11:53:05 --> Total execution time: 0.0371
