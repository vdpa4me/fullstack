<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-12-22 05:33:38 --> Config Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Hooks Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Utf8 Class Initialized
DEBUG - 2019-12-22 05:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-12-22 05:33:38 --> URI Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Router Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Output Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Security Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Input Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-22 05:33:38 --> Language Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Loader Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Helper loaded: date_helper
DEBUG - 2019-12-22 05:33:38 --> Controller Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Database Driver Class Initialized
ERROR - 2019-12-22 05:33:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-22 05:33:38 --> Model Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Model Class Initialized
DEBUG - 2019-12-22 05:33:38 --> Helper loaded: url_helper
DEBUG - 2019-12-22 05:33:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-22 05:33:38 --> Final output sent to browser
DEBUG - 2019-12-22 05:33:38 --> Total execution time: 0.1920
DEBUG - 2019-12-22 07:28:09 --> Config Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Hooks Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Utf8 Class Initialized
DEBUG - 2019-12-22 07:28:09 --> UTF-8 Support Enabled
DEBUG - 2019-12-22 07:28:09 --> URI Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Router Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Output Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Security Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Input Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-22 07:28:09 --> Language Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Loader Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Helper loaded: date_helper
DEBUG - 2019-12-22 07:28:09 --> Controller Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Database Driver Class Initialized
ERROR - 2019-12-22 07:28:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-22 07:28:09 --> Model Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Model Class Initialized
DEBUG - 2019-12-22 07:28:09 --> Helper loaded: url_helper
DEBUG - 2019-12-22 07:28:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-22 07:28:09 --> Final output sent to browser
DEBUG - 2019-12-22 07:28:09 --> Total execution time: 0.1048
DEBUG - 2019-12-22 11:28:02 --> Config Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Hooks Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Utf8 Class Initialized
DEBUG - 2019-12-22 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2019-12-22 11:28:02 --> URI Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Router Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Output Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Security Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Input Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-22 11:28:02 --> Language Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Loader Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Helper loaded: date_helper
DEBUG - 2019-12-22 11:28:02 --> Controller Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Database Driver Class Initialized
ERROR - 2019-12-22 11:28:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-22 11:28:02 --> Model Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Model Class Initialized
DEBUG - 2019-12-22 11:28:02 --> Helper loaded: url_helper
DEBUG - 2019-12-22 11:28:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-22 11:28:02 --> Final output sent to browser
DEBUG - 2019-12-22 11:28:02 --> Total execution time: 0.1041
