<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-12-10 13:15:29 --> Config Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Hooks Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Utf8 Class Initialized
DEBUG - 2019-12-10 13:15:29 --> UTF-8 Support Enabled
DEBUG - 2019-12-10 13:15:29 --> URI Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Router Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Output Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Security Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Input Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-10 13:15:29 --> Language Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Loader Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Helper loaded: date_helper
DEBUG - 2019-12-10 13:15:29 --> Controller Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Database Driver Class Initialized
ERROR - 2019-12-10 13:15:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-10 13:15:29 --> Model Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Model Class Initialized
DEBUG - 2019-12-10 13:15:29 --> Helper loaded: url_helper
DEBUG - 2019-12-10 13:15:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-10 13:15:29 --> Final output sent to browser
DEBUG - 2019-12-10 13:15:29 --> Total execution time: 0.1944
DEBUG - 2019-12-10 16:52:32 --> Config Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Hooks Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Utf8 Class Initialized
DEBUG - 2019-12-10 16:52:32 --> UTF-8 Support Enabled
DEBUG - 2019-12-10 16:52:32 --> URI Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Router Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Output Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Security Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Input Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-10 16:52:32 --> Language Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Loader Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Helper loaded: date_helper
DEBUG - 2019-12-10 16:52:32 --> Controller Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Database Driver Class Initialized
ERROR - 2019-12-10 16:52:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-10 16:52:32 --> Model Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Model Class Initialized
DEBUG - 2019-12-10 16:52:32 --> Helper loaded: url_helper
DEBUG - 2019-12-10 16:52:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-10 16:52:32 --> Final output sent to browser
DEBUG - 2019-12-10 16:52:32 --> Total execution time: 0.1842
DEBUG - 2019-12-10 17:13:33 --> Config Class Initialized
DEBUG - 2019-12-10 17:13:33 --> Hooks Class Initialized
DEBUG - 2019-12-10 17:13:33 --> Utf8 Class Initialized
DEBUG - 2019-12-10 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2019-12-10 17:13:34 --> URI Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Router Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Output Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Security Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Input Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-10 17:13:34 --> Language Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Loader Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Helper loaded: date_helper
DEBUG - 2019-12-10 17:13:34 --> Controller Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Database Driver Class Initialized
ERROR - 2019-12-10 17:13:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-10 17:13:34 --> Model Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Model Class Initialized
DEBUG - 2019-12-10 17:13:34 --> Helper loaded: url_helper
DEBUG - 2019-12-10 17:13:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-10 17:13:34 --> Final output sent to browser
DEBUG - 2019-12-10 17:13:34 --> Total execution time: 0.1076
DEBUG - 2019-12-10 18:40:47 --> Config Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Hooks Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Utf8 Class Initialized
DEBUG - 2019-12-10 18:40:47 --> UTF-8 Support Enabled
DEBUG - 2019-12-10 18:40:47 --> URI Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Router Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Output Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Security Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Input Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-12-10 18:40:47 --> Language Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Loader Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Helper loaded: date_helper
DEBUG - 2019-12-10 18:40:47 --> Controller Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Database Driver Class Initialized
ERROR - 2019-12-10 18:40:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-12-10 18:40:47 --> Model Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Model Class Initialized
DEBUG - 2019-12-10 18:40:47 --> Helper loaded: url_helper
DEBUG - 2019-12-10 18:40:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-12-10 18:40:47 --> Final output sent to browser
DEBUG - 2019-12-10 18:40:47 --> Total execution time: 0.1162
