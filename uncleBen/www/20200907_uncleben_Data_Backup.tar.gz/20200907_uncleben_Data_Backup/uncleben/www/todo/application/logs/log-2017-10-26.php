<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-26 04:27:51 --> Config Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Hooks Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Utf8 Class Initialized
DEBUG - 2017-10-26 04:27:51 --> UTF-8 Support Enabled
DEBUG - 2017-10-26 04:27:51 --> URI Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Router Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Output Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Security Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Input Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-26 04:27:51 --> Language Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Loader Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Helper loaded: date_helper
DEBUG - 2017-10-26 04:27:51 --> Controller Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Database Driver Class Initialized
ERROR - 2017-10-26 04:27:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-26 04:27:51 --> Model Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Model Class Initialized
DEBUG - 2017-10-26 04:27:51 --> Helper loaded: url_helper
DEBUG - 2017-10-26 04:27:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-26 04:27:51 --> Final output sent to browser
DEBUG - 2017-10-26 04:27:51 --> Total execution time: 0.0241
DEBUG - 2017-10-26 10:14:06 --> Config Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Hooks Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Utf8 Class Initialized
DEBUG - 2017-10-26 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2017-10-26 10:14:06 --> URI Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Router Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Output Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Security Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Input Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-26 10:14:06 --> Language Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Loader Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Helper loaded: date_helper
DEBUG - 2017-10-26 10:14:06 --> Controller Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Database Driver Class Initialized
ERROR - 2017-10-26 10:14:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-26 10:14:06 --> Model Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Model Class Initialized
DEBUG - 2017-10-26 10:14:06 --> Helper loaded: url_helper
DEBUG - 2017-10-26 10:14:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-26 10:14:07 --> Final output sent to browser
DEBUG - 2017-10-26 10:14:07 --> Total execution time: 0.0328
DEBUG - 2017-10-26 16:28:08 --> Config Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Hooks Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Utf8 Class Initialized
DEBUG - 2017-10-26 16:28:08 --> UTF-8 Support Enabled
DEBUG - 2017-10-26 16:28:08 --> URI Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Router Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Output Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Security Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Input Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-26 16:28:08 --> Language Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Loader Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Helper loaded: date_helper
DEBUG - 2017-10-26 16:28:08 --> Controller Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Database Driver Class Initialized
ERROR - 2017-10-26 16:28:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-26 16:28:08 --> Model Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Model Class Initialized
DEBUG - 2017-10-26 16:28:08 --> Helper loaded: url_helper
DEBUG - 2017-10-26 16:28:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-26 16:28:08 --> Final output sent to browser
DEBUG - 2017-10-26 16:28:08 --> Total execution time: 0.0377
