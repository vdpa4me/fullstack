<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-11 00:58:11 --> Config Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Hooks Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Utf8 Class Initialized
DEBUG - 2017-11-11 00:58:11 --> UTF-8 Support Enabled
DEBUG - 2017-11-11 00:58:11 --> URI Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Router Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Output Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Security Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Input Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-11 00:58:11 --> Language Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Loader Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Helper loaded: date_helper
DEBUG - 2017-11-11 00:58:11 --> Controller Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Database Driver Class Initialized
ERROR - 2017-11-11 00:58:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-11 00:58:11 --> Model Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Model Class Initialized
DEBUG - 2017-11-11 00:58:11 --> Helper loaded: url_helper
DEBUG - 2017-11-11 00:58:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-11 00:58:11 --> Final output sent to browser
DEBUG - 2017-11-11 00:58:11 --> Total execution time: 0.0214
DEBUG - 2017-11-11 02:55:08 --> Config Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Hooks Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Utf8 Class Initialized
DEBUG - 2017-11-11 02:55:08 --> UTF-8 Support Enabled
DEBUG - 2017-11-11 02:55:08 --> URI Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Router Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Output Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Security Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Input Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-11 02:55:08 --> Language Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Loader Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Helper loaded: date_helper
DEBUG - 2017-11-11 02:55:08 --> Controller Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Database Driver Class Initialized
ERROR - 2017-11-11 02:55:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-11 02:55:08 --> Model Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Model Class Initialized
DEBUG - 2017-11-11 02:55:08 --> Helper loaded: url_helper
DEBUG - 2017-11-11 02:55:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-11 02:55:08 --> Final output sent to browser
DEBUG - 2017-11-11 02:55:08 --> Total execution time: 0.0220
DEBUG - 2017-11-11 10:49:34 --> Config Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Hooks Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Utf8 Class Initialized
DEBUG - 2017-11-11 10:49:34 --> UTF-8 Support Enabled
DEBUG - 2017-11-11 10:49:34 --> URI Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Router Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Output Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Security Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Input Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-11 10:49:34 --> Language Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Loader Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Helper loaded: date_helper
DEBUG - 2017-11-11 10:49:34 --> Controller Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Database Driver Class Initialized
ERROR - 2017-11-11 10:49:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-11 10:49:34 --> Model Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Model Class Initialized
DEBUG - 2017-11-11 10:49:34 --> Helper loaded: url_helper
DEBUG - 2017-11-11 10:49:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-11 10:49:34 --> Final output sent to browser
DEBUG - 2017-11-11 10:49:34 --> Total execution time: 0.0321
DEBUG - 2017-11-11 16:07:22 --> Config Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Hooks Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Utf8 Class Initialized
DEBUG - 2017-11-11 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2017-11-11 16:07:22 --> URI Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Router Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Output Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Security Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Input Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-11 16:07:22 --> Language Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Loader Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Helper loaded: date_helper
DEBUG - 2017-11-11 16:07:22 --> Controller Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Database Driver Class Initialized
ERROR - 2017-11-11 16:07:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-11 16:07:22 --> Model Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Model Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Helper loaded: url_helper
DEBUG - 2017-11-11 16:07:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-11 16:07:22 --> Final output sent to browser
DEBUG - 2017-11-11 16:07:22 --> Total execution time: 0.0377
DEBUG - 2017-11-11 16:07:22 --> Config Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Hooks Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Utf8 Class Initialized
DEBUG - 2017-11-11 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2017-11-11 16:07:22 --> URI Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Router Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Output Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Security Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Input Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-11 16:07:22 --> Language Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Loader Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Helper loaded: date_helper
DEBUG - 2017-11-11 16:07:22 --> Controller Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Database Driver Class Initialized
ERROR - 2017-11-11 16:07:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-11 16:07:22 --> Model Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Model Class Initialized
DEBUG - 2017-11-11 16:07:22 --> Helper loaded: url_helper
DEBUG - 2017-11-11 16:07:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-11 16:07:22 --> Final output sent to browser
DEBUG - 2017-11-11 16:07:22 --> Total execution time: 0.0198
