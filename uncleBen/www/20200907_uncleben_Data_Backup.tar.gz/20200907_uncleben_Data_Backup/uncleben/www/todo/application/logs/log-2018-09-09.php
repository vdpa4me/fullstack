<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-09-09 00:21:51 --> Config Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Hooks Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Utf8 Class Initialized
DEBUG - 2018-09-09 00:21:51 --> UTF-8 Support Enabled
DEBUG - 2018-09-09 00:21:51 --> URI Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Router Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Output Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Security Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Input Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-09 00:21:51 --> Language Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Loader Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Helper loaded: date_helper
DEBUG - 2018-09-09 00:21:51 --> Controller Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Database Driver Class Initialized
ERROR - 2018-09-09 00:21:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-09 00:21:51 --> Model Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Model Class Initialized
DEBUG - 2018-09-09 00:21:51 --> Helper loaded: url_helper
DEBUG - 2018-09-09 00:21:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-09 00:21:51 --> Final output sent to browser
DEBUG - 2018-09-09 00:21:51 --> Total execution time: 0.0330
DEBUG - 2018-09-09 00:55:20 --> Config Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Hooks Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Utf8 Class Initialized
DEBUG - 2018-09-09 00:55:20 --> UTF-8 Support Enabled
DEBUG - 2018-09-09 00:55:20 --> URI Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Router Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Output Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Security Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Input Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-09 00:55:20 --> Language Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Loader Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Helper loaded: date_helper
DEBUG - 2018-09-09 00:55:20 --> Controller Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Database Driver Class Initialized
ERROR - 2018-09-09 00:55:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-09 00:55:20 --> Model Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Model Class Initialized
DEBUG - 2018-09-09 00:55:20 --> Helper loaded: url_helper
DEBUG - 2018-09-09 00:55:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-09 00:55:20 --> Final output sent to browser
DEBUG - 2018-09-09 00:55:20 --> Total execution time: 0.0291
DEBUG - 2018-09-09 03:10:46 --> Config Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Hooks Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Utf8 Class Initialized
DEBUG - 2018-09-09 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2018-09-09 03:10:46 --> URI Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Router Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Output Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Security Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Input Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-09 03:10:46 --> Language Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Loader Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Helper loaded: date_helper
DEBUG - 2018-09-09 03:10:46 --> Controller Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Database Driver Class Initialized
ERROR - 2018-09-09 03:10:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-09 03:10:46 --> Model Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Model Class Initialized
DEBUG - 2018-09-09 03:10:46 --> Helper loaded: url_helper
DEBUG - 2018-09-09 03:10:46 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-09 03:10:46 --> Final output sent to browser
DEBUG - 2018-09-09 03:10:46 --> Total execution time: 0.0288
DEBUG - 2018-09-09 20:36:44 --> Config Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Hooks Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Utf8 Class Initialized
DEBUG - 2018-09-09 20:36:44 --> UTF-8 Support Enabled
DEBUG - 2018-09-09 20:36:44 --> URI Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Router Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Output Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Security Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Input Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-09 20:36:44 --> Language Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Loader Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Helper loaded: date_helper
DEBUG - 2018-09-09 20:36:44 --> Controller Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Database Driver Class Initialized
ERROR - 2018-09-09 20:36:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-09 20:36:44 --> Model Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Model Class Initialized
DEBUG - 2018-09-09 20:36:44 --> Helper loaded: url_helper
DEBUG - 2018-09-09 20:36:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-09 20:36:44 --> Final output sent to browser
DEBUG - 2018-09-09 20:36:44 --> Total execution time: 0.0622
