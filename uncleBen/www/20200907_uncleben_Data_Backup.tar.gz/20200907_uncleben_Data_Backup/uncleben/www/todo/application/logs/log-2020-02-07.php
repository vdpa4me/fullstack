<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-02-07 04:59:28 --> Config Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Hooks Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Utf8 Class Initialized
DEBUG - 2020-02-07 04:59:28 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 04:59:28 --> URI Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Router Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Output Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Security Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Input Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-07 04:59:28 --> Language Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Loader Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Helper loaded: date_helper
DEBUG - 2020-02-07 04:59:28 --> Controller Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Database Driver Class Initialized
ERROR - 2020-02-07 04:59:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-07 04:59:28 --> Model Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Model Class Initialized
DEBUG - 2020-02-07 04:59:28 --> Helper loaded: url_helper
DEBUG - 2020-02-07 04:59:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-07 04:59:28 --> Final output sent to browser
DEBUG - 2020-02-07 04:59:28 --> Total execution time: 0.2035
DEBUG - 2020-02-07 05:12:43 --> Config Class Initialized
DEBUG - 2020-02-07 05:12:43 --> Hooks Class Initialized
DEBUG - 2020-02-07 05:12:43 --> Utf8 Class Initialized
DEBUG - 2020-02-07 05:12:43 --> UTF-8 Support Enabled
DEBUG - 2020-02-07 05:12:43 --> URI Class Initialized
DEBUG - 2020-02-07 05:12:43 --> Router Class Initialized
DEBUG - 2020-02-07 05:12:43 --> Output Class Initialized
DEBUG - 2020-02-07 05:12:43 --> Security Class Initialized
DEBUG - 2020-02-07 05:12:44 --> Input Class Initialized
DEBUG - 2020-02-07 05:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-07 05:12:44 --> Language Class Initialized
DEBUG - 2020-02-07 05:12:44 --> Loader Class Initialized
DEBUG - 2020-02-07 05:12:44 --> Helper loaded: date_helper
DEBUG - 2020-02-07 05:12:44 --> Controller Class Initialized
DEBUG - 2020-02-07 05:12:44 --> Database Driver Class Initialized
ERROR - 2020-02-07 05:12:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-07 05:12:44 --> Model Class Initialized
DEBUG - 2020-02-07 05:12:44 --> Model Class Initialized
DEBUG - 2020-02-07 05:12:44 --> Helper loaded: url_helper
DEBUG - 2020-02-07 05:12:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-07 05:12:44 --> Final output sent to browser
DEBUG - 2020-02-07 05:12:44 --> Total execution time: 0.1187
