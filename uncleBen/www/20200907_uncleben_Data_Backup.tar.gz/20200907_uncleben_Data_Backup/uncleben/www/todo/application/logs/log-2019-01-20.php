<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-01-20 07:56:55 --> Config Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Hooks Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Utf8 Class Initialized
DEBUG - 2019-01-20 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-01-20 07:56:55 --> URI Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Router Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Output Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Security Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Input Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-20 07:56:55 --> Language Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Loader Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Helper loaded: date_helper
DEBUG - 2019-01-20 07:56:55 --> Controller Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Database Driver Class Initialized
ERROR - 2019-01-20 07:56:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-20 07:56:55 --> Model Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Model Class Initialized
DEBUG - 2019-01-20 07:56:55 --> Helper loaded: url_helper
DEBUG - 2019-01-20 07:56:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-20 07:56:55 --> Final output sent to browser
DEBUG - 2019-01-20 07:56:55 --> Total execution time: 0.0474
DEBUG - 2019-01-20 08:02:04 --> Config Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Hooks Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Utf8 Class Initialized
DEBUG - 2019-01-20 08:02:04 --> UTF-8 Support Enabled
DEBUG - 2019-01-20 08:02:04 --> URI Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Router Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Output Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Security Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Input Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-20 08:02:04 --> Language Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Loader Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Helper loaded: date_helper
DEBUG - 2019-01-20 08:02:04 --> Controller Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Database Driver Class Initialized
ERROR - 2019-01-20 08:02:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-20 08:02:04 --> Model Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Model Class Initialized
DEBUG - 2019-01-20 08:02:04 --> Helper loaded: url_helper
DEBUG - 2019-01-20 08:02:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-20 08:02:04 --> Final output sent to browser
DEBUG - 2019-01-20 08:02:04 --> Total execution time: 0.0212
DEBUG - 2019-01-20 14:12:14 --> Config Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Hooks Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Utf8 Class Initialized
DEBUG - 2019-01-20 14:12:14 --> UTF-8 Support Enabled
DEBUG - 2019-01-20 14:12:14 --> URI Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Router Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Output Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Security Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Input Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-20 14:12:14 --> Language Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Loader Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Helper loaded: date_helper
DEBUG - 2019-01-20 14:12:14 --> Controller Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Database Driver Class Initialized
ERROR - 2019-01-20 14:12:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-20 14:12:14 --> Model Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Model Class Initialized
DEBUG - 2019-01-20 14:12:14 --> Helper loaded: url_helper
DEBUG - 2019-01-20 14:12:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-20 14:12:14 --> Final output sent to browser
DEBUG - 2019-01-20 14:12:14 --> Total execution time: 0.0360
DEBUG - 2019-01-20 15:30:08 --> Config Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Hooks Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Utf8 Class Initialized
DEBUG - 2019-01-20 15:30:08 --> UTF-8 Support Enabled
DEBUG - 2019-01-20 15:30:08 --> URI Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Router Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Output Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Security Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Input Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-20 15:30:08 --> Language Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Loader Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Helper loaded: date_helper
DEBUG - 2019-01-20 15:30:08 --> Controller Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Database Driver Class Initialized
ERROR - 2019-01-20 15:30:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-20 15:30:08 --> Model Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Model Class Initialized
DEBUG - 2019-01-20 15:30:08 --> Helper loaded: url_helper
DEBUG - 2019-01-20 15:30:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-20 15:30:08 --> Final output sent to browser
DEBUG - 2019-01-20 15:30:08 --> Total execution time: 0.0215
