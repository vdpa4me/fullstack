<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-05-16 06:53:23 --> Config Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Hooks Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Utf8 Class Initialized
DEBUG - 2020-05-16 06:53:23 --> UTF-8 Support Enabled
DEBUG - 2020-05-16 06:53:23 --> URI Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Router Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Output Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Security Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Input Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2020-05-16 06:53:23 --> Language Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Loader Class Initialized
DEBUG - 2020-05-16 06:53:23 --> Helper loaded: date_helper
DEBUG - 2020-05-16 06:53:23 --> Controller Class Initialized
DEBUG - 2020-05-16 06:53:24 --> Database Driver Class Initialized
ERROR - 2020-05-16 06:53:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-05-16 06:53:24 --> Model Class Initialized
DEBUG - 2020-05-16 06:53:24 --> Model Class Initialized
DEBUG - 2020-05-16 06:53:24 --> Helper loaded: url_helper
DEBUG - 2020-05-16 06:53:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-05-16 06:53:24 --> Final output sent to browser
DEBUG - 2020-05-16 06:53:24 --> Total execution time: 0.1766
DEBUG - 2020-05-16 21:02:37 --> Config Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Hooks Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Utf8 Class Initialized
DEBUG - 2020-05-16 21:02:37 --> UTF-8 Support Enabled
DEBUG - 2020-05-16 21:02:37 --> URI Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Router Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Output Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Security Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Input Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2020-05-16 21:02:37 --> Language Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Loader Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Helper loaded: date_helper
DEBUG - 2020-05-16 21:02:37 --> Controller Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Database Driver Class Initialized
ERROR - 2020-05-16 21:02:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-05-16 21:02:37 --> Model Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Model Class Initialized
DEBUG - 2020-05-16 21:02:37 --> Helper loaded: url_helper
DEBUG - 2020-05-16 21:02:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-05-16 21:02:37 --> Final output sent to browser
DEBUG - 2020-05-16 21:02:37 --> Total execution time: 0.1723
