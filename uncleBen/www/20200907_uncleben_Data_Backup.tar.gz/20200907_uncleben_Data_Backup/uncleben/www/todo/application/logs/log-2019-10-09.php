<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-10-09 02:00:17 --> Config Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Hooks Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Utf8 Class Initialized
DEBUG - 2019-10-09 02:00:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 02:00:17 --> URI Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Router Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Output Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Security Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Input Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-09 02:00:17 --> Language Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Loader Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Helper loaded: date_helper
DEBUG - 2019-10-09 02:00:17 --> Controller Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Database Driver Class Initialized
ERROR - 2019-10-09 02:00:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-09 02:00:17 --> Model Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Model Class Initialized
DEBUG - 2019-10-09 02:00:17 --> Helper loaded: url_helper
DEBUG - 2019-10-09 02:00:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-09 02:00:17 --> Final output sent to browser
DEBUG - 2019-10-09 02:00:17 --> Total execution time: 0.2134
DEBUG - 2019-10-09 06:34:51 --> Config Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Hooks Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Utf8 Class Initialized
DEBUG - 2019-10-09 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 06:34:51 --> URI Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Router Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Output Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Security Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Input Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-09 06:34:51 --> Language Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Loader Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Helper loaded: date_helper
DEBUG - 2019-10-09 06:34:51 --> Controller Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Database Driver Class Initialized
ERROR - 2019-10-09 06:34:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-09 06:34:51 --> Model Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Model Class Initialized
DEBUG - 2019-10-09 06:34:51 --> Helper loaded: url_helper
DEBUG - 2019-10-09 06:34:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-09 06:34:51 --> Final output sent to browser
DEBUG - 2019-10-09 06:34:51 --> Total execution time: 0.1121
DEBUG - 2019-10-09 09:35:13 --> Config Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Hooks Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Utf8 Class Initialized
DEBUG - 2019-10-09 09:35:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 09:35:13 --> URI Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Router Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Output Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Security Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Input Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-09 09:35:13 --> Language Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Loader Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Helper loaded: date_helper
DEBUG - 2019-10-09 09:35:13 --> Controller Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Database Driver Class Initialized
ERROR - 2019-10-09 09:35:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-09 09:35:13 --> Model Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Model Class Initialized
DEBUG - 2019-10-09 09:35:13 --> Helper loaded: url_helper
DEBUG - 2019-10-09 09:35:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-09 09:35:13 --> Final output sent to browser
DEBUG - 2019-10-09 09:35:13 --> Total execution time: 0.1955
DEBUG - 2019-10-09 13:26:22 --> Config Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Hooks Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Utf8 Class Initialized
DEBUG - 2019-10-09 13:26:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:26:22 --> URI Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Router Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Output Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Security Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Input Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-09 13:26:22 --> Language Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Loader Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Helper loaded: date_helper
DEBUG - 2019-10-09 13:26:22 --> Controller Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Database Driver Class Initialized
ERROR - 2019-10-09 13:26:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-09 13:26:22 --> Model Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Model Class Initialized
DEBUG - 2019-10-09 13:26:22 --> Helper loaded: url_helper
DEBUG - 2019-10-09 13:26:22 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-09 13:26:22 --> Final output sent to browser
DEBUG - 2019-10-09 13:26:22 --> Total execution time: 0.1134
DEBUG - 2019-10-09 17:08:35 --> Config Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Hooks Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Utf8 Class Initialized
DEBUG - 2019-10-09 17:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:08:35 --> URI Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Router Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Output Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Security Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Input Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-09 17:08:35 --> Language Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Loader Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Helper loaded: date_helper
DEBUG - 2019-10-09 17:08:35 --> Controller Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Database Driver Class Initialized
ERROR - 2019-10-09 17:08:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-09 17:08:35 --> Model Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Model Class Initialized
DEBUG - 2019-10-09 17:08:35 --> Helper loaded: url_helper
DEBUG - 2019-10-09 17:08:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-09 17:08:35 --> Final output sent to browser
DEBUG - 2019-10-09 17:08:35 --> Total execution time: 0.1738
