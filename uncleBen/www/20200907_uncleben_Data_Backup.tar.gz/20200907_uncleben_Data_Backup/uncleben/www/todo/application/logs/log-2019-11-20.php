<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-11-20 02:46:11 --> Config Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Hooks Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Utf8 Class Initialized
DEBUG - 2019-11-20 02:46:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 02:46:11 --> URI Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Router Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Output Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Security Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Input Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-20 02:46:11 --> Language Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Loader Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Helper loaded: date_helper
DEBUG - 2019-11-20 02:46:11 --> Controller Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Database Driver Class Initialized
ERROR - 2019-11-20 02:46:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-20 02:46:11 --> Model Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Model Class Initialized
DEBUG - 2019-11-20 02:46:11 --> Helper loaded: url_helper
DEBUG - 2019-11-20 02:46:11 --> File loaded: application/views/todo/search_v.php
DEBUG - 2019-11-20 02:46:11 --> Final output sent to browser
DEBUG - 2019-11-20 02:46:11 --> Total execution time: 0.2188
DEBUG - 2019-11-20 02:46:22 --> Config Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Hooks Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Utf8 Class Initialized
DEBUG - 2019-11-20 02:46:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 02:46:22 --> URI Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Router Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Output Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Security Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Input Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-20 02:46:22 --> Language Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Loader Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Helper loaded: date_helper
DEBUG - 2019-11-20 02:46:22 --> Controller Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Database Driver Class Initialized
ERROR - 2019-11-20 02:46:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-20 02:46:22 --> Model Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Model Class Initialized
DEBUG - 2019-11-20 02:46:22 --> Helper loaded: url_helper
DEBUG - 2019-11-20 02:46:22 --> File loaded: application/views/todo/search_v.php
DEBUG - 2019-11-20 02:46:22 --> Final output sent to browser
DEBUG - 2019-11-20 02:46:22 --> Total execution time: 0.0882
DEBUG - 2019-11-20 04:29:09 --> Config Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Hooks Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Utf8 Class Initialized
DEBUG - 2019-11-20 04:29:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 04:29:09 --> URI Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Router Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Output Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Security Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Input Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-20 04:29:09 --> Language Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Loader Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Helper loaded: date_helper
DEBUG - 2019-11-20 04:29:09 --> Controller Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Database Driver Class Initialized
ERROR - 2019-11-20 04:29:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-20 04:29:09 --> Model Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Model Class Initialized
DEBUG - 2019-11-20 04:29:09 --> Helper loaded: url_helper
DEBUG - 2019-11-20 04:29:09 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2019-11-20 04:29:09 --> Final output sent to browser
DEBUG - 2019-11-20 04:29:09 --> Total execution time: 0.1206
DEBUG - 2019-11-20 07:32:39 --> Config Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Hooks Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Utf8 Class Initialized
DEBUG - 2019-11-20 07:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 07:32:39 --> URI Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Router Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Output Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Security Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Input Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-20 07:32:39 --> Language Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Loader Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Helper loaded: date_helper
DEBUG - 2019-11-20 07:32:39 --> Controller Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Database Driver Class Initialized
ERROR - 2019-11-20 07:32:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-20 07:32:39 --> Model Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Model Class Initialized
DEBUG - 2019-11-20 07:32:39 --> Helper loaded: url_helper
DEBUG - 2019-11-20 07:32:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-20 07:32:39 --> Final output sent to browser
DEBUG - 2019-11-20 07:32:39 --> Total execution time: 0.2159
