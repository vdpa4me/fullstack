<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-12-03 00:42:03 --> Config Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Hooks Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Utf8 Class Initialized
DEBUG - 2017-12-03 00:42:03 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 00:42:03 --> URI Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Router Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Output Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Security Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Input Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 00:42:03 --> Language Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Loader Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Helper loaded: date_helper
DEBUG - 2017-12-03 00:42:03 --> Controller Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Database Driver Class Initialized
ERROR - 2017-12-03 00:42:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 00:42:03 --> Model Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Model Class Initialized
DEBUG - 2017-12-03 00:42:03 --> Helper loaded: url_helper
DEBUG - 2017-12-03 00:42:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 00:42:03 --> Final output sent to browser
DEBUG - 2017-12-03 00:42:03 --> Total execution time: 0.0212
DEBUG - 2017-12-03 00:42:37 --> Config Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Hooks Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Utf8 Class Initialized
DEBUG - 2017-12-03 00:42:37 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 00:42:37 --> URI Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Router Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Output Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Security Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Input Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 00:42:37 --> Language Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Loader Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Helper loaded: date_helper
DEBUG - 2017-12-03 00:42:37 --> Controller Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Database Driver Class Initialized
ERROR - 2017-12-03 00:42:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 00:42:37 --> Model Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Model Class Initialized
DEBUG - 2017-12-03 00:42:37 --> Helper loaded: url_helper
DEBUG - 2017-12-03 00:42:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 00:42:37 --> Final output sent to browser
DEBUG - 2017-12-03 00:42:37 --> Total execution time: 0.0196
DEBUG - 2017-12-03 06:06:30 --> Config Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Hooks Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Utf8 Class Initialized
DEBUG - 2017-12-03 06:06:30 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 06:06:30 --> URI Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Router Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Output Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Security Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Input Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 06:06:30 --> Language Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Loader Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Helper loaded: date_helper
DEBUG - 2017-12-03 06:06:30 --> Controller Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Database Driver Class Initialized
ERROR - 2017-12-03 06:06:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 06:06:30 --> Model Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Model Class Initialized
DEBUG - 2017-12-03 06:06:30 --> Helper loaded: url_helper
DEBUG - 2017-12-03 06:06:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 06:06:30 --> Final output sent to browser
DEBUG - 2017-12-03 06:06:30 --> Total execution time: 0.0260
DEBUG - 2017-12-03 09:19:01 --> Config Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Hooks Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Utf8 Class Initialized
DEBUG - 2017-12-03 09:19:01 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 09:19:01 --> URI Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Router Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Output Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Security Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Input Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 09:19:01 --> Language Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Loader Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Helper loaded: date_helper
DEBUG - 2017-12-03 09:19:01 --> Controller Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Database Driver Class Initialized
ERROR - 2017-12-03 09:19:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 09:19:01 --> Model Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Model Class Initialized
DEBUG - 2017-12-03 09:19:01 --> Helper loaded: url_helper
DEBUG - 2017-12-03 09:19:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 09:19:01 --> Final output sent to browser
DEBUG - 2017-12-03 09:19:01 --> Total execution time: 0.0199
DEBUG - 2017-12-03 09:19:02 --> Config Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Hooks Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Utf8 Class Initialized
DEBUG - 2017-12-03 09:19:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 09:19:02 --> URI Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Router Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Output Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Security Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Input Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 09:19:02 --> Language Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Loader Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Helper loaded: date_helper
DEBUG - 2017-12-03 09:19:02 --> Controller Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Database Driver Class Initialized
ERROR - 2017-12-03 09:19:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 09:19:02 --> Model Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Model Class Initialized
DEBUG - 2017-12-03 09:19:02 --> Helper loaded: url_helper
DEBUG - 2017-12-03 09:19:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 09:19:02 --> Final output sent to browser
DEBUG - 2017-12-03 09:19:02 --> Total execution time: 0.0200
DEBUG - 2017-12-03 10:44:58 --> Config Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Hooks Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Utf8 Class Initialized
DEBUG - 2017-12-03 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 10:44:58 --> URI Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Router Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Output Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Security Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Input Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 10:44:58 --> Language Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Loader Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Helper loaded: date_helper
DEBUG - 2017-12-03 10:44:58 --> Controller Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Database Driver Class Initialized
ERROR - 2017-12-03 10:44:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 10:44:58 --> Model Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Model Class Initialized
DEBUG - 2017-12-03 10:44:58 --> Helper loaded: url_helper
DEBUG - 2017-12-03 10:44:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 10:44:58 --> Final output sent to browser
DEBUG - 2017-12-03 10:44:58 --> Total execution time: 0.0200
DEBUG - 2017-12-03 10:59:00 --> Config Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Hooks Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Utf8 Class Initialized
DEBUG - 2017-12-03 10:59:00 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 10:59:00 --> URI Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Router Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Output Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Security Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Input Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 10:59:00 --> Language Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Loader Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Helper loaded: date_helper
DEBUG - 2017-12-03 10:59:00 --> Controller Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Database Driver Class Initialized
ERROR - 2017-12-03 10:59:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 10:59:00 --> Model Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Model Class Initialized
DEBUG - 2017-12-03 10:59:00 --> Helper loaded: url_helper
DEBUG - 2017-12-03 10:59:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 10:59:00 --> Final output sent to browser
DEBUG - 2017-12-03 10:59:00 --> Total execution time: 0.0194
DEBUG - 2017-12-03 17:20:34 --> Config Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Hooks Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Utf8 Class Initialized
DEBUG - 2017-12-03 17:20:34 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 17:20:34 --> URI Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Router Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Output Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Security Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Input Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 17:20:34 --> Language Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Loader Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Helper loaded: date_helper
DEBUG - 2017-12-03 17:20:34 --> Controller Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Database Driver Class Initialized
ERROR - 2017-12-03 17:20:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 17:20:34 --> Model Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Model Class Initialized
DEBUG - 2017-12-03 17:20:34 --> Helper loaded: url_helper
DEBUG - 2017-12-03 17:20:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-03 17:20:34 --> Final output sent to browser
DEBUG - 2017-12-03 17:20:34 --> Total execution time: 0.0498
DEBUG - 2017-12-03 22:28:24 --> Config Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Hooks Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Utf8 Class Initialized
DEBUG - 2017-12-03 22:28:24 --> UTF-8 Support Enabled
DEBUG - 2017-12-03 22:28:24 --> URI Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Router Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Output Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Security Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Input Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-03 22:28:24 --> Language Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Loader Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Helper loaded: date_helper
DEBUG - 2017-12-03 22:28:24 --> Controller Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Database Driver Class Initialized
ERROR - 2017-12-03 22:28:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-03 22:28:24 --> Model Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Model Class Initialized
DEBUG - 2017-12-03 22:28:24 --> Helper loaded: url_helper
DEBUG - 2017-12-03 22:28:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-03 22:28:24 --> Final output sent to browser
DEBUG - 2017-12-03 22:28:24 --> Total execution time: 0.0251
