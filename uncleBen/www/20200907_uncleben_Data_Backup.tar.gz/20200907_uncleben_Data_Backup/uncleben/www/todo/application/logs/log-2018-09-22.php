<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-09-22 02:31:03 --> Config Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Hooks Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Utf8 Class Initialized
DEBUG - 2018-09-22 02:31:03 --> UTF-8 Support Enabled
DEBUG - 2018-09-22 02:31:03 --> URI Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Router Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Output Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Security Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Input Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-22 02:31:03 --> Language Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Loader Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Helper loaded: date_helper
DEBUG - 2018-09-22 02:31:03 --> Controller Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Database Driver Class Initialized
ERROR - 2018-09-22 02:31:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-22 02:31:03 --> Model Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Model Class Initialized
DEBUG - 2018-09-22 02:31:03 --> Helper loaded: url_helper
DEBUG - 2018-09-22 02:31:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-22 02:31:03 --> Final output sent to browser
DEBUG - 2018-09-22 02:31:03 --> Total execution time: 0.0586
DEBUG - 2018-09-22 20:24:08 --> Config Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Hooks Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Utf8 Class Initialized
DEBUG - 2018-09-22 20:24:08 --> UTF-8 Support Enabled
DEBUG - 2018-09-22 20:24:08 --> URI Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Router Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Output Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Security Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Input Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-09-22 20:24:08 --> Language Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Loader Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Helper loaded: date_helper
DEBUG - 2018-09-22 20:24:08 --> Controller Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Database Driver Class Initialized
ERROR - 2018-09-22 20:24:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-09-22 20:24:08 --> Model Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Model Class Initialized
DEBUG - 2018-09-22 20:24:08 --> Helper loaded: url_helper
DEBUG - 2018-09-22 20:24:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-09-22 20:24:09 --> Final output sent to browser
DEBUG - 2018-09-22 20:24:09 --> Total execution time: 0.0579
