<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-08-09 01:44:07 --> Config Class Initialized
DEBUG - 2020-08-09 01:44:07 --> Hooks Class Initialized
DEBUG - 2020-08-09 01:44:07 --> Utf8 Class Initialized
DEBUG - 2020-08-09 01:44:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-09 01:44:07 --> URI Class Initialized
DEBUG - 2020-08-09 01:44:07 --> Router Class Initialized
DEBUG - 2020-08-09 01:44:07 --> Output Class Initialized
DEBUG - 2020-08-09 01:44:07 --> Security Class Initialized
DEBUG - 2020-08-09 01:44:07 --> Input Class Initialized
DEBUG - 2020-08-09 01:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2020-08-09 01:44:08 --> Language Class Initialized
DEBUG - 2020-08-09 01:44:08 --> Loader Class Initialized
DEBUG - 2020-08-09 01:44:08 --> Helper loaded: date_helper
DEBUG - 2020-08-09 01:44:08 --> Controller Class Initialized
DEBUG - 2020-08-09 01:44:08 --> Database Driver Class Initialized
ERROR - 2020-08-09 01:44:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-08-09 01:44:08 --> Model Class Initialized
DEBUG - 2020-08-09 01:44:08 --> Model Class Initialized
DEBUG - 2020-08-09 01:44:08 --> Helper loaded: url_helper
DEBUG - 2020-08-09 01:44:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-08-09 01:44:08 --> Final output sent to browser
DEBUG - 2020-08-09 01:44:08 --> Total execution time: 0.1760
DEBUG - 2020-08-09 15:02:22 --> Config Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Hooks Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Utf8 Class Initialized
DEBUG - 2020-08-09 15:02:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-09 15:02:22 --> URI Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Router Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Output Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Security Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Input Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2020-08-09 15:02:22 --> Language Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Loader Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Helper loaded: date_helper
DEBUG - 2020-08-09 15:02:22 --> Controller Class Initialized
DEBUG - 2020-08-09 15:02:22 --> Database Driver Class Initialized
ERROR - 2020-08-09 15:02:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-08-09 15:02:23 --> Model Class Initialized
DEBUG - 2020-08-09 15:02:23 --> Model Class Initialized
DEBUG - 2020-08-09 15:02:23 --> Helper loaded: url_helper
DEBUG - 2020-08-09 15:02:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-08-09 15:02:23 --> Final output sent to browser
DEBUG - 2020-08-09 15:02:23 --> Total execution time: 0.1847
