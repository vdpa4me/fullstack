<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-10-23 02:04:52 --> Config Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Hooks Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Utf8 Class Initialized
DEBUG - 2019-10-23 02:04:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 02:04:52 --> URI Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Router Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Output Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Security Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Input Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-23 02:04:52 --> Language Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Loader Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Helper loaded: date_helper
DEBUG - 2019-10-23 02:04:52 --> Controller Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Database Driver Class Initialized
ERROR - 2019-10-23 02:04:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-23 02:04:52 --> Model Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Model Class Initialized
DEBUG - 2019-10-23 02:04:52 --> Helper loaded: url_helper
DEBUG - 2019-10-23 02:04:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-23 02:04:52 --> Final output sent to browser
DEBUG - 2019-10-23 02:04:52 --> Total execution time: 0.1911
DEBUG - 2019-10-23 06:03:07 --> Config Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Hooks Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Utf8 Class Initialized
DEBUG - 2019-10-23 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 06:03:07 --> URI Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Router Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Output Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Security Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Input Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-23 06:03:07 --> Language Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Loader Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Helper loaded: date_helper
DEBUG - 2019-10-23 06:03:07 --> Controller Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Database Driver Class Initialized
ERROR - 2019-10-23 06:03:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-23 06:03:07 --> Model Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Model Class Initialized
DEBUG - 2019-10-23 06:03:07 --> Helper loaded: url_helper
DEBUG - 2019-10-23 06:03:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-23 06:03:07 --> Final output sent to browser
DEBUG - 2019-10-23 06:03:07 --> Total execution time: 0.1045
DEBUG - 2019-10-23 06:30:58 --> Config Class Initialized
DEBUG - 2019-10-23 06:30:58 --> Hooks Class Initialized
DEBUG - 2019-10-23 06:30:58 --> Utf8 Class Initialized
DEBUG - 2019-10-23 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 06:30:58 --> URI Class Initialized
DEBUG - 2019-10-23 06:30:58 --> Router Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Output Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Security Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Input Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-23 06:30:59 --> Language Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Loader Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Helper loaded: date_helper
DEBUG - 2019-10-23 06:30:59 --> Controller Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Database Driver Class Initialized
ERROR - 2019-10-23 06:30:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-23 06:30:59 --> Model Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Model Class Initialized
DEBUG - 2019-10-23 06:30:59 --> Helper loaded: url_helper
DEBUG - 2019-10-23 06:30:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-23 06:30:59 --> Final output sent to browser
DEBUG - 2019-10-23 06:30:59 --> Total execution time: 0.1069
DEBUG - 2019-10-23 13:14:04 --> Config Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Hooks Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Utf8 Class Initialized
DEBUG - 2019-10-23 13:14:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 13:14:04 --> URI Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Router Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Output Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Security Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Input Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-23 13:14:04 --> Language Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Loader Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Helper loaded: date_helper
DEBUG - 2019-10-23 13:14:04 --> Controller Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Database Driver Class Initialized
ERROR - 2019-10-23 13:14:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-23 13:14:04 --> Model Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Model Class Initialized
DEBUG - 2019-10-23 13:14:04 --> Helper loaded: url_helper
DEBUG - 2019-10-23 13:14:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-23 13:14:04 --> Final output sent to browser
DEBUG - 2019-10-23 13:14:04 --> Total execution time: 0.2038
