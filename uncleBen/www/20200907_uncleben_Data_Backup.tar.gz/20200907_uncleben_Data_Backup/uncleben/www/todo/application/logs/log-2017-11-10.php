<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-10 11:45:09 --> Config Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Hooks Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Utf8 Class Initialized
DEBUG - 2017-11-10 11:45:09 --> UTF-8 Support Enabled
DEBUG - 2017-11-10 11:45:09 --> URI Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Router Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Output Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Security Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Input Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-10 11:45:09 --> Language Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Loader Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Helper loaded: date_helper
DEBUG - 2017-11-10 11:45:09 --> Controller Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Database Driver Class Initialized
ERROR - 2017-11-10 11:45:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-10 11:45:09 --> Model Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Model Class Initialized
DEBUG - 2017-11-10 11:45:09 --> Helper loaded: url_helper
DEBUG - 2017-11-10 11:45:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-10 11:45:09 --> Final output sent to browser
DEBUG - 2017-11-10 11:45:09 --> Total execution time: 0.0463
DEBUG - 2017-11-10 16:25:43 --> Config Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Hooks Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Utf8 Class Initialized
DEBUG - 2017-11-10 16:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-11-10 16:25:43 --> URI Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Router Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Output Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Security Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Input Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-10 16:25:43 --> Language Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Loader Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Helper loaded: date_helper
DEBUG - 2017-11-10 16:25:43 --> Controller Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Database Driver Class Initialized
ERROR - 2017-11-10 16:25:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-10 16:25:43 --> Model Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Model Class Initialized
DEBUG - 2017-11-10 16:25:43 --> Helper loaded: url_helper
DEBUG - 2017-11-10 16:25:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-10 16:25:43 --> Final output sent to browser
DEBUG - 2017-11-10 16:25:43 --> Total execution time: 0.0299
DEBUG - 2017-11-10 18:52:20 --> Config Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Hooks Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Utf8 Class Initialized
DEBUG - 2017-11-10 18:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-11-10 18:52:20 --> URI Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Router Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Output Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Security Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Input Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-10 18:52:20 --> Language Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Loader Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Helper loaded: date_helper
DEBUG - 2017-11-10 18:52:20 --> Controller Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Database Driver Class Initialized
ERROR - 2017-11-10 18:52:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-10 18:52:20 --> Model Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Model Class Initialized
DEBUG - 2017-11-10 18:52:20 --> Helper loaded: url_helper
DEBUG - 2017-11-10 18:52:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-10 18:52:20 --> Final output sent to browser
DEBUG - 2017-11-10 18:52:20 --> Total execution time: 0.0201
DEBUG - 2017-11-10 22:16:14 --> Config Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Hooks Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Utf8 Class Initialized
DEBUG - 2017-11-10 22:16:14 --> UTF-8 Support Enabled
DEBUG - 2017-11-10 22:16:14 --> URI Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Router Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Output Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Security Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Input Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-10 22:16:14 --> Language Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Loader Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Helper loaded: date_helper
DEBUG - 2017-11-10 22:16:14 --> Controller Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Database Driver Class Initialized
ERROR - 2017-11-10 22:16:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-10 22:16:14 --> Model Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Model Class Initialized
DEBUG - 2017-11-10 22:16:14 --> Helper loaded: url_helper
DEBUG - 2017-11-10 22:16:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-10 22:16:14 --> Final output sent to browser
DEBUG - 2017-11-10 22:16:14 --> Total execution time: 0.0751
DEBUG - 2017-11-10 22:16:18 --> Config Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Hooks Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Utf8 Class Initialized
DEBUG - 2017-11-10 22:16:18 --> UTF-8 Support Enabled
DEBUG - 2017-11-10 22:16:18 --> URI Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Router Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Output Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Security Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Input Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-10 22:16:18 --> Language Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Loader Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Helper loaded: date_helper
DEBUG - 2017-11-10 22:16:18 --> Controller Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Database Driver Class Initialized
ERROR - 2017-11-10 22:16:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-10 22:16:18 --> Model Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Model Class Initialized
DEBUG - 2017-11-10 22:16:18 --> Helper loaded: url_helper
DEBUG - 2017-11-10 22:16:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-10 22:16:19 --> Final output sent to browser
DEBUG - 2017-11-10 22:16:19 --> Total execution time: 0.0410
