<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-07-16 03:03:13 --> Config Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:03:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:03:13 --> URI Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Router Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Output Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Security Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Input Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:03:13 --> Language Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Loader Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:03:13 --> Controller Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:03:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:03:13 --> Model Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Model Class Initialized
DEBUG - 2017-07-16 03:03:13 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:03:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:03:13 --> Final output sent to browser
DEBUG - 2017-07-16 03:03:13 --> Total execution time: 0.0524
DEBUG - 2017-07-16 03:03:16 --> Config Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:03:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:03:16 --> URI Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Router Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Output Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Security Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Input Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:03:16 --> Language Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Loader Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:03:16 --> Controller Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:03:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:03:16 --> Model Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Model Class Initialized
DEBUG - 2017-07-16 03:03:16 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:03:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:03:16 --> Final output sent to browser
DEBUG - 2017-07-16 03:03:16 --> Total execution time: 0.0351
DEBUG - 2017-07-16 03:03:49 --> Config Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:03:49 --> URI Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Router Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Output Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Security Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Input Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:03:49 --> Language Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Loader Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:03:49 --> Controller Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:03:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:03:49 --> Model Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Model Class Initialized
DEBUG - 2017-07-16 03:03:49 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:03:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:03:49 --> Final output sent to browser
DEBUG - 2017-07-16 03:03:49 --> Total execution time: 0.0362
DEBUG - 2017-07-16 03:04:20 --> Config Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:04:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:04:20 --> URI Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Router Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Output Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Security Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Input Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:04:20 --> Language Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Loader Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:04:20 --> Controller Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:04:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:04:20 --> Model Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Model Class Initialized
DEBUG - 2017-07-16 03:04:20 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:04:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:04:20 --> Final output sent to browser
DEBUG - 2017-07-16 03:04:20 --> Total execution time: 0.0355
DEBUG - 2017-07-16 03:04:52 --> Config Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:04:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:04:52 --> URI Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Router Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Output Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Security Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Input Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:04:52 --> Language Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Loader Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:04:52 --> Controller Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:04:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:04:52 --> Model Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Model Class Initialized
DEBUG - 2017-07-16 03:04:52 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:04:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:04:52 --> Final output sent to browser
DEBUG - 2017-07-16 03:04:52 --> Total execution time: 0.0364
DEBUG - 2017-07-16 03:07:09 --> Config Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:07:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:07:09 --> URI Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Router Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Output Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Security Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Input Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:07:09 --> Language Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Loader Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:07:09 --> Controller Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:07:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:07:09 --> Model Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Model Class Initialized
DEBUG - 2017-07-16 03:07:09 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:07:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:07:09 --> Final output sent to browser
DEBUG - 2017-07-16 03:07:09 --> Total execution time: 0.0364
DEBUG - 2017-07-16 03:08:54 --> Config Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:08:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:08:54 --> URI Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Router Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Output Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Security Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Input Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:08:54 --> Language Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Loader Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:08:54 --> Controller Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:08:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:08:54 --> Model Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Model Class Initialized
DEBUG - 2017-07-16 03:08:54 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:08:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:08:54 --> Final output sent to browser
DEBUG - 2017-07-16 03:08:54 --> Total execution time: 0.0363
DEBUG - 2017-07-16 03:11:22 --> Config Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:11:22 --> URI Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Router Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Output Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Security Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Input Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:11:22 --> Language Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Loader Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:11:22 --> Controller Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:11:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:11:22 --> Model Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Model Class Initialized
DEBUG - 2017-07-16 03:11:22 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:11:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:11:22 --> Final output sent to browser
DEBUG - 2017-07-16 03:11:22 --> Total execution time: 0.0347
DEBUG - 2017-07-16 03:31:28 --> Config Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:31:28 --> URI Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Router Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Output Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Security Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Input Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:31:28 --> Language Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Loader Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:31:28 --> Controller Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:31:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:31:28 --> Model Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Model Class Initialized
DEBUG - 2017-07-16 03:31:28 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:31:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:31:28 --> Final output sent to browser
DEBUG - 2017-07-16 03:31:28 --> Total execution time: 0.0364
DEBUG - 2017-07-16 03:32:05 --> Config Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:32:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:32:05 --> URI Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Router Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Output Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Security Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Input Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:32:05 --> Language Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Loader Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:32:05 --> Controller Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:32:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:32:05 --> Model Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Model Class Initialized
DEBUG - 2017-07-16 03:32:05 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:32:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:32:05 --> Final output sent to browser
DEBUG - 2017-07-16 03:32:05 --> Total execution time: 0.0360
DEBUG - 2017-07-16 03:32:09 --> Config Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:32:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:32:09 --> URI Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Router Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Output Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Security Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Input Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:32:09 --> Language Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Loader Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:32:09 --> Controller Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:32:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:32:09 --> Model Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Model Class Initialized
DEBUG - 2017-07-16 03:32:09 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:32:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:32:09 --> Final output sent to browser
DEBUG - 2017-07-16 03:32:09 --> Total execution time: 0.0365
DEBUG - 2017-07-16 03:32:52 --> Config Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:32:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:32:52 --> URI Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Router Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Output Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Security Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Input Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:32:52 --> Language Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Loader Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:32:52 --> Controller Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:32:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:32:52 --> Model Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Model Class Initialized
DEBUG - 2017-07-16 03:32:52 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:32:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:32:52 --> Final output sent to browser
DEBUG - 2017-07-16 03:32:52 --> Total execution time: 0.0364
DEBUG - 2017-07-16 03:33:47 --> Config Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Hooks Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Utf8 Class Initialized
DEBUG - 2017-07-16 03:33:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 03:33:47 --> URI Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Router Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Output Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Security Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Input Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 03:33:47 --> Language Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Loader Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Helper loaded: date_helper
DEBUG - 2017-07-16 03:33:47 --> Controller Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Database Driver Class Initialized
ERROR - 2017-07-16 03:33:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 03:33:47 --> Model Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Model Class Initialized
DEBUG - 2017-07-16 03:33:47 --> Helper loaded: url_helper
DEBUG - 2017-07-16 03:33:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 03:33:47 --> Final output sent to browser
DEBUG - 2017-07-16 03:33:47 --> Total execution time: 0.0367
DEBUG - 2017-07-16 04:44:46 --> Config Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Hooks Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Utf8 Class Initialized
DEBUG - 2017-07-16 04:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 04:44:46 --> URI Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Router Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Output Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Security Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Input Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 04:44:46 --> Language Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Loader Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Helper loaded: date_helper
DEBUG - 2017-07-16 04:44:46 --> Controller Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Database Driver Class Initialized
ERROR - 2017-07-16 04:44:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 04:44:46 --> Model Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Model Class Initialized
DEBUG - 2017-07-16 04:44:46 --> Helper loaded: url_helper
DEBUG - 2017-07-16 04:44:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 04:44:46 --> Final output sent to browser
DEBUG - 2017-07-16 04:44:46 --> Total execution time: 0.0425
DEBUG - 2017-07-16 04:44:58 --> Config Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Hooks Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Utf8 Class Initialized
DEBUG - 2017-07-16 04:44:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 04:44:58 --> URI Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Router Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Output Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Security Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Input Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 04:44:58 --> Language Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Loader Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Helper loaded: date_helper
DEBUG - 2017-07-16 04:44:58 --> Controller Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Database Driver Class Initialized
ERROR - 2017-07-16 04:44:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 04:44:58 --> Model Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Model Class Initialized
DEBUG - 2017-07-16 04:44:58 --> Helper loaded: url_helper
DEBUG - 2017-07-16 04:44:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 04:44:58 --> Final output sent to browser
DEBUG - 2017-07-16 04:44:58 --> Total execution time: 0.0366
DEBUG - 2017-07-16 07:27:27 --> Config Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Hooks Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Utf8 Class Initialized
DEBUG - 2017-07-16 07:27:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 07:27:27 --> URI Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Router Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Output Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Security Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Input Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 07:27:27 --> Language Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Loader Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Helper loaded: date_helper
DEBUG - 2017-07-16 07:27:27 --> Controller Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Database Driver Class Initialized
ERROR - 2017-07-16 07:27:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 07:27:27 --> Model Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Model Class Initialized
DEBUG - 2017-07-16 07:27:27 --> Helper loaded: url_helper
DEBUG - 2017-07-16 07:27:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 07:27:27 --> Final output sent to browser
DEBUG - 2017-07-16 07:27:27 --> Total execution time: 0.0291
DEBUG - 2017-07-16 07:28:42 --> Config Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Hooks Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Utf8 Class Initialized
DEBUG - 2017-07-16 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 07:28:42 --> URI Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Router Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Output Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Security Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Input Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 07:28:42 --> Language Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Loader Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Helper loaded: date_helper
DEBUG - 2017-07-16 07:28:42 --> Controller Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Database Driver Class Initialized
ERROR - 2017-07-16 07:28:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 07:28:42 --> Model Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Model Class Initialized
DEBUG - 2017-07-16 07:28:42 --> Helper loaded: url_helper
DEBUG - 2017-07-16 07:28:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 07:28:42 --> Final output sent to browser
DEBUG - 2017-07-16 07:28:42 --> Total execution time: 0.0204
DEBUG - 2017-07-16 07:32:19 --> Config Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Hooks Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Utf8 Class Initialized
DEBUG - 2017-07-16 07:32:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 07:32:19 --> URI Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Router Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Output Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Security Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Input Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 07:32:19 --> Language Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Loader Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Helper loaded: date_helper
DEBUG - 2017-07-16 07:32:19 --> Controller Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Database Driver Class Initialized
ERROR - 2017-07-16 07:32:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 07:32:19 --> Model Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Model Class Initialized
DEBUG - 2017-07-16 07:32:19 --> Helper loaded: url_helper
DEBUG - 2017-07-16 07:32:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 07:32:19 --> Final output sent to browser
DEBUG - 2017-07-16 07:32:19 --> Total execution time: 0.0202
DEBUG - 2017-07-16 07:36:08 --> Config Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Hooks Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Utf8 Class Initialized
DEBUG - 2017-07-16 07:36:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 07:36:08 --> URI Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Router Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Output Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Security Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Input Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 07:36:08 --> Language Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Loader Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Helper loaded: date_helper
DEBUG - 2017-07-16 07:36:08 --> Controller Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Database Driver Class Initialized
ERROR - 2017-07-16 07:36:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 07:36:08 --> Model Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Model Class Initialized
DEBUG - 2017-07-16 07:36:08 --> Helper loaded: url_helper
DEBUG - 2017-07-16 07:36:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 07:36:08 --> Final output sent to browser
DEBUG - 2017-07-16 07:36:08 --> Total execution time: 0.0199
DEBUG - 2017-07-16 07:47:17 --> Config Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Hooks Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Utf8 Class Initialized
DEBUG - 2017-07-16 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 07:47:17 --> URI Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Router Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Output Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Security Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Input Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 07:47:17 --> Language Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Loader Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Helper loaded: date_helper
DEBUG - 2017-07-16 07:47:17 --> Controller Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Database Driver Class Initialized
ERROR - 2017-07-16 07:47:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 07:47:17 --> Model Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Model Class Initialized
DEBUG - 2017-07-16 07:47:17 --> Helper loaded: url_helper
DEBUG - 2017-07-16 07:47:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 07:47:17 --> Final output sent to browser
DEBUG - 2017-07-16 07:47:17 --> Total execution time: 0.0200
DEBUG - 2017-07-16 07:57:38 --> Config Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Hooks Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Utf8 Class Initialized
DEBUG - 2017-07-16 07:57:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 07:57:38 --> URI Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Router Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Output Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Security Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Input Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 07:57:38 --> Language Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Loader Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Helper loaded: date_helper
DEBUG - 2017-07-16 07:57:38 --> Controller Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Database Driver Class Initialized
ERROR - 2017-07-16 07:57:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 07:57:38 --> Model Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Model Class Initialized
DEBUG - 2017-07-16 07:57:38 --> Helper loaded: url_helper
DEBUG - 2017-07-16 07:57:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 07:57:38 --> Final output sent to browser
DEBUG - 2017-07-16 07:57:38 --> Total execution time: 0.0205
DEBUG - 2017-07-16 08:49:07 --> Config Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Hooks Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Utf8 Class Initialized
DEBUG - 2017-07-16 08:49:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 08:49:07 --> URI Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Router Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Output Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Security Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Input Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 08:49:07 --> Language Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Loader Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Helper loaded: date_helper
DEBUG - 2017-07-16 08:49:07 --> Controller Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Database Driver Class Initialized
ERROR - 2017-07-16 08:49:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 08:49:07 --> Model Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Model Class Initialized
DEBUG - 2017-07-16 08:49:07 --> Helper loaded: url_helper
DEBUG - 2017-07-16 08:49:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 08:49:07 --> Final output sent to browser
DEBUG - 2017-07-16 08:49:07 --> Total execution time: 0.0198
DEBUG - 2017-07-16 08:56:34 --> Config Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Hooks Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Utf8 Class Initialized
DEBUG - 2017-07-16 08:56:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 08:56:34 --> URI Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Router Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Output Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Security Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Input Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 08:56:34 --> Language Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Loader Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Helper loaded: date_helper
DEBUG - 2017-07-16 08:56:34 --> Controller Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Database Driver Class Initialized
ERROR - 2017-07-16 08:56:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 08:56:34 --> Model Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Model Class Initialized
DEBUG - 2017-07-16 08:56:34 --> Helper loaded: url_helper
DEBUG - 2017-07-16 08:56:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 08:56:34 --> Final output sent to browser
DEBUG - 2017-07-16 08:56:34 --> Total execution time: 0.0199
DEBUG - 2017-07-16 08:57:27 --> Config Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Hooks Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Utf8 Class Initialized
DEBUG - 2017-07-16 08:57:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 08:57:27 --> URI Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Router Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Output Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Security Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Input Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 08:57:27 --> Language Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Loader Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Helper loaded: date_helper
DEBUG - 2017-07-16 08:57:27 --> Controller Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Database Driver Class Initialized
ERROR - 2017-07-16 08:57:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 08:57:27 --> Model Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Model Class Initialized
DEBUG - 2017-07-16 08:57:27 --> Helper loaded: url_helper
DEBUG - 2017-07-16 08:57:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 08:57:27 --> Final output sent to browser
DEBUG - 2017-07-16 08:57:27 --> Total execution time: 0.0194
DEBUG - 2017-07-16 09:35:14 --> Config Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Hooks Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Utf8 Class Initialized
DEBUG - 2017-07-16 09:35:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 09:35:14 --> URI Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Router Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Output Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Security Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Input Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 09:35:14 --> Language Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Loader Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Helper loaded: date_helper
DEBUG - 2017-07-16 09:35:14 --> Controller Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Database Driver Class Initialized
ERROR - 2017-07-16 09:35:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 09:35:14 --> Model Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Model Class Initialized
DEBUG - 2017-07-16 09:35:14 --> Helper loaded: url_helper
DEBUG - 2017-07-16 09:35:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 09:35:14 --> Final output sent to browser
DEBUG - 2017-07-16 09:35:14 --> Total execution time: 0.0202
DEBUG - 2017-07-16 10:51:41 --> Config Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Hooks Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Utf8 Class Initialized
DEBUG - 2017-07-16 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 10:51:41 --> URI Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Router Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Output Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Security Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Input Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 10:51:41 --> Language Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Loader Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Helper loaded: date_helper
DEBUG - 2017-07-16 10:51:41 --> Controller Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Database Driver Class Initialized
ERROR - 2017-07-16 10:51:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 10:51:41 --> Model Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Model Class Initialized
DEBUG - 2017-07-16 10:51:41 --> Helper loaded: url_helper
DEBUG - 2017-07-16 10:51:41 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-07-16 10:51:41 --> Final output sent to browser
DEBUG - 2017-07-16 10:51:41 --> Total execution time: 0.0241
DEBUG - 2017-07-16 12:52:58 --> Config Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Hooks Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Utf8 Class Initialized
DEBUG - 2017-07-16 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 12:52:58 --> URI Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Router Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Output Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Security Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Input Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 12:52:58 --> Language Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Loader Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Helper loaded: date_helper
DEBUG - 2017-07-16 12:52:58 --> Controller Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Database Driver Class Initialized
ERROR - 2017-07-16 12:52:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 12:52:58 --> Model Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Model Class Initialized
DEBUG - 2017-07-16 12:52:58 --> Helper loaded: url_helper
DEBUG - 2017-07-16 12:52:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-16 12:52:58 --> Final output sent to browser
DEBUG - 2017-07-16 12:52:58 --> Total execution time: 0.0455
DEBUG - 2017-07-16 15:48:12 --> Config Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Hooks Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Utf8 Class Initialized
DEBUG - 2017-07-16 15:48:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 15:48:12 --> URI Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Router Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Output Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Security Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Input Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-16 15:48:12 --> Language Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Loader Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Helper loaded: date_helper
DEBUG - 2017-07-16 15:48:12 --> Controller Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Database Driver Class Initialized
ERROR - 2017-07-16 15:48:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-16 15:48:12 --> Model Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Model Class Initialized
DEBUG - 2017-07-16 15:48:12 --> Helper loaded: url_helper
DEBUG - 2017-07-16 15:48:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-16 15:48:12 --> Final output sent to browser
DEBUG - 2017-07-16 15:48:12 --> Total execution time: 0.0246
