<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-07-19 00:43:36 --> Config Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Hooks Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Utf8 Class Initialized
DEBUG - 2017-07-19 00:43:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-19 00:43:36 --> URI Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Router Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Output Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Security Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Input Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-19 00:43:36 --> Language Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Loader Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Helper loaded: date_helper
DEBUG - 2017-07-19 00:43:36 --> Controller Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Database Driver Class Initialized
ERROR - 2017-07-19 00:43:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-19 00:43:36 --> Model Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Model Class Initialized
DEBUG - 2017-07-19 00:43:36 --> Helper loaded: url_helper
DEBUG - 2017-07-19 00:43:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-19 00:43:36 --> Final output sent to browser
DEBUG - 2017-07-19 00:43:36 --> Total execution time: 0.0833
DEBUG - 2017-07-19 00:46:50 --> Config Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Hooks Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Utf8 Class Initialized
DEBUG - 2017-07-19 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-19 00:46:50 --> URI Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Router Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Output Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Security Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Input Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-19 00:46:50 --> Language Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Loader Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Helper loaded: date_helper
DEBUG - 2017-07-19 00:46:50 --> Controller Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Database Driver Class Initialized
ERROR - 2017-07-19 00:46:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-19 00:46:50 --> Model Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Model Class Initialized
DEBUG - 2017-07-19 00:46:50 --> Helper loaded: url_helper
DEBUG - 2017-07-19 00:46:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-19 00:46:50 --> Final output sent to browser
DEBUG - 2017-07-19 00:46:50 --> Total execution time: 0.0360
DEBUG - 2017-07-19 00:48:06 --> Config Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Hooks Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Utf8 Class Initialized
DEBUG - 2017-07-19 00:48:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-19 00:48:06 --> URI Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Router Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Output Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Security Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Input Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-19 00:48:06 --> Language Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Loader Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Helper loaded: date_helper
DEBUG - 2017-07-19 00:48:06 --> Controller Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Database Driver Class Initialized
ERROR - 2017-07-19 00:48:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-19 00:48:06 --> Model Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Model Class Initialized
DEBUG - 2017-07-19 00:48:06 --> Helper loaded: url_helper
DEBUG - 2017-07-19 00:48:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-19 00:48:06 --> Final output sent to browser
DEBUG - 2017-07-19 00:48:06 --> Total execution time: 0.0350
DEBUG - 2017-07-19 07:45:40 --> Config Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Hooks Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Utf8 Class Initialized
DEBUG - 2017-07-19 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-19 07:45:40 --> URI Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Router Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Output Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Security Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Input Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-19 07:45:40 --> Language Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Loader Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Helper loaded: date_helper
DEBUG - 2017-07-19 07:45:40 --> Controller Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Database Driver Class Initialized
ERROR - 2017-07-19 07:45:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-19 07:45:40 --> Model Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Model Class Initialized
DEBUG - 2017-07-19 07:45:40 --> Helper loaded: url_helper
DEBUG - 2017-07-19 07:45:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-19 07:45:40 --> Final output sent to browser
DEBUG - 2017-07-19 07:45:40 --> Total execution time: 0.0489
DEBUG - 2017-07-19 10:07:34 --> Config Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Hooks Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Utf8 Class Initialized
DEBUG - 2017-07-19 10:07:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-19 10:07:34 --> URI Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Router Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Output Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Security Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Input Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-19 10:07:34 --> Language Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Loader Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Helper loaded: date_helper
DEBUG - 2017-07-19 10:07:34 --> Controller Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Database Driver Class Initialized
ERROR - 2017-07-19 10:07:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-19 10:07:34 --> Model Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Model Class Initialized
DEBUG - 2017-07-19 10:07:34 --> Helper loaded: url_helper
DEBUG - 2017-07-19 10:07:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-19 10:07:34 --> Final output sent to browser
DEBUG - 2017-07-19 10:07:34 --> Total execution time: 0.0243
