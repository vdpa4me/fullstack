<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-04-15 00:00:06 --> Config Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:00:06 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:00:06 --> URI Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Router Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Output Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Security Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Input Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:00:06 --> Language Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Loader Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:00:06 --> Controller Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:00:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:00:06 --> Model Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Model Class Initialized
DEBUG - 2017-04-15 00:00:06 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:00:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:00:06 --> Final output sent to browser
DEBUG - 2017-04-15 00:00:06 --> Total execution time: 0.0304
DEBUG - 2017-04-15 00:00:43 --> Config Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:00:43 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:00:43 --> URI Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Router Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Output Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Security Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Input Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:00:43 --> Language Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Loader Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:00:43 --> Controller Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:00:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:00:43 --> Model Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Model Class Initialized
DEBUG - 2017-04-15 00:00:43 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:00:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:00:43 --> Final output sent to browser
DEBUG - 2017-04-15 00:00:43 --> Total execution time: 0.0298
DEBUG - 2017-04-15 00:00:53 --> Config Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:00:53 --> URI Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Router Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Output Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Security Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Input Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:00:53 --> Language Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Loader Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:00:53 --> Controller Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:00:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:00:53 --> Model Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Model Class Initialized
DEBUG - 2017-04-15 00:00:53 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:00:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:00:53 --> Final output sent to browser
DEBUG - 2017-04-15 00:00:53 --> Total execution time: 0.0304
DEBUG - 2017-04-15 00:01:03 --> Config Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:01:03 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:01:03 --> URI Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Router Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Output Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Security Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Input Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:01:03 --> Language Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Loader Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:01:03 --> Controller Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:01:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:01:03 --> Model Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Model Class Initialized
DEBUG - 2017-04-15 00:01:03 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:01:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:01:03 --> Final output sent to browser
DEBUG - 2017-04-15 00:01:03 --> Total execution time: 0.0307
DEBUG - 2017-04-15 00:01:06 --> Config Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:01:06 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:01:06 --> URI Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Router Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Output Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Security Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Input Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:01:06 --> Language Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Loader Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:01:06 --> Controller Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:01:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:01:06 --> Model Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Model Class Initialized
DEBUG - 2017-04-15 00:01:06 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:01:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:01:06 --> Final output sent to browser
DEBUG - 2017-04-15 00:01:06 --> Total execution time: 0.0308
DEBUG - 2017-04-15 00:13:34 --> Config Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:13:34 --> URI Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Router Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Output Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Security Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Input Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:13:34 --> Language Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Loader Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:13:34 --> Controller Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:13:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:13:34 --> Model Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Model Class Initialized
DEBUG - 2017-04-15 00:13:34 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:13:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:13:34 --> Final output sent to browser
DEBUG - 2017-04-15 00:13:34 --> Total execution time: 0.0294
DEBUG - 2017-04-15 00:15:28 --> Config Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:15:28 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:15:28 --> URI Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Router Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Output Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Security Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Input Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:15:28 --> Language Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Loader Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:15:28 --> Controller Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:15:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:15:28 --> Model Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Model Class Initialized
DEBUG - 2017-04-15 00:15:28 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:15:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:15:28 --> Final output sent to browser
DEBUG - 2017-04-15 00:15:28 --> Total execution time: 0.0296
DEBUG - 2017-04-15 00:30:51 --> Config Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:30:51 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:30:51 --> URI Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Router Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Output Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Security Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Input Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:30:51 --> Language Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Loader Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:30:51 --> Controller Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:30:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:30:51 --> Model Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Model Class Initialized
DEBUG - 2017-04-15 00:30:51 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:30:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:30:51 --> Final output sent to browser
DEBUG - 2017-04-15 00:30:51 --> Total execution time: 0.0286
DEBUG - 2017-04-15 00:31:40 --> Config Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:31:40 --> URI Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Router Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Output Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Security Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Input Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:31:40 --> Language Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Loader Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:31:40 --> Controller Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:31:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:31:40 --> Model Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Model Class Initialized
DEBUG - 2017-04-15 00:31:40 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:31:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:31:40 --> Final output sent to browser
DEBUG - 2017-04-15 00:31:40 --> Total execution time: 0.0287
DEBUG - 2017-04-15 00:32:08 --> Config Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Hooks Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Utf8 Class Initialized
DEBUG - 2017-04-15 00:32:08 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 00:32:08 --> URI Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Router Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Output Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Security Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Input Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 00:32:08 --> Language Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Loader Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Helper loaded: date_helper
DEBUG - 2017-04-15 00:32:08 --> Controller Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Database Driver Class Initialized
ERROR - 2017-04-15 00:32:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 00:32:08 --> Model Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Model Class Initialized
DEBUG - 2017-04-15 00:32:08 --> Helper loaded: url_helper
DEBUG - 2017-04-15 00:32:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 00:32:08 --> Final output sent to browser
DEBUG - 2017-04-15 00:32:08 --> Total execution time: 0.0286
DEBUG - 2017-04-15 04:24:22 --> Config Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:24:22 --> URI Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Router Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Output Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Security Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Input Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:24:22 --> Language Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Loader Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:24:22 --> Controller Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:24:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:24:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:24:22 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:24:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:24:22 --> Final output sent to browser
DEBUG - 2017-04-15 04:24:22 --> Total execution time: 0.0348
DEBUG - 2017-04-15 04:32:02 --> Config Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:32:02 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:32:02 --> URI Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Router Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Output Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Security Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Input Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:32:02 --> Language Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Loader Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:32:02 --> Controller Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:32:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:32:02 --> Model Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Model Class Initialized
DEBUG - 2017-04-15 04:32:02 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:32:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:32:02 --> Final output sent to browser
DEBUG - 2017-04-15 04:32:02 --> Total execution time: 0.0286
DEBUG - 2017-04-15 04:32:05 --> Config Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:32:05 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:32:05 --> URI Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Router Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Output Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Security Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Input Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:32:05 --> Language Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Loader Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:32:05 --> Controller Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:32:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:32:05 --> Model Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Model Class Initialized
DEBUG - 2017-04-15 04:32:05 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:32:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:32:05 --> Final output sent to browser
DEBUG - 2017-04-15 04:32:05 --> Total execution time: 0.0288
DEBUG - 2017-04-15 04:35:14 --> Config Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:35:14 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:35:14 --> URI Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Router Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Output Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Security Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Input Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:35:14 --> Language Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Loader Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:35:14 --> Controller Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:35:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:35:14 --> Model Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Model Class Initialized
DEBUG - 2017-04-15 04:35:14 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:35:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:35:14 --> Final output sent to browser
DEBUG - 2017-04-15 04:35:14 --> Total execution time: 0.0300
DEBUG - 2017-04-15 04:36:06 --> Config Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:36:06 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:36:06 --> URI Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Router Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Output Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Security Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Input Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:36:06 --> Language Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Loader Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:36:06 --> Controller Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:36:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:36:06 --> Model Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Model Class Initialized
DEBUG - 2017-04-15 04:36:06 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:36:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:36:06 --> Final output sent to browser
DEBUG - 2017-04-15 04:36:06 --> Total execution time: 0.0295
DEBUG - 2017-04-15 04:37:28 --> Config Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:37:28 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:37:28 --> URI Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Router Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Output Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Security Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Input Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:37:28 --> Language Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Loader Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:37:28 --> Controller Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:37:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:37:28 --> Model Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Model Class Initialized
DEBUG - 2017-04-15 04:37:28 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:37:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:37:28 --> Final output sent to browser
DEBUG - 2017-04-15 04:37:28 --> Total execution time: 0.0288
DEBUG - 2017-04-15 04:37:51 --> Config Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:37:51 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:37:51 --> URI Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Router Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Output Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Security Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Input Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:37:51 --> Language Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Loader Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:37:51 --> Controller Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:37:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:37:51 --> Model Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Model Class Initialized
DEBUG - 2017-04-15 04:37:51 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:37:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:37:51 --> Final output sent to browser
DEBUG - 2017-04-15 04:37:51 --> Total execution time: 0.0288
DEBUG - 2017-04-15 04:38:04 --> Config Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:38:04 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:38:04 --> URI Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Router Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Output Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Security Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Input Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:38:04 --> Language Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Loader Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:38:04 --> Controller Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:38:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:38:04 --> Model Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Model Class Initialized
DEBUG - 2017-04-15 04:38:04 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:38:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:38:04 --> Final output sent to browser
DEBUG - 2017-04-15 04:38:04 --> Total execution time: 0.0288
DEBUG - 2017-04-15 04:38:45 --> Config Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:38:45 --> URI Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Router Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Output Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Security Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Input Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:38:45 --> Language Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Loader Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:38:45 --> Controller Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:38:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:38:45 --> Model Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Model Class Initialized
DEBUG - 2017-04-15 04:38:45 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:38:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:38:45 --> Final output sent to browser
DEBUG - 2017-04-15 04:38:45 --> Total execution time: 0.0292
DEBUG - 2017-04-15 04:39:53 --> Config Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:39:53 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:39:53 --> URI Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Router Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Output Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Security Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Input Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:39:53 --> Language Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Loader Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:39:53 --> Controller Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:39:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:39:53 --> Model Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Model Class Initialized
DEBUG - 2017-04-15 04:39:53 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:39:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:39:53 --> Final output sent to browser
DEBUG - 2017-04-15 04:39:53 --> Total execution time: 0.0286
DEBUG - 2017-04-15 04:41:09 --> Config Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:41:09 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:41:09 --> URI Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Router Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Output Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Security Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Input Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:41:09 --> Language Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Loader Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:41:09 --> Controller Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:41:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:41:09 --> Model Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Model Class Initialized
DEBUG - 2017-04-15 04:41:09 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:41:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:41:09 --> Final output sent to browser
DEBUG - 2017-04-15 04:41:09 --> Total execution time: 0.0290
DEBUG - 2017-04-15 04:43:09 --> Config Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:43:09 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:43:09 --> URI Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Router Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Output Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Security Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Input Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:43:09 --> Language Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Loader Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:43:09 --> Controller Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:43:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:43:09 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:09 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:43:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:43:09 --> Final output sent to browser
DEBUG - 2017-04-15 04:43:09 --> Total execution time: 0.0292
DEBUG - 2017-04-15 04:43:22 --> Config Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:43:22 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:43:22 --> URI Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Router Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Output Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Security Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Input Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:43:22 --> Language Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Loader Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:43:22 --> Controller Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:43:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:43:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:22 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:43:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:43:22 --> Final output sent to browser
DEBUG - 2017-04-15 04:43:22 --> Total execution time: 0.0290
DEBUG - 2017-04-15 04:43:31 --> Config Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:43:31 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:43:31 --> URI Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Router Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Output Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Security Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Input Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:43:31 --> Language Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Loader Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:43:31 --> Controller Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:43:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:43:31 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:31 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:43:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:43:31 --> Final output sent to browser
DEBUG - 2017-04-15 04:43:31 --> Total execution time: 0.0293
DEBUG - 2017-04-15 04:43:38 --> Config Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:43:38 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:43:38 --> URI Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Router Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Output Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Security Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Input Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:43:38 --> Language Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Loader Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:43:38 --> Controller Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:43:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:43:38 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Model Class Initialized
DEBUG - 2017-04-15 04:43:38 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:43:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:43:38 --> Final output sent to browser
DEBUG - 2017-04-15 04:43:38 --> Total execution time: 0.0292
DEBUG - 2017-04-15 04:44:22 --> Config Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:44:22 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:44:22 --> URI Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Router Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Output Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Security Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Input Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:44:22 --> Language Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Loader Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:44:22 --> Controller Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:44:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:44:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:44:22 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:44:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:44:22 --> Final output sent to browser
DEBUG - 2017-04-15 04:44:22 --> Total execution time: 0.0293
DEBUG - 2017-04-15 04:44:30 --> Config Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:44:30 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:44:30 --> URI Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Router Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Output Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Security Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Input Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:44:30 --> Language Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Loader Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:44:30 --> Controller Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:44:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:44:30 --> Model Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Model Class Initialized
DEBUG - 2017-04-15 04:44:30 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:44:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:44:30 --> Final output sent to browser
DEBUG - 2017-04-15 04:44:30 --> Total execution time: 0.0287
DEBUG - 2017-04-15 04:45:01 --> Config Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:45:01 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:45:01 --> URI Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Router Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Output Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Security Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Input Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:45:01 --> Language Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Loader Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:45:01 --> Controller Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:45:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:45:01 --> Model Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Model Class Initialized
DEBUG - 2017-04-15 04:45:01 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:45:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:45:01 --> Final output sent to browser
DEBUG - 2017-04-15 04:45:01 --> Total execution time: 0.0285
DEBUG - 2017-04-15 04:46:04 --> Config Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:46:04 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:46:04 --> URI Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Router Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Output Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Security Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Input Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:46:04 --> Language Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Loader Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:46:04 --> Controller Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:46:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:46:04 --> Model Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Model Class Initialized
DEBUG - 2017-04-15 04:46:04 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:46:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:46:04 --> Final output sent to browser
DEBUG - 2017-04-15 04:46:04 --> Total execution time: 0.0289
DEBUG - 2017-04-15 04:47:04 --> Config Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:47:04 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:47:04 --> URI Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Router Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Output Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Security Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Input Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:47:04 --> Language Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Loader Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:47:04 --> Controller Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:47:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:47:04 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:04 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:47:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:47:04 --> Final output sent to browser
DEBUG - 2017-04-15 04:47:04 --> Total execution time: 0.0292
DEBUG - 2017-04-15 04:47:12 --> Config Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:47:12 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:47:12 --> URI Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Router Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Output Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Security Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Input Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:47:12 --> Language Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Loader Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:47:12 --> Controller Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:47:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:47:12 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:12 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:47:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:47:12 --> Final output sent to browser
DEBUG - 2017-04-15 04:47:12 --> Total execution time: 0.0293
DEBUG - 2017-04-15 04:47:19 --> Config Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:47:19 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:47:19 --> URI Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Router Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Output Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Security Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Input Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:47:19 --> Language Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Loader Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:47:19 --> Controller Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:47:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:47:19 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:19 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:47:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:47:19 --> Final output sent to browser
DEBUG - 2017-04-15 04:47:19 --> Total execution time: 0.0289
DEBUG - 2017-04-15 04:47:43 --> Config Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:47:43 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:47:43 --> URI Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Router Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Output Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Security Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Input Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:47:43 --> Language Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Loader Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:47:43 --> Controller Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:47:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:47:43 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:43 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:47:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:47:43 --> Final output sent to browser
DEBUG - 2017-04-15 04:47:43 --> Total execution time: 0.0290
DEBUG - 2017-04-15 04:47:54 --> Config Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:47:54 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:47:54 --> URI Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Router Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Output Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Security Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Input Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:47:54 --> Language Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Loader Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:47:54 --> Controller Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:47:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:47:54 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:54 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:47:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:47:54 --> Final output sent to browser
DEBUG - 2017-04-15 04:47:54 --> Total execution time: 0.0288
DEBUG - 2017-04-15 04:47:56 --> Config Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:47:56 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:47:56 --> URI Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Router Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Output Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Security Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Input Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:47:56 --> Language Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Loader Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:47:56 --> Controller Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:47:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:47:56 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Model Class Initialized
DEBUG - 2017-04-15 04:47:56 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:47:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:47:56 --> Final output sent to browser
DEBUG - 2017-04-15 04:47:56 --> Total execution time: 0.0283
DEBUG - 2017-04-15 04:48:09 --> Config Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:48:09 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:48:09 --> URI Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Router Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Output Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Security Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Input Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:48:09 --> Language Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Loader Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:48:09 --> Controller Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:48:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:48:09 --> Model Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Model Class Initialized
DEBUG - 2017-04-15 04:48:09 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:48:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:48:09 --> Final output sent to browser
DEBUG - 2017-04-15 04:48:09 --> Total execution time: 0.0289
DEBUG - 2017-04-15 04:48:22 --> Config Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:48:22 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:48:22 --> URI Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Router Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Output Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Security Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Input Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:48:22 --> Language Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Loader Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:48:22 --> Controller Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:48:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:48:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Model Class Initialized
DEBUG - 2017-04-15 04:48:22 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:48:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:48:22 --> Final output sent to browser
DEBUG - 2017-04-15 04:48:22 --> Total execution time: 0.0287
DEBUG - 2017-04-15 04:48:56 --> Config Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:48:56 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:48:56 --> URI Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Router Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Output Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Security Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Input Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:48:56 --> Language Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Loader Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:48:56 --> Controller Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:48:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:48:56 --> Model Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Model Class Initialized
DEBUG - 2017-04-15 04:48:56 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:48:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:48:56 --> Final output sent to browser
DEBUG - 2017-04-15 04:48:56 --> Total execution time: 0.0284
DEBUG - 2017-04-15 04:49:02 --> Config Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:49:02 --> URI Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Router Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Output Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Security Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Input Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:49:02 --> Language Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Loader Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:49:02 --> Controller Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:49:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:49:02 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:02 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:49:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:49:02 --> Final output sent to browser
DEBUG - 2017-04-15 04:49:02 --> Total execution time: 0.0284
DEBUG - 2017-04-15 04:49:10 --> Config Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:49:10 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:49:10 --> URI Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Router Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Output Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Security Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Input Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:49:10 --> Language Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Loader Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:49:10 --> Controller Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:49:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:49:10 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:10 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:49:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:49:10 --> Final output sent to browser
DEBUG - 2017-04-15 04:49:10 --> Total execution time: 0.0286
DEBUG - 2017-04-15 04:49:19 --> Config Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:49:19 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:49:19 --> URI Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Router Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Output Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Security Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Input Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:49:19 --> Language Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Loader Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:49:19 --> Controller Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:49:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:49:19 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:19 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:49:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:49:19 --> Final output sent to browser
DEBUG - 2017-04-15 04:49:19 --> Total execution time: 0.0290
DEBUG - 2017-04-15 04:49:28 --> Config Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:49:28 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:49:28 --> URI Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Router Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Output Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Security Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Input Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:49:28 --> Language Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Loader Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:49:28 --> Controller Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:49:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:49:28 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:28 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:49:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:49:28 --> Final output sent to browser
DEBUG - 2017-04-15 04:49:28 --> Total execution time: 0.0292
DEBUG - 2017-04-15 04:49:35 --> Config Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:49:35 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:49:35 --> URI Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Router Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Output Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Security Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Input Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:49:35 --> Language Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Loader Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:49:35 --> Controller Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:49:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:49:35 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:35 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:49:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:49:35 --> Final output sent to browser
DEBUG - 2017-04-15 04:49:35 --> Total execution time: 0.0289
DEBUG - 2017-04-15 04:49:50 --> Config Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:49:50 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:49:50 --> URI Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Router Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Output Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Security Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Input Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:49:50 --> Language Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Loader Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:49:50 --> Controller Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:49:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:49:50 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Model Class Initialized
DEBUG - 2017-04-15 04:49:50 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:49:50 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:49:50 --> Final output sent to browser
DEBUG - 2017-04-15 04:49:50 --> Total execution time: 0.0287
DEBUG - 2017-04-15 04:50:11 --> Config Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:50:11 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:50:11 --> URI Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Router Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Output Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Security Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Input Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:50:11 --> Language Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Loader Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:50:11 --> Controller Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:50:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:50:11 --> Model Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Model Class Initialized
DEBUG - 2017-04-15 04:50:11 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:50:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:50:11 --> Final output sent to browser
DEBUG - 2017-04-15 04:50:11 --> Total execution time: 0.0297
DEBUG - 2017-04-15 04:50:30 --> Config Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:50:30 --> URI Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Router Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Output Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Security Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Input Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:50:30 --> Language Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Loader Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:50:30 --> Controller Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:50:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:50:30 --> Model Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Model Class Initialized
DEBUG - 2017-04-15 04:50:30 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:50:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:50:30 --> Final output sent to browser
DEBUG - 2017-04-15 04:50:30 --> Total execution time: 0.0285
DEBUG - 2017-04-15 04:50:48 --> Config Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Hooks Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Utf8 Class Initialized
DEBUG - 2017-04-15 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 04:50:48 --> URI Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Router Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Output Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Security Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Input Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 04:50:48 --> Language Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Loader Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Helper loaded: date_helper
DEBUG - 2017-04-15 04:50:48 --> Controller Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Database Driver Class Initialized
ERROR - 2017-04-15 04:50:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 04:50:48 --> Model Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Model Class Initialized
DEBUG - 2017-04-15 04:50:48 --> Helper loaded: url_helper
DEBUG - 2017-04-15 04:50:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 04:50:48 --> Final output sent to browser
DEBUG - 2017-04-15 04:50:48 --> Total execution time: 0.0284
DEBUG - 2017-04-15 05:04:58 --> Config Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:04:58 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:04:58 --> URI Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Router Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Output Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Security Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Input Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:04:58 --> Language Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Loader Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:04:58 --> Controller Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:04:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:04:58 --> Model Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Model Class Initialized
DEBUG - 2017-04-15 05:04:58 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:04:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:04:58 --> Final output sent to browser
DEBUG - 2017-04-15 05:04:58 --> Total execution time: 0.0319
DEBUG - 2017-04-15 05:12:31 --> Config Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:12:31 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:12:31 --> URI Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Router Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Output Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Security Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Input Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:12:31 --> Language Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Loader Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:12:31 --> Controller Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:12:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:12:31 --> Model Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Model Class Initialized
DEBUG - 2017-04-15 05:12:31 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:12:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:12:31 --> Final output sent to browser
DEBUG - 2017-04-15 05:12:31 --> Total execution time: 0.0299
DEBUG - 2017-04-15 05:13:28 --> Config Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:13:28 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:13:28 --> URI Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Router Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Output Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Security Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Input Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:13:28 --> Language Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Loader Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:13:28 --> Controller Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:13:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:13:28 --> Model Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Model Class Initialized
DEBUG - 2017-04-15 05:13:28 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:13:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:13:28 --> Final output sent to browser
DEBUG - 2017-04-15 05:13:28 --> Total execution time: 0.0302
DEBUG - 2017-04-15 05:15:11 --> Config Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:15:11 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:15:11 --> URI Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Router Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Output Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Security Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Input Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:15:11 --> Language Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Loader Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:15:11 --> Controller Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:15:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:15:11 --> Model Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Model Class Initialized
DEBUG - 2017-04-15 05:15:11 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:15:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:15:11 --> Final output sent to browser
DEBUG - 2017-04-15 05:15:11 --> Total execution time: 0.0295
DEBUG - 2017-04-15 05:17:25 --> Config Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:17:25 --> URI Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Router Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Output Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Security Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Input Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:17:25 --> Language Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Loader Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:17:25 --> Controller Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:17:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:17:25 --> Model Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Model Class Initialized
DEBUG - 2017-04-15 05:17:25 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:17:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:17:25 --> Final output sent to browser
DEBUG - 2017-04-15 05:17:25 --> Total execution time: 0.0300
DEBUG - 2017-04-15 05:21:30 --> Config Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:21:30 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:21:30 --> URI Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Router Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Output Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Security Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Input Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:21:30 --> Language Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Loader Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:21:30 --> Controller Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:21:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:21:30 --> Model Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Model Class Initialized
DEBUG - 2017-04-15 05:21:30 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:21:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:21:30 --> Final output sent to browser
DEBUG - 2017-04-15 05:21:30 --> Total execution time: 0.0321
DEBUG - 2017-04-15 05:27:39 --> Config Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:27:39 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:27:39 --> URI Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Router Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Output Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Security Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Input Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:27:39 --> Language Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Loader Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:27:39 --> Controller Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:27:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:27:39 --> Model Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Model Class Initialized
DEBUG - 2017-04-15 05:27:39 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:27:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:27:39 --> Final output sent to browser
DEBUG - 2017-04-15 05:27:39 --> Total execution time: 0.0292
DEBUG - 2017-04-15 05:29:14 --> Config Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:29:14 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:29:14 --> URI Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Router Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Output Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Security Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Input Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:29:14 --> Language Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Loader Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:29:14 --> Controller Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:29:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:29:14 --> Model Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Model Class Initialized
DEBUG - 2017-04-15 05:29:14 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:29:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:29:14 --> Final output sent to browser
DEBUG - 2017-04-15 05:29:14 --> Total execution time: 0.0294
DEBUG - 2017-04-15 05:31:09 --> Config Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:31:09 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:31:09 --> URI Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Router Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Output Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Security Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Input Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:31:09 --> Language Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Loader Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:31:09 --> Controller Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:31:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:31:09 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:09 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:31:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:31:09 --> Final output sent to browser
DEBUG - 2017-04-15 05:31:09 --> Total execution time: 0.0286
DEBUG - 2017-04-15 05:31:11 --> Config Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:31:11 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:31:11 --> URI Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Router Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Output Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Security Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Input Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:31:11 --> Language Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Loader Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:31:11 --> Controller Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:31:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:31:11 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:11 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:31:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:31:11 --> Final output sent to browser
DEBUG - 2017-04-15 05:31:11 --> Total execution time: 0.0290
DEBUG - 2017-04-15 05:31:53 --> Config Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:31:53 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:31:53 --> URI Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Router Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Output Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Security Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Input Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:31:53 --> Language Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Loader Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:31:53 --> Controller Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:31:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:31:53 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:53 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:31:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:31:53 --> Final output sent to browser
DEBUG - 2017-04-15 05:31:53 --> Total execution time: 0.0292
DEBUG - 2017-04-15 05:31:56 --> Config Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:31:56 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:31:56 --> URI Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Router Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Output Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Security Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Input Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:31:56 --> Language Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Loader Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:31:56 --> Controller Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:31:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:31:56 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Model Class Initialized
DEBUG - 2017-04-15 05:31:56 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:31:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:31:56 --> Final output sent to browser
DEBUG - 2017-04-15 05:31:56 --> Total execution time: 0.0289
DEBUG - 2017-04-15 05:32:35 --> Config Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:32:35 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:32:35 --> URI Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Router Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Output Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Security Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Input Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:32:35 --> Language Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Loader Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:32:35 --> Controller Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:32:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:32:35 --> Model Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Model Class Initialized
DEBUG - 2017-04-15 05:32:35 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:32:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:32:35 --> Final output sent to browser
DEBUG - 2017-04-15 05:32:35 --> Total execution time: 0.0289
DEBUG - 2017-04-15 05:32:36 --> Config Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:32:36 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:32:36 --> URI Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Router Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Output Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Security Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Input Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:32:36 --> Language Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Loader Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:32:36 --> Controller Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:32:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:32:36 --> Model Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Model Class Initialized
DEBUG - 2017-04-15 05:32:36 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:32:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:32:37 --> Final output sent to browser
DEBUG - 2017-04-15 05:32:37 --> Total execution time: 0.0291
DEBUG - 2017-04-15 05:38:49 --> Config Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:38:49 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:38:49 --> URI Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Router Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Output Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Security Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Input Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:38:49 --> Language Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Loader Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:38:49 --> Controller Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:38:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:38:49 --> Model Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Model Class Initialized
DEBUG - 2017-04-15 05:38:49 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:38:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:38:49 --> Final output sent to browser
DEBUG - 2017-04-15 05:38:49 --> Total execution time: 0.0301
DEBUG - 2017-04-15 05:41:05 --> Config Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:41:05 --> URI Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Router Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Output Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Security Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Input Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:41:05 --> Language Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Loader Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:41:05 --> Controller Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:41:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:41:05 --> Model Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Model Class Initialized
DEBUG - 2017-04-15 05:41:05 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:41:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:41:05 --> Final output sent to browser
DEBUG - 2017-04-15 05:41:05 --> Total execution time: 0.0301
DEBUG - 2017-04-15 05:45:40 --> Config Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:45:40 --> URI Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Router Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Output Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Security Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Input Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:45:40 --> Language Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Loader Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:45:40 --> Controller Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:45:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:45:40 --> Model Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Model Class Initialized
DEBUG - 2017-04-15 05:45:40 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:45:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:45:40 --> Final output sent to browser
DEBUG - 2017-04-15 05:45:40 --> Total execution time: 0.0293
DEBUG - 2017-04-15 05:48:31 --> Config Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:48:31 --> URI Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Router Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Output Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Security Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Input Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:48:31 --> Language Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Loader Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:48:31 --> Controller Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:48:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:48:31 --> Model Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Model Class Initialized
DEBUG - 2017-04-15 05:48:31 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:48:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:48:31 --> Final output sent to browser
DEBUG - 2017-04-15 05:48:31 --> Total execution time: 0.0298
DEBUG - 2017-04-15 05:52:55 --> Config Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:52:55 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:52:55 --> URI Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Router Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Output Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Security Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Input Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:52:55 --> Language Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Loader Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:52:55 --> Controller Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:52:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:52:55 --> Model Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Model Class Initialized
DEBUG - 2017-04-15 05:52:55 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:52:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:52:55 --> Final output sent to browser
DEBUG - 2017-04-15 05:52:55 --> Total execution time: 0.0306
DEBUG - 2017-04-15 05:52:57 --> Config Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:52:57 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:52:57 --> URI Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Router Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Output Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Security Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Input Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:52:57 --> Language Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Loader Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:52:57 --> Controller Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:52:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:52:57 --> Model Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Model Class Initialized
DEBUG - 2017-04-15 05:52:57 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:52:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:52:57 --> Final output sent to browser
DEBUG - 2017-04-15 05:52:57 --> Total execution time: 0.0299
DEBUG - 2017-04-15 05:53:41 --> Config Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:53:41 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:53:41 --> URI Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Router Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Output Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Security Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Input Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:53:41 --> Language Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Loader Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:53:41 --> Controller Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:53:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:53:41 --> Model Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Model Class Initialized
DEBUG - 2017-04-15 05:53:41 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:53:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:53:41 --> Final output sent to browser
DEBUG - 2017-04-15 05:53:41 --> Total execution time: 0.0303
DEBUG - 2017-04-15 05:53:45 --> Config Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:53:45 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:53:45 --> URI Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Router Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Output Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Security Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Input Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:53:45 --> Language Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Loader Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:53:45 --> Controller Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:53:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:53:45 --> Model Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Model Class Initialized
DEBUG - 2017-04-15 05:53:45 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:53:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:53:45 --> Final output sent to browser
DEBUG - 2017-04-15 05:53:45 --> Total execution time: 0.0298
DEBUG - 2017-04-15 05:55:11 --> Config Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:55:11 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:55:11 --> URI Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Router Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Output Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Security Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Input Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:55:11 --> Language Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Loader Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:55:11 --> Controller Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:55:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:55:11 --> Model Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Model Class Initialized
DEBUG - 2017-04-15 05:55:11 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:55:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:55:11 --> Final output sent to browser
DEBUG - 2017-04-15 05:55:11 --> Total execution time: 0.0287
DEBUG - 2017-04-15 05:55:37 --> Config Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:55:37 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:55:37 --> URI Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Router Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Output Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Security Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Input Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:55:37 --> Language Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Loader Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:55:37 --> Controller Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:55:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:55:37 --> Model Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Model Class Initialized
DEBUG - 2017-04-15 05:55:37 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:55:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:55:37 --> Final output sent to browser
DEBUG - 2017-04-15 05:55:37 --> Total execution time: 0.0291
DEBUG - 2017-04-15 05:56:37 --> Config Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:56:37 --> URI Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Router Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Output Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Security Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Input Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:56:37 --> Language Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Loader Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:56:37 --> Controller Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:56:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:56:37 --> Model Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Model Class Initialized
DEBUG - 2017-04-15 05:56:37 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:56:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:56:37 --> Final output sent to browser
DEBUG - 2017-04-15 05:56:37 --> Total execution time: 0.0289
DEBUG - 2017-04-15 05:57:19 --> Config Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:57:19 --> URI Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Router Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Output Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Security Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Input Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:57:19 --> Language Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Loader Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:57:19 --> Controller Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:57:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:57:19 --> Model Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Model Class Initialized
DEBUG - 2017-04-15 05:57:19 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:57:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:57:19 --> Final output sent to browser
DEBUG - 2017-04-15 05:57:19 --> Total execution time: 0.0288
DEBUG - 2017-04-15 05:57:25 --> Config Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:57:25 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:57:25 --> URI Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Router Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Output Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Security Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Input Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:57:25 --> Language Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Loader Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:57:25 --> Controller Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:57:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:57:25 --> Model Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Model Class Initialized
DEBUG - 2017-04-15 05:57:25 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:57:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:57:25 --> Final output sent to browser
DEBUG - 2017-04-15 05:57:25 --> Total execution time: 0.0294
DEBUG - 2017-04-15 05:57:27 --> Config Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:57:27 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:57:27 --> URI Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Router Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Output Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Security Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Input Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:57:27 --> Language Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Loader Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:57:27 --> Controller Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:57:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:57:27 --> Model Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Model Class Initialized
DEBUG - 2017-04-15 05:57:27 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:57:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:57:27 --> Final output sent to browser
DEBUG - 2017-04-15 05:57:27 --> Total execution time: 0.0288
DEBUG - 2017-04-15 05:58:16 --> Config Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:58:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:58:16 --> URI Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Router Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Output Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Security Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Input Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:58:16 --> Language Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Loader Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:58:16 --> Controller Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:58:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:58:16 --> Model Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Model Class Initialized
DEBUG - 2017-04-15 05:58:16 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:58:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:58:16 --> Final output sent to browser
DEBUG - 2017-04-15 05:58:16 --> Total execution time: 0.0286
DEBUG - 2017-04-15 05:58:18 --> Config Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Hooks Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Utf8 Class Initialized
DEBUG - 2017-04-15 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 05:58:18 --> URI Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Router Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Output Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Security Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Input Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 05:58:18 --> Language Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Loader Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Helper loaded: date_helper
DEBUG - 2017-04-15 05:58:18 --> Controller Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Database Driver Class Initialized
ERROR - 2017-04-15 05:58:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 05:58:18 --> Model Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Model Class Initialized
DEBUG - 2017-04-15 05:58:18 --> Helper loaded: url_helper
DEBUG - 2017-04-15 05:58:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 05:58:18 --> Final output sent to browser
DEBUG - 2017-04-15 05:58:18 --> Total execution time: 0.0290
DEBUG - 2017-04-15 06:00:30 --> Config Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:00:30 --> URI Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Router Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Output Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Security Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Input Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:00:30 --> Language Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Loader Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:00:30 --> Controller Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:00:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:00:30 --> Model Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Model Class Initialized
DEBUG - 2017-04-15 06:00:30 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:00:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:00:30 --> Final output sent to browser
DEBUG - 2017-04-15 06:00:30 --> Total execution time: 0.0290
DEBUG - 2017-04-15 06:01:13 --> Config Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:01:13 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:01:13 --> URI Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Router Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Output Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Security Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Input Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:01:13 --> Language Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Loader Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:01:13 --> Controller Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:01:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:01:13 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:13 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:01:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:01:13 --> Final output sent to browser
DEBUG - 2017-04-15 06:01:13 --> Total execution time: 0.0286
DEBUG - 2017-04-15 06:01:16 --> Config Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:01:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:01:16 --> URI Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Router Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Output Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Security Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Input Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:01:16 --> Language Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Loader Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:01:16 --> Controller Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:01:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:01:16 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:16 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:01:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:01:16 --> Final output sent to browser
DEBUG - 2017-04-15 06:01:16 --> Total execution time: 0.0283
DEBUG - 2017-04-15 06:01:35 --> Config Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:01:35 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:01:35 --> URI Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Router Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Output Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Security Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Input Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:01:35 --> Language Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Loader Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:01:35 --> Controller Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:01:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:01:35 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:35 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:01:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:01:35 --> Final output sent to browser
DEBUG - 2017-04-15 06:01:35 --> Total execution time: 0.0297
DEBUG - 2017-04-15 06:01:42 --> Config Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:01:42 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:01:42 --> URI Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Router Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Output Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Security Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Input Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:01:42 --> Language Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Loader Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:01:42 --> Controller Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:01:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:01:42 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Model Class Initialized
DEBUG - 2017-04-15 06:01:42 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:01:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:01:42 --> Final output sent to browser
DEBUG - 2017-04-15 06:01:42 --> Total execution time: 0.0296
DEBUG - 2017-04-15 06:02:04 --> Config Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:02:04 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:02:04 --> URI Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Router Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Output Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Security Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Input Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:02:04 --> Language Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Loader Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:02:04 --> Controller Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:02:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:02:04 --> Model Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Model Class Initialized
DEBUG - 2017-04-15 06:02:04 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:02:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:02:04 --> Final output sent to browser
DEBUG - 2017-04-15 06:02:04 --> Total execution time: 0.0286
DEBUG - 2017-04-15 06:02:12 --> Config Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:02:12 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:02:12 --> URI Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Router Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Output Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Security Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Input Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:02:12 --> Language Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Loader Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:02:12 --> Controller Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:02:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:02:12 --> Model Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Model Class Initialized
DEBUG - 2017-04-15 06:02:12 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:02:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:02:12 --> Final output sent to browser
DEBUG - 2017-04-15 06:02:12 --> Total execution time: 0.0298
DEBUG - 2017-04-15 06:03:33 --> Config Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:03:33 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:03:33 --> URI Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Router Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Output Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Security Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Input Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:03:33 --> Language Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Loader Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:03:33 --> Controller Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:03:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:03:33 --> Model Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Model Class Initialized
DEBUG - 2017-04-15 06:03:33 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:03:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:03:33 --> Final output sent to browser
DEBUG - 2017-04-15 06:03:33 --> Total execution time: 0.0298
DEBUG - 2017-04-15 06:08:00 --> Config Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:08:00 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:08:00 --> URI Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Router Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Output Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Security Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Input Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:08:00 --> Language Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Loader Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:08:00 --> Controller Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:08:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:08:00 --> Model Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Model Class Initialized
DEBUG - 2017-04-15 06:08:00 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:08:00 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:08:00 --> Final output sent to browser
DEBUG - 2017-04-15 06:08:00 --> Total execution time: 0.0288
DEBUG - 2017-04-15 06:13:18 --> Config Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:13:18 --> URI Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Router Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Output Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Security Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Input Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:13:18 --> Language Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Loader Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:13:18 --> Controller Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:13:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:13:18 --> Model Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Model Class Initialized
DEBUG - 2017-04-15 06:13:18 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:13:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:13:18 --> Final output sent to browser
DEBUG - 2017-04-15 06:13:18 --> Total execution time: 0.0299
DEBUG - 2017-04-15 06:57:27 --> Config Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Hooks Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Utf8 Class Initialized
DEBUG - 2017-04-15 06:57:27 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 06:57:27 --> URI Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Router Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Output Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Security Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Input Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 06:57:27 --> Language Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Loader Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Helper loaded: date_helper
DEBUG - 2017-04-15 06:57:27 --> Controller Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Database Driver Class Initialized
ERROR - 2017-04-15 06:57:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 06:57:27 --> Model Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Model Class Initialized
DEBUG - 2017-04-15 06:57:27 --> Helper loaded: url_helper
DEBUG - 2017-04-15 06:57:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 06:57:27 --> Final output sent to browser
DEBUG - 2017-04-15 06:57:27 --> Total execution time: 0.0352
DEBUG - 2017-04-15 09:07:38 --> Config Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Hooks Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Utf8 Class Initialized
DEBUG - 2017-04-15 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 09:07:38 --> URI Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Router Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Output Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Security Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Input Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 09:07:38 --> Language Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Loader Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Helper loaded: date_helper
DEBUG - 2017-04-15 09:07:38 --> Controller Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Database Driver Class Initialized
ERROR - 2017-04-15 09:07:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 09:07:38 --> Model Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Model Class Initialized
DEBUG - 2017-04-15 09:07:38 --> Helper loaded: url_helper
DEBUG - 2017-04-15 09:07:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 09:07:38 --> Final output sent to browser
DEBUG - 2017-04-15 09:07:38 --> Total execution time: 0.0352
DEBUG - 2017-04-15 12:26:58 --> Config Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Hooks Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Utf8 Class Initialized
DEBUG - 2017-04-15 12:26:58 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 12:26:58 --> URI Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Router Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Output Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Security Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Input Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 12:26:58 --> Language Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Loader Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Helper loaded: date_helper
DEBUG - 2017-04-15 12:26:58 --> Controller Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Database Driver Class Initialized
ERROR - 2017-04-15 12:26:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 12:26:58 --> Model Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Model Class Initialized
DEBUG - 2017-04-15 12:26:58 --> Helper loaded: url_helper
DEBUG - 2017-04-15 12:26:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 12:26:58 --> Final output sent to browser
DEBUG - 2017-04-15 12:26:58 --> Total execution time: 0.0309
DEBUG - 2017-04-15 13:15:37 --> Config Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Hooks Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Utf8 Class Initialized
DEBUG - 2017-04-15 13:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 13:15:37 --> URI Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Router Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Output Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Security Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Input Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 13:15:37 --> Language Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Loader Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Helper loaded: date_helper
DEBUG - 2017-04-15 13:15:37 --> Controller Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Database Driver Class Initialized
ERROR - 2017-04-15 13:15:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 13:15:37 --> Model Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Model Class Initialized
DEBUG - 2017-04-15 13:15:37 --> Helper loaded: url_helper
DEBUG - 2017-04-15 13:15:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 13:15:38 --> Final output sent to browser
DEBUG - 2017-04-15 13:15:38 --> Total execution time: 0.0369
DEBUG - 2017-04-15 13:16:00 --> Config Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Hooks Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Utf8 Class Initialized
DEBUG - 2017-04-15 13:16:00 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 13:16:00 --> URI Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Router Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Output Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Security Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Input Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 13:16:00 --> Language Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Loader Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Helper loaded: date_helper
DEBUG - 2017-04-15 13:16:00 --> Controller Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Database Driver Class Initialized
ERROR - 2017-04-15 13:16:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 13:16:00 --> Model Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Model Class Initialized
DEBUG - 2017-04-15 13:16:00 --> Helper loaded: url_helper
DEBUG - 2017-04-15 13:16:00 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 13:16:00 --> Final output sent to browser
DEBUG - 2017-04-15 13:16:00 --> Total execution time: 0.0310
DEBUG - 2017-04-15 13:23:11 --> Config Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Hooks Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Utf8 Class Initialized
DEBUG - 2017-04-15 13:23:11 --> UTF-8 Support Enabled
DEBUG - 2017-04-15 13:23:11 --> URI Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Router Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Output Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Security Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Input Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-15 13:23:11 --> Language Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Loader Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Helper loaded: date_helper
DEBUG - 2017-04-15 13:23:11 --> Controller Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Database Driver Class Initialized
ERROR - 2017-04-15 13:23:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-15 13:23:11 --> Model Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Model Class Initialized
DEBUG - 2017-04-15 13:23:11 --> Helper loaded: url_helper
DEBUG - 2017-04-15 13:23:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-15 13:23:11 --> Final output sent to browser
DEBUG - 2017-04-15 13:23:11 --> Total execution time: 0.0313
