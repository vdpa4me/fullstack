<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-12-02 00:37:59 --> Config Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Hooks Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Utf8 Class Initialized
DEBUG - 2017-12-02 00:37:59 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 00:37:59 --> URI Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Router Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Output Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Security Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Input Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 00:37:59 --> Language Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Loader Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Helper loaded: date_helper
DEBUG - 2017-12-02 00:37:59 --> Controller Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Database Driver Class Initialized
ERROR - 2017-12-02 00:37:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 00:37:59 --> Model Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Model Class Initialized
DEBUG - 2017-12-02 00:37:59 --> Helper loaded: url_helper
DEBUG - 2017-12-02 00:37:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 00:37:59 --> Final output sent to browser
DEBUG - 2017-12-02 00:37:59 --> Total execution time: 0.0252
DEBUG - 2017-12-02 00:54:33 --> Config Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Hooks Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Utf8 Class Initialized
DEBUG - 2017-12-02 00:54:33 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 00:54:33 --> URI Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Router Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Output Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Security Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Input Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 00:54:33 --> Language Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Loader Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Helper loaded: date_helper
DEBUG - 2017-12-02 00:54:33 --> Controller Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Database Driver Class Initialized
ERROR - 2017-12-02 00:54:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 00:54:33 --> Model Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Model Class Initialized
DEBUG - 2017-12-02 00:54:33 --> Helper loaded: url_helper
DEBUG - 2017-12-02 00:54:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 00:54:33 --> Final output sent to browser
DEBUG - 2017-12-02 00:54:33 --> Total execution time: 0.0198
DEBUG - 2017-12-02 00:55:26 --> Config Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Hooks Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Utf8 Class Initialized
DEBUG - 2017-12-02 00:55:26 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 00:55:26 --> URI Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Router Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Output Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Security Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Input Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 00:55:26 --> Language Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Loader Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Helper loaded: date_helper
DEBUG - 2017-12-02 00:55:26 --> Controller Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Database Driver Class Initialized
ERROR - 2017-12-02 00:55:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 00:55:26 --> Model Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Model Class Initialized
DEBUG - 2017-12-02 00:55:26 --> Helper loaded: url_helper
DEBUG - 2017-12-02 00:55:26 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 00:55:26 --> Final output sent to browser
DEBUG - 2017-12-02 00:55:26 --> Total execution time: 0.0205
DEBUG - 2017-12-02 09:53:53 --> Config Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Hooks Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Utf8 Class Initialized
DEBUG - 2017-12-02 09:53:53 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 09:53:53 --> URI Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Router Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Output Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Security Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Input Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 09:53:53 --> Language Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Loader Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Helper loaded: date_helper
DEBUG - 2017-12-02 09:53:53 --> Controller Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Database Driver Class Initialized
ERROR - 2017-12-02 09:53:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 09:53:53 --> Model Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Model Class Initialized
DEBUG - 2017-12-02 09:53:53 --> Helper loaded: url_helper
DEBUG - 2017-12-02 09:53:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 09:53:53 --> Final output sent to browser
DEBUG - 2017-12-02 09:53:53 --> Total execution time: 0.0272
DEBUG - 2017-12-02 09:53:59 --> Config Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Hooks Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Utf8 Class Initialized
DEBUG - 2017-12-02 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 09:53:59 --> URI Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Router Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Output Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Security Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Input Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 09:53:59 --> Language Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Loader Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Helper loaded: date_helper
DEBUG - 2017-12-02 09:53:59 --> Controller Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Database Driver Class Initialized
ERROR - 2017-12-02 09:53:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 09:53:59 --> Model Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Model Class Initialized
DEBUG - 2017-12-02 09:53:59 --> Helper loaded: url_helper
DEBUG - 2017-12-02 09:53:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 09:53:59 --> Final output sent to browser
DEBUG - 2017-12-02 09:53:59 --> Total execution time: 0.0205
DEBUG - 2017-12-02 10:38:33 --> Config Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Hooks Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Utf8 Class Initialized
DEBUG - 2017-12-02 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 10:38:33 --> URI Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Router Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Output Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Security Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Input Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 10:38:33 --> Language Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Loader Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Helper loaded: date_helper
DEBUG - 2017-12-02 10:38:33 --> Controller Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Database Driver Class Initialized
ERROR - 2017-12-02 10:38:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 10:38:33 --> Model Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Model Class Initialized
DEBUG - 2017-12-02 10:38:33 --> Helper loaded: url_helper
DEBUG - 2017-12-02 10:38:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 10:38:33 --> Final output sent to browser
DEBUG - 2017-12-02 10:38:33 --> Total execution time: 0.0211
DEBUG - 2017-12-02 10:38:35 --> Config Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Hooks Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Utf8 Class Initialized
DEBUG - 2017-12-02 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 10:38:35 --> URI Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Router Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Output Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Security Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Input Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 10:38:35 --> Language Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Loader Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Helper loaded: date_helper
DEBUG - 2017-12-02 10:38:35 --> Controller Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Database Driver Class Initialized
ERROR - 2017-12-02 10:38:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 10:38:35 --> Model Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Model Class Initialized
DEBUG - 2017-12-02 10:38:35 --> Helper loaded: url_helper
DEBUG - 2017-12-02 10:38:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 10:38:35 --> Final output sent to browser
DEBUG - 2017-12-02 10:38:35 --> Total execution time: 0.0195
DEBUG - 2017-12-02 16:29:20 --> Config Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Hooks Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Utf8 Class Initialized
DEBUG - 2017-12-02 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 16:29:20 --> URI Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Router Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Output Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Security Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Input Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 16:29:20 --> Language Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Loader Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Helper loaded: date_helper
DEBUG - 2017-12-02 16:29:20 --> Controller Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Database Driver Class Initialized
ERROR - 2017-12-02 16:29:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 16:29:20 --> Model Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Model Class Initialized
DEBUG - 2017-12-02 16:29:20 --> Helper loaded: url_helper
DEBUG - 2017-12-02 16:29:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 16:29:20 --> Final output sent to browser
DEBUG - 2017-12-02 16:29:20 --> Total execution time: 0.0275
DEBUG - 2017-12-02 22:31:12 --> Config Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Hooks Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Utf8 Class Initialized
DEBUG - 2017-12-02 22:31:12 --> UTF-8 Support Enabled
DEBUG - 2017-12-02 22:31:12 --> URI Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Router Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Output Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Security Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Input Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-02 22:31:12 --> Language Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Loader Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Helper loaded: date_helper
DEBUG - 2017-12-02 22:31:12 --> Controller Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Database Driver Class Initialized
ERROR - 2017-12-02 22:31:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-02 22:31:12 --> Model Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Model Class Initialized
DEBUG - 2017-12-02 22:31:12 --> Helper loaded: url_helper
DEBUG - 2017-12-02 22:31:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-02 22:31:12 --> Final output sent to browser
DEBUG - 2017-12-02 22:31:12 --> Total execution time: 0.0205
