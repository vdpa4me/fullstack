<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-08-13 02:23:58 --> Config Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Hooks Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Utf8 Class Initialized
DEBUG - 2019-08-13 02:23:58 --> UTF-8 Support Enabled
DEBUG - 2019-08-13 02:23:58 --> URI Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Router Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Output Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Security Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Input Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-13 02:23:58 --> Language Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Loader Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Helper loaded: date_helper
DEBUG - 2019-08-13 02:23:58 --> Controller Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Database Driver Class Initialized
ERROR - 2019-08-13 02:23:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-13 02:23:58 --> Model Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Model Class Initialized
DEBUG - 2019-08-13 02:23:58 --> Helper loaded: url_helper
DEBUG - 2019-08-13 02:23:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-13 02:23:58 --> Final output sent to browser
DEBUG - 2019-08-13 02:23:58 --> Total execution time: 0.0471
DEBUG - 2019-08-13 07:27:33 --> Config Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Hooks Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Utf8 Class Initialized
DEBUG - 2019-08-13 07:27:33 --> UTF-8 Support Enabled
DEBUG - 2019-08-13 07:27:33 --> URI Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Router Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Output Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Security Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Input Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-13 07:27:33 --> Language Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Loader Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Helper loaded: date_helper
DEBUG - 2019-08-13 07:27:33 --> Controller Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Database Driver Class Initialized
ERROR - 2019-08-13 07:27:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-13 07:27:33 --> Model Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Model Class Initialized
DEBUG - 2019-08-13 07:27:33 --> Helper loaded: url_helper
DEBUG - 2019-08-13 07:27:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-13 07:27:33 --> Final output sent to browser
DEBUG - 2019-08-13 07:27:33 --> Total execution time: 0.0360
DEBUG - 2019-08-13 15:52:39 --> Config Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Hooks Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Utf8 Class Initialized
DEBUG - 2019-08-13 15:52:39 --> UTF-8 Support Enabled
DEBUG - 2019-08-13 15:52:39 --> URI Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Router Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Output Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Security Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Input Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-13 15:52:39 --> Language Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Loader Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Helper loaded: date_helper
DEBUG - 2019-08-13 15:52:39 --> Controller Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Database Driver Class Initialized
ERROR - 2019-08-13 15:52:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-13 15:52:39 --> Model Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Model Class Initialized
DEBUG - 2019-08-13 15:52:39 --> Helper loaded: url_helper
DEBUG - 2019-08-13 15:52:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-13 15:52:39 --> Final output sent to browser
DEBUG - 2019-08-13 15:52:39 --> Total execution time: 0.0620
DEBUG - 2019-08-13 23:34:32 --> Config Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Hooks Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Utf8 Class Initialized
DEBUG - 2019-08-13 23:34:32 --> UTF-8 Support Enabled
DEBUG - 2019-08-13 23:34:32 --> URI Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Router Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Output Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Security Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Input Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-13 23:34:32 --> Language Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Loader Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Helper loaded: date_helper
DEBUG - 2019-08-13 23:34:32 --> Controller Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Database Driver Class Initialized
ERROR - 2019-08-13 23:34:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-13 23:34:32 --> Model Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Model Class Initialized
DEBUG - 2019-08-13 23:34:32 --> Helper loaded: url_helper
DEBUG - 2019-08-13 23:34:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-13 23:34:32 --> Final output sent to browser
DEBUG - 2019-08-13 23:34:32 --> Total execution time: 0.0586
