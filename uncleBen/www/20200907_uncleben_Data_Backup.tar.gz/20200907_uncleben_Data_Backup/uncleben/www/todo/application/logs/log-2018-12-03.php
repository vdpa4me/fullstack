<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-03 02:58:42 --> Config Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Hooks Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Utf8 Class Initialized
DEBUG - 2018-12-03 02:58:42 --> UTF-8 Support Enabled
DEBUG - 2018-12-03 02:58:42 --> URI Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Router Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Output Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Security Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Input Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-03 02:58:42 --> Language Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Loader Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Helper loaded: date_helper
DEBUG - 2018-12-03 02:58:42 --> Controller Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Database Driver Class Initialized
ERROR - 2018-12-03 02:58:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-03 02:58:42 --> Model Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Model Class Initialized
DEBUG - 2018-12-03 02:58:42 --> Helper loaded: url_helper
DEBUG - 2018-12-03 02:58:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-03 02:58:42 --> Final output sent to browser
DEBUG - 2018-12-03 02:58:42 --> Total execution time: 0.0502
DEBUG - 2018-12-03 19:00:55 --> Config Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Hooks Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Utf8 Class Initialized
DEBUG - 2018-12-03 19:00:55 --> UTF-8 Support Enabled
DEBUG - 2018-12-03 19:00:55 --> URI Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Router Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Output Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Security Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Input Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-03 19:00:55 --> Language Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Loader Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Helper loaded: date_helper
DEBUG - 2018-12-03 19:00:55 --> Controller Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Database Driver Class Initialized
ERROR - 2018-12-03 19:00:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-03 19:00:55 --> Model Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Model Class Initialized
DEBUG - 2018-12-03 19:00:55 --> Helper loaded: url_helper
DEBUG - 2018-12-03 19:00:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-03 19:00:55 --> Final output sent to browser
DEBUG - 2018-12-03 19:00:55 --> Total execution time: 0.0533
DEBUG - 2018-12-03 19:35:41 --> Config Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Hooks Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Utf8 Class Initialized
DEBUG - 2018-12-03 19:35:41 --> UTF-8 Support Enabled
DEBUG - 2018-12-03 19:35:41 --> URI Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Router Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Output Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Security Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Input Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-03 19:35:41 --> Language Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Loader Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Helper loaded: date_helper
DEBUG - 2018-12-03 19:35:41 --> Controller Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Database Driver Class Initialized
ERROR - 2018-12-03 19:35:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-03 19:35:41 --> Model Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Model Class Initialized
DEBUG - 2018-12-03 19:35:41 --> Helper loaded: url_helper
DEBUG - 2018-12-03 19:35:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-03 19:35:41 --> Final output sent to browser
DEBUG - 2018-12-03 19:35:41 --> Total execution time: 0.0214
DEBUG - 2018-12-03 21:24:06 --> Config Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Hooks Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Utf8 Class Initialized
DEBUG - 2018-12-03 21:24:06 --> UTF-8 Support Enabled
DEBUG - 2018-12-03 21:24:06 --> URI Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Router Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Output Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Security Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Input Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-03 21:24:06 --> Language Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Loader Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Helper loaded: date_helper
DEBUG - 2018-12-03 21:24:06 --> Controller Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Database Driver Class Initialized
ERROR - 2018-12-03 21:24:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-03 21:24:06 --> Model Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Model Class Initialized
DEBUG - 2018-12-03 21:24:06 --> Helper loaded: url_helper
DEBUG - 2018-12-03 21:24:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-03 21:24:06 --> Final output sent to browser
DEBUG - 2018-12-03 21:24:06 --> Total execution time: 0.0645
DEBUG - 2018-12-03 21:24:10 --> Config Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Hooks Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Utf8 Class Initialized
DEBUG - 2018-12-03 21:24:10 --> UTF-8 Support Enabled
DEBUG - 2018-12-03 21:24:10 --> URI Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Router Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Output Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Security Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Input Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-03 21:24:10 --> Language Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Loader Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Helper loaded: date_helper
DEBUG - 2018-12-03 21:24:10 --> Controller Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Database Driver Class Initialized
ERROR - 2018-12-03 21:24:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-03 21:24:10 --> Model Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Model Class Initialized
DEBUG - 2018-12-03 21:24:10 --> Helper loaded: url_helper
DEBUG - 2018-12-03 21:24:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-03 21:24:11 --> Final output sent to browser
DEBUG - 2018-12-03 21:24:11 --> Total execution time: 0.0660
DEBUG - 2018-12-03 21:25:32 --> Config Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Hooks Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Utf8 Class Initialized
DEBUG - 2018-12-03 21:25:32 --> UTF-8 Support Enabled
DEBUG - 2018-12-03 21:25:32 --> URI Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Router Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Output Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Security Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Input Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-03 21:25:32 --> Language Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Loader Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Helper loaded: date_helper
DEBUG - 2018-12-03 21:25:32 --> Controller Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Database Driver Class Initialized
ERROR - 2018-12-03 21:25:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-03 21:25:32 --> Model Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Model Class Initialized
DEBUG - 2018-12-03 21:25:32 --> Helper loaded: url_helper
DEBUG - 2018-12-03 21:25:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-03 21:25:32 --> Final output sent to browser
DEBUG - 2018-12-03 21:25:32 --> Total execution time: 0.0661
