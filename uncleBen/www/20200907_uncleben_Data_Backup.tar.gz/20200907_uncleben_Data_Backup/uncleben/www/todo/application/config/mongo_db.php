<?php

/* PLEASE NOTE: Alex Bilbe (http://www.alexbilbie.com) has merged this fork of his original code back into his own. http://bitbucket.org/alexbilbie/codeigniter-mongo-library/wiki/Home
*/

$config['mongo_host'] = 'localhost';
$config['mongo_port'] = 27017;
$config['mongo_db'] = 'test';
$config['mongo_user'] = '';
$config['mongo_pass'] = '';
$config['mongo_persist'] = TRUE;
$config['mongo_persist_key'] = 'ci_mongo_persist';

?>