<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-08 06:04:55 --> Config Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Hooks Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Utf8 Class Initialized
DEBUG - 2019-04-08 06:04:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-08 06:04:55 --> URI Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Router Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Output Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Security Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Input Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-08 06:04:55 --> Language Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Loader Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Helper loaded: date_helper
DEBUG - 2019-04-08 06:04:55 --> Controller Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Database Driver Class Initialized
ERROR - 2019-04-08 06:04:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-08 06:04:55 --> Model Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Model Class Initialized
DEBUG - 2019-04-08 06:04:55 --> Helper loaded: url_helper
DEBUG - 2019-04-08 06:04:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-04-08 06:04:55 --> Final output sent to browser
DEBUG - 2019-04-08 06:04:55 --> Total execution time: 0.0418
DEBUG - 2019-04-08 06:05:06 --> Config Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Hooks Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Utf8 Class Initialized
DEBUG - 2019-04-08 06:05:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-08 06:05:06 --> URI Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Router Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Output Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Security Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Input Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-08 06:05:06 --> Language Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Loader Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Helper loaded: date_helper
DEBUG - 2019-04-08 06:05:06 --> Controller Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Database Driver Class Initialized
ERROR - 2019-04-08 06:05:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-08 06:05:06 --> Model Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Model Class Initialized
DEBUG - 2019-04-08 06:05:06 --> Helper loaded: url_helper
DEBUG - 2019-04-08 06:05:06 --> File loaded: application/views/todo/search_v.php
DEBUG - 2019-04-08 06:05:06 --> Final output sent to browser
DEBUG - 2019-04-08 06:05:06 --> Total execution time: 0.0380
DEBUG - 2019-04-08 06:05:08 --> Config Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Hooks Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Utf8 Class Initialized
DEBUG - 2019-04-08 06:05:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-08 06:05:08 --> URI Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Router Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Output Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Security Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Input Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-08 06:05:08 --> Language Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Loader Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Helper loaded: date_helper
DEBUG - 2019-04-08 06:05:08 --> Controller Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Database Driver Class Initialized
ERROR - 2019-04-08 06:05:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-08 06:05:08 --> Model Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Model Class Initialized
DEBUG - 2019-04-08 06:05:08 --> Helper loaded: url_helper
DEBUG - 2019-04-08 06:05:08 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2019-04-08 06:05:08 --> Final output sent to browser
DEBUG - 2019-04-08 06:05:08 --> Total execution time: 0.0371
DEBUG - 2019-04-08 06:05:09 --> Config Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Hooks Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Utf8 Class Initialized
DEBUG - 2019-04-08 06:05:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-08 06:05:09 --> URI Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Router Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Output Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Security Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Input Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-08 06:05:09 --> Language Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Loader Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Helper loaded: date_helper
DEBUG - 2019-04-08 06:05:09 --> Controller Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Database Driver Class Initialized
ERROR - 2019-04-08 06:05:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-08 06:05:09 --> Model Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Model Class Initialized
DEBUG - 2019-04-08 06:05:09 --> Helper loaded: url_helper
DEBUG - 2019-04-08 06:05:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-04-08 06:05:09 --> Final output sent to browser
DEBUG - 2019-04-08 06:05:09 --> Total execution time: 0.0207
DEBUG - 2019-04-08 10:40:21 --> Config Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Hooks Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Utf8 Class Initialized
DEBUG - 2019-04-08 10:40:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-08 10:40:21 --> URI Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Router Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Output Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Security Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Input Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-08 10:40:21 --> Language Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Loader Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Helper loaded: date_helper
DEBUG - 2019-04-08 10:40:21 --> Controller Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Database Driver Class Initialized
ERROR - 2019-04-08 10:40:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-08 10:40:21 --> Model Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Model Class Initialized
DEBUG - 2019-04-08 10:40:21 --> Helper loaded: url_helper
DEBUG - 2019-04-08 10:40:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-04-08 10:40:21 --> Final output sent to browser
DEBUG - 2019-04-08 10:40:21 --> Total execution time: 0.0269
