<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-06-27 02:20:34 --> Config Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Hooks Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Utf8 Class Initialized
DEBUG - 2018-06-27 02:20:34 --> UTF-8 Support Enabled
DEBUG - 2018-06-27 02:20:34 --> URI Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Router Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Output Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Security Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Input Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-27 02:20:34 --> Language Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Loader Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Helper loaded: date_helper
DEBUG - 2018-06-27 02:20:34 --> Controller Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Database Driver Class Initialized
ERROR - 2018-06-27 02:20:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-27 02:20:34 --> Model Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Model Class Initialized
DEBUG - 2018-06-27 02:20:34 --> Helper loaded: url_helper
DEBUG - 2018-06-27 02:20:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-06-27 02:20:34 --> Final output sent to browser
DEBUG - 2018-06-27 02:20:34 --> Total execution time: 0.0327
DEBUG - 2018-06-27 16:46:28 --> Config Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Utf8 Class Initialized
DEBUG - 2018-06-27 16:46:28 --> UTF-8 Support Enabled
DEBUG - 2018-06-27 16:46:28 --> URI Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Router Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Output Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Security Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Input Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-27 16:46:28 --> Language Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Loader Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Helper loaded: date_helper
DEBUG - 2018-06-27 16:46:28 --> Controller Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Database Driver Class Initialized
ERROR - 2018-06-27 16:46:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-27 16:46:28 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:28 --> Helper loaded: url_helper
DEBUG - 2018-06-27 16:46:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-06-27 16:46:28 --> Final output sent to browser
DEBUG - 2018-06-27 16:46:28 --> Total execution time: 0.0684
DEBUG - 2018-06-27 16:46:29 --> Config Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Utf8 Class Initialized
DEBUG - 2018-06-27 16:46:29 --> UTF-8 Support Enabled
DEBUG - 2018-06-27 16:46:29 --> URI Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Router Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Output Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Security Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Input Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-27 16:46:29 --> Language Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Loader Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Helper loaded: date_helper
DEBUG - 2018-06-27 16:46:29 --> Controller Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Database Driver Class Initialized
ERROR - 2018-06-27 16:46:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-27 16:46:29 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:29 --> Helper loaded: url_helper
DEBUG - 2018-06-27 16:46:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-06-27 16:46:29 --> Final output sent to browser
DEBUG - 2018-06-27 16:46:29 --> Total execution time: 0.0438
DEBUG - 2018-06-27 16:46:38 --> Config Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Utf8 Class Initialized
DEBUG - 2018-06-27 16:46:38 --> UTF-8 Support Enabled
DEBUG - 2018-06-27 16:46:38 --> URI Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Router Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Output Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Security Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Input Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-27 16:46:38 --> Language Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Loader Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Helper loaded: date_helper
DEBUG - 2018-06-27 16:46:38 --> Controller Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Database Driver Class Initialized
ERROR - 2018-06-27 16:46:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-27 16:46:38 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:38 --> Helper loaded: url_helper
DEBUG - 2018-06-27 16:46:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-06-27 16:46:38 --> Final output sent to browser
DEBUG - 2018-06-27 16:46:38 --> Total execution time: 0.0417
DEBUG - 2018-06-27 16:46:40 --> Config Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Utf8 Class Initialized
DEBUG - 2018-06-27 16:46:40 --> UTF-8 Support Enabled
DEBUG - 2018-06-27 16:46:40 --> URI Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Router Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Output Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Security Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Input Class Initialized
ERROR - 2018-06-27 16:46:40 --> Severity: Notice  --> iconv(): Detected an illegal character in input string /home/hosting_users/uncleben/www/todo/system/core/Utf8.php 89
DEBUG - 2018-06-27 16:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-27 16:46:40 --> Language Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Loader Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Helper loaded: date_helper
DEBUG - 2018-06-27 16:46:40 --> Controller Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Database Driver Class Initialized
ERROR - 2018-06-27 16:46:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-27 16:46:40 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Model Class Initialized
DEBUG - 2018-06-27 16:46:40 --> Helper loaded: url_helper
DEBUG - 2018-06-27 16:46:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-06-27 16:46:40 --> Final output sent to browser
DEBUG - 2018-06-27 16:46:40 --> Total execution time: 0.0426
DEBUG - 2018-06-27 16:50:26 --> Config Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Utf8 Class Initialized
DEBUG - 2018-06-27 16:50:26 --> UTF-8 Support Enabled
DEBUG - 2018-06-27 16:50:26 --> URI Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Router Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Output Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Security Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Input Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-27 16:50:26 --> Language Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Loader Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Helper loaded: date_helper
DEBUG - 2018-06-27 16:50:26 --> Controller Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Database Driver Class Initialized
ERROR - 2018-06-27 16:50:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-27 16:50:26 --> Model Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Model Class Initialized
DEBUG - 2018-06-27 16:50:26 --> Helper loaded: url_helper
DEBUG - 2018-06-27 16:50:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-06-27 16:50:26 --> Final output sent to browser
DEBUG - 2018-06-27 16:50:26 --> Total execution time: 0.0431
DEBUG - 2018-06-27 16:50:30 --> Config Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Hooks Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Utf8 Class Initialized
DEBUG - 2018-06-27 16:50:30 --> UTF-8 Support Enabled
DEBUG - 2018-06-27 16:50:30 --> URI Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Router Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Output Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Security Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Input Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-06-27 16:50:30 --> Language Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Loader Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Helper loaded: date_helper
DEBUG - 2018-06-27 16:50:30 --> Controller Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Database Driver Class Initialized
ERROR - 2018-06-27 16:50:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-06-27 16:50:30 --> Model Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Model Class Initialized
DEBUG - 2018-06-27 16:50:30 --> Helper loaded: url_helper
DEBUG - 2018-06-27 16:50:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-06-27 16:50:30 --> Final output sent to browser
DEBUG - 2018-06-27 16:50:30 --> Total execution time: 0.0433
