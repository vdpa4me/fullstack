<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-07-18 00:05:19 --> Config Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:05:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:05:19 --> URI Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Router Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Output Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Security Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Input Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:05:19 --> Language Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Loader Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:05:19 --> Controller Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:05:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:05:19 --> Model Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Model Class Initialized
DEBUG - 2017-07-18 00:05:19 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:05:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:05:19 --> Final output sent to browser
DEBUG - 2017-07-18 00:05:19 --> Total execution time: 0.0649
DEBUG - 2017-07-18 00:05:21 --> Config Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:05:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:05:21 --> URI Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Router Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Output Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Security Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Input Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:05:21 --> Language Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Loader Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:05:21 --> Controller Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:05:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:05:21 --> Model Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Model Class Initialized
DEBUG - 2017-07-18 00:05:21 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:05:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:05:21 --> Final output sent to browser
DEBUG - 2017-07-18 00:05:21 --> Total execution time: 0.0347
DEBUG - 2017-07-18 00:08:30 --> Config Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:08:30 --> URI Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Router Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Output Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Security Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Input Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:08:30 --> Language Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Loader Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:08:30 --> Controller Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:08:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:08:30 --> Model Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Model Class Initialized
DEBUG - 2017-07-18 00:08:30 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:08:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:08:30 --> Final output sent to browser
DEBUG - 2017-07-18 00:08:30 --> Total execution time: 0.0350
DEBUG - 2017-07-18 00:11:16 --> Config Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:11:16 --> URI Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Router Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Output Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Security Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Input Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:11:16 --> Language Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Loader Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:11:16 --> Controller Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:11:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:11:16 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:16 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:11:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:11:16 --> Final output sent to browser
DEBUG - 2017-07-18 00:11:16 --> Total execution time: 0.0346
DEBUG - 2017-07-18 00:11:18 --> Config Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:11:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:11:18 --> URI Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Router Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Output Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Security Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Input Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:11:18 --> Language Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Loader Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:11:18 --> Controller Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:11:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:11:18 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:18 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:11:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:11:18 --> Final output sent to browser
DEBUG - 2017-07-18 00:11:18 --> Total execution time: 0.0343
DEBUG - 2017-07-18 00:11:21 --> Config Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:11:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:11:21 --> URI Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Router Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Output Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Security Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Input Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:11:21 --> Language Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Loader Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:11:21 --> Controller Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:11:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:11:21 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:21 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:11:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:11:21 --> Final output sent to browser
DEBUG - 2017-07-18 00:11:21 --> Total execution time: 0.0347
DEBUG - 2017-07-18 00:11:26 --> Config Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:11:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:11:26 --> URI Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Router Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Output Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Security Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Input Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:11:26 --> Language Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Loader Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:11:26 --> Controller Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:11:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:11:26 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:26 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:11:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:11:26 --> Final output sent to browser
DEBUG - 2017-07-18 00:11:26 --> Total execution time: 0.0343
DEBUG - 2017-07-18 00:11:47 --> Config Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:11:47 --> URI Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Router Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Output Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Security Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Input Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:11:47 --> Language Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Loader Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:11:47 --> Controller Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:11:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:11:47 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Model Class Initialized
DEBUG - 2017-07-18 00:11:47 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:11:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:11:47 --> Final output sent to browser
DEBUG - 2017-07-18 00:11:47 --> Total execution time: 0.0338
DEBUG - 2017-07-18 00:12:01 --> Config Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:12:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:12:01 --> URI Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Router Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Output Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Security Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Input Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:12:01 --> Language Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Loader Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:12:01 --> Controller Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:12:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:12:01 --> Model Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Model Class Initialized
DEBUG - 2017-07-18 00:12:01 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:12:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:12:01 --> Final output sent to browser
DEBUG - 2017-07-18 00:12:01 --> Total execution time: 0.0338
DEBUG - 2017-07-18 00:12:07 --> Config Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:12:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:12:07 --> URI Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Router Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Output Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Security Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Input Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:12:07 --> Language Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Loader Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:12:07 --> Controller Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:12:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:12:07 --> Model Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Model Class Initialized
DEBUG - 2017-07-18 00:12:07 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:12:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:12:07 --> Final output sent to browser
DEBUG - 2017-07-18 00:12:07 --> Total execution time: 0.0368
DEBUG - 2017-07-18 00:13:14 --> Config Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:13:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:13:14 --> URI Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Router Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Output Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Security Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Input Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:13:14 --> Language Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Loader Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:13:14 --> Controller Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:13:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:13:14 --> Model Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Model Class Initialized
DEBUG - 2017-07-18 00:13:14 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:13:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:13:14 --> Final output sent to browser
DEBUG - 2017-07-18 00:13:14 --> Total execution time: 0.0359
DEBUG - 2017-07-18 00:14:56 --> Config Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:14:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:14:56 --> URI Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Router Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Output Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Security Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Input Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:14:56 --> Language Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Loader Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:14:56 --> Controller Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:14:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:14:56 --> Model Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Model Class Initialized
DEBUG - 2017-07-18 00:14:56 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:14:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:14:56 --> Final output sent to browser
DEBUG - 2017-07-18 00:14:56 --> Total execution time: 0.0349
DEBUG - 2017-07-18 00:17:13 --> Config Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:17:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:17:13 --> URI Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Router Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Output Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Security Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Input Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:17:13 --> Language Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Loader Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:17:13 --> Controller Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:17:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:17:13 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:13 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:17:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:17:13 --> Final output sent to browser
DEBUG - 2017-07-18 00:17:13 --> Total execution time: 0.0355
DEBUG - 2017-07-18 00:17:16 --> Config Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:17:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:17:16 --> URI Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Router Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Output Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Security Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Input Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:17:16 --> Language Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Loader Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:17:16 --> Controller Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:17:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:17:16 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:16 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:17:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:17:16 --> Final output sent to browser
DEBUG - 2017-07-18 00:17:16 --> Total execution time: 0.0357
DEBUG - 2017-07-18 00:17:20 --> Config Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:17:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:17:20 --> URI Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Router Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Output Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Security Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Input Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:17:20 --> Language Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Loader Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:17:20 --> Controller Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:17:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:17:20 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:20 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:17:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:17:20 --> Final output sent to browser
DEBUG - 2017-07-18 00:17:20 --> Total execution time: 0.0358
DEBUG - 2017-07-18 00:17:27 --> Config Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:17:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:17:27 --> URI Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Router Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Output Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Security Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Input Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:17:27 --> Language Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Loader Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:17:27 --> Controller Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:17:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:17:27 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:27 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:17:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:17:27 --> Final output sent to browser
DEBUG - 2017-07-18 00:17:27 --> Total execution time: 0.0353
DEBUG - 2017-07-18 00:17:47 --> Config Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:17:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:17:47 --> URI Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Router Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Output Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Security Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Input Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:17:47 --> Language Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Loader Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:17:47 --> Controller Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:17:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:17:47 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:47 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:17:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:17:47 --> Final output sent to browser
DEBUG - 2017-07-18 00:17:47 --> Total execution time: 0.0354
DEBUG - 2017-07-18 00:17:55 --> Config Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:17:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:17:55 --> URI Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Router Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Output Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Security Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Input Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:17:55 --> Language Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Loader Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:17:55 --> Controller Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:17:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:17:55 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Model Class Initialized
DEBUG - 2017-07-18 00:17:55 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:17:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:17:55 --> Final output sent to browser
DEBUG - 2017-07-18 00:17:55 --> Total execution time: 0.0366
DEBUG - 2017-07-18 00:32:22 --> Config Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:32:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:32:22 --> URI Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Router Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Output Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Security Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Input Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:32:22 --> Language Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Loader Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:32:22 --> Controller Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:32:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:32:22 --> Model Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Model Class Initialized
DEBUG - 2017-07-18 00:32:22 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:32:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:32:22 --> Final output sent to browser
DEBUG - 2017-07-18 00:32:22 --> Total execution time: 0.0355
DEBUG - 2017-07-18 00:32:26 --> Config Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:32:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:32:26 --> URI Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Router Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Output Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Security Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Input Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:32:26 --> Language Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Loader Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:32:26 --> Controller Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:32:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:32:26 --> Model Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Model Class Initialized
DEBUG - 2017-07-18 00:32:26 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:32:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:32:26 --> Final output sent to browser
DEBUG - 2017-07-18 00:32:26 --> Total execution time: 0.0352
DEBUG - 2017-07-18 00:33:08 --> Config Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:33:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:33:08 --> URI Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Router Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Output Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Security Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Input Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:33:08 --> Language Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Loader Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:33:08 --> Controller Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:33:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:33:08 --> Model Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Model Class Initialized
DEBUG - 2017-07-18 00:33:08 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:33:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:33:08 --> Final output sent to browser
DEBUG - 2017-07-18 00:33:08 --> Total execution time: 0.0342
DEBUG - 2017-07-18 00:37:04 --> Config Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:37:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:37:04 --> URI Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Router Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Output Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Security Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Input Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:37:04 --> Language Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Loader Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:37:04 --> Controller Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:37:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:37:04 --> Model Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Model Class Initialized
DEBUG - 2017-07-18 00:37:04 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:37:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:37:04 --> Final output sent to browser
DEBUG - 2017-07-18 00:37:04 --> Total execution time: 0.0362
DEBUG - 2017-07-18 00:37:41 --> Config Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Hooks Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Utf8 Class Initialized
DEBUG - 2017-07-18 00:37:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 00:37:41 --> URI Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Router Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Output Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Security Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Input Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 00:37:41 --> Language Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Loader Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Helper loaded: date_helper
DEBUG - 2017-07-18 00:37:41 --> Controller Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Database Driver Class Initialized
ERROR - 2017-07-18 00:37:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 00:37:41 --> Model Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Model Class Initialized
DEBUG - 2017-07-18 00:37:41 --> Helper loaded: url_helper
DEBUG - 2017-07-18 00:37:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 00:37:41 --> Final output sent to browser
DEBUG - 2017-07-18 00:37:41 --> Total execution time: 0.0345
DEBUG - 2017-07-18 03:08:38 --> Config Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Hooks Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Utf8 Class Initialized
DEBUG - 2017-07-18 03:08:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 03:08:38 --> URI Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Router Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Output Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Security Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Input Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 03:08:38 --> Language Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Loader Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Helper loaded: date_helper
DEBUG - 2017-07-18 03:08:38 --> Controller Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Database Driver Class Initialized
ERROR - 2017-07-18 03:08:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 03:08:38 --> Model Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Model Class Initialized
DEBUG - 2017-07-18 03:08:38 --> Helper loaded: url_helper
DEBUG - 2017-07-18 03:08:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 03:08:38 --> Final output sent to browser
DEBUG - 2017-07-18 03:08:38 --> Total execution time: 0.0412
DEBUG - 2017-07-18 03:50:37 --> Config Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Hooks Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Utf8 Class Initialized
DEBUG - 2017-07-18 03:50:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 03:50:37 --> URI Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Router Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Output Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Security Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Input Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 03:50:37 --> Language Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Loader Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Helper loaded: date_helper
DEBUG - 2017-07-18 03:50:37 --> Controller Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Database Driver Class Initialized
ERROR - 2017-07-18 03:50:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 03:50:37 --> Model Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Model Class Initialized
DEBUG - 2017-07-18 03:50:37 --> Helper loaded: url_helper
DEBUG - 2017-07-18 03:50:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 03:50:37 --> Final output sent to browser
DEBUG - 2017-07-18 03:50:37 --> Total execution time: 0.0425
DEBUG - 2017-07-18 04:27:41 --> Config Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Hooks Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Utf8 Class Initialized
DEBUG - 2017-07-18 04:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 04:27:41 --> URI Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Router Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Output Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Security Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Input Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 04:27:41 --> Language Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Loader Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Helper loaded: date_helper
DEBUG - 2017-07-18 04:27:41 --> Controller Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Database Driver Class Initialized
ERROR - 2017-07-18 04:27:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 04:27:41 --> Model Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Model Class Initialized
DEBUG - 2017-07-18 04:27:41 --> Helper loaded: url_helper
DEBUG - 2017-07-18 04:27:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 04:27:41 --> Final output sent to browser
DEBUG - 2017-07-18 04:27:41 --> Total execution time: 0.0422
DEBUG - 2017-07-18 04:43:34 --> Config Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Hooks Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Utf8 Class Initialized
DEBUG - 2017-07-18 04:43:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 04:43:34 --> URI Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Router Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Output Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Security Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Input Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 04:43:34 --> Language Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Loader Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Helper loaded: date_helper
DEBUG - 2017-07-18 04:43:34 --> Controller Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Database Driver Class Initialized
ERROR - 2017-07-18 04:43:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Model Class Initialized
DEBUG - 2017-07-18 04:43:34 --> Helper loaded: url_helper
DEBUG - 2017-07-18 04:43:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 04:43:34 --> Final output sent to browser
DEBUG - 2017-07-18 04:43:34 --> Total execution time: 0.0357
DEBUG - 2017-07-18 04:47:53 --> Config Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Hooks Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Utf8 Class Initialized
DEBUG - 2017-07-18 04:47:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 04:47:53 --> URI Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Router Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Output Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Security Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Input Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 04:47:53 --> Language Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Loader Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Helper loaded: date_helper
DEBUG - 2017-07-18 04:47:53 --> Controller Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Database Driver Class Initialized
ERROR - 2017-07-18 04:47:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 04:47:53 --> Model Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Model Class Initialized
DEBUG - 2017-07-18 04:47:53 --> Helper loaded: url_helper
DEBUG - 2017-07-18 04:47:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 04:47:53 --> Final output sent to browser
DEBUG - 2017-07-18 04:47:53 --> Total execution time: 0.0352
DEBUG - 2017-07-18 04:52:20 --> Config Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Hooks Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Utf8 Class Initialized
DEBUG - 2017-07-18 04:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 04:52:20 --> URI Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Router Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Output Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Security Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Input Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 04:52:20 --> Language Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Loader Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Helper loaded: date_helper
DEBUG - 2017-07-18 04:52:20 --> Controller Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Database Driver Class Initialized
ERROR - 2017-07-18 04:52:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 04:52:20 --> Model Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Model Class Initialized
DEBUG - 2017-07-18 04:52:20 --> Helper loaded: url_helper
DEBUG - 2017-07-18 04:52:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 04:52:20 --> Final output sent to browser
DEBUG - 2017-07-18 04:52:20 --> Total execution time: 0.0356
DEBUG - 2017-07-18 05:01:16 --> Config Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Hooks Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Utf8 Class Initialized
DEBUG - 2017-07-18 05:01:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 05:01:16 --> URI Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Router Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Output Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Security Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Input Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 05:01:16 --> Language Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Loader Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Helper loaded: date_helper
DEBUG - 2017-07-18 05:01:16 --> Controller Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Database Driver Class Initialized
ERROR - 2017-07-18 05:01:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 05:01:16 --> Model Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Model Class Initialized
DEBUG - 2017-07-18 05:01:16 --> Helper loaded: url_helper
DEBUG - 2017-07-18 05:01:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 05:01:16 --> Final output sent to browser
DEBUG - 2017-07-18 05:01:16 --> Total execution time: 0.0360
DEBUG - 2017-07-18 05:01:19 --> Config Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Hooks Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Utf8 Class Initialized
DEBUG - 2017-07-18 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 05:01:19 --> URI Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Router Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Output Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Security Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Input Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 05:01:19 --> Language Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Loader Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Helper loaded: date_helper
DEBUG - 2017-07-18 05:01:19 --> Controller Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Database Driver Class Initialized
ERROR - 2017-07-18 05:01:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 05:01:19 --> Model Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Model Class Initialized
DEBUG - 2017-07-18 05:01:19 --> Helper loaded: url_helper
DEBUG - 2017-07-18 05:01:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 05:01:19 --> Final output sent to browser
DEBUG - 2017-07-18 05:01:19 --> Total execution time: 0.0357
DEBUG - 2017-07-18 05:17:42 --> Config Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Hooks Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Utf8 Class Initialized
DEBUG - 2017-07-18 05:17:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 05:17:42 --> URI Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Router Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Output Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Security Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Input Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 05:17:42 --> Language Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Loader Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Helper loaded: date_helper
DEBUG - 2017-07-18 05:17:42 --> Controller Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Database Driver Class Initialized
ERROR - 2017-07-18 05:17:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 05:17:42 --> Model Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Model Class Initialized
DEBUG - 2017-07-18 05:17:42 --> Helper loaded: url_helper
DEBUG - 2017-07-18 05:17:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 05:17:42 --> Final output sent to browser
DEBUG - 2017-07-18 05:17:42 --> Total execution time: 0.0360
DEBUG - 2017-07-18 06:32:09 --> Config Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Hooks Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Utf8 Class Initialized
DEBUG - 2017-07-18 06:32:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 06:32:09 --> URI Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Router Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Output Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Security Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Input Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 06:32:09 --> Language Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Loader Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Helper loaded: date_helper
DEBUG - 2017-07-18 06:32:09 --> Controller Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Database Driver Class Initialized
ERROR - 2017-07-18 06:32:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 06:32:09 --> Model Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Model Class Initialized
DEBUG - 2017-07-18 06:32:09 --> Helper loaded: url_helper
DEBUG - 2017-07-18 06:32:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 06:32:09 --> Final output sent to browser
DEBUG - 2017-07-18 06:32:09 --> Total execution time: 0.0487
DEBUG - 2017-07-18 07:12:29 --> Config Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Hooks Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Utf8 Class Initialized
DEBUG - 2017-07-18 07:12:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 07:12:29 --> URI Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Router Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Output Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Security Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Input Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 07:12:29 --> Language Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Loader Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Helper loaded: date_helper
DEBUG - 2017-07-18 07:12:29 --> Controller Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Database Driver Class Initialized
ERROR - 2017-07-18 07:12:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 07:12:29 --> Model Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Model Class Initialized
DEBUG - 2017-07-18 07:12:29 --> Helper loaded: url_helper
DEBUG - 2017-07-18 07:12:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 07:12:29 --> Final output sent to browser
DEBUG - 2017-07-18 07:12:29 --> Total execution time: 0.0362
DEBUG - 2017-07-18 07:14:57 --> Config Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Hooks Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Utf8 Class Initialized
DEBUG - 2017-07-18 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 07:14:57 --> URI Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Router Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Output Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Security Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Input Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 07:14:57 --> Language Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Loader Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Helper loaded: date_helper
DEBUG - 2017-07-18 07:14:57 --> Controller Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Database Driver Class Initialized
ERROR - 2017-07-18 07:14:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 07:14:57 --> Model Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Model Class Initialized
DEBUG - 2017-07-18 07:14:57 --> Helper loaded: url_helper
DEBUG - 2017-07-18 07:14:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 07:14:57 --> Final output sent to browser
DEBUG - 2017-07-18 07:14:57 --> Total execution time: 0.0368
DEBUG - 2017-07-18 07:24:53 --> Config Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Hooks Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Utf8 Class Initialized
DEBUG - 2017-07-18 07:24:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 07:24:53 --> URI Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Router Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Output Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Security Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Input Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 07:24:53 --> Language Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Loader Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Helper loaded: date_helper
DEBUG - 2017-07-18 07:24:53 --> Controller Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Database Driver Class Initialized
ERROR - 2017-07-18 07:24:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 07:24:53 --> Model Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Model Class Initialized
DEBUG - 2017-07-18 07:24:53 --> Helper loaded: url_helper
DEBUG - 2017-07-18 07:24:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 07:24:53 --> Final output sent to browser
DEBUG - 2017-07-18 07:24:53 --> Total execution time: 0.0360
DEBUG - 2017-07-18 08:53:23 --> Config Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Hooks Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Utf8 Class Initialized
DEBUG - 2017-07-18 08:53:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 08:53:23 --> URI Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Router Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Output Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Security Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Input Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 08:53:23 --> Language Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Loader Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Helper loaded: date_helper
DEBUG - 2017-07-18 08:53:23 --> Controller Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Database Driver Class Initialized
ERROR - 2017-07-18 08:53:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 08:53:23 --> Model Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Model Class Initialized
DEBUG - 2017-07-18 08:53:23 --> Helper loaded: url_helper
DEBUG - 2017-07-18 08:53:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 08:53:23 --> Final output sent to browser
DEBUG - 2017-07-18 08:53:23 --> Total execution time: 0.0427
DEBUG - 2017-07-18 08:55:32 --> Config Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Hooks Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Utf8 Class Initialized
DEBUG - 2017-07-18 08:55:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 08:55:32 --> URI Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Router Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Output Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Security Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Input Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 08:55:32 --> Language Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Loader Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Helper loaded: date_helper
DEBUG - 2017-07-18 08:55:32 --> Controller Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Database Driver Class Initialized
ERROR - 2017-07-18 08:55:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 08:55:32 --> Model Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Model Class Initialized
DEBUG - 2017-07-18 08:55:32 --> Helper loaded: url_helper
DEBUG - 2017-07-18 08:55:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 08:55:32 --> Final output sent to browser
DEBUG - 2017-07-18 08:55:32 --> Total execution time: 0.0378
DEBUG - 2017-07-18 09:00:31 --> Config Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Hooks Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Utf8 Class Initialized
DEBUG - 2017-07-18 09:00:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 09:00:31 --> URI Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Router Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Output Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Security Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Input Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-18 09:00:31 --> Language Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Loader Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Helper loaded: date_helper
DEBUG - 2017-07-18 09:00:31 --> Controller Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Database Driver Class Initialized
ERROR - 2017-07-18 09:00:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-18 09:00:31 --> Model Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Model Class Initialized
DEBUG - 2017-07-18 09:00:31 --> Helper loaded: url_helper
DEBUG - 2017-07-18 09:00:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-18 09:00:31 --> Final output sent to browser
DEBUG - 2017-07-18 09:00:31 --> Total execution time: 0.0365
