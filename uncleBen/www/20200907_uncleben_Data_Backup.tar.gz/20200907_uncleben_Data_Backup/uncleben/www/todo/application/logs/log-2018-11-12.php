<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-11-12 00:12:39 --> Config Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Hooks Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Utf8 Class Initialized
DEBUG - 2018-11-12 00:12:39 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 00:12:39 --> URI Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Router Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Output Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Security Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Input Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 00:12:39 --> Language Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Loader Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Helper loaded: date_helper
DEBUG - 2018-11-12 00:12:39 --> Controller Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Database Driver Class Initialized
ERROR - 2018-11-12 00:12:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 00:12:39 --> Model Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Model Class Initialized
DEBUG - 2018-11-12 00:12:39 --> Helper loaded: url_helper
DEBUG - 2018-11-12 00:12:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 00:12:39 --> Final output sent to browser
DEBUG - 2018-11-12 00:12:39 --> Total execution time: 0.0648
DEBUG - 2018-11-12 00:12:44 --> Config Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Hooks Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Utf8 Class Initialized
DEBUG - 2018-11-12 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 00:12:44 --> URI Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Router Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Output Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Security Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Input Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 00:12:44 --> Language Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Loader Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Helper loaded: date_helper
DEBUG - 2018-11-12 00:12:44 --> Controller Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Database Driver Class Initialized
ERROR - 2018-11-12 00:12:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 00:12:44 --> Model Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Model Class Initialized
DEBUG - 2018-11-12 00:12:44 --> Helper loaded: url_helper
DEBUG - 2018-11-12 00:12:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 00:12:44 --> Final output sent to browser
DEBUG - 2018-11-12 00:12:44 --> Total execution time: 0.0604
DEBUG - 2018-11-12 01:01:21 --> Config Class Initialized
DEBUG - 2018-11-12 01:01:21 --> Hooks Class Initialized
DEBUG - 2018-11-12 01:01:21 --> Utf8 Class Initialized
DEBUG - 2018-11-12 01:01:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 01:01:21 --> URI Class Initialized
DEBUG - 2018-11-12 01:01:21 --> Router Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Output Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Security Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Input Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 01:01:22 --> Language Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Loader Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Helper loaded: date_helper
DEBUG - 2018-11-12 01:01:22 --> Controller Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Database Driver Class Initialized
ERROR - 2018-11-12 01:01:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 01:01:22 --> Model Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Model Class Initialized
DEBUG - 2018-11-12 01:01:22 --> Helper loaded: url_helper
DEBUG - 2018-11-12 01:01:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 01:01:22 --> Final output sent to browser
DEBUG - 2018-11-12 01:01:22 --> Total execution time: 0.0438
DEBUG - 2018-11-12 01:01:28 --> Config Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Hooks Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Utf8 Class Initialized
DEBUG - 2018-11-12 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 01:01:28 --> URI Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Router Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Output Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Security Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Input Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 01:01:28 --> Language Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Loader Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Helper loaded: date_helper
DEBUG - 2018-11-12 01:01:28 --> Controller Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Database Driver Class Initialized
ERROR - 2018-11-12 01:01:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 01:01:28 --> Model Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Model Class Initialized
DEBUG - 2018-11-12 01:01:28 --> Helper loaded: url_helper
ERROR - 2018-11-12 01:01:28 --> Severity: Warning  --> strstr(): Empty needle /home/hosting_users/uncleben/www/todo/application/views/todo/yumi_v.php 142
DEBUG - 2018-11-12 01:01:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 01:01:28 --> Final output sent to browser
DEBUG - 2018-11-12 01:01:28 --> Total execution time: 0.0634
DEBUG - 2018-11-12 04:33:04 --> Config Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Hooks Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Utf8 Class Initialized
DEBUG - 2018-11-12 04:33:04 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 04:33:04 --> URI Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Router Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Output Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Security Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Input Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 04:33:04 --> Language Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Loader Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Helper loaded: date_helper
DEBUG - 2018-11-12 04:33:04 --> Controller Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Database Driver Class Initialized
ERROR - 2018-11-12 04:33:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 04:33:04 --> Model Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Model Class Initialized
DEBUG - 2018-11-12 04:33:04 --> Helper loaded: url_helper
DEBUG - 2018-11-12 04:33:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-11-12 04:33:04 --> Final output sent to browser
DEBUG - 2018-11-12 04:33:04 --> Total execution time: 0.0339
DEBUG - 2018-11-12 10:24:37 --> Config Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Hooks Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Utf8 Class Initialized
DEBUG - 2018-11-12 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 10:24:37 --> URI Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Router Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Output Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Security Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Input Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 10:24:37 --> Language Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Loader Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Helper loaded: date_helper
DEBUG - 2018-11-12 10:24:37 --> Controller Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Database Driver Class Initialized
ERROR - 2018-11-12 10:24:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 10:24:37 --> Model Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Model Class Initialized
DEBUG - 2018-11-12 10:24:37 --> Helper loaded: url_helper
DEBUG - 2018-11-12 10:24:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 10:24:37 --> Final output sent to browser
DEBUG - 2018-11-12 10:24:37 --> Total execution time: 0.0890
DEBUG - 2018-11-12 13:05:26 --> Config Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Hooks Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Utf8 Class Initialized
DEBUG - 2018-11-12 13:05:26 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 13:05:26 --> URI Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Router Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Output Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Security Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Input Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 13:05:26 --> Language Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Loader Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Helper loaded: date_helper
DEBUG - 2018-11-12 13:05:26 --> Controller Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Database Driver Class Initialized
ERROR - 2018-11-12 13:05:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 13:05:26 --> Model Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Model Class Initialized
DEBUG - 2018-11-12 13:05:26 --> Helper loaded: url_helper
DEBUG - 2018-11-12 13:05:26 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-11-12 13:05:26 --> Final output sent to browser
DEBUG - 2018-11-12 13:05:26 --> Total execution time: 0.0533
DEBUG - 2018-11-12 16:38:32 --> Config Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Hooks Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Utf8 Class Initialized
DEBUG - 2018-11-12 16:38:32 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 16:38:32 --> URI Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Router Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Output Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Security Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Input Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 16:38:32 --> Language Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Loader Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Helper loaded: date_helper
DEBUG - 2018-11-12 16:38:32 --> Controller Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Database Driver Class Initialized
ERROR - 2018-11-12 16:38:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 16:38:32 --> Model Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Model Class Initialized
DEBUG - 2018-11-12 16:38:32 --> Helper loaded: url_helper
DEBUG - 2018-11-12 16:38:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 16:38:32 --> Final output sent to browser
DEBUG - 2018-11-12 16:38:32 --> Total execution time: 0.0978
DEBUG - 2018-11-12 16:38:37 --> Config Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Hooks Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Utf8 Class Initialized
DEBUG - 2018-11-12 16:38:37 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 16:38:37 --> URI Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Router Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Output Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Security Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Input Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 16:38:37 --> Language Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Loader Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Helper loaded: date_helper
DEBUG - 2018-11-12 16:38:37 --> Controller Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Database Driver Class Initialized
ERROR - 2018-11-12 16:38:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 16:38:37 --> Model Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Model Class Initialized
DEBUG - 2018-11-12 16:38:37 --> Helper loaded: url_helper
DEBUG - 2018-11-12 16:38:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 16:38:37 --> Final output sent to browser
DEBUG - 2018-11-12 16:38:37 --> Total execution time: 0.0443
DEBUG - 2018-11-12 16:41:30 --> Config Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Hooks Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Utf8 Class Initialized
DEBUG - 2018-11-12 16:41:30 --> UTF-8 Support Enabled
DEBUG - 2018-11-12 16:41:30 --> URI Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Router Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Output Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Security Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Input Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-11-12 16:41:30 --> Language Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Loader Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Helper loaded: date_helper
DEBUG - 2018-11-12 16:41:30 --> Controller Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Database Driver Class Initialized
ERROR - 2018-11-12 16:41:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-11-12 16:41:30 --> Model Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Model Class Initialized
DEBUG - 2018-11-12 16:41:30 --> Helper loaded: url_helper
DEBUG - 2018-11-12 16:41:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-11-12 16:41:30 --> Final output sent to browser
DEBUG - 2018-11-12 16:41:30 --> Total execution time: 0.0561
