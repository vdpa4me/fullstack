<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-03-19 13:30:29 --> Config Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Hooks Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Utf8 Class Initialized
DEBUG - 2020-03-19 13:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-19 13:30:29 --> URI Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Router Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Output Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Security Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Input Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2020-03-19 13:30:29 --> Language Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Loader Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Helper loaded: date_helper
DEBUG - 2020-03-19 13:30:29 --> Controller Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Database Driver Class Initialized
ERROR - 2020-03-19 13:30:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-03-19 13:30:29 --> Model Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Model Class Initialized
DEBUG - 2020-03-19 13:30:29 --> Helper loaded: url_helper
DEBUG - 2020-03-19 13:30:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-03-19 13:30:29 --> Final output sent to browser
DEBUG - 2020-03-19 13:30:29 --> Total execution time: 0.1846
DEBUG - 2020-03-19 17:10:20 --> Config Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Hooks Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Utf8 Class Initialized
DEBUG - 2020-03-19 17:10:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-19 17:10:20 --> URI Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Router Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Output Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Security Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Input Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2020-03-19 17:10:20 --> Language Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Loader Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Helper loaded: date_helper
DEBUG - 2020-03-19 17:10:20 --> Controller Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Database Driver Class Initialized
ERROR - 2020-03-19 17:10:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-03-19 17:10:20 --> Model Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Model Class Initialized
DEBUG - 2020-03-19 17:10:20 --> Helper loaded: url_helper
DEBUG - 2020-03-19 17:10:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-03-19 17:10:20 --> Final output sent to browser
DEBUG - 2020-03-19 17:10:20 --> Total execution time: 0.1667
