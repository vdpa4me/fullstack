<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-02-09 00:35:50 --> Config Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Hooks Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Utf8 Class Initialized
DEBUG - 2018-02-09 00:35:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-09 00:35:50 --> URI Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Router Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Output Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Security Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Input Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-09 00:35:50 --> Language Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Loader Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Helper loaded: date_helper
DEBUG - 2018-02-09 00:35:50 --> Controller Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Database Driver Class Initialized
ERROR - 2018-02-09 00:35:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-02-09 00:35:50 --> Model Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Model Class Initialized
DEBUG - 2018-02-09 00:35:50 --> Helper loaded: url_helper
DEBUG - 2018-02-09 00:35:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-02-09 00:35:50 --> Final output sent to browser
DEBUG - 2018-02-09 00:35:50 --> Total execution time: 0.0380
DEBUG - 2018-02-09 14:38:56 --> Config Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Utf8 Class Initialized
DEBUG - 2018-02-09 14:38:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-09 14:38:56 --> URI Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Router Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Output Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Security Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Input Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-09 14:38:56 --> Language Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Loader Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Helper loaded: date_helper
DEBUG - 2018-02-09 14:38:56 --> Controller Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Database Driver Class Initialized
ERROR - 2018-02-09 14:38:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-02-09 14:38:56 --> Model Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Model Class Initialized
DEBUG - 2018-02-09 14:38:56 --> Helper loaded: url_helper
DEBUG - 2018-02-09 14:38:56 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-02-09 14:38:56 --> Final output sent to browser
DEBUG - 2018-02-09 14:38:56 --> Total execution time: 0.0345
DEBUG - 2018-02-09 14:47:29 --> Config Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Hooks Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Utf8 Class Initialized
DEBUG - 2018-02-09 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-09 14:47:29 --> URI Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Router Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Output Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Security Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Input Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-09 14:47:29 --> Language Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Loader Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Helper loaded: date_helper
DEBUG - 2018-02-09 14:47:29 --> Controller Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Database Driver Class Initialized
ERROR - 2018-02-09 14:47:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-02-09 14:47:29 --> Model Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Model Class Initialized
DEBUG - 2018-02-09 14:47:29 --> Helper loaded: url_helper
DEBUG - 2018-02-09 14:47:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-02-09 14:47:29 --> Final output sent to browser
DEBUG - 2018-02-09 14:47:29 --> Total execution time: 0.0217
