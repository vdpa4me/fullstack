<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-07-26 03:57:49 --> Config Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Hooks Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Utf8 Class Initialized
DEBUG - 2017-07-26 03:57:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-26 03:57:49 --> URI Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Router Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Output Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Security Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Input Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-26 03:57:49 --> Language Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Loader Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Helper loaded: date_helper
DEBUG - 2017-07-26 03:57:49 --> Controller Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Database Driver Class Initialized
ERROR - 2017-07-26 03:57:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-26 03:57:49 --> Model Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Model Class Initialized
DEBUG - 2017-07-26 03:57:49 --> Helper loaded: url_helper
DEBUG - 2017-07-26 03:57:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-26 03:57:49 --> Final output sent to browser
DEBUG - 2017-07-26 03:57:49 --> Total execution time: 0.0407
DEBUG - 2017-07-26 03:57:54 --> Config Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Hooks Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Utf8 Class Initialized
DEBUG - 2017-07-26 03:57:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-26 03:57:54 --> URI Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Router Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Output Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Security Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Input Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-26 03:57:54 --> Language Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Loader Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Helper loaded: date_helper
DEBUG - 2017-07-26 03:57:54 --> Controller Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Database Driver Class Initialized
ERROR - 2017-07-26 03:57:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-26 03:57:54 --> Model Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Model Class Initialized
DEBUG - 2017-07-26 03:57:54 --> Helper loaded: url_helper
DEBUG - 2017-07-26 03:57:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-26 03:57:54 --> Final output sent to browser
DEBUG - 2017-07-26 03:57:54 --> Total execution time: 0.0353
DEBUG - 2017-07-26 06:37:14 --> Config Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Utf8 Class Initialized
DEBUG - 2017-07-26 06:37:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-26 06:37:14 --> URI Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Router Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Output Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Security Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Input Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-26 06:37:14 --> Language Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Loader Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Helper loaded: date_helper
DEBUG - 2017-07-26 06:37:14 --> Controller Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Database Driver Class Initialized
ERROR - 2017-07-26 06:37:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-26 06:37:14 --> Model Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Model Class Initialized
DEBUG - 2017-07-26 06:37:14 --> Helper loaded: url_helper
DEBUG - 2017-07-26 06:37:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-26 06:37:14 --> Final output sent to browser
DEBUG - 2017-07-26 06:37:14 --> Total execution time: 0.0466
DEBUG - 2017-07-26 06:37:32 --> Config Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Utf8 Class Initialized
DEBUG - 2017-07-26 06:37:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-26 06:37:32 --> URI Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Router Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Output Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Security Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Input Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-26 06:37:32 --> Language Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Loader Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Helper loaded: date_helper
DEBUG - 2017-07-26 06:37:32 --> Controller Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Database Driver Class Initialized
ERROR - 2017-07-26 06:37:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-26 06:37:32 --> Model Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Model Class Initialized
DEBUG - 2017-07-26 06:37:32 --> Helper loaded: url_helper
DEBUG - 2017-07-26 06:37:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-26 06:37:32 --> Final output sent to browser
DEBUG - 2017-07-26 06:37:32 --> Total execution time: 0.0348
DEBUG - 2017-07-26 07:01:39 --> Config Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Utf8 Class Initialized
DEBUG - 2017-07-26 07:01:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-26 07:01:39 --> URI Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Router Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Output Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Security Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Input Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-26 07:01:39 --> Language Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Loader Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Helper loaded: date_helper
DEBUG - 2017-07-26 07:01:39 --> Controller Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Database Driver Class Initialized
ERROR - 2017-07-26 07:01:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-26 07:01:39 --> Model Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Model Class Initialized
DEBUG - 2017-07-26 07:01:39 --> Helper loaded: url_helper
DEBUG - 2017-07-26 07:01:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-26 07:01:39 --> Final output sent to browser
DEBUG - 2017-07-26 07:01:39 --> Total execution time: 0.0389
DEBUG - 2017-07-26 19:32:03 --> Config Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Hooks Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Utf8 Class Initialized
DEBUG - 2017-07-26 19:32:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-26 19:32:03 --> URI Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Router Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Output Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Security Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Input Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-26 19:32:03 --> Language Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Loader Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Helper loaded: date_helper
DEBUG - 2017-07-26 19:32:03 --> Controller Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Database Driver Class Initialized
ERROR - 2017-07-26 19:32:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-26 19:32:03 --> Model Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Model Class Initialized
DEBUG - 2017-07-26 19:32:03 --> Helper loaded: url_helper
DEBUG - 2017-07-26 19:32:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-07-26 19:32:03 --> Final output sent to browser
DEBUG - 2017-07-26 19:32:03 --> Total execution time: 0.0395
