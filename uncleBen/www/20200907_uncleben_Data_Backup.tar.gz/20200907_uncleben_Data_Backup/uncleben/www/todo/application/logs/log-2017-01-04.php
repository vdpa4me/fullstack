<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-04 06:25:17 --> Config Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:25:17 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:25:17 --> URI Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Router Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Output Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Security Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Input Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:25:17 --> Language Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Loader Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:25:17 --> Controller Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:25:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:25:17 --> Model Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Model Class Initialized
DEBUG - 2017-01-04 06:25:17 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:25:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:25:17 --> Final output sent to browser
DEBUG - 2017-01-04 06:25:17 --> Total execution time: 0.0543
DEBUG - 2017-01-04 06:25:25 --> Config Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:25:25 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:25:25 --> URI Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Router Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Output Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Security Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Input Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:25:25 --> Language Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Loader Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:25:25 --> Controller Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:25:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:25:25 --> Model Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Model Class Initialized
DEBUG - 2017-01-04 06:25:25 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:25:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:25:25 --> Final output sent to browser
DEBUG - 2017-01-04 06:25:25 --> Total execution time: 0.0256
DEBUG - 2017-01-04 06:26:17 --> Config Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:26:17 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:26:17 --> URI Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Router Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Output Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Security Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Input Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:26:17 --> Language Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Loader Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:26:17 --> Controller Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:26:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:26:17 --> Model Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Model Class Initialized
DEBUG - 2017-01-04 06:26:17 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:26:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:26:17 --> Final output sent to browser
DEBUG - 2017-01-04 06:26:17 --> Total execution time: 0.0257
DEBUG - 2017-01-04 06:26:23 --> Config Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:26:23 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:26:23 --> URI Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Router Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Output Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Security Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Input Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:26:23 --> Language Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Loader Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:26:23 --> Controller Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:26:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:26:23 --> Model Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Model Class Initialized
DEBUG - 2017-01-04 06:26:23 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:26:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:26:23 --> Final output sent to browser
DEBUG - 2017-01-04 06:26:23 --> Total execution time: 0.0322
DEBUG - 2017-01-04 06:27:10 --> Config Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:27:10 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:27:10 --> URI Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Router Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Output Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Security Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Input Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:27:10 --> Language Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Loader Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:27:10 --> Controller Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:27:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:27:10 --> Model Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Model Class Initialized
DEBUG - 2017-01-04 06:27:10 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:27:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:27:10 --> Final output sent to browser
DEBUG - 2017-01-04 06:27:10 --> Total execution time: 0.0260
DEBUG - 2017-01-04 06:34:22 --> Config Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:34:22 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:34:22 --> URI Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Router Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Output Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Security Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Input Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:34:22 --> Language Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Loader Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:34:22 --> Controller Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:34:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:34:22 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:22 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:34:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:34:22 --> Final output sent to browser
DEBUG - 2017-01-04 06:34:22 --> Total execution time: 0.0267
DEBUG - 2017-01-04 06:34:37 --> Config Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:34:37 --> URI Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Router Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Output Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Security Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Input Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:34:37 --> Language Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Loader Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:34:37 --> Controller Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:34:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:34:37 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:37 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:34:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:34:37 --> Final output sent to browser
DEBUG - 2017-01-04 06:34:37 --> Total execution time: 0.0267
DEBUG - 2017-01-04 06:34:46 --> Config Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:34:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:34:46 --> URI Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Router Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Output Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Security Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Input Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:34:46 --> Language Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Loader Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:34:46 --> Controller Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:34:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:34:46 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:46 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:34:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:34:46 --> Final output sent to browser
DEBUG - 2017-01-04 06:34:46 --> Total execution time: 0.0261
DEBUG - 2017-01-04 06:34:49 --> Config Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:34:49 --> URI Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Router Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Output Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Security Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Input Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:34:49 --> Language Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Loader Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:34:49 --> Controller Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:34:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:34:49 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Model Class Initialized
DEBUG - 2017-01-04 06:34:49 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:34:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:34:49 --> Final output sent to browser
DEBUG - 2017-01-04 06:34:49 --> Total execution time: 0.0261
DEBUG - 2017-01-04 06:35:43 --> Config Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:35:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:35:43 --> URI Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Router Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Output Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Security Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Input Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:35:43 --> Language Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Loader Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:35:43 --> Controller Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:35:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:35:43 --> Model Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Model Class Initialized
DEBUG - 2017-01-04 06:35:43 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:35:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:35:43 --> Final output sent to browser
DEBUG - 2017-01-04 06:35:43 --> Total execution time: 0.0277
DEBUG - 2017-01-04 06:41:16 --> Config Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:41:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:41:16 --> URI Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Router Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Output Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Security Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Input Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:41:16 --> Language Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Loader Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:41:16 --> Controller Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:41:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:41:16 --> Model Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Model Class Initialized
DEBUG - 2017-01-04 06:41:16 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:41:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:41:16 --> Final output sent to browser
DEBUG - 2017-01-04 06:41:16 --> Total execution time: 0.0254
DEBUG - 2017-01-04 06:42:14 --> Config Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:42:14 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:42:14 --> URI Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Router Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Output Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Security Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Input Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:42:14 --> Language Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Loader Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:42:14 --> Controller Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:42:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:42:14 --> Model Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Model Class Initialized
DEBUG - 2017-01-04 06:42:14 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:42:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:42:14 --> Final output sent to browser
DEBUG - 2017-01-04 06:42:14 --> Total execution time: 0.0267
DEBUG - 2017-01-04 06:44:42 --> Config Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:44:42 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:44:42 --> URI Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Router Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Output Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Security Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Input Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:44:42 --> Language Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Loader Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:44:42 --> Controller Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:44:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:44:42 --> Model Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Model Class Initialized
DEBUG - 2017-01-04 06:44:42 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:44:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:44:42 --> Final output sent to browser
DEBUG - 2017-01-04 06:44:42 --> Total execution time: 0.0266
DEBUG - 2017-01-04 06:53:42 --> Config Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Hooks Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Utf8 Class Initialized
DEBUG - 2017-01-04 06:53:42 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 06:53:42 --> URI Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Router Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Output Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Security Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Input Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 06:53:42 --> Language Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Loader Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Helper loaded: date_helper
DEBUG - 2017-01-04 06:53:42 --> Controller Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Database Driver Class Initialized
ERROR - 2017-01-04 06:53:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 06:53:42 --> Model Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Model Class Initialized
DEBUG - 2017-01-04 06:53:42 --> Helper loaded: url_helper
DEBUG - 2017-01-04 06:53:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 06:53:42 --> Final output sent to browser
DEBUG - 2017-01-04 06:53:42 --> Total execution time: 0.0296
DEBUG - 2017-01-04 07:05:30 --> Config Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:05:30 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:05:30 --> URI Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Router Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Output Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Security Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Input Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:05:30 --> Language Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Loader Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:05:30 --> Controller Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:05:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:05:30 --> Model Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Model Class Initialized
DEBUG - 2017-01-04 07:05:30 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:05:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:05:30 --> Final output sent to browser
DEBUG - 2017-01-04 07:05:30 --> Total execution time: 0.0267
DEBUG - 2017-01-04 07:05:32 --> Config Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:05:32 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:05:32 --> URI Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Router Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Output Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Security Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Input Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:05:32 --> Language Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Loader Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:05:32 --> Controller Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:05:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:05:32 --> Model Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Model Class Initialized
DEBUG - 2017-01-04 07:05:32 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:05:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:05:32 --> Final output sent to browser
DEBUG - 2017-01-04 07:05:32 --> Total execution time: 0.0254
DEBUG - 2017-01-04 07:16:00 --> Config Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:16:00 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:16:00 --> URI Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Router Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Output Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Security Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Input Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:16:00 --> Language Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Loader Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:16:00 --> Controller Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:16:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:16:00 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:00 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:16:00 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:16:00 --> Final output sent to browser
DEBUG - 2017-01-04 07:16:00 --> Total execution time: 0.0261
DEBUG - 2017-01-04 07:16:03 --> Config Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:16:03 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:16:03 --> URI Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Router Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Output Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Security Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Input Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:16:03 --> Language Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Loader Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:16:03 --> Controller Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:16:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:16:03 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:03 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:16:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:16:03 --> Final output sent to browser
DEBUG - 2017-01-04 07:16:03 --> Total execution time: 0.0258
DEBUG - 2017-01-04 07:16:39 --> Config Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:16:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:16:39 --> URI Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Router Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Output Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Security Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Input Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:16:39 --> Language Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Loader Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:16:39 --> Controller Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:16:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:16:39 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:39 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:16:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:16:39 --> Final output sent to browser
DEBUG - 2017-01-04 07:16:39 --> Total execution time: 0.0263
DEBUG - 2017-01-04 07:16:42 --> Config Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:16:42 --> URI Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Router Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Output Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Security Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Input Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:16:42 --> Language Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Loader Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:16:42 --> Controller Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:16:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:16:42 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:42 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:16:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:16:42 --> Final output sent to browser
DEBUG - 2017-01-04 07:16:42 --> Total execution time: 0.0257
DEBUG - 2017-01-04 07:16:44 --> Config Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:16:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:16:44 --> URI Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Router Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Output Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Security Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Input Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:16:44 --> Language Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Loader Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:16:44 --> Controller Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:16:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:16:44 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Model Class Initialized
DEBUG - 2017-01-04 07:16:44 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:16:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:16:44 --> Final output sent to browser
DEBUG - 2017-01-04 07:16:44 --> Total execution time: 0.0261
DEBUG - 2017-01-04 07:20:36 --> Config Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:20:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:20:36 --> URI Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Router Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Output Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Security Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Input Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:20:36 --> Language Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Loader Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:20:36 --> Controller Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:20:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:20:36 --> Model Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Model Class Initialized
DEBUG - 2017-01-04 07:20:36 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:20:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:20:36 --> Final output sent to browser
DEBUG - 2017-01-04 07:20:36 --> Total execution time: 0.0263
DEBUG - 2017-01-04 07:20:52 --> Config Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:20:52 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:20:52 --> URI Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Router Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Output Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Security Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Input Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:20:52 --> Language Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Loader Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:20:52 --> Controller Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:20:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:20:52 --> Model Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Model Class Initialized
DEBUG - 2017-01-04 07:20:52 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:20:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:20:52 --> Final output sent to browser
DEBUG - 2017-01-04 07:20:52 --> Total execution time: 0.0265
DEBUG - 2017-01-04 07:20:55 --> Config Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:20:55 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:20:55 --> URI Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Router Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Output Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Security Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Input Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:20:55 --> Language Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Loader Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:20:55 --> Controller Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:20:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:20:55 --> Model Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Model Class Initialized
DEBUG - 2017-01-04 07:20:55 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:20:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:20:55 --> Final output sent to browser
DEBUG - 2017-01-04 07:20:55 --> Total execution time: 0.0266
DEBUG - 2017-01-04 07:35:46 --> Config Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Hooks Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Utf8 Class Initialized
DEBUG - 2017-01-04 07:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 07:35:46 --> URI Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Router Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Output Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Security Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Input Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 07:35:46 --> Language Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Loader Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Helper loaded: date_helper
DEBUG - 2017-01-04 07:35:46 --> Controller Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Database Driver Class Initialized
ERROR - 2017-01-04 07:35:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 07:35:46 --> Model Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Model Class Initialized
DEBUG - 2017-01-04 07:35:46 --> Helper loaded: url_helper
DEBUG - 2017-01-04 07:35:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 07:35:46 --> Final output sent to browser
DEBUG - 2017-01-04 07:35:46 --> Total execution time: 0.0301
DEBUG - 2017-01-04 09:22:56 --> Config Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Hooks Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Utf8 Class Initialized
DEBUG - 2017-01-04 09:22:56 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 09:22:56 --> URI Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Router Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Output Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Security Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Input Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 09:22:56 --> Language Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Loader Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Helper loaded: date_helper
DEBUG - 2017-01-04 09:22:56 --> Controller Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Database Driver Class Initialized
ERROR - 2017-01-04 09:22:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 09:22:56 --> Model Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Model Class Initialized
DEBUG - 2017-01-04 09:22:56 --> Helper loaded: url_helper
DEBUG - 2017-01-04 09:22:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 09:22:56 --> Final output sent to browser
DEBUG - 2017-01-04 09:22:56 --> Total execution time: 0.0298
DEBUG - 2017-01-04 09:44:44 --> Config Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Hooks Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Utf8 Class Initialized
DEBUG - 2017-01-04 09:44:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 09:44:44 --> URI Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Router Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Output Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Security Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Input Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 09:44:44 --> Language Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Loader Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Helper loaded: date_helper
DEBUG - 2017-01-04 09:44:44 --> Controller Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Database Driver Class Initialized
ERROR - 2017-01-04 09:44:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 09:44:44 --> Model Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Model Class Initialized
DEBUG - 2017-01-04 09:44:44 --> Helper loaded: url_helper
DEBUG - 2017-01-04 09:44:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 09:44:44 --> Final output sent to browser
DEBUG - 2017-01-04 09:44:44 --> Total execution time: 0.0291
DEBUG - 2017-01-04 10:05:16 --> Config Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Hooks Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Utf8 Class Initialized
DEBUG - 2017-01-04 10:05:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 10:05:16 --> URI Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Router Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Output Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Security Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Input Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 10:05:16 --> Language Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Loader Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Helper loaded: date_helper
DEBUG - 2017-01-04 10:05:16 --> Controller Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Database Driver Class Initialized
ERROR - 2017-01-04 10:05:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 10:05:16 --> Model Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Model Class Initialized
DEBUG - 2017-01-04 10:05:16 --> Helper loaded: url_helper
DEBUG - 2017-01-04 10:05:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 10:05:16 --> Final output sent to browser
DEBUG - 2017-01-04 10:05:16 --> Total execution time: 0.0490
DEBUG - 2017-01-04 12:13:22 --> Config Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:13:22 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:13:22 --> URI Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Router Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Output Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Security Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Input Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:13:22 --> Language Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Loader Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:13:22 --> Controller Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:13:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:13:22 --> Model Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Model Class Initialized
DEBUG - 2017-01-04 12:13:22 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:13:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:13:22 --> Final output sent to browser
DEBUG - 2017-01-04 12:13:22 --> Total execution time: 0.0505
DEBUG - 2017-01-04 12:13:27 --> Config Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:13:27 --> URI Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Router Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Output Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Security Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Input Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:13:27 --> Language Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Loader Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:13:27 --> Controller Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:13:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:13:27 --> Model Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Model Class Initialized
DEBUG - 2017-01-04 12:13:27 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:13:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:13:27 --> Final output sent to browser
DEBUG - 2017-01-04 12:13:27 --> Total execution time: 0.0458
DEBUG - 2017-01-04 12:16:16 --> Config Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:16:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:16:16 --> URI Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Router Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Output Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Security Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Input Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:16:16 --> Language Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Loader Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:16:16 --> Controller Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:16:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:16:16 --> Model Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Model Class Initialized
DEBUG - 2017-01-04 12:16:16 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:16:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:16:16 --> Final output sent to browser
DEBUG - 2017-01-04 12:16:16 --> Total execution time: 0.0841
DEBUG - 2017-01-04 12:16:19 --> Config Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:16:19 --> URI Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Router Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Output Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Security Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Input Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:16:19 --> Language Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Loader Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:16:19 --> Controller Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:16:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:16:19 --> Model Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Model Class Initialized
DEBUG - 2017-01-04 12:16:19 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:16:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:16:19 --> Final output sent to browser
DEBUG - 2017-01-04 12:16:19 --> Total execution time: 0.0422
DEBUG - 2017-01-04 12:26:06 --> Config Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:26:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:26:06 --> URI Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Router Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Output Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Security Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Input Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:26:06 --> Language Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Loader Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:26:06 --> Controller Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:26:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:26:06 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:06 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:26:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:26:06 --> Final output sent to browser
DEBUG - 2017-01-04 12:26:06 --> Total execution time: 0.0724
DEBUG - 2017-01-04 12:26:19 --> Config Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:26:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:26:19 --> URI Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Router Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Output Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Security Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Input Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:26:19 --> Language Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Loader Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:26:19 --> Controller Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:26:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:26:19 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:19 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:26:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:26:19 --> Final output sent to browser
DEBUG - 2017-01-04 12:26:19 --> Total execution time: 0.1155
DEBUG - 2017-01-04 12:26:31 --> Config Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:26:31 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:26:31 --> URI Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Router Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Output Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Security Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Input Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:26:31 --> Language Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Loader Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:26:31 --> Controller Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:26:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:26:31 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:31 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:26:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:26:31 --> Final output sent to browser
DEBUG - 2017-01-04 12:26:31 --> Total execution time: 0.0543
DEBUG - 2017-01-04 12:26:36 --> Config Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:26:36 --> URI Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Router Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Output Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Security Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Input Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:26:36 --> Language Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Loader Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:26:36 --> Controller Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:26:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:26:36 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Model Class Initialized
DEBUG - 2017-01-04 12:26:36 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:26:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:26:36 --> Final output sent to browser
DEBUG - 2017-01-04 12:26:36 --> Total execution time: 0.0903
DEBUG - 2017-01-04 12:27:06 --> Config Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:27:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:27:06 --> URI Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Router Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Output Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Security Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Input Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:27:06 --> Language Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Loader Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:27:06 --> Controller Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:27:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:27:06 --> Model Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Model Class Initialized
DEBUG - 2017-01-04 12:27:06 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:27:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:27:06 --> Final output sent to browser
DEBUG - 2017-01-04 12:27:06 --> Total execution time: 0.0268
DEBUG - 2017-01-04 12:27:27 --> Config Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:27:27 --> URI Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Router Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Output Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Security Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Input Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:27:27 --> Language Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Loader Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:27:27 --> Controller Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:27:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:27:27 --> Model Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Model Class Initialized
DEBUG - 2017-01-04 12:27:27 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:27:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:27:27 --> Final output sent to browser
DEBUG - 2017-01-04 12:27:27 --> Total execution time: 0.0474
DEBUG - 2017-01-04 12:28:08 --> Config Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:28:08 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:28:08 --> URI Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Router Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Output Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Security Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Input Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:28:08 --> Language Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Loader Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:28:08 --> Controller Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:28:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:28:08 --> Model Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Model Class Initialized
DEBUG - 2017-01-04 12:28:08 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:28:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:28:08 --> Final output sent to browser
DEBUG - 2017-01-04 12:28:08 --> Total execution time: 0.0267
DEBUG - 2017-01-04 12:28:25 --> Config Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:28:25 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:28:25 --> URI Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Router Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Output Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Security Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Input Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:28:25 --> Language Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Loader Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:28:25 --> Controller Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:28:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:28:25 --> Model Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Model Class Initialized
DEBUG - 2017-01-04 12:28:25 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:28:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:28:25 --> Final output sent to browser
DEBUG - 2017-01-04 12:28:25 --> Total execution time: 0.0262
DEBUG - 2017-01-04 12:28:38 --> Config Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:28:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:28:38 --> URI Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Router Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Output Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Security Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Input Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:28:38 --> Language Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Loader Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:28:38 --> Controller Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:28:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:28:38 --> Model Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Model Class Initialized
DEBUG - 2017-01-04 12:28:38 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:28:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:28:38 --> Final output sent to browser
DEBUG - 2017-01-04 12:28:38 --> Total execution time: 0.0262
DEBUG - 2017-01-04 12:29:16 --> Config Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:29:16 --> URI Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Router Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Output Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Security Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Input Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:29:16 --> Language Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Loader Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:29:16 --> Controller Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:29:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:29:16 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:16 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:29:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:29:16 --> Final output sent to browser
DEBUG - 2017-01-04 12:29:16 --> Total execution time: 0.0469
DEBUG - 2017-01-04 12:29:21 --> Config Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:29:21 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:29:21 --> URI Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Router Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Output Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Security Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Input Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:29:21 --> Language Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Loader Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:29:21 --> Controller Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:29:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:29:21 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:21 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:29:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:29:21 --> Final output sent to browser
DEBUG - 2017-01-04 12:29:21 --> Total execution time: 0.0864
DEBUG - 2017-01-04 12:29:24 --> Config Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:29:24 --> URI Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Router Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Output Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Security Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Input Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:29:24 --> Language Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Loader Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:29:24 --> Controller Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:29:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:29:24 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:24 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:29:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:29:24 --> Final output sent to browser
DEBUG - 2017-01-04 12:29:24 --> Total execution time: 0.0271
DEBUG - 2017-01-04 12:29:54 --> Config Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:29:54 --> URI Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Router Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Output Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Security Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Input Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:29:54 --> Language Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Loader Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:29:54 --> Controller Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:29:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:29:54 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Model Class Initialized
DEBUG - 2017-01-04 12:29:54 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:29:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:29:54 --> Final output sent to browser
DEBUG - 2017-01-04 12:29:54 --> Total execution time: 0.1065
DEBUG - 2017-01-04 12:34:39 --> Config Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:34:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:34:39 --> URI Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Router Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Output Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Security Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Input Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:34:39 --> Language Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Loader Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:34:39 --> Controller Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:34:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:34:39 --> Model Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Model Class Initialized
DEBUG - 2017-01-04 12:34:39 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:34:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:34:39 --> Final output sent to browser
DEBUG - 2017-01-04 12:34:39 --> Total execution time: 0.0298
DEBUG - 2017-01-04 12:35:51 --> Config Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:35:51 --> URI Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Router Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Output Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Security Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Input Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:35:51 --> Language Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Loader Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:35:51 --> Controller Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:35:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:35:51 --> Model Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Model Class Initialized
DEBUG - 2017-01-04 12:35:51 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:35:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:35:51 --> Final output sent to browser
DEBUG - 2017-01-04 12:35:51 --> Total execution time: 0.0269
DEBUG - 2017-01-04 12:58:06 --> Config Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Hooks Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Utf8 Class Initialized
DEBUG - 2017-01-04 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 12:58:06 --> URI Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Router Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Output Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Security Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Input Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 12:58:06 --> Language Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Loader Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Helper loaded: date_helper
DEBUG - 2017-01-04 12:58:06 --> Controller Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Database Driver Class Initialized
ERROR - 2017-01-04 12:58:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 12:58:06 --> Model Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Model Class Initialized
DEBUG - 2017-01-04 12:58:06 --> Helper loaded: url_helper
DEBUG - 2017-01-04 12:58:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 12:58:06 --> Final output sent to browser
DEBUG - 2017-01-04 12:58:06 --> Total execution time: 0.0463
DEBUG - 2017-01-04 13:07:57 --> Config Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:07:57 --> URI Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Router Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Output Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Security Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Input Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:07:57 --> Language Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Loader Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:07:57 --> Controller Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:07:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:07:57 --> Model Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Model Class Initialized
DEBUG - 2017-01-04 13:07:57 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:07:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:07:57 --> Final output sent to browser
DEBUG - 2017-01-04 13:07:57 --> Total execution time: 0.0607
DEBUG - 2017-01-04 13:09:53 --> Config Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:09:53 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:09:53 --> URI Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Router Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Output Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Security Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Input Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:09:53 --> Language Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Loader Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:09:53 --> Controller Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:09:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:09:53 --> Model Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Model Class Initialized
DEBUG - 2017-01-04 13:09:53 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:09:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:09:53 --> Final output sent to browser
DEBUG - 2017-01-04 13:09:53 --> Total execution time: 0.0263
DEBUG - 2017-01-04 13:12:16 --> Config Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:12:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:12:16 --> URI Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Router Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Output Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Security Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Input Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:12:16 --> Language Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Loader Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:12:16 --> Controller Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:12:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:12:16 --> Model Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Model Class Initialized
DEBUG - 2017-01-04 13:12:16 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:12:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:12:16 --> Final output sent to browser
DEBUG - 2017-01-04 13:12:16 --> Total execution time: 0.0857
DEBUG - 2017-01-04 13:14:15 --> Config Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:14:15 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:14:15 --> URI Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Router Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Output Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Security Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Input Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:14:15 --> Language Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Loader Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:14:15 --> Controller Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:14:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:14:15 --> Model Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Model Class Initialized
DEBUG - 2017-01-04 13:14:15 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:14:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:14:15 --> Final output sent to browser
DEBUG - 2017-01-04 13:14:15 --> Total execution time: 0.0271
DEBUG - 2017-01-04 13:14:20 --> Config Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:14:20 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:14:20 --> URI Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Router Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Output Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Security Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Input Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:14:20 --> Language Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Loader Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:14:20 --> Controller Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:14:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:14:20 --> Model Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Model Class Initialized
DEBUG - 2017-01-04 13:14:20 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:14:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:14:20 --> Final output sent to browser
DEBUG - 2017-01-04 13:14:20 --> Total execution time: 0.0480
DEBUG - 2017-01-04 13:19:40 --> Config Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:19:40 --> URI Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Router Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Output Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Security Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Input Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:19:40 --> Language Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Loader Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:19:40 --> Controller Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:19:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:19:40 --> Model Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Model Class Initialized
DEBUG - 2017-01-04 13:19:40 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:19:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:19:40 --> Final output sent to browser
DEBUG - 2017-01-04 13:19:40 --> Total execution time: 0.0625
DEBUG - 2017-01-04 13:19:43 --> Config Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:19:43 --> URI Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Router Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Output Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Security Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Input Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:19:43 --> Language Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Loader Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:19:43 --> Controller Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:19:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:19:43 --> Model Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Model Class Initialized
DEBUG - 2017-01-04 13:19:43 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:19:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:19:43 --> Final output sent to browser
DEBUG - 2017-01-04 13:19:43 --> Total execution time: 0.1107
DEBUG - 2017-01-04 13:31:47 --> Config Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:31:47 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:31:47 --> URI Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Router Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Output Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Security Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Input Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:31:47 --> Language Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Loader Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:31:47 --> Controller Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:31:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:31:47 --> Model Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Model Class Initialized
DEBUG - 2017-01-04 13:31:47 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:31:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:31:47 --> Final output sent to browser
DEBUG - 2017-01-04 13:31:47 --> Total execution time: 0.0768
DEBUG - 2017-01-04 13:48:07 --> Config Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:48:07 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:48:07 --> URI Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Router Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Output Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Security Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Input Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:48:07 --> Language Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Loader Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:48:07 --> Controller Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:48:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:48:07 --> Model Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Model Class Initialized
DEBUG - 2017-01-04 13:48:07 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:48:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:48:07 --> Final output sent to browser
DEBUG - 2017-01-04 13:48:07 --> Total execution time: 0.0692
DEBUG - 2017-01-04 13:48:24 --> Config Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Hooks Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Utf8 Class Initialized
DEBUG - 2017-01-04 13:48:24 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 13:48:24 --> URI Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Router Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Output Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Security Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Input Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 13:48:24 --> Language Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Loader Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Helper loaded: date_helper
DEBUG - 2017-01-04 13:48:24 --> Controller Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Database Driver Class Initialized
ERROR - 2017-01-04 13:48:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 13:48:24 --> Model Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Model Class Initialized
DEBUG - 2017-01-04 13:48:24 --> Helper loaded: url_helper
DEBUG - 2017-01-04 13:48:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 13:48:24 --> Final output sent to browser
DEBUG - 2017-01-04 13:48:24 --> Total execution time: 0.0604
DEBUG - 2017-01-04 14:09:16 --> Config Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:09:16 --> URI Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Router Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Output Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Security Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Input Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:09:16 --> Language Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Loader Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:09:16 --> Controller Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:09:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:09:16 --> Model Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Model Class Initialized
DEBUG - 2017-01-04 14:09:16 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:09:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 14:09:16 --> Final output sent to browser
DEBUG - 2017-01-04 14:09:16 --> Total execution time: 0.0613
DEBUG - 2017-01-04 14:09:33 --> Config Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:09:33 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:09:33 --> URI Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Router Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Output Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Security Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Input Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:09:33 --> Language Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Loader Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:09:33 --> Controller Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:09:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:09:33 --> Model Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Model Class Initialized
DEBUG - 2017-01-04 14:09:33 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:09:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 14:09:33 --> Final output sent to browser
DEBUG - 2017-01-04 14:09:33 --> Total execution time: 0.0445
DEBUG - 2017-01-04 14:16:40 --> Config Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:16:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:16:40 --> URI Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Router Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Output Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Security Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Input Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:16:40 --> Language Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Loader Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:16:40 --> Controller Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:16:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:16:40 --> Model Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Model Class Initialized
DEBUG - 2017-01-04 14:16:40 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:16:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 14:16:40 --> Final output sent to browser
DEBUG - 2017-01-04 14:16:40 --> Total execution time: 0.0771
DEBUG - 2017-01-04 14:16:44 --> Config Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:16:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:16:44 --> URI Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Router Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Output Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Security Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Input Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:16:44 --> Language Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Loader Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:16:44 --> Controller Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:16:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:16:44 --> Model Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Model Class Initialized
DEBUG - 2017-01-04 14:16:44 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:16:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 14:16:44 --> Final output sent to browser
DEBUG - 2017-01-04 14:16:44 --> Total execution time: 0.0686
DEBUG - 2017-01-04 14:19:35 --> Config Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:19:35 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:19:35 --> URI Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Router Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Output Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Security Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Input Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:19:35 --> Language Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Loader Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:19:35 --> Controller Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:19:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:19:35 --> Model Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Model Class Initialized
DEBUG - 2017-01-04 14:19:35 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:19:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-04 14:19:35 --> Final output sent to browser
DEBUG - 2017-01-04 14:19:35 --> Total execution time: 0.0747
DEBUG - 2017-01-04 14:51:29 --> Config Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:51:29 --> URI Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Router Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Output Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Security Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Input Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:51:29 --> Language Class Initialized
DEBUG - 2017-01-04 14:51:29 --> Loader Class Initialized
DEBUG - 2017-01-04 14:51:30 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:51:30 --> Controller Class Initialized
DEBUG - 2017-01-04 14:51:30 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:51:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:51:30 --> Model Class Initialized
DEBUG - 2017-01-04 14:51:30 --> Model Class Initialized
DEBUG - 2017-01-04 14:51:30 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:51:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 14:51:30 --> Final output sent to browser
DEBUG - 2017-01-04 14:51:30 --> Total execution time: 0.0400
DEBUG - 2017-01-04 14:51:38 --> Config Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:51:38 --> URI Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Router Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Output Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Security Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Input Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:51:38 --> Language Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Loader Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:51:38 --> Controller Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:51:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:51:38 --> Model Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Model Class Initialized
DEBUG - 2017-01-04 14:51:38 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:51:38 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-01-04 14:51:38 --> Final output sent to browser
DEBUG - 2017-01-04 14:51:38 --> Total execution time: 0.0375
DEBUG - 2017-01-04 14:51:58 --> Config Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:51:58 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:51:58 --> URI Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Router Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Output Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Security Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Input Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:51:58 --> Language Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Loader Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:51:58 --> Controller Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:51:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:51:58 --> Model Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Model Class Initialized
DEBUG - 2017-01-04 14:51:58 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:51:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 14:51:58 --> Final output sent to browser
DEBUG - 2017-01-04 14:51:58 --> Total execution time: 0.0193
DEBUG - 2017-01-04 14:52:00 --> Config Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Hooks Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Utf8 Class Initialized
DEBUG - 2017-01-04 14:52:00 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 14:52:00 --> URI Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Router Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Output Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Security Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Input Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 14:52:00 --> Language Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Loader Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Helper loaded: date_helper
DEBUG - 2017-01-04 14:52:00 --> Controller Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Database Driver Class Initialized
ERROR - 2017-01-04 14:52:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 14:52:00 --> Model Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Model Class Initialized
DEBUG - 2017-01-04 14:52:00 --> Helper loaded: url_helper
DEBUG - 2017-01-04 14:52:00 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-01-04 14:52:00 --> Final output sent to browser
DEBUG - 2017-01-04 14:52:00 --> Total execution time: 0.0534
DEBUG - 2017-01-04 17:35:09 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:09 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:09 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:09 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:09 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:09 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:09 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:09 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:09 --> Total execution time: 0.0251
DEBUG - 2017-01-04 17:35:36 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:36 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:36 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:36 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:36 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:36 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:36 --> Total execution time: 0.0207
DEBUG - 2017-01-04 17:35:36 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:36 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:36 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:36 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:36 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:36 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:36 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:36 --> Total execution time: 0.0259
DEBUG - 2017-01-04 17:35:38 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:38 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:38 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:38 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:38 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:38 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:38 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:38 --> Total execution time: 0.0201
DEBUG - 2017-01-04 17:35:39 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:39 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:39 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:39 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:39 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:39 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:39 --> Total execution time: 0.0241
DEBUG - 2017-01-04 17:35:39 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:39 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:39 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:39 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:39 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:39 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:39 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:39 --> Total execution time: 0.0195
DEBUG - 2017-01-04 17:35:40 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:40 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:40 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:40 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:40 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:40 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:40 --> Total execution time: 0.0202
DEBUG - 2017-01-04 17:35:40 --> Config Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Hooks Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Utf8 Class Initialized
DEBUG - 2017-01-04 17:35:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 17:35:40 --> URI Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Router Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Output Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Security Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Input Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 17:35:40 --> Language Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Loader Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Helper loaded: date_helper
DEBUG - 2017-01-04 17:35:40 --> Controller Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Database Driver Class Initialized
ERROR - 2017-01-04 17:35:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 17:35:40 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Model Class Initialized
DEBUG - 2017-01-04 17:35:40 --> Helper loaded: url_helper
DEBUG - 2017-01-04 17:35:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-01-04 17:35:40 --> Final output sent to browser
DEBUG - 2017-01-04 17:35:40 --> Total execution time: 0.0225
DEBUG - 2017-01-04 21:21:35 --> Config Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Hooks Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Utf8 Class Initialized
DEBUG - 2017-01-04 21:21:35 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 21:21:35 --> URI Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Router Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Output Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Security Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Input Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 21:21:35 --> Language Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Loader Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Helper loaded: date_helper
DEBUG - 2017-01-04 21:21:35 --> Controller Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Database Driver Class Initialized
ERROR - 2017-01-04 21:21:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 21:21:35 --> Model Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Model Class Initialized
DEBUG - 2017-01-04 21:21:35 --> Helper loaded: url_helper
DEBUG - 2017-01-04 21:21:35 --> File loaded: application/views/todo/ben_v.php
DEBUG - 2017-01-04 21:21:35 --> Final output sent to browser
DEBUG - 2017-01-04 21:21:35 --> Total execution time: 0.0208
DEBUG - 2017-01-04 22:04:26 --> Config Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Hooks Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Utf8 Class Initialized
DEBUG - 2017-01-04 22:04:26 --> UTF-8 Support Enabled
DEBUG - 2017-01-04 22:04:26 --> URI Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Router Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Output Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Security Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Input Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-04 22:04:26 --> Language Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Loader Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Helper loaded: date_helper
DEBUG - 2017-01-04 22:04:26 --> Controller Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Database Driver Class Initialized
ERROR - 2017-01-04 22:04:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-04 22:04:26 --> Model Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Model Class Initialized
DEBUG - 2017-01-04 22:04:26 --> Helper loaded: url_helper
DEBUG - 2017-01-04 22:04:26 --> File loaded: application/views/todo/ben_v.php
DEBUG - 2017-01-04 22:04:26 --> Final output sent to browser
DEBUG - 2017-01-04 22:04:26 --> Total execution time: 0.0199
