<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-24 04:04:19 --> Config Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Hooks Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Utf8 Class Initialized
DEBUG - 2017-11-24 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 04:04:19 --> URI Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Router Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Output Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Security Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Input Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 04:04:19 --> Language Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Loader Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Helper loaded: date_helper
DEBUG - 2017-11-24 04:04:19 --> Controller Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Database Driver Class Initialized
ERROR - 2017-11-24 04:04:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 04:04:19 --> Model Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Model Class Initialized
DEBUG - 2017-11-24 04:04:19 --> Helper loaded: url_helper
DEBUG - 2017-11-24 04:04:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-24 04:04:19 --> Final output sent to browser
DEBUG - 2017-11-24 04:04:19 --> Total execution time: 0.0264
DEBUG - 2017-11-24 04:04:20 --> Config Class Initialized
DEBUG - 2017-11-24 04:04:20 --> Hooks Class Initialized
DEBUG - 2017-11-24 04:04:20 --> Utf8 Class Initialized
DEBUG - 2017-11-24 04:04:20 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 04:04:20 --> URI Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Router Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Output Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Security Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Input Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 04:04:21 --> Language Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Loader Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Helper loaded: date_helper
DEBUG - 2017-11-24 04:04:21 --> Controller Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Database Driver Class Initialized
ERROR - 2017-11-24 04:04:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 04:04:21 --> Model Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Model Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Helper loaded: url_helper
DEBUG - 2017-11-24 04:04:21 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-11-24 04:04:21 --> Final output sent to browser
DEBUG - 2017-11-24 04:04:21 --> Total execution time: 0.0205
DEBUG - 2017-11-24 04:04:21 --> Config Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Hooks Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Utf8 Class Initialized
DEBUG - 2017-11-24 04:04:21 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 04:04:21 --> URI Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Router Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Output Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Security Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Input Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 04:04:21 --> Language Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Loader Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Helper loaded: date_helper
DEBUG - 2017-11-24 04:04:21 --> Controller Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Database Driver Class Initialized
ERROR - 2017-11-24 04:04:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 04:04:21 --> Model Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Model Class Initialized
DEBUG - 2017-11-24 04:04:21 --> Helper loaded: url_helper
DEBUG - 2017-11-24 04:04:21 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-11-24 04:04:21 --> Final output sent to browser
DEBUG - 2017-11-24 04:04:21 --> Total execution time: 0.0242
DEBUG - 2017-11-24 04:38:32 --> Config Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Hooks Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Utf8 Class Initialized
DEBUG - 2017-11-24 04:38:32 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 04:38:32 --> URI Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Router Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Output Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Security Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Input Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 04:38:32 --> Language Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Loader Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Helper loaded: date_helper
DEBUG - 2017-11-24 04:38:32 --> Controller Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Database Driver Class Initialized
ERROR - 2017-11-24 04:38:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 04:38:32 --> Model Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Model Class Initialized
DEBUG - 2017-11-24 04:38:32 --> Helper loaded: url_helper
DEBUG - 2017-11-24 04:38:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-24 04:38:32 --> Final output sent to browser
DEBUG - 2017-11-24 04:38:32 --> Total execution time: 0.0206
DEBUG - 2017-11-24 08:16:31 --> Config Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Hooks Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Utf8 Class Initialized
DEBUG - 2017-11-24 08:16:31 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 08:16:31 --> URI Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Router Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Output Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Security Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Input Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 08:16:31 --> Language Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Loader Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Helper loaded: date_helper
DEBUG - 2017-11-24 08:16:31 --> Controller Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Database Driver Class Initialized
ERROR - 2017-11-24 08:16:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 08:16:31 --> Model Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Model Class Initialized
DEBUG - 2017-11-24 08:16:31 --> Helper loaded: url_helper
DEBUG - 2017-11-24 08:16:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-24 08:16:31 --> Final output sent to browser
DEBUG - 2017-11-24 08:16:31 --> Total execution time: 0.0268
DEBUG - 2017-11-24 17:10:36 --> Config Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:10:36 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:10:36 --> URI Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Router Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Output Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Security Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Input Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:10:36 --> Language Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Loader Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:10:36 --> Controller Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:10:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:10:36 --> Model Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Model Class Initialized
DEBUG - 2017-11-24 17:10:36 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:10:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:10:37 --> Final output sent to browser
DEBUG - 2017-11-24 17:10:37 --> Total execution time: 0.0731
DEBUG - 2017-11-24 17:10:40 --> Config Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:10:40 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:10:40 --> URI Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Router Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Output Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Security Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Input Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:10:40 --> Language Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Loader Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:10:40 --> Controller Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:10:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:10:40 --> Model Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Model Class Initialized
DEBUG - 2017-11-24 17:10:40 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:10:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:10:40 --> Final output sent to browser
DEBUG - 2017-11-24 17:10:40 --> Total execution time: 0.0389
DEBUG - 2017-11-24 17:13:19 --> Config Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:13:19 --> URI Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Router Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Output Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Security Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Input Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:13:19 --> Language Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Loader Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:13:19 --> Controller Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:13:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:13:19 --> Model Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Model Class Initialized
DEBUG - 2017-11-24 17:13:19 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:13:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:13:19 --> Final output sent to browser
DEBUG - 2017-11-24 17:13:19 --> Total execution time: 0.0385
DEBUG - 2017-11-24 17:13:24 --> Config Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:13:24 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:13:24 --> URI Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Router Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Output Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Security Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Input Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:13:24 --> Language Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Loader Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:13:24 --> Controller Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:13:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:13:24 --> Model Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Model Class Initialized
DEBUG - 2017-11-24 17:13:24 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:13:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:13:24 --> Final output sent to browser
DEBUG - 2017-11-24 17:13:24 --> Total execution time: 0.0400
DEBUG - 2017-11-24 17:14:37 --> Config Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:14:37 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:14:37 --> URI Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Router Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Output Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Security Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Input Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:14:37 --> Language Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Loader Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:14:37 --> Controller Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:14:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:14:37 --> Model Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Model Class Initialized
DEBUG - 2017-11-24 17:14:37 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:14:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:14:38 --> Final output sent to browser
DEBUG - 2017-11-24 17:14:38 --> Total execution time: 0.0473
DEBUG - 2017-11-24 17:23:22 --> Config Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:23:22 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:23:22 --> URI Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Router Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Output Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Security Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Input Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:23:22 --> Language Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Loader Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:23:22 --> Controller Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:23:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:23:22 --> Model Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Model Class Initialized
DEBUG - 2017-11-24 17:23:22 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:23:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:23:22 --> Final output sent to browser
DEBUG - 2017-11-24 17:23:22 --> Total execution time: 0.0393
DEBUG - 2017-11-24 17:24:20 --> Config Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:24:20 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:24:20 --> URI Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Router Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Output Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Security Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Input Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:24:20 --> Language Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Loader Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:24:20 --> Controller Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:24:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:24:20 --> Model Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Model Class Initialized
DEBUG - 2017-11-24 17:24:20 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:24:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:24:20 --> Final output sent to browser
DEBUG - 2017-11-24 17:24:20 --> Total execution time: 0.0395
DEBUG - 2017-11-24 17:27:48 --> Config Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:27:48 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:27:48 --> URI Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Router Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Output Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Security Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Input Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:27:48 --> Language Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Loader Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:27:48 --> Controller Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:27:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:27:48 --> Model Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Model Class Initialized
DEBUG - 2017-11-24 17:27:48 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:27:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:27:48 --> Final output sent to browser
DEBUG - 2017-11-24 17:27:48 --> Total execution time: 0.0429
DEBUG - 2017-11-24 17:28:19 --> Config Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:28:19 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:28:19 --> URI Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Router Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Output Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Security Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Input Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:28:19 --> Language Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Loader Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:28:19 --> Controller Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:28:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:28:19 --> Model Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Model Class Initialized
DEBUG - 2017-11-24 17:28:19 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:28:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:28:19 --> Final output sent to browser
DEBUG - 2017-11-24 17:28:19 --> Total execution time: 0.0403
DEBUG - 2017-11-24 17:34:16 --> Config Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:34:16 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:34:16 --> URI Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Router Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Output Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Security Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Input Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:34:16 --> Language Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Loader Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:34:16 --> Controller Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:34:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:34:16 --> Model Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Model Class Initialized
DEBUG - 2017-11-24 17:34:16 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:34:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:34:16 --> Final output sent to browser
DEBUG - 2017-11-24 17:34:16 --> Total execution time: 0.0393
DEBUG - 2017-11-24 17:36:52 --> Config Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:36:52 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:36:52 --> URI Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Router Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Output Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Security Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Input Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:36:52 --> Language Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Loader Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:36:52 --> Controller Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:36:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:36:52 --> Model Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Model Class Initialized
DEBUG - 2017-11-24 17:36:52 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:36:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:36:52 --> Final output sent to browser
DEBUG - 2017-11-24 17:36:52 --> Total execution time: 0.0388
DEBUG - 2017-11-24 17:37:10 --> Config Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:37:10 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:37:10 --> URI Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Router Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Output Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Security Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Input Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:37:10 --> Language Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Loader Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:37:10 --> Controller Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:37:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:37:10 --> Model Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Model Class Initialized
DEBUG - 2017-11-24 17:37:10 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:37:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:37:10 --> Final output sent to browser
DEBUG - 2017-11-24 17:37:10 --> Total execution time: 0.0391
DEBUG - 2017-11-24 17:38:43 --> Config Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:38:43 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:38:43 --> URI Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Router Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Output Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Security Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Input Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:38:43 --> Language Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Loader Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:38:43 --> Controller Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:38:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:38:43 --> Model Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Model Class Initialized
DEBUG - 2017-11-24 17:38:43 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:38:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:38:43 --> Final output sent to browser
DEBUG - 2017-11-24 17:38:43 --> Total execution time: 0.0392
DEBUG - 2017-11-24 17:38:52 --> Config Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:38:52 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:38:52 --> URI Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Router Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Output Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Security Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Input Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:38:52 --> Language Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Loader Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:38:52 --> Controller Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:38:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:38:52 --> Model Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Model Class Initialized
DEBUG - 2017-11-24 17:38:52 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:38:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:38:52 --> Final output sent to browser
DEBUG - 2017-11-24 17:38:52 --> Total execution time: 0.0391
DEBUG - 2017-11-24 17:39:58 --> Config Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:39:58 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:39:58 --> URI Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Router Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Output Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Security Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Input Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:39:58 --> Language Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Loader Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:39:58 --> Controller Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:39:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:39:58 --> Model Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Model Class Initialized
DEBUG - 2017-11-24 17:39:58 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:39:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:39:58 --> Final output sent to browser
DEBUG - 2017-11-24 17:39:58 --> Total execution time: 0.0440
DEBUG - 2017-11-24 17:42:46 --> Config Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:42:46 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:42:46 --> URI Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Router Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Output Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Security Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Input Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:42:46 --> Language Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Loader Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:42:46 --> Controller Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:42:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:42:46 --> Model Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Model Class Initialized
DEBUG - 2017-11-24 17:42:46 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:42:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:42:46 --> Final output sent to browser
DEBUG - 2017-11-24 17:42:46 --> Total execution time: 0.0409
DEBUG - 2017-11-24 17:55:40 --> Config Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Hooks Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Utf8 Class Initialized
DEBUG - 2017-11-24 17:55:40 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 17:55:40 --> URI Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Router Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Output Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Security Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Input Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 17:55:40 --> Language Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Loader Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Helper loaded: date_helper
DEBUG - 2017-11-24 17:55:40 --> Controller Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Database Driver Class Initialized
ERROR - 2017-11-24 17:55:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 17:55:40 --> Model Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Model Class Initialized
DEBUG - 2017-11-24 17:55:40 --> Helper loaded: url_helper
DEBUG - 2017-11-24 17:55:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 17:55:40 --> Final output sent to browser
DEBUG - 2017-11-24 17:55:40 --> Total execution time: 0.0450
DEBUG - 2017-11-24 18:08:38 --> Config Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Hooks Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Utf8 Class Initialized
DEBUG - 2017-11-24 18:08:38 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 18:08:38 --> URI Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Router Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Output Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Security Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Input Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 18:08:38 --> Language Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Loader Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Helper loaded: date_helper
DEBUG - 2017-11-24 18:08:38 --> Controller Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Database Driver Class Initialized
ERROR - 2017-11-24 18:08:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 18:08:38 --> Model Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Model Class Initialized
DEBUG - 2017-11-24 18:08:38 --> Helper loaded: url_helper
DEBUG - 2017-11-24 18:08:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 18:08:38 --> Final output sent to browser
DEBUG - 2017-11-24 18:08:38 --> Total execution time: 0.0392
DEBUG - 2017-11-24 18:33:18 --> Config Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Hooks Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Utf8 Class Initialized
DEBUG - 2017-11-24 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 18:33:18 --> URI Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Router Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Output Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Security Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Input Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 18:33:18 --> Language Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Loader Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Helper loaded: date_helper
DEBUG - 2017-11-24 18:33:18 --> Controller Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Database Driver Class Initialized
ERROR - 2017-11-24 18:33:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 18:33:18 --> Model Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Model Class Initialized
DEBUG - 2017-11-24 18:33:18 --> Helper loaded: url_helper
DEBUG - 2017-11-24 18:33:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 18:33:18 --> Final output sent to browser
DEBUG - 2017-11-24 18:33:18 --> Total execution time: 0.0486
DEBUG - 2017-11-24 18:33:24 --> Config Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Hooks Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Utf8 Class Initialized
DEBUG - 2017-11-24 18:33:24 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 18:33:24 --> URI Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Router Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Output Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Security Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Input Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 18:33:24 --> Language Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Loader Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Helper loaded: date_helper
DEBUG - 2017-11-24 18:33:24 --> Controller Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Database Driver Class Initialized
ERROR - 2017-11-24 18:33:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 18:33:24 --> Model Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Model Class Initialized
DEBUG - 2017-11-24 18:33:24 --> Helper loaded: url_helper
DEBUG - 2017-11-24 18:33:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 18:33:24 --> Final output sent to browser
DEBUG - 2017-11-24 18:33:24 --> Total execution time: 0.0391
DEBUG - 2017-11-24 21:15:02 --> Config Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:15:02 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:15:02 --> URI Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Router Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Output Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Security Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Input Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:15:02 --> Language Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Loader Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:15:02 --> Controller Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:15:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:15:02 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:02 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:15:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:15:02 --> Final output sent to browser
DEBUG - 2017-11-24 21:15:02 --> Total execution time: 0.0484
DEBUG - 2017-11-24 21:15:05 --> Config Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:15:05 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:15:05 --> URI Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Router Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Output Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Security Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Input Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:15:05 --> Language Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Loader Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:15:05 --> Controller Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:15:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:15:05 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:05 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:15:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:15:05 --> Final output sent to browser
DEBUG - 2017-11-24 21:15:05 --> Total execution time: 0.0399
DEBUG - 2017-11-24 21:15:09 --> Config Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:15:09 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:15:09 --> URI Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Router Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Output Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Security Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Input Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:15:09 --> Language Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Loader Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:15:09 --> Controller Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:15:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:15:09 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:09 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:15:09 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:15:09 --> Final output sent to browser
DEBUG - 2017-11-24 21:15:09 --> Total execution time: 0.0380
DEBUG - 2017-11-24 21:15:13 --> Config Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:15:13 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:15:13 --> URI Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Router Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Output Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Security Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Input Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:15:13 --> Language Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Loader Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:15:13 --> Controller Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:15:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:15:13 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:13 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:15:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:15:13 --> Final output sent to browser
DEBUG - 2017-11-24 21:15:13 --> Total execution time: 0.0378
DEBUG - 2017-11-24 21:15:23 --> Config Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:15:23 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:15:23 --> URI Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Router Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Output Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Security Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Input Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:15:23 --> Language Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Loader Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:15:23 --> Controller Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:15:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:15:23 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:23 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:15:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:15:23 --> Final output sent to browser
DEBUG - 2017-11-24 21:15:23 --> Total execution time: 0.0381
DEBUG - 2017-11-24 21:15:45 --> Config Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:15:45 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:15:45 --> URI Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Router Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Output Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Security Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Input Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:15:45 --> Language Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Loader Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:15:45 --> Controller Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:15:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:15:45 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:45 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:15:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:15:45 --> Final output sent to browser
DEBUG - 2017-11-24 21:15:45 --> Total execution time: 0.0379
DEBUG - 2017-11-24 21:15:49 --> Config Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:15:49 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:15:49 --> URI Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Router Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Output Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Security Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Input Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:15:49 --> Language Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Loader Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:15:49 --> Controller Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:15:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:15:49 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Model Class Initialized
DEBUG - 2017-11-24 21:15:49 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:15:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:15:49 --> Final output sent to browser
DEBUG - 2017-11-24 21:15:49 --> Total execution time: 0.0368
DEBUG - 2017-11-24 21:16:00 --> Config Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:16:00 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:16:00 --> URI Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Router Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Output Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Security Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Input Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:16:00 --> Language Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Loader Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:16:00 --> Controller Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:16:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:16:00 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:00 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:16:00 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:16:00 --> Final output sent to browser
DEBUG - 2017-11-24 21:16:00 --> Total execution time: 0.0377
DEBUG - 2017-11-24 21:16:08 --> Config Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:16:08 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:16:08 --> URI Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Router Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Output Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Security Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Input Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:16:08 --> Language Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Loader Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:16:08 --> Controller Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:16:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:16:08 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:08 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:16:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:16:08 --> Final output sent to browser
DEBUG - 2017-11-24 21:16:08 --> Total execution time: 0.0378
DEBUG - 2017-11-24 21:16:16 --> Config Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:16:16 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:16:16 --> URI Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Router Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Output Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Security Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Input Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:16:16 --> Language Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Loader Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:16:16 --> Controller Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:16:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:16:16 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:16 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:16:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:16:16 --> Final output sent to browser
DEBUG - 2017-11-24 21:16:16 --> Total execution time: 0.0377
DEBUG - 2017-11-24 21:16:21 --> Config Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:16:21 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:16:21 --> URI Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Router Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Output Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Security Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Input Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:16:21 --> Language Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Loader Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:16:21 --> Controller Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:16:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:16:21 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Model Class Initialized
DEBUG - 2017-11-24 21:16:21 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:16:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:16:21 --> Final output sent to browser
DEBUG - 2017-11-24 21:16:21 --> Total execution time: 0.0380
DEBUG - 2017-11-24 21:42:10 --> Config Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Hooks Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Utf8 Class Initialized
DEBUG - 2017-11-24 21:42:10 --> UTF-8 Support Enabled
DEBUG - 2017-11-24 21:42:10 --> URI Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Router Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Output Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Security Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Input Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-24 21:42:10 --> Language Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Loader Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Helper loaded: date_helper
DEBUG - 2017-11-24 21:42:10 --> Controller Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Database Driver Class Initialized
ERROR - 2017-11-24 21:42:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-24 21:42:10 --> Model Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Model Class Initialized
DEBUG - 2017-11-24 21:42:10 --> Helper loaded: url_helper
DEBUG - 2017-11-24 21:42:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-24 21:42:10 --> Final output sent to browser
DEBUG - 2017-11-24 21:42:10 --> Total execution time: 0.0461
