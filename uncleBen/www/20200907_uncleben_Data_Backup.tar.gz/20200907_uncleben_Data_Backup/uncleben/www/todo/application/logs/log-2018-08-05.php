<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-05 00:55:05 --> Config Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Hooks Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Utf8 Class Initialized
DEBUG - 2018-08-05 00:55:05 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 00:55:05 --> URI Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Router Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Output Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Security Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Input Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 00:55:05 --> Language Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Loader Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Helper loaded: date_helper
DEBUG - 2018-08-05 00:55:05 --> Controller Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Database Driver Class Initialized
ERROR - 2018-08-05 00:55:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 00:55:05 --> Model Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Model Class Initialized
DEBUG - 2018-08-05 00:55:05 --> Helper loaded: url_helper
DEBUG - 2018-08-05 00:55:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 00:55:05 --> Final output sent to browser
DEBUG - 2018-08-05 00:55:05 --> Total execution time: 0.0298
DEBUG - 2018-08-05 00:57:35 --> Config Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Hooks Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Utf8 Class Initialized
DEBUG - 2018-08-05 00:57:35 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 00:57:35 --> URI Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Router Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Output Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Security Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Input Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 00:57:35 --> Language Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Loader Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Helper loaded: date_helper
DEBUG - 2018-08-05 00:57:35 --> Controller Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Database Driver Class Initialized
ERROR - 2018-08-05 00:57:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 00:57:35 --> Model Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Model Class Initialized
DEBUG - 2018-08-05 00:57:35 --> Helper loaded: url_helper
DEBUG - 2018-08-05 00:57:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 00:57:35 --> Final output sent to browser
DEBUG - 2018-08-05 00:57:35 --> Total execution time: 0.0208
DEBUG - 2018-08-05 06:23:18 --> Config Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Hooks Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Utf8 Class Initialized
DEBUG - 2018-08-05 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 06:23:18 --> URI Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Router Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Output Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Security Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Input Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 06:23:18 --> Language Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Loader Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Helper loaded: date_helper
DEBUG - 2018-08-05 06:23:18 --> Controller Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Database Driver Class Initialized
ERROR - 2018-08-05 06:23:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 06:23:18 --> Model Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Model Class Initialized
DEBUG - 2018-08-05 06:23:18 --> Helper loaded: url_helper
DEBUG - 2018-08-05 06:23:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 06:23:18 --> Final output sent to browser
DEBUG - 2018-08-05 06:23:18 --> Total execution time: 0.0283
DEBUG - 2018-08-05 14:09:10 --> Config Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Hooks Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Utf8 Class Initialized
DEBUG - 2018-08-05 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 14:09:10 --> URI Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Router Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Output Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Security Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Input Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 14:09:10 --> Language Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Loader Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Helper loaded: date_helper
DEBUG - 2018-08-05 14:09:10 --> Controller Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Database Driver Class Initialized
ERROR - 2018-08-05 14:09:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 14:09:10 --> Model Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Model Class Initialized
DEBUG - 2018-08-05 14:09:10 --> Helper loaded: url_helper
DEBUG - 2018-08-05 14:09:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 14:09:10 --> Final output sent to browser
DEBUG - 2018-08-05 14:09:10 --> Total execution time: 0.0214
DEBUG - 2018-08-05 16:01:47 --> Config Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Utf8 Class Initialized
DEBUG - 2018-08-05 16:01:47 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 16:01:47 --> URI Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Router Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Output Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Security Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Input Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 16:01:47 --> Language Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Loader Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Helper loaded: date_helper
DEBUG - 2018-08-05 16:01:47 --> Controller Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Database Driver Class Initialized
ERROR - 2018-08-05 16:01:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 16:01:47 --> Model Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Model Class Initialized
DEBUG - 2018-08-05 16:01:47 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:01:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 16:01:47 --> Final output sent to browser
DEBUG - 2018-08-05 16:01:47 --> Total execution time: 0.0210
DEBUG - 2018-08-05 16:03:01 --> Config Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Utf8 Class Initialized
DEBUG - 2018-08-05 16:03:01 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 16:03:01 --> URI Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Router Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Output Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Security Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Input Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 16:03:01 --> Language Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Loader Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Helper loaded: date_helper
DEBUG - 2018-08-05 16:03:01 --> Controller Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Database Driver Class Initialized
ERROR - 2018-08-05 16:03:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 16:03:01 --> Model Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Model Class Initialized
DEBUG - 2018-08-05 16:03:01 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:03:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 16:03:01 --> Final output sent to browser
DEBUG - 2018-08-05 16:03:01 --> Total execution time: 0.0215
DEBUG - 2018-08-05 16:21:40 --> Config Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Utf8 Class Initialized
DEBUG - 2018-08-05 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 16:21:40 --> URI Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Router Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Output Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Security Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Input Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 16:21:40 --> Language Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Loader Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Helper loaded: date_helper
DEBUG - 2018-08-05 16:21:40 --> Controller Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Database Driver Class Initialized
ERROR - 2018-08-05 16:21:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 16:21:40 --> Model Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Model Class Initialized
DEBUG - 2018-08-05 16:21:40 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:21:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 16:21:40 --> Final output sent to browser
DEBUG - 2018-08-05 16:21:40 --> Total execution time: 0.0228
DEBUG - 2018-08-05 21:52:05 --> Config Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Hooks Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Utf8 Class Initialized
DEBUG - 2018-08-05 21:52:05 --> UTF-8 Support Enabled
DEBUG - 2018-08-05 21:52:05 --> URI Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Router Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Output Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Security Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Input Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-05 21:52:05 --> Language Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Loader Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Helper loaded: date_helper
DEBUG - 2018-08-05 21:52:05 --> Controller Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Database Driver Class Initialized
ERROR - 2018-08-05 21:52:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-05 21:52:05 --> Model Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Model Class Initialized
DEBUG - 2018-08-05 21:52:05 --> Helper loaded: url_helper
DEBUG - 2018-08-05 21:52:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-05 21:52:05 --> Final output sent to browser
DEBUG - 2018-08-05 21:52:05 --> Total execution time: 0.0207
