<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-16 01:05:48 --> Config Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Hooks Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Utf8 Class Initialized
DEBUG - 2017-11-16 01:05:48 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 01:05:48 --> URI Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Router Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Output Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Security Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Input Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 01:05:48 --> Language Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Loader Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Helper loaded: date_helper
DEBUG - 2017-11-16 01:05:48 --> Controller Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Database Driver Class Initialized
ERROR - 2017-11-16 01:05:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 01:05:48 --> Model Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Model Class Initialized
DEBUG - 2017-11-16 01:05:48 --> Helper loaded: url_helper
DEBUG - 2017-11-16 01:05:48 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 01:05:48 --> Final output sent to browser
DEBUG - 2017-11-16 01:05:48 --> Total execution time: 0.0248
DEBUG - 2017-11-16 01:06:05 --> Config Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Hooks Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Utf8 Class Initialized
DEBUG - 2017-11-16 01:06:05 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 01:06:05 --> URI Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Router Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Output Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Security Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Input Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 01:06:05 --> Language Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Loader Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Helper loaded: date_helper
DEBUG - 2017-11-16 01:06:05 --> Controller Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Database Driver Class Initialized
ERROR - 2017-11-16 01:06:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 01:06:05 --> Model Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Model Class Initialized
DEBUG - 2017-11-16 01:06:05 --> Helper loaded: url_helper
DEBUG - 2017-11-16 01:06:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 01:06:05 --> Final output sent to browser
DEBUG - 2017-11-16 01:06:05 --> Total execution time: 0.0192
DEBUG - 2017-11-16 07:48:39 --> Config Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Hooks Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Utf8 Class Initialized
DEBUG - 2017-11-16 07:48:39 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 07:48:39 --> URI Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Router Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Output Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Security Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Input Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 07:48:39 --> Language Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Loader Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Helper loaded: date_helper
DEBUG - 2017-11-16 07:48:39 --> Controller Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Database Driver Class Initialized
ERROR - 2017-11-16 07:48:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 07:48:39 --> Model Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Model Class Initialized
DEBUG - 2017-11-16 07:48:39 --> Helper loaded: url_helper
DEBUG - 2017-11-16 07:48:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 07:48:39 --> Final output sent to browser
DEBUG - 2017-11-16 07:48:39 --> Total execution time: 0.0345
DEBUG - 2017-11-16 07:48:44 --> Config Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Hooks Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Utf8 Class Initialized
DEBUG - 2017-11-16 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 07:48:44 --> URI Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Router Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Output Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Security Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Input Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 07:48:44 --> Language Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Loader Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Helper loaded: date_helper
DEBUG - 2017-11-16 07:48:44 --> Controller Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Database Driver Class Initialized
ERROR - 2017-11-16 07:48:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 07:48:44 --> Model Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Model Class Initialized
DEBUG - 2017-11-16 07:48:44 --> Helper loaded: url_helper
DEBUG - 2017-11-16 07:48:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 07:48:44 --> Final output sent to browser
DEBUG - 2017-11-16 07:48:44 --> Total execution time: 0.0194
DEBUG - 2017-11-16 11:43:32 --> Config Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Hooks Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Utf8 Class Initialized
DEBUG - 2017-11-16 11:43:32 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 11:43:32 --> URI Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Router Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Output Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Security Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Input Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 11:43:32 --> Language Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Loader Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Helper loaded: date_helper
DEBUG - 2017-11-16 11:43:32 --> Controller Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Database Driver Class Initialized
ERROR - 2017-11-16 11:43:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 11:43:32 --> Model Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Model Class Initialized
DEBUG - 2017-11-16 11:43:32 --> Helper loaded: url_helper
DEBUG - 2017-11-16 11:43:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 11:43:32 --> Final output sent to browser
DEBUG - 2017-11-16 11:43:32 --> Total execution time: 0.0205
DEBUG - 2017-11-16 22:49:40 --> Config Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Hooks Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Utf8 Class Initialized
DEBUG - 2017-11-16 22:49:40 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 22:49:40 --> URI Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Router Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Output Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Security Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Input Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 22:49:40 --> Language Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Loader Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Helper loaded: date_helper
DEBUG - 2017-11-16 22:49:40 --> Controller Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Database Driver Class Initialized
ERROR - 2017-11-16 22:49:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 22:49:40 --> Model Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Model Class Initialized
DEBUG - 2017-11-16 22:49:40 --> Helper loaded: url_helper
DEBUG - 2017-11-16 22:49:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 22:49:40 --> Final output sent to browser
DEBUG - 2017-11-16 22:49:40 --> Total execution time: 0.0446
DEBUG - 2017-11-16 22:51:17 --> Config Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Hooks Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Utf8 Class Initialized
DEBUG - 2017-11-16 22:51:17 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 22:51:17 --> URI Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Router Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Output Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Security Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Input Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 22:51:17 --> Language Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Loader Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Helper loaded: date_helper
DEBUG - 2017-11-16 22:51:17 --> Controller Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Database Driver Class Initialized
ERROR - 2017-11-16 22:51:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 22:51:17 --> Model Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Model Class Initialized
DEBUG - 2017-11-16 22:51:17 --> Helper loaded: url_helper
DEBUG - 2017-11-16 22:51:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 22:51:17 --> Final output sent to browser
DEBUG - 2017-11-16 22:51:17 --> Total execution time: 0.0201
DEBUG - 2017-11-16 23:52:58 --> Config Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Hooks Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Utf8 Class Initialized
DEBUG - 2017-11-16 23:52:58 --> UTF-8 Support Enabled
DEBUG - 2017-11-16 23:52:58 --> URI Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Router Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Output Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Security Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Input Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-16 23:52:58 --> Language Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Loader Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Helper loaded: date_helper
DEBUG - 2017-11-16 23:52:58 --> Controller Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Database Driver Class Initialized
ERROR - 2017-11-16 23:52:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-16 23:52:58 --> Model Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Model Class Initialized
DEBUG - 2017-11-16 23:52:58 --> Helper loaded: url_helper
DEBUG - 2017-11-16 23:52:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-16 23:52:58 --> Final output sent to browser
DEBUG - 2017-11-16 23:52:58 --> Total execution time: 0.0212
