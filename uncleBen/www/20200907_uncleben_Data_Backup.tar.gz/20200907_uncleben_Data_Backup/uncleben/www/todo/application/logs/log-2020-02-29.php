<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-02-29 03:17:21 --> Config Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Hooks Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Utf8 Class Initialized
DEBUG - 2020-02-29 03:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 03:17:21 --> URI Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Router Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Output Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Security Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Input Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-29 03:17:21 --> Language Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Loader Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Helper loaded: date_helper
DEBUG - 2020-02-29 03:17:21 --> Controller Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Database Driver Class Initialized
ERROR - 2020-02-29 03:17:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-29 03:17:21 --> Model Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Model Class Initialized
DEBUG - 2020-02-29 03:17:21 --> Helper loaded: url_helper
DEBUG - 2020-02-29 03:17:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-29 03:17:21 --> Final output sent to browser
DEBUG - 2020-02-29 03:17:21 --> Total execution time: 0.2385
DEBUG - 2020-02-29 08:39:01 --> Config Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Hooks Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Utf8 Class Initialized
DEBUG - 2020-02-29 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 08:39:01 --> URI Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Router Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Output Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Security Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Input Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-29 08:39:01 --> Language Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Loader Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Helper loaded: date_helper
DEBUG - 2020-02-29 08:39:01 --> Controller Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Database Driver Class Initialized
ERROR - 2020-02-29 08:39:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-29 08:39:01 --> Model Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Model Class Initialized
DEBUG - 2020-02-29 08:39:01 --> Helper loaded: url_helper
DEBUG - 2020-02-29 08:39:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-29 08:39:01 --> Final output sent to browser
DEBUG - 2020-02-29 08:39:01 --> Total execution time: 0.0971
DEBUG - 2020-02-29 16:24:31 --> Config Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Hooks Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Utf8 Class Initialized
DEBUG - 2020-02-29 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 16:24:31 --> URI Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Router Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Output Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Security Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Input Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-29 16:24:31 --> Language Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Loader Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Helper loaded: date_helper
DEBUG - 2020-02-29 16:24:31 --> Controller Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Database Driver Class Initialized
ERROR - 2020-02-29 16:24:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-29 16:24:31 --> Model Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Model Class Initialized
DEBUG - 2020-02-29 16:24:31 --> Helper loaded: url_helper
DEBUG - 2020-02-29 16:24:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-29 16:24:31 --> Final output sent to browser
DEBUG - 2020-02-29 16:24:31 --> Total execution time: 0.1012
DEBUG - 2020-02-29 23:28:58 --> Config Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Hooks Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Utf8 Class Initialized
DEBUG - 2020-02-29 23:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-02-29 23:28:58 --> URI Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Router Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Output Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Security Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Input Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-29 23:28:58 --> Language Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Loader Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Helper loaded: date_helper
DEBUG - 2020-02-29 23:28:58 --> Controller Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Database Driver Class Initialized
ERROR - 2020-02-29 23:28:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-29 23:28:58 --> Model Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Model Class Initialized
DEBUG - 2020-02-29 23:28:58 --> Helper loaded: url_helper
DEBUG - 2020-02-29 23:28:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-29 23:28:58 --> Final output sent to browser
DEBUG - 2020-02-29 23:28:58 --> Total execution time: 0.1031
