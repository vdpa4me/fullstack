<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-30 02:19:55 --> Config Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Hooks Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Utf8 Class Initialized
DEBUG - 2017-05-30 02:19:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-30 02:19:55 --> URI Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Router Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Output Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Security Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Input Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-30 02:19:55 --> Language Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Loader Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Helper loaded: date_helper
DEBUG - 2017-05-30 02:19:55 --> Controller Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Database Driver Class Initialized
ERROR - 2017-05-30 02:19:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-30 02:19:55 --> Model Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Model Class Initialized
DEBUG - 2017-05-30 02:19:55 --> Helper loaded: url_helper
DEBUG - 2017-05-30 02:19:55 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-30 02:19:55 --> Final output sent to browser
DEBUG - 2017-05-30 02:19:55 --> Total execution time: 0.0680
DEBUG - 2017-05-30 02:20:08 --> Config Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Hooks Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Utf8 Class Initialized
DEBUG - 2017-05-30 02:20:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-30 02:20:08 --> URI Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Router Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Output Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Security Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Input Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-30 02:20:08 --> Language Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Loader Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Helper loaded: date_helper
DEBUG - 2017-05-30 02:20:08 --> Controller Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Database Driver Class Initialized
ERROR - 2017-05-30 02:20:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-30 02:20:08 --> Model Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Model Class Initialized
DEBUG - 2017-05-30 02:20:08 --> Helper loaded: url_helper
DEBUG - 2017-05-30 02:20:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-30 02:20:08 --> Final output sent to browser
DEBUG - 2017-05-30 02:20:08 --> Total execution time: 0.0329
DEBUG - 2017-05-30 02:20:12 --> Config Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Hooks Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Utf8 Class Initialized
DEBUG - 2017-05-30 02:20:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-30 02:20:12 --> URI Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Router Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Output Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Security Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Input Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-30 02:20:12 --> Language Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Loader Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Helper loaded: date_helper
DEBUG - 2017-05-30 02:20:12 --> Controller Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Database Driver Class Initialized
ERROR - 2017-05-30 02:20:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-30 02:20:12 --> Model Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Model Class Initialized
DEBUG - 2017-05-30 02:20:12 --> Helper loaded: url_helper
DEBUG - 2017-05-30 02:20:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-30 02:20:12 --> Final output sent to browser
DEBUG - 2017-05-30 02:20:12 --> Total execution time: 0.0328
DEBUG - 2017-05-30 05:36:25 --> Config Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Hooks Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Utf8 Class Initialized
DEBUG - 2017-05-30 05:36:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-30 05:36:25 --> URI Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Router Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Output Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Security Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Input Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-30 05:36:25 --> Language Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Loader Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Helper loaded: date_helper
DEBUG - 2017-05-30 05:36:25 --> Controller Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Database Driver Class Initialized
ERROR - 2017-05-30 05:36:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-30 05:36:25 --> Model Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Model Class Initialized
DEBUG - 2017-05-30 05:36:25 --> Helper loaded: url_helper
DEBUG - 2017-05-30 05:36:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-05-30 05:36:25 --> Final output sent to browser
DEBUG - 2017-05-30 05:36:25 --> Total execution time: 0.0272
DEBUG - 2017-05-30 07:20:05 --> Config Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Hooks Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Utf8 Class Initialized
DEBUG - 2017-05-30 07:20:05 --> UTF-8 Support Enabled
DEBUG - 2017-05-30 07:20:05 --> URI Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Router Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Output Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Security Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Input Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-30 07:20:05 --> Language Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Loader Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Helper loaded: date_helper
DEBUG - 2017-05-30 07:20:05 --> Controller Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Database Driver Class Initialized
ERROR - 2017-05-30 07:20:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-30 07:20:05 --> Model Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Model Class Initialized
DEBUG - 2017-05-30 07:20:05 --> Helper loaded: url_helper
DEBUG - 2017-05-30 07:20:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-05-30 07:20:05 --> Final output sent to browser
DEBUG - 2017-05-30 07:20:05 --> Total execution time: 0.0255
