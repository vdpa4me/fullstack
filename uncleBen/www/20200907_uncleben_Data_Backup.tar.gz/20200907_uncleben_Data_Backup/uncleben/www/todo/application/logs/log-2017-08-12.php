<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-08-12 01:53:53 --> Config Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Hooks Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Utf8 Class Initialized
DEBUG - 2017-08-12 01:53:53 --> UTF-8 Support Enabled
DEBUG - 2017-08-12 01:53:53 --> URI Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Router Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Output Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Security Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Input Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-12 01:53:53 --> Language Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Loader Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Helper loaded: date_helper
DEBUG - 2017-08-12 01:53:53 --> Controller Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Database Driver Class Initialized
ERROR - 2017-08-12 01:53:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-12 01:53:53 --> Model Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Model Class Initialized
DEBUG - 2017-08-12 01:53:53 --> Helper loaded: url_helper
DEBUG - 2017-08-12 01:53:53 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-08-12 01:53:53 --> Final output sent to browser
DEBUG - 2017-08-12 01:53:53 --> Total execution time: 0.0392
