<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-02-09 06:05:05 --> Config Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Hooks Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Utf8 Class Initialized
DEBUG - 2017-02-09 06:05:05 --> UTF-8 Support Enabled
DEBUG - 2017-02-09 06:05:05 --> URI Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Router Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Output Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Security Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Input Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-09 06:05:05 --> Language Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Loader Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Helper loaded: date_helper
DEBUG - 2017-02-09 06:05:05 --> Controller Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Database Driver Class Initialized
ERROR - 2017-02-09 06:05:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-09 06:05:05 --> Model Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Model Class Initialized
DEBUG - 2017-02-09 06:05:05 --> Helper loaded: url_helper
DEBUG - 2017-02-09 06:05:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-02-09 06:05:05 --> Final output sent to browser
DEBUG - 2017-02-09 06:05:05 --> Total execution time: 0.0427
DEBUG - 2017-02-09 06:05:16 --> Config Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Hooks Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Utf8 Class Initialized
DEBUG - 2017-02-09 06:05:16 --> UTF-8 Support Enabled
DEBUG - 2017-02-09 06:05:16 --> URI Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Router Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Output Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Security Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Input Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-09 06:05:16 --> Language Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Loader Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Helper loaded: date_helper
DEBUG - 2017-02-09 06:05:16 --> Controller Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Database Driver Class Initialized
ERROR - 2017-02-09 06:05:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-09 06:05:16 --> Model Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Model Class Initialized
DEBUG - 2017-02-09 06:05:16 --> Helper loaded: url_helper
DEBUG - 2017-02-09 06:05:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-02-09 06:05:16 --> Final output sent to browser
DEBUG - 2017-02-09 06:05:16 --> Total execution time: 0.0280
DEBUG - 2017-02-09 06:05:22 --> Config Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Hooks Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Utf8 Class Initialized
DEBUG - 2017-02-09 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2017-02-09 06:05:22 --> URI Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Router Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Output Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Security Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Input Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-09 06:05:22 --> Language Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Loader Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Helper loaded: date_helper
DEBUG - 2017-02-09 06:05:22 --> Controller Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Database Driver Class Initialized
ERROR - 2017-02-09 06:05:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-09 06:05:22 --> Model Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Model Class Initialized
DEBUG - 2017-02-09 06:05:22 --> Helper loaded: url_helper
DEBUG - 2017-02-09 06:05:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-02-09 06:05:22 --> Final output sent to browser
DEBUG - 2017-02-09 06:05:22 --> Total execution time: 0.0287
