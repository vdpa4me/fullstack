<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-05-07 00:48:12 --> Config Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Hooks Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Utf8 Class Initialized
DEBUG - 2018-05-07 00:48:12 --> UTF-8 Support Enabled
DEBUG - 2018-05-07 00:48:12 --> URI Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Router Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Output Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Security Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Input Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-07 00:48:12 --> Language Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Loader Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Helper loaded: date_helper
DEBUG - 2018-05-07 00:48:12 --> Controller Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Database Driver Class Initialized
ERROR - 2018-05-07 00:48:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-07 00:48:12 --> Model Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Model Class Initialized
DEBUG - 2018-05-07 00:48:12 --> Helper loaded: url_helper
DEBUG - 2018-05-07 00:48:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-07 00:48:12 --> Final output sent to browser
DEBUG - 2018-05-07 00:48:12 --> Total execution time: 0.0218
DEBUG - 2018-05-07 07:17:15 --> Config Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Hooks Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Utf8 Class Initialized
DEBUG - 2018-05-07 07:17:15 --> UTF-8 Support Enabled
DEBUG - 2018-05-07 07:17:15 --> URI Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Router Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Output Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Security Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Input Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-07 07:17:15 --> Language Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Loader Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Helper loaded: date_helper
DEBUG - 2018-05-07 07:17:15 --> Controller Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Database Driver Class Initialized
ERROR - 2018-05-07 07:17:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-07 07:17:15 --> Model Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Model Class Initialized
DEBUG - 2018-05-07 07:17:15 --> Helper loaded: url_helper
DEBUG - 2018-05-07 07:17:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-07 07:17:15 --> Final output sent to browser
DEBUG - 2018-05-07 07:17:15 --> Total execution time: 0.0273
DEBUG - 2018-05-07 22:59:32 --> Config Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Hooks Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Utf8 Class Initialized
DEBUG - 2018-05-07 22:59:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-07 22:59:32 --> URI Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Router Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Output Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Security Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Input Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-07 22:59:32 --> Language Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Loader Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Helper loaded: date_helper
DEBUG - 2018-05-07 22:59:32 --> Controller Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Database Driver Class Initialized
ERROR - 2018-05-07 22:59:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-07 22:59:32 --> Model Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Model Class Initialized
DEBUG - 2018-05-07 22:59:32 --> Helper loaded: url_helper
DEBUG - 2018-05-07 22:59:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-07 22:59:32 --> Final output sent to browser
DEBUG - 2018-05-07 22:59:32 --> Total execution time: 0.0259
