<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-23 08:33:19 --> Config Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Hooks Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Utf8 Class Initialized
DEBUG - 2017-11-23 08:33:19 --> UTF-8 Support Enabled
DEBUG - 2017-11-23 08:33:19 --> URI Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Router Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Output Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Security Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Input Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-23 08:33:19 --> Language Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Loader Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Helper loaded: date_helper
DEBUG - 2017-11-23 08:33:19 --> Controller Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Database Driver Class Initialized
ERROR - 2017-11-23 08:33:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-23 08:33:19 --> Model Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Model Class Initialized
DEBUG - 2017-11-23 08:33:19 --> Helper loaded: url_helper
DEBUG - 2017-11-23 08:33:19 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-23 08:33:19 --> Final output sent to browser
DEBUG - 2017-11-23 08:33:19 --> Total execution time: 0.0402
DEBUG - 2017-11-23 18:03:42 --> Config Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Hooks Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Utf8 Class Initialized
DEBUG - 2017-11-23 18:03:42 --> UTF-8 Support Enabled
DEBUG - 2017-11-23 18:03:42 --> URI Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Router Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Output Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Security Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Input Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-23 18:03:42 --> Language Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Loader Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Helper loaded: date_helper
DEBUG - 2017-11-23 18:03:42 --> Controller Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Database Driver Class Initialized
ERROR - 2017-11-23 18:03:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-23 18:03:42 --> Model Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Model Class Initialized
DEBUG - 2017-11-23 18:03:42 --> Helper loaded: url_helper
DEBUG - 2017-11-23 18:03:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-11-23 18:03:42 --> Final output sent to browser
DEBUG - 2017-11-23 18:03:42 --> Total execution time: 0.0729
