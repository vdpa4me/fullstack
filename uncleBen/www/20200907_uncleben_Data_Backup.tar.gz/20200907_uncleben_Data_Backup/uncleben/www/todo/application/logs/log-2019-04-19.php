<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-19 03:17:26 --> Config Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Hooks Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Utf8 Class Initialized
DEBUG - 2019-04-19 03:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-19 03:17:26 --> URI Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Router Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Output Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Security Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Input Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-19 03:17:26 --> Language Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Loader Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Helper loaded: date_helper
DEBUG - 2019-04-19 03:17:26 --> Controller Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Database Driver Class Initialized
ERROR - 2019-04-19 03:17:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-19 03:17:26 --> Model Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Model Class Initialized
DEBUG - 2019-04-19 03:17:26 --> Helper loaded: url_helper
DEBUG - 2019-04-19 03:17:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-04-19 03:17:27 --> Final output sent to browser
DEBUG - 2019-04-19 03:17:27 --> Total execution time: 0.1246
DEBUG - 2019-04-19 03:17:33 --> Config Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Hooks Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Utf8 Class Initialized
DEBUG - 2019-04-19 03:17:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-19 03:17:33 --> URI Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Router Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Output Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Security Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Input Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-19 03:17:33 --> Language Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Loader Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Helper loaded: date_helper
DEBUG - 2019-04-19 03:17:33 --> Controller Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Database Driver Class Initialized
ERROR - 2019-04-19 03:17:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-19 03:17:33 --> Model Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Model Class Initialized
DEBUG - 2019-04-19 03:17:33 --> Helper loaded: url_helper
DEBUG - 2019-04-19 03:17:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-04-19 03:17:33 --> Final output sent to browser
DEBUG - 2019-04-19 03:17:33 --> Total execution time: 0.0665
DEBUG - 2019-04-19 03:18:02 --> Config Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Hooks Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Utf8 Class Initialized
DEBUG - 2019-04-19 03:18:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-19 03:18:02 --> URI Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Router Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Output Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Security Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Input Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-19 03:18:02 --> Language Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Loader Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Helper loaded: date_helper
DEBUG - 2019-04-19 03:18:02 --> Controller Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Database Driver Class Initialized
ERROR - 2019-04-19 03:18:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-19 03:18:02 --> Model Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Model Class Initialized
DEBUG - 2019-04-19 03:18:02 --> Helper loaded: url_helper
DEBUG - 2019-04-19 03:18:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-04-19 03:18:02 --> Final output sent to browser
DEBUG - 2019-04-19 03:18:02 --> Total execution time: 0.0685
DEBUG - 2019-04-19 07:13:46 --> Config Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Hooks Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Utf8 Class Initialized
DEBUG - 2019-04-19 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-19 07:13:46 --> URI Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Router Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Output Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Security Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Input Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-19 07:13:46 --> Language Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Loader Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Helper loaded: date_helper
DEBUG - 2019-04-19 07:13:46 --> Controller Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Database Driver Class Initialized
ERROR - 2019-04-19 07:13:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-04-19 07:13:46 --> Model Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Model Class Initialized
DEBUG - 2019-04-19 07:13:46 --> Helper loaded: url_helper
DEBUG - 2019-04-19 07:13:46 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-04-19 07:13:46 --> Final output sent to browser
DEBUG - 2019-04-19 07:13:46 --> Total execution time: 0.0344
