<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-07-20 02:30:58 --> Config Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Hooks Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Utf8 Class Initialized
DEBUG - 2019-07-20 02:30:58 --> UTF-8 Support Enabled
DEBUG - 2019-07-20 02:30:58 --> URI Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Router Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Output Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Security Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Input Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-20 02:30:58 --> Language Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Loader Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Helper loaded: date_helper
DEBUG - 2019-07-20 02:30:58 --> Controller Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Database Driver Class Initialized
ERROR - 2019-07-20 02:30:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-20 02:30:58 --> Model Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Model Class Initialized
DEBUG - 2019-07-20 02:30:58 --> Helper loaded: url_helper
DEBUG - 2019-07-20 02:30:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-20 02:30:58 --> Final output sent to browser
DEBUG - 2019-07-20 02:30:58 --> Total execution time: 0.0369
DEBUG - 2019-07-20 04:02:18 --> Config Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Utf8 Class Initialized
DEBUG - 2019-07-20 04:02:18 --> UTF-8 Support Enabled
DEBUG - 2019-07-20 04:02:18 --> URI Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Router Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Output Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Security Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Input Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-20 04:02:18 --> Language Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Loader Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Helper loaded: date_helper
DEBUG - 2019-07-20 04:02:18 --> Controller Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Database Driver Class Initialized
ERROR - 2019-07-20 04:02:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-20 04:02:18 --> Model Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Model Class Initialized
DEBUG - 2019-07-20 04:02:18 --> Helper loaded: url_helper
DEBUG - 2019-07-20 04:02:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-20 04:02:18 --> Final output sent to browser
DEBUG - 2019-07-20 04:02:18 --> Total execution time: 0.0303
DEBUG - 2019-07-20 09:40:15 --> Config Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Utf8 Class Initialized
DEBUG - 2019-07-20 09:40:15 --> UTF-8 Support Enabled
DEBUG - 2019-07-20 09:40:15 --> URI Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Router Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Output Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Security Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Input Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-20 09:40:15 --> Language Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Loader Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Helper loaded: date_helper
DEBUG - 2019-07-20 09:40:15 --> Controller Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Database Driver Class Initialized
ERROR - 2019-07-20 09:40:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-20 09:40:15 --> Model Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Model Class Initialized
DEBUG - 2019-07-20 09:40:15 --> Helper loaded: url_helper
DEBUG - 2019-07-20 09:40:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-20 09:40:15 --> Final output sent to browser
DEBUG - 2019-07-20 09:40:15 --> Total execution time: 0.0371
DEBUG - 2019-07-20 11:56:45 --> Config Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Utf8 Class Initialized
DEBUG - 2019-07-20 11:56:45 --> UTF-8 Support Enabled
DEBUG - 2019-07-20 11:56:45 --> URI Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Router Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Output Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Security Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Input Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-20 11:56:45 --> Language Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Loader Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Helper loaded: date_helper
DEBUG - 2019-07-20 11:56:45 --> Controller Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Database Driver Class Initialized
ERROR - 2019-07-20 11:56:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-20 11:56:45 --> Model Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Model Class Initialized
DEBUG - 2019-07-20 11:56:45 --> Helper loaded: url_helper
DEBUG - 2019-07-20 11:56:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-20 11:56:45 --> Final output sent to browser
DEBUG - 2019-07-20 11:56:45 --> Total execution time: 0.0231
DEBUG - 2019-07-20 18:04:01 --> Config Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Utf8 Class Initialized
DEBUG - 2019-07-20 18:04:01 --> UTF-8 Support Enabled
DEBUG - 2019-07-20 18:04:01 --> URI Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Router Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Output Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Security Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Input Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-20 18:04:01 --> Language Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Loader Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Helper loaded: date_helper
DEBUG - 2019-07-20 18:04:01 --> Controller Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Database Driver Class Initialized
ERROR - 2019-07-20 18:04:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-20 18:04:01 --> Model Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Model Class Initialized
DEBUG - 2019-07-20 18:04:01 --> Helper loaded: url_helper
DEBUG - 2019-07-20 18:04:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-20 18:04:01 --> Final output sent to browser
DEBUG - 2019-07-20 18:04:01 --> Total execution time: 0.0422
DEBUG - 2019-07-20 20:51:00 --> Config Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Hooks Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Utf8 Class Initialized
DEBUG - 2019-07-20 20:51:00 --> UTF-8 Support Enabled
DEBUG - 2019-07-20 20:51:00 --> URI Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Router Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Output Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Security Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Input Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-20 20:51:00 --> Language Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Loader Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Helper loaded: date_helper
DEBUG - 2019-07-20 20:51:00 --> Controller Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Database Driver Class Initialized
ERROR - 2019-07-20 20:51:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-20 20:51:00 --> Model Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Model Class Initialized
DEBUG - 2019-07-20 20:51:00 --> Helper loaded: url_helper
DEBUG - 2019-07-20 20:51:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-20 20:51:00 --> Final output sent to browser
DEBUG - 2019-07-20 20:51:00 --> Total execution time: 0.0298
