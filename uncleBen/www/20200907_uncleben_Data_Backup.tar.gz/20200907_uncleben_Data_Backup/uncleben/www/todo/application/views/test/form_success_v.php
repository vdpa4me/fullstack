	<article id="board_area">
		<header>
			<h1>전송 성공</h1>
		</header>
	</article>