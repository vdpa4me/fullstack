<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-11-04 17:39:01 --> Config Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Hooks Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Utf8 Class Initialized
DEBUG - 2017-11-04 17:39:01 --> UTF-8 Support Enabled
DEBUG - 2017-11-04 17:39:01 --> URI Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Router Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Output Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Security Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Input Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-04 17:39:01 --> Language Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Loader Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Helper loaded: date_helper
DEBUG - 2017-11-04 17:39:01 --> Controller Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Database Driver Class Initialized
ERROR - 2017-11-04 17:39:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-04 17:39:01 --> Model Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Model Class Initialized
DEBUG - 2017-11-04 17:39:01 --> Helper loaded: url_helper
DEBUG - 2017-11-04 17:39:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-04 17:39:01 --> Final output sent to browser
DEBUG - 2017-11-04 17:39:01 --> Total execution time: 0.0349
DEBUG - 2017-11-04 22:46:07 --> Config Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Hooks Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Utf8 Class Initialized
DEBUG - 2017-11-04 22:46:07 --> UTF-8 Support Enabled
DEBUG - 2017-11-04 22:46:07 --> URI Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Router Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Output Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Security Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Input Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-11-04 22:46:07 --> Language Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Loader Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Helper loaded: date_helper
DEBUG - 2017-11-04 22:46:07 --> Controller Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Database Driver Class Initialized
ERROR - 2017-11-04 22:46:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-11-04 22:46:07 --> Model Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Model Class Initialized
DEBUG - 2017-11-04 22:46:07 --> Helper loaded: url_helper
DEBUG - 2017-11-04 22:46:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-11-04 22:46:07 --> Final output sent to browser
DEBUG - 2017-11-04 22:46:07 --> Total execution time: 0.0200
