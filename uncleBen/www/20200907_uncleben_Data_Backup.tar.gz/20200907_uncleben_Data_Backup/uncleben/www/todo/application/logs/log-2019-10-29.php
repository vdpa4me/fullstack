<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-10-29 05:19:02 --> Config Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Hooks Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Utf8 Class Initialized
DEBUG - 2019-10-29 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-29 05:19:02 --> URI Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Router Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Output Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Security Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Input Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-29 05:19:02 --> Language Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Loader Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Helper loaded: date_helper
DEBUG - 2019-10-29 05:19:02 --> Controller Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Database Driver Class Initialized
ERROR - 2019-10-29 05:19:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-29 05:19:02 --> Model Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Model Class Initialized
DEBUG - 2019-10-29 05:19:02 --> Helper loaded: url_helper
DEBUG - 2019-10-29 05:19:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-29 05:19:02 --> Final output sent to browser
DEBUG - 2019-10-29 05:19:02 --> Total execution time: 0.2346
DEBUG - 2019-10-29 07:08:21 --> Config Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Hooks Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Utf8 Class Initialized
DEBUG - 2019-10-29 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-29 07:08:21 --> URI Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Router Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Output Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Security Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Input Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-29 07:08:21 --> Language Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Loader Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Helper loaded: date_helper
DEBUG - 2019-10-29 07:08:21 --> Controller Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Database Driver Class Initialized
ERROR - 2019-10-29 07:08:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-29 07:08:21 --> Model Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Model Class Initialized
DEBUG - 2019-10-29 07:08:21 --> Helper loaded: url_helper
DEBUG - 2019-10-29 07:08:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-29 07:08:21 --> Final output sent to browser
DEBUG - 2019-10-29 07:08:21 --> Total execution time: 0.1852
DEBUG - 2019-10-29 17:59:36 --> Config Class Initialized
DEBUG - 2019-10-29 17:59:36 --> Hooks Class Initialized
DEBUG - 2019-10-29 17:59:36 --> Utf8 Class Initialized
DEBUG - 2019-10-29 17:59:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-29 17:59:36 --> URI Class Initialized
DEBUG - 2019-10-29 17:59:36 --> Router Class Initialized
DEBUG - 2019-10-29 17:59:36 --> Output Class Initialized
DEBUG - 2019-10-29 17:59:36 --> Security Class Initialized
DEBUG - 2019-10-29 17:59:36 --> Input Class Initialized
DEBUG - 2019-10-29 17:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-29 17:59:37 --> Language Class Initialized
DEBUG - 2019-10-29 17:59:37 --> Loader Class Initialized
DEBUG - 2019-10-29 17:59:37 --> Helper loaded: date_helper
DEBUG - 2019-10-29 17:59:37 --> Controller Class Initialized
DEBUG - 2019-10-29 17:59:37 --> Database Driver Class Initialized
ERROR - 2019-10-29 17:59:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-29 17:59:37 --> Model Class Initialized
DEBUG - 2019-10-29 17:59:37 --> Model Class Initialized
DEBUG - 2019-10-29 17:59:37 --> Helper loaded: url_helper
DEBUG - 2019-10-29 17:59:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-29 17:59:37 --> Final output sent to browser
DEBUG - 2019-10-29 17:59:37 --> Total execution time: 0.2395
