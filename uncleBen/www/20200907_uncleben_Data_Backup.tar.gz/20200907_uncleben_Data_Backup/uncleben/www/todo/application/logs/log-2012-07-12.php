<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-12 16:41:43 --> Config Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:41:43 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:41:43 --> URI Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Router Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Output Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Security Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Input Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:41:43 --> Language Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Loader Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:41:43 --> Controller Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:43 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:43 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:41:43 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:41:43 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:41:43 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:41:43 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:41:43 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:41:43 --> Final output sent to browser
DEBUG - 2012-07-12 16:41:43 --> Total execution time: 0.4587
DEBUG - 2012-07-12 16:41:51 --> Config Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:41:51 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:41:51 --> URI Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Router Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Output Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Security Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Input Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:41:51 --> Language Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Loader Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:41:51 --> Controller Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:51 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:51 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:41:51 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:41:51 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:41:51 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:41:51 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:41:51 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:41:51 --> Final output sent to browser
DEBUG - 2012-07-12 16:41:51 --> Total execution time: 0.0561
DEBUG - 2012-07-12 16:41:53 --> Config Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:41:53 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:41:53 --> URI Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Router Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Output Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Security Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Input Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:41:53 --> Language Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Loader Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:41:53 --> Controller Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:53 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:53 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:41:53 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-12 16:41:53 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:41:53 --> Final output sent to browser
DEBUG - 2012-07-12 16:41:53 --> Total execution time: 0.0844
DEBUG - 2012-07-12 16:41:55 --> Config Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:41:55 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:41:55 --> URI Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Router Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Output Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Security Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Input Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:41:55 --> Language Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Loader Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:41:55 --> Controller Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:55 --> Model Class Initialized
DEBUG - 2012-07-12 16:41:55 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:41:55 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:41:55 --> Final output sent to browser
DEBUG - 2012-07-12 16:41:55 --> Total execution time: 0.0406
DEBUG - 2012-07-12 16:42:06 --> Config Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:42:06 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:42:06 --> URI Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Router Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Output Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Security Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Input Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:42:06 --> Language Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Loader Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:42:06 --> Controller Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Model Class Initialized
DEBUG - 2012-07-12 16:42:06 --> Model Class Initialized
DEBUG - 2012-07-12 16:42:06 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:42:06 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:42:06 --> Final output sent to browser
DEBUG - 2012-07-12 16:42:06 --> Total execution time: 0.0378
DEBUG - 2012-07-12 16:42:11 --> Config Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:42:11 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:42:11 --> URI Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Router Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Output Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Security Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Input Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:42:11 --> Language Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Loader Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:42:11 --> Controller Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Model Class Initialized
DEBUG - 2012-07-12 16:42:11 --> Model Class Initialized
DEBUG - 2012-07-12 16:42:11 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:42:11 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:42:11 --> Final output sent to browser
DEBUG - 2012-07-12 16:42:11 --> Total execution time: 0.0502
DEBUG - 2012-07-12 16:42:19 --> Config Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:42:19 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:42:19 --> URI Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Router Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Output Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Security Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Input Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:42:19 --> Language Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Loader Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:42:19 --> Controller Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Model Class Initialized
DEBUG - 2012-07-12 16:42:19 --> Model Class Initialized
DEBUG - 2012-07-12 16:42:19 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:43:08 --> Config Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:43:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:43:08 --> URI Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Router Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Output Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Security Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Input Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:43:08 --> Language Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Loader Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:43:08 --> Controller Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Model Class Initialized
DEBUG - 2012-07-12 16:43:08 --> Model Class Initialized
DEBUG - 2012-07-12 16:43:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:43:08 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:43:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:43:08 --> Final output sent to browser
DEBUG - 2012-07-12 16:43:08 --> Total execution time: 0.0544
DEBUG - 2012-07-12 16:43:57 --> Config Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:43:57 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:43:57 --> URI Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Router Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Output Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Security Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Input Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:43:57 --> Language Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Loader Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:43:57 --> Controller Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Model Class Initialized
DEBUG - 2012-07-12 16:43:57 --> Model Class Initialized
DEBUG - 2012-07-12 16:43:57 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:43:57 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:43:57 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:43:57 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:43:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:43:57 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:43:57 --> Final output sent to browser
DEBUG - 2012-07-12 16:43:57 --> Total execution time: 0.0515
DEBUG - 2012-07-12 16:43:58 --> Config Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:43:58 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:43:58 --> URI Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Router Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Output Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Security Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Input Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:43:58 --> Language Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Loader Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:43:58 --> Controller Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Model Class Initialized
DEBUG - 2012-07-12 16:43:58 --> Model Class Initialized
DEBUG - 2012-07-12 16:43:58 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:43:58 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-12 16:43:58 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:43:58 --> Final output sent to browser
DEBUG - 2012-07-12 16:43:58 --> Total execution time: 0.0679
DEBUG - 2012-07-12 16:44:00 --> Config Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:44:00 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:44:00 --> URI Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Router Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Output Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Security Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Input Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:44:00 --> Language Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Loader Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:44:00 --> Controller Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Model Class Initialized
DEBUG - 2012-07-12 16:44:00 --> Model Class Initialized
DEBUG - 2012-07-12 16:44:00 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:44:00 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:44:00 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:44:00 --> Final output sent to browser
DEBUG - 2012-07-12 16:44:00 --> Total execution time: 0.0536
DEBUG - 2012-07-12 16:47:48 --> Config Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:47:48 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:47:48 --> URI Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Router Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Output Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Security Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Input Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:47:48 --> Language Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Loader Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:47:48 --> Controller Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Model Class Initialized
DEBUG - 2012-07-12 16:47:48 --> Model Class Initialized
DEBUG - 2012-07-12 16:47:48 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:47:48 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:47:48 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:47:48 --> Final output sent to browser
DEBUG - 2012-07-12 16:47:48 --> Total execution time: 0.0406
DEBUG - 2012-07-12 16:48:13 --> Config Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:48:13 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:48:13 --> URI Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Router Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Output Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Security Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Input Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:48:13 --> Language Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Loader Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:48:13 --> Controller Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Model Class Initialized
DEBUG - 2012-07-12 16:48:13 --> Model Class Initialized
DEBUG - 2012-07-12 16:48:13 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:48:13 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:48:13 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:48:13 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:48:13 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:48:13 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:48:13 --> Final output sent to browser
DEBUG - 2012-07-12 16:48:13 --> Total execution time: 0.0457
DEBUG - 2012-07-12 16:48:18 --> Config Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:48:18 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:48:18 --> URI Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Router Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Output Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Security Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Input Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:48:18 --> Language Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Loader Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:48:18 --> Controller Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Model Class Initialized
DEBUG - 2012-07-12 16:48:18 --> Model Class Initialized
DEBUG - 2012-07-12 16:48:18 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:48:18 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-12 16:48:18 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:48:18 --> Final output sent to browser
DEBUG - 2012-07-12 16:48:18 --> Total execution time: 0.0550
DEBUG - 2012-07-12 16:48:21 --> Config Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:48:21 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:48:21 --> URI Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Router Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Output Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Security Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Input Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:48:21 --> Language Class Initialized
DEBUG - 2012-07-12 16:48:21 --> Loader Class Initialized
DEBUG - 2012-07-12 16:48:22 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:48:22 --> Controller Class Initialized
DEBUG - 2012-07-12 16:48:22 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:48:22 --> Model Class Initialized
DEBUG - 2012-07-12 16:48:22 --> Model Class Initialized
DEBUG - 2012-07-12 16:48:22 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:48:22 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-12 16:48:22 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:48:22 --> Final output sent to browser
DEBUG - 2012-07-12 16:48:22 --> Total execution time: 0.0554
DEBUG - 2012-07-12 16:49:40 --> Config Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:49:40 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:49:40 --> URI Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Router Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Output Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Security Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Input Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:49:40 --> Language Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Loader Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:49:40 --> Controller Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Model Class Initialized
DEBUG - 2012-07-12 16:49:40 --> Model Class Initialized
DEBUG - 2012-07-12 16:49:40 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:49:40 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:49:40 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:49:40 --> Final output sent to browser
DEBUG - 2012-07-12 16:49:40 --> Total execution time: 0.0595
DEBUG - 2012-07-12 16:49:47 --> Config Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:49:47 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:49:47 --> URI Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Router Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Output Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Security Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Input Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:49:47 --> Language Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Loader Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:49:47 --> Controller Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Model Class Initialized
DEBUG - 2012-07-12 16:49:47 --> Model Class Initialized
DEBUG - 2012-07-12 16:49:47 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:49:47 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:49:47 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:49:47 --> Final output sent to browser
DEBUG - 2012-07-12 16:49:47 --> Total execution time: 0.0502
DEBUG - 2012-07-12 16:52:08 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:08 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:08 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:08 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:08 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:08 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:52:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:52:08 --> Final output sent to browser
DEBUG - 2012-07-12 16:52:08 --> Total execution time: 0.0557
DEBUG - 2012-07-12 16:52:11 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:11 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:11 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:11 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:11 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:11 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:11 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:11 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:52:11 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:52:11 --> Final output sent to browser
DEBUG - 2012-07-12 16:52:11 --> Total execution time: 0.0408
DEBUG - 2012-07-12 16:52:41 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:41 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:41 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:41 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:41 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:41 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:41 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:41 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:52:41 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:52:41 --> Final output sent to browser
DEBUG - 2012-07-12 16:52:41 --> Total execution time: 0.0483
DEBUG - 2012-07-12 16:52:43 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:43 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:43 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:43 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:43 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:43 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:43 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:43 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-12 16:52:43 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:52:43 --> Final output sent to browser
DEBUG - 2012-07-12 16:52:43 --> Total execution time: 0.0465
DEBUG - 2012-07-12 16:52:52 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:52 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:52 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:52 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:52 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:52 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:52 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:52 --> Helper loaded: alert_helper
DEBUG - 2012-07-12 16:52:52 --> XSS Filtering completed
DEBUG - 2012-07-12 16:52:52 --> XSS Filtering completed
DEBUG - 2012-07-12 16:52:52 --> XSS Filtering completed
DEBUG - 2012-07-12 16:52:54 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:54 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:54 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:54 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:54 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:54 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:54 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:54 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:52:54 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:52:54 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:52:54 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:52:54 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:52:54 --> Final output sent to browser
DEBUG - 2012-07-12 16:52:54 --> Total execution time: 0.0415
DEBUG - 2012-07-12 16:52:56 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:56 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:56 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:56 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:56 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:56 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:56 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:56 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-12 16:52:56 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:52:56 --> Final output sent to browser
DEBUG - 2012-07-12 16:52:56 --> Total execution time: 0.0595
DEBUG - 2012-07-12 16:52:57 --> Config Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:52:57 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:52:57 --> URI Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Router Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Output Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Security Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Input Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:52:57 --> Language Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Loader Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:52:57 --> Controller Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:57 --> Model Class Initialized
DEBUG - 2012-07-12 16:52:57 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:52:57 --> File loaded: application/views/board/modify_v.php
DEBUG - 2012-07-12 16:52:57 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:52:57 --> Final output sent to browser
DEBUG - 2012-07-12 16:52:57 --> Total execution time: 0.0477
DEBUG - 2012-07-12 16:56:36 --> Config Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:56:36 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:56:36 --> URI Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Router Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Output Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Security Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Input Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:56:36 --> Language Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Loader Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:56:36 --> Controller Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:36 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:36 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:56:36 --> Helper loaded: alert_helper
DEBUG - 2012-07-12 16:56:36 --> XSS Filtering completed
DEBUG - 2012-07-12 16:56:36 --> XSS Filtering completed
DEBUG - 2012-07-12 16:56:36 --> XSS Filtering completed
DEBUG - 2012-07-12 16:56:37 --> Config Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:56:37 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:56:37 --> URI Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Router Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Output Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Security Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Input Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:56:37 --> Language Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Loader Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:56:37 --> Controller Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:37 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:37 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:56:37 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:56:37 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:56:37 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:56:37 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:56:37 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:56:37 --> Final output sent to browser
DEBUG - 2012-07-12 16:56:37 --> Total execution time: 0.0485
DEBUG - 2012-07-12 16:56:41 --> Config Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:56:41 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:56:41 --> URI Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Router Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Output Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Security Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Input Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:56:41 --> Language Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Loader Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:56:41 --> Controller Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:41 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:41 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:56:41 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-12 16:56:41 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:56:41 --> Final output sent to browser
DEBUG - 2012-07-12 16:56:41 --> Total execution time: 0.0591
DEBUG - 2012-07-12 16:56:43 --> Config Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:56:43 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:56:43 --> URI Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Router Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Output Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Security Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Input Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:56:43 --> Language Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Loader Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:56:43 --> Controller Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:43 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:43 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:56:43 --> Helper loaded: alert_helper
DEBUG - 2012-07-12 16:56:45 --> Config Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:56:45 --> URI Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Router Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Output Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Security Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Input Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:56:45 --> Language Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Loader Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:56:45 --> Controller Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:45 --> Model Class Initialized
DEBUG - 2012-07-12 16:56:45 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:56:45 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:56:45 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:56:45 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:56:45 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:56:45 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:56:45 --> Final output sent to browser
DEBUG - 2012-07-12 16:56:45 --> Total execution time: 0.0467
DEBUG - 2012-07-12 16:57:49 --> Config Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:57:49 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:57:49 --> URI Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Router Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Output Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Security Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Input Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:57:49 --> Language Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Loader Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:57:49 --> Controller Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Model Class Initialized
DEBUG - 2012-07-12 16:57:49 --> Model Class Initialized
DEBUG - 2012-07-12 16:57:49 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:57:49 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-12 16:57:49 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:57:49 --> Final output sent to browser
DEBUG - 2012-07-12 16:57:49 --> Total execution time: 0.0441
DEBUG - 2012-07-12 16:57:50 --> Config Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:57:50 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:57:50 --> URI Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Router Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Output Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Security Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Input Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:57:50 --> Language Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Loader Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:57:50 --> Controller Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Model Class Initialized
DEBUG - 2012-07-12 16:57:50 --> Model Class Initialized
DEBUG - 2012-07-12 16:57:50 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:57:50 --> Helper loaded: alert_helper
DEBUG - 2012-07-12 16:58:11 --> Config Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Hooks Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Utf8 Class Initialized
DEBUG - 2012-07-12 16:58:11 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 16:58:11 --> URI Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Router Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Output Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Security Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Input Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 16:58:11 --> Language Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Loader Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Helper loaded: date_helper
DEBUG - 2012-07-12 16:58:11 --> Controller Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Database Driver Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Model Class Initialized
DEBUG - 2012-07-12 16:58:11 --> Model Class Initialized
DEBUG - 2012-07-12 16:58:11 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 16:58:11 --> Pagination Class Initialized
DEBUG - 2012-07-12 16:58:11 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 16:58:11 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 16:58:11 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 16:58:11 --> Helper loaded: text_helper
DEBUG - 2012-07-12 16:58:11 --> Final output sent to browser
DEBUG - 2012-07-12 16:58:11 --> Total execution time: 0.0497
