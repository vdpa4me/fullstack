<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-27 08:26:02 --> Config Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Hooks Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Utf8 Class Initialized
DEBUG - 2018-08-27 08:26:02 --> UTF-8 Support Enabled
DEBUG - 2018-08-27 08:26:02 --> URI Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Router Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Output Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Security Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Input Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-27 08:26:02 --> Language Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Loader Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Helper loaded: date_helper
DEBUG - 2018-08-27 08:26:02 --> Controller Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Database Driver Class Initialized
ERROR - 2018-08-27 08:26:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-27 08:26:02 --> Model Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Model Class Initialized
DEBUG - 2018-08-27 08:26:02 --> Helper loaded: url_helper
DEBUG - 2018-08-27 08:26:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-27 08:26:02 --> Final output sent to browser
DEBUG - 2018-08-27 08:26:02 --> Total execution time: 0.0905
DEBUG - 2018-08-27 13:53:00 --> Config Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Hooks Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Utf8 Class Initialized
DEBUG - 2018-08-27 13:53:00 --> UTF-8 Support Enabled
DEBUG - 2018-08-27 13:53:00 --> URI Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Router Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Output Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Security Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Input Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-27 13:53:00 --> Language Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Loader Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Helper loaded: date_helper
DEBUG - 2018-08-27 13:53:00 --> Controller Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Database Driver Class Initialized
ERROR - 2018-08-27 13:53:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-27 13:53:00 --> Model Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Model Class Initialized
DEBUG - 2018-08-27 13:53:00 --> Helper loaded: url_helper
DEBUG - 2018-08-27 13:53:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-27 13:53:00 --> Final output sent to browser
DEBUG - 2018-08-27 13:53:00 --> Total execution time: 0.0217
DEBUG - 2018-08-27 17:33:59 --> Config Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Hooks Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Utf8 Class Initialized
DEBUG - 2018-08-27 17:33:59 --> UTF-8 Support Enabled
DEBUG - 2018-08-27 17:33:59 --> URI Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Router Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Output Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Security Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Input Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-27 17:33:59 --> Language Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Loader Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Helper loaded: date_helper
DEBUG - 2018-08-27 17:33:59 --> Controller Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Database Driver Class Initialized
ERROR - 2018-08-27 17:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-27 17:33:59 --> Model Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Model Class Initialized
DEBUG - 2018-08-27 17:33:59 --> Helper loaded: url_helper
DEBUG - 2018-08-27 17:33:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-27 17:33:59 --> Final output sent to browser
DEBUG - 2018-08-27 17:33:59 --> Total execution time: 0.0216
