<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-07-19 02:31:24 --> Config Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Hooks Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Utf8 Class Initialized
DEBUG - 2019-07-19 02:31:24 --> UTF-8 Support Enabled
DEBUG - 2019-07-19 02:31:24 --> URI Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Router Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Output Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Security Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Input Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-19 02:31:24 --> Language Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Loader Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Helper loaded: date_helper
DEBUG - 2019-07-19 02:31:24 --> Controller Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Database Driver Class Initialized
ERROR - 2019-07-19 02:31:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-19 02:31:24 --> Model Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Model Class Initialized
DEBUG - 2019-07-19 02:31:24 --> Helper loaded: url_helper
DEBUG - 2019-07-19 02:31:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-19 02:31:24 --> Final output sent to browser
DEBUG - 2019-07-19 02:31:24 --> Total execution time: 0.0516
DEBUG - 2019-07-19 06:09:29 --> Config Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Hooks Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Utf8 Class Initialized
DEBUG - 2019-07-19 06:09:29 --> UTF-8 Support Enabled
DEBUG - 2019-07-19 06:09:29 --> URI Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Router Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Output Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Security Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Input Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-19 06:09:29 --> Language Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Loader Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Helper loaded: date_helper
DEBUG - 2019-07-19 06:09:29 --> Controller Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Database Driver Class Initialized
ERROR - 2019-07-19 06:09:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-19 06:09:29 --> Model Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Model Class Initialized
DEBUG - 2019-07-19 06:09:29 --> Helper loaded: url_helper
DEBUG - 2019-07-19 06:09:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-19 06:09:29 --> Final output sent to browser
DEBUG - 2019-07-19 06:09:29 --> Total execution time: 0.0288
DEBUG - 2019-07-19 13:42:05 --> Config Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Hooks Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Utf8 Class Initialized
DEBUG - 2019-07-19 13:42:05 --> UTF-8 Support Enabled
DEBUG - 2019-07-19 13:42:05 --> URI Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Router Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Output Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Security Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Input Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-19 13:42:05 --> Language Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Loader Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Helper loaded: date_helper
DEBUG - 2019-07-19 13:42:05 --> Controller Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Database Driver Class Initialized
ERROR - 2019-07-19 13:42:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-19 13:42:05 --> Model Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Model Class Initialized
DEBUG - 2019-07-19 13:42:05 --> Helper loaded: url_helper
DEBUG - 2019-07-19 13:42:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-19 13:42:05 --> Final output sent to browser
DEBUG - 2019-07-19 13:42:05 --> Total execution time: 0.0556
DEBUG - 2019-07-19 23:07:33 --> Config Class Initialized
DEBUG - 2019-07-19 23:07:33 --> Hooks Class Initialized
DEBUG - 2019-07-19 23:07:33 --> Utf8 Class Initialized
DEBUG - 2019-07-19 23:07:33 --> UTF-8 Support Enabled
DEBUG - 2019-07-19 23:07:33 --> URI Class Initialized
DEBUG - 2019-07-19 23:07:33 --> Router Class Initialized
DEBUG - 2019-07-19 23:07:33 --> Output Class Initialized
DEBUG - 2019-07-19 23:07:33 --> Security Class Initialized
DEBUG - 2019-07-19 23:07:34 --> Input Class Initialized
DEBUG - 2019-07-19 23:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-19 23:07:34 --> Language Class Initialized
DEBUG - 2019-07-19 23:07:34 --> Loader Class Initialized
DEBUG - 2019-07-19 23:07:34 --> Helper loaded: date_helper
DEBUG - 2019-07-19 23:07:34 --> Controller Class Initialized
DEBUG - 2019-07-19 23:07:34 --> Database Driver Class Initialized
ERROR - 2019-07-19 23:07:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-19 23:07:34 --> Model Class Initialized
DEBUG - 2019-07-19 23:07:34 --> Model Class Initialized
DEBUG - 2019-07-19 23:07:34 --> Helper loaded: url_helper
DEBUG - 2019-07-19 23:07:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-19 23:07:34 --> Final output sent to browser
DEBUG - 2019-07-19 23:07:34 --> Total execution time: 0.0485
