<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-09-21 00:15:45 --> Config Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Hooks Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Utf8 Class Initialized
DEBUG - 2017-09-21 00:15:45 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 00:15:45 --> URI Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Router Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Output Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Security Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Input Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 00:15:45 --> Language Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Loader Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Helper loaded: date_helper
DEBUG - 2017-09-21 00:15:45 --> Controller Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Database Driver Class Initialized
ERROR - 2017-09-21 00:15:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 00:15:45 --> Model Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Model Class Initialized
DEBUG - 2017-09-21 00:15:45 --> Helper loaded: url_helper
DEBUG - 2017-09-21 00:15:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 00:15:45 --> Final output sent to browser
DEBUG - 2017-09-21 00:15:45 --> Total execution time: 0.0207
DEBUG - 2017-09-21 01:38:21 --> Config Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Hooks Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Utf8 Class Initialized
DEBUG - 2017-09-21 01:38:21 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 01:38:21 --> URI Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Router Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Output Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Security Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Input Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 01:38:21 --> Language Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Loader Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Helper loaded: date_helper
DEBUG - 2017-09-21 01:38:21 --> Controller Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Database Driver Class Initialized
ERROR - 2017-09-21 01:38:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 01:38:21 --> Model Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Model Class Initialized
DEBUG - 2017-09-21 01:38:21 --> Helper loaded: url_helper
DEBUG - 2017-09-21 01:38:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 01:38:21 --> Final output sent to browser
DEBUG - 2017-09-21 01:38:21 --> Total execution time: 0.0202
DEBUG - 2017-09-21 06:29:38 --> Config Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Hooks Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Utf8 Class Initialized
DEBUG - 2017-09-21 06:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 06:29:38 --> URI Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Router Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Output Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Security Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Input Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 06:29:38 --> Language Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Loader Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Helper loaded: date_helper
DEBUG - 2017-09-21 06:29:38 --> Controller Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Database Driver Class Initialized
ERROR - 2017-09-21 06:29:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 06:29:38 --> Model Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Model Class Initialized
DEBUG - 2017-09-21 06:29:38 --> Helper loaded: url_helper
DEBUG - 2017-09-21 06:29:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 06:29:38 --> Final output sent to browser
DEBUG - 2017-09-21 06:29:38 --> Total execution time: 0.0261
DEBUG - 2017-09-21 07:05:15 --> Config Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Hooks Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Utf8 Class Initialized
DEBUG - 2017-09-21 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 07:05:15 --> URI Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Router Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Output Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Security Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Input Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 07:05:15 --> Language Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Loader Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Helper loaded: date_helper
DEBUG - 2017-09-21 07:05:15 --> Controller Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Database Driver Class Initialized
ERROR - 2017-09-21 07:05:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 07:05:15 --> Model Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Model Class Initialized
DEBUG - 2017-09-21 07:05:15 --> Helper loaded: url_helper
DEBUG - 2017-09-21 07:05:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 07:05:15 --> Final output sent to browser
DEBUG - 2017-09-21 07:05:15 --> Total execution time: 0.0209
DEBUG - 2017-09-21 12:55:14 --> Config Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Hooks Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Utf8 Class Initialized
DEBUG - 2017-09-21 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 12:55:14 --> URI Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Router Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Output Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Security Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Input Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 12:55:14 --> Language Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Loader Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Helper loaded: date_helper
DEBUG - 2017-09-21 12:55:14 --> Controller Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Database Driver Class Initialized
ERROR - 2017-09-21 12:55:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 12:55:14 --> Model Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Model Class Initialized
DEBUG - 2017-09-21 12:55:14 --> Helper loaded: url_helper
DEBUG - 2017-09-21 12:55:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 12:55:14 --> Final output sent to browser
DEBUG - 2017-09-21 12:55:14 --> Total execution time: 0.0330
DEBUG - 2017-09-21 13:52:36 --> Config Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Hooks Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Utf8 Class Initialized
DEBUG - 2017-09-21 13:52:36 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 13:52:36 --> URI Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Router Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Output Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Security Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Input Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 13:52:36 --> Language Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Loader Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Helper loaded: date_helper
DEBUG - 2017-09-21 13:52:36 --> Controller Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Database Driver Class Initialized
ERROR - 2017-09-21 13:52:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 13:52:36 --> Model Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Model Class Initialized
DEBUG - 2017-09-21 13:52:36 --> Helper loaded: url_helper
DEBUG - 2017-09-21 13:52:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 13:52:36 --> Final output sent to browser
DEBUG - 2017-09-21 13:52:36 --> Total execution time: 0.0200
DEBUG - 2017-09-21 21:07:01 --> Config Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Hooks Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Utf8 Class Initialized
DEBUG - 2017-09-21 21:07:01 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 21:07:01 --> URI Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Router Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Output Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Security Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Input Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 21:07:01 --> Language Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Loader Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Helper loaded: date_helper
DEBUG - 2017-09-21 21:07:01 --> Controller Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Database Driver Class Initialized
ERROR - 2017-09-21 21:07:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 21:07:01 --> Model Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Model Class Initialized
DEBUG - 2017-09-21 21:07:01 --> Helper loaded: url_helper
DEBUG - 2017-09-21 21:07:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 21:07:01 --> Final output sent to browser
DEBUG - 2017-09-21 21:07:01 --> Total execution time: 0.0266
DEBUG - 2017-09-21 21:33:09 --> Config Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Hooks Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Utf8 Class Initialized
DEBUG - 2017-09-21 21:33:09 --> UTF-8 Support Enabled
DEBUG - 2017-09-21 21:33:09 --> URI Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Router Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Output Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Security Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Input Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-21 21:33:09 --> Language Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Loader Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Helper loaded: date_helper
DEBUG - 2017-09-21 21:33:09 --> Controller Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Database Driver Class Initialized
ERROR - 2017-09-21 21:33:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-21 21:33:09 --> Model Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Model Class Initialized
DEBUG - 2017-09-21 21:33:09 --> Helper loaded: url_helper
DEBUG - 2017-09-21 21:33:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-21 21:33:09 --> Final output sent to browser
DEBUG - 2017-09-21 21:33:09 --> Total execution time: 0.0201
