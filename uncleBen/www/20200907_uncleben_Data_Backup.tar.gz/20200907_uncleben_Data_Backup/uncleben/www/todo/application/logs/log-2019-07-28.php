<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-07-28 04:14:40 --> Config Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Hooks Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Utf8 Class Initialized
DEBUG - 2019-07-28 04:14:40 --> UTF-8 Support Enabled
DEBUG - 2019-07-28 04:14:40 --> URI Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Router Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Output Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Security Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Input Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-28 04:14:40 --> Language Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Loader Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Helper loaded: date_helper
DEBUG - 2019-07-28 04:14:40 --> Controller Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Database Driver Class Initialized
ERROR - 2019-07-28 04:14:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-28 04:14:40 --> Model Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Model Class Initialized
DEBUG - 2019-07-28 04:14:40 --> Helper loaded: url_helper
DEBUG - 2019-07-28 04:14:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-28 04:14:40 --> Final output sent to browser
DEBUG - 2019-07-28 04:14:40 --> Total execution time: 0.0536
DEBUG - 2019-07-28 09:25:46 --> Config Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Hooks Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Utf8 Class Initialized
DEBUG - 2019-07-28 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-07-28 09:25:46 --> URI Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Router Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Output Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Security Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Input Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-28 09:25:46 --> Language Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Loader Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Helper loaded: date_helper
DEBUG - 2019-07-28 09:25:46 --> Controller Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Database Driver Class Initialized
ERROR - 2019-07-28 09:25:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-28 09:25:46 --> Model Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Model Class Initialized
DEBUG - 2019-07-28 09:25:46 --> Helper loaded: url_helper
DEBUG - 2019-07-28 09:25:46 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-28 09:25:46 --> Final output sent to browser
DEBUG - 2019-07-28 09:25:46 --> Total execution time: 0.0482
DEBUG - 2019-07-28 16:07:51 --> Config Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Hooks Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Utf8 Class Initialized
DEBUG - 2019-07-28 16:07:51 --> UTF-8 Support Enabled
DEBUG - 2019-07-28 16:07:51 --> URI Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Router Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Output Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Security Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Input Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-28 16:07:51 --> Language Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Loader Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Helper loaded: date_helper
DEBUG - 2019-07-28 16:07:51 --> Controller Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Database Driver Class Initialized
ERROR - 2019-07-28 16:07:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-28 16:07:51 --> Model Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Model Class Initialized
DEBUG - 2019-07-28 16:07:51 --> Helper loaded: url_helper
DEBUG - 2019-07-28 16:07:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-28 16:07:51 --> Final output sent to browser
DEBUG - 2019-07-28 16:07:51 --> Total execution time: 0.0442
DEBUG - 2019-07-28 17:15:39 --> Config Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Hooks Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Utf8 Class Initialized
DEBUG - 2019-07-28 17:15:39 --> UTF-8 Support Enabled
DEBUG - 2019-07-28 17:15:39 --> URI Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Router Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Output Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Security Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Input Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-28 17:15:39 --> Language Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Loader Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Helper loaded: date_helper
DEBUG - 2019-07-28 17:15:39 --> Controller Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Database Driver Class Initialized
ERROR - 2019-07-28 17:15:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-28 17:15:39 --> Model Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Model Class Initialized
DEBUG - 2019-07-28 17:15:39 --> Helper loaded: url_helper
DEBUG - 2019-07-28 17:15:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-28 17:15:39 --> Final output sent to browser
DEBUG - 2019-07-28 17:15:39 --> Total execution time: 0.0303
DEBUG - 2019-07-28 18:28:18 --> Config Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Hooks Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Utf8 Class Initialized
DEBUG - 2019-07-28 18:28:18 --> UTF-8 Support Enabled
DEBUG - 2019-07-28 18:28:18 --> URI Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Router Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Output Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Security Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Input Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-28 18:28:18 --> Language Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Loader Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Helper loaded: date_helper
DEBUG - 2019-07-28 18:28:18 --> Controller Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Database Driver Class Initialized
ERROR - 2019-07-28 18:28:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-28 18:28:18 --> Model Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Model Class Initialized
DEBUG - 2019-07-28 18:28:18 --> Helper loaded: url_helper
DEBUG - 2019-07-28 18:28:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-28 18:28:18 --> Final output sent to browser
DEBUG - 2019-07-28 18:28:18 --> Total execution time: 0.0348
DEBUG - 2019-07-28 19:17:25 --> Config Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Hooks Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Utf8 Class Initialized
DEBUG - 2019-07-28 19:17:25 --> UTF-8 Support Enabled
DEBUG - 2019-07-28 19:17:25 --> URI Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Router Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Output Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Security Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Input Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-28 19:17:25 --> Language Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Loader Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Helper loaded: date_helper
DEBUG - 2019-07-28 19:17:25 --> Controller Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Database Driver Class Initialized
ERROR - 2019-07-28 19:17:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-28 19:17:25 --> Model Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Model Class Initialized
DEBUG - 2019-07-28 19:17:25 --> Helper loaded: url_helper
DEBUG - 2019-07-28 19:17:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-28 19:17:25 --> Final output sent to browser
DEBUG - 2019-07-28 19:17:25 --> Total execution time: 0.0266
