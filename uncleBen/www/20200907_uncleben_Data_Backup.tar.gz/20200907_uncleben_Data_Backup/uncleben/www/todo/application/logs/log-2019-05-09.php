<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-09 00:15:30 --> Config Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Hooks Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Utf8 Class Initialized
DEBUG - 2019-05-09 00:15:30 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 00:15:30 --> URI Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Router Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Output Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Security Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Input Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 00:15:30 --> Language Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Loader Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Helper loaded: date_helper
DEBUG - 2019-05-09 00:15:30 --> Controller Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Database Driver Class Initialized
ERROR - 2019-05-09 00:15:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 00:15:30 --> Model Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Model Class Initialized
DEBUG - 2019-05-09 00:15:30 --> Helper loaded: url_helper
DEBUG - 2019-05-09 00:15:30 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2019-05-09 00:15:30 --> Final output sent to browser
DEBUG - 2019-05-09 00:15:30 --> Total execution time: 0.0289
DEBUG - 2019-05-09 07:40:04 --> Config Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Hooks Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Utf8 Class Initialized
DEBUG - 2019-05-09 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 07:40:04 --> URI Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Router Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Output Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Security Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Input Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 07:40:04 --> Language Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Loader Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Helper loaded: date_helper
DEBUG - 2019-05-09 07:40:04 --> Controller Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Database Driver Class Initialized
ERROR - 2019-05-09 07:40:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 07:40:04 --> Model Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Model Class Initialized
DEBUG - 2019-05-09 07:40:04 --> Helper loaded: url_helper
DEBUG - 2019-05-09 07:40:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-09 07:40:04 --> Final output sent to browser
DEBUG - 2019-05-09 07:40:04 --> Total execution time: 0.0418
DEBUG - 2019-05-09 10:52:27 --> Config Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Hooks Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Utf8 Class Initialized
DEBUG - 2019-05-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 10:52:27 --> URI Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Router Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Output Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Security Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Input Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 10:52:27 --> Language Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Loader Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Helper loaded: date_helper
DEBUG - 2019-05-09 10:52:27 --> Controller Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Database Driver Class Initialized
ERROR - 2019-05-09 10:52:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 10:52:27 --> Model Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Model Class Initialized
DEBUG - 2019-05-09 10:52:27 --> Helper loaded: url_helper
DEBUG - 2019-05-09 10:52:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-09 10:52:27 --> Final output sent to browser
DEBUG - 2019-05-09 10:52:27 --> Total execution time: 0.0288
DEBUG - 2019-05-09 11:14:35 --> Config Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Hooks Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Utf8 Class Initialized
DEBUG - 2019-05-09 11:14:35 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 11:14:35 --> URI Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Router Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Output Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Security Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Input Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 11:14:35 --> Language Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Loader Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Helper loaded: date_helper
DEBUG - 2019-05-09 11:14:35 --> Controller Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Database Driver Class Initialized
ERROR - 2019-05-09 11:14:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 11:14:35 --> Model Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Model Class Initialized
DEBUG - 2019-05-09 11:14:35 --> Helper loaded: url_helper
DEBUG - 2019-05-09 11:14:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-09 11:14:35 --> Final output sent to browser
DEBUG - 2019-05-09 11:14:35 --> Total execution time: 0.0256
DEBUG - 2019-05-09 12:29:41 --> Config Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Hooks Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Utf8 Class Initialized
DEBUG - 2019-05-09 12:29:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 12:29:41 --> URI Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Router Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Output Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Security Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Input Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 12:29:41 --> Language Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Loader Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Helper loaded: date_helper
DEBUG - 2019-05-09 12:29:41 --> Controller Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Database Driver Class Initialized
ERROR - 2019-05-09 12:29:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 12:29:41 --> Model Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Model Class Initialized
DEBUG - 2019-05-09 12:29:41 --> Helper loaded: url_helper
DEBUG - 2019-05-09 12:29:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-09 12:29:41 --> Final output sent to browser
DEBUG - 2019-05-09 12:29:41 --> Total execution time: 0.0309
DEBUG - 2019-05-09 15:53:04 --> Config Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Hooks Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Utf8 Class Initialized
DEBUG - 2019-05-09 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 15:53:04 --> URI Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Router Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Output Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Security Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Input Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 15:53:04 --> Language Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Loader Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Helper loaded: date_helper
DEBUG - 2019-05-09 15:53:04 --> Controller Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Database Driver Class Initialized
ERROR - 2019-05-09 15:53:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 15:53:04 --> Model Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Model Class Initialized
DEBUG - 2019-05-09 15:53:04 --> Helper loaded: url_helper
DEBUG - 2019-05-09 15:53:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-09 15:53:04 --> Final output sent to browser
DEBUG - 2019-05-09 15:53:04 --> Total execution time: 0.0323
DEBUG - 2019-05-09 18:23:09 --> Config Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Hooks Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Utf8 Class Initialized
DEBUG - 2019-05-09 18:23:09 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 18:23:09 --> URI Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Router Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Output Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Security Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Input Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 18:23:09 --> Language Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Loader Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Helper loaded: date_helper
DEBUG - 2019-05-09 18:23:09 --> Controller Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Database Driver Class Initialized
ERROR - 2019-05-09 18:23:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 18:23:09 --> Model Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Model Class Initialized
DEBUG - 2019-05-09 18:23:09 --> Helper loaded: url_helper
DEBUG - 2019-05-09 18:23:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-09 18:23:09 --> Final output sent to browser
DEBUG - 2019-05-09 18:23:09 --> Total execution time: 0.0316
DEBUG - 2019-05-09 21:10:57 --> Config Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Hooks Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Utf8 Class Initialized
DEBUG - 2019-05-09 21:10:57 --> UTF-8 Support Enabled
DEBUG - 2019-05-09 21:10:57 --> URI Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Router Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Output Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Security Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Input Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-09 21:10:57 --> Language Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Loader Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Helper loaded: date_helper
DEBUG - 2019-05-09 21:10:57 --> Controller Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Database Driver Class Initialized
ERROR - 2019-05-09 21:10:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-09 21:10:57 --> Model Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Model Class Initialized
DEBUG - 2019-05-09 21:10:57 --> Helper loaded: url_helper
DEBUG - 2019-05-09 21:10:57 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-09 21:10:57 --> Final output sent to browser
DEBUG - 2019-05-09 21:10:57 --> Total execution time: 0.0345
