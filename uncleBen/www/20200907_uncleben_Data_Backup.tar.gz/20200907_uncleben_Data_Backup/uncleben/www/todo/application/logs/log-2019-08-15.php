<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-08-15 18:36:05 --> Config Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Hooks Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Utf8 Class Initialized
DEBUG - 2019-08-15 18:36:05 --> UTF-8 Support Enabled
DEBUG - 2019-08-15 18:36:05 --> URI Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Router Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Output Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Security Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Input Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-15 18:36:05 --> Language Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Loader Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Helper loaded: date_helper
DEBUG - 2019-08-15 18:36:05 --> Controller Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Database Driver Class Initialized
ERROR - 2019-08-15 18:36:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-15 18:36:05 --> Model Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Model Class Initialized
DEBUG - 2019-08-15 18:36:05 --> Helper loaded: url_helper
DEBUG - 2019-08-15 18:36:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-15 18:36:05 --> Final output sent to browser
DEBUG - 2019-08-15 18:36:05 --> Total execution time: 0.0569
