<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-04-14 00:22:24 --> Config Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:22:24 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:22:24 --> URI Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Router Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Output Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Security Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Input Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:22:24 --> Language Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Loader Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:22:24 --> Controller Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:22:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:22:24 --> Model Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Model Class Initialized
DEBUG - 2017-04-14 00:22:24 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:22:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:22:24 --> Final output sent to browser
DEBUG - 2017-04-14 00:22:24 --> Total execution time: 0.0359
DEBUG - 2017-04-14 00:23:27 --> Config Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:23:27 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:23:27 --> URI Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Router Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Output Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Security Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Input Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:23:27 --> Language Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Loader Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:23:27 --> Controller Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:23:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:23:27 --> Model Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Model Class Initialized
DEBUG - 2017-04-14 00:23:27 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:23:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:23:27 --> Final output sent to browser
DEBUG - 2017-04-14 00:23:27 --> Total execution time: 0.0305
DEBUG - 2017-04-14 00:23:31 --> Config Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:23:31 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:23:31 --> URI Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Router Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Output Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Security Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Input Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:23:31 --> Language Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Loader Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:23:31 --> Controller Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:23:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:23:31 --> Model Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Model Class Initialized
DEBUG - 2017-04-14 00:23:31 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:23:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:23:31 --> Final output sent to browser
DEBUG - 2017-04-14 00:23:31 --> Total execution time: 0.0301
DEBUG - 2017-04-14 00:23:34 --> Config Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:23:34 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:23:34 --> URI Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Router Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Output Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Security Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Input Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:23:34 --> Language Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Loader Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:23:34 --> Controller Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:23:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:23:34 --> Model Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Model Class Initialized
DEBUG - 2017-04-14 00:23:34 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:23:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:23:34 --> Final output sent to browser
DEBUG - 2017-04-14 00:23:34 --> Total execution time: 0.0303
DEBUG - 2017-04-14 00:24:19 --> Config Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:24:19 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:24:19 --> URI Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Router Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Output Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Security Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Input Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:24:19 --> Language Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Loader Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:24:19 --> Controller Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:24:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:24:19 --> Model Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Model Class Initialized
DEBUG - 2017-04-14 00:24:19 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:24:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:24:19 --> Final output sent to browser
DEBUG - 2017-04-14 00:24:19 --> Total execution time: 0.0298
DEBUG - 2017-04-14 00:24:49 --> Config Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:24:49 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:24:49 --> URI Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Router Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Output Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Security Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Input Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:24:49 --> Language Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Loader Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:24:49 --> Controller Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:24:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:24:49 --> Model Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Model Class Initialized
DEBUG - 2017-04-14 00:24:49 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:24:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:24:49 --> Final output sent to browser
DEBUG - 2017-04-14 00:24:49 --> Total execution time: 0.0291
DEBUG - 2017-04-14 00:24:58 --> Config Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:24:58 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:24:58 --> URI Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Router Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Output Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Security Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Input Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:24:58 --> Language Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Loader Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:24:58 --> Controller Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:24:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:24:58 --> Model Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Model Class Initialized
DEBUG - 2017-04-14 00:24:58 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:24:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:24:58 --> Final output sent to browser
DEBUG - 2017-04-14 00:24:58 --> Total execution time: 0.0295
DEBUG - 2017-04-14 00:25:07 --> Config Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:25:07 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:25:07 --> URI Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Router Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Output Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Security Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Input Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:25:07 --> Language Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Loader Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:25:07 --> Controller Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:25:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:25:07 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:07 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:25:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:25:07 --> Final output sent to browser
DEBUG - 2017-04-14 00:25:07 --> Total execution time: 0.0298
DEBUG - 2017-04-14 00:25:17 --> Config Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:25:17 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:25:17 --> URI Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Router Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Output Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Security Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Input Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:25:17 --> Language Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Loader Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:25:17 --> Controller Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:25:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:25:17 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:17 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:25:17 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:25:17 --> Final output sent to browser
DEBUG - 2017-04-14 00:25:17 --> Total execution time: 0.0294
DEBUG - 2017-04-14 00:25:21 --> Config Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:25:21 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:25:21 --> URI Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Router Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Output Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Security Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Input Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:25:21 --> Language Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Loader Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:25:21 --> Controller Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:25:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:25:21 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:21 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:25:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:25:21 --> Final output sent to browser
DEBUG - 2017-04-14 00:25:21 --> Total execution time: 0.0291
DEBUG - 2017-04-14 00:25:37 --> Config Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:25:37 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:25:37 --> URI Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Router Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Output Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Security Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Input Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:25:37 --> Language Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Loader Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:25:37 --> Controller Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:25:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:25:37 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:37 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:25:37 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:25:37 --> Final output sent to browser
DEBUG - 2017-04-14 00:25:37 --> Total execution time: 0.0288
DEBUG - 2017-04-14 00:25:43 --> Config Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:25:43 --> URI Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Router Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Output Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Security Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Input Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:25:43 --> Language Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Loader Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:25:43 --> Controller Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:25:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:25:43 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:43 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:25:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:25:43 --> Final output sent to browser
DEBUG - 2017-04-14 00:25:43 --> Total execution time: 0.0293
DEBUG - 2017-04-14 00:25:54 --> Config Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:25:54 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:25:54 --> URI Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Router Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Output Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Security Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Input Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:25:54 --> Language Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Loader Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:25:54 --> Controller Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:25:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:25:54 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Model Class Initialized
DEBUG - 2017-04-14 00:25:54 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:25:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:25:54 --> Final output sent to browser
DEBUG - 2017-04-14 00:25:54 --> Total execution time: 0.0290
DEBUG - 2017-04-14 00:26:04 --> Config Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:26:04 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:26:04 --> URI Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Router Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Output Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Security Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Input Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:26:04 --> Language Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Loader Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:26:04 --> Controller Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:26:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:26:04 --> Model Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Model Class Initialized
DEBUG - 2017-04-14 00:26:04 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:26:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:26:04 --> Final output sent to browser
DEBUG - 2017-04-14 00:26:04 --> Total execution time: 0.0297
DEBUG - 2017-04-14 00:26:16 --> Config Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:26:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:26:16 --> URI Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Router Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Output Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Security Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Input Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:26:16 --> Language Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Loader Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:26:16 --> Controller Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:26:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:26:16 --> Model Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Model Class Initialized
DEBUG - 2017-04-14 00:26:16 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:26:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:26:16 --> Final output sent to browser
DEBUG - 2017-04-14 00:26:16 --> Total execution time: 0.0290
DEBUG - 2017-04-14 00:26:28 --> Config Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Hooks Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Utf8 Class Initialized
DEBUG - 2017-04-14 00:26:28 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 00:26:28 --> URI Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Router Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Output Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Security Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Input Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 00:26:28 --> Language Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Loader Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Helper loaded: date_helper
DEBUG - 2017-04-14 00:26:28 --> Controller Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Database Driver Class Initialized
ERROR - 2017-04-14 00:26:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 00:26:28 --> Model Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Model Class Initialized
DEBUG - 2017-04-14 00:26:28 --> Helper loaded: url_helper
DEBUG - 2017-04-14 00:26:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 00:26:29 --> Final output sent to browser
DEBUG - 2017-04-14 00:26:29 --> Total execution time: 0.0297
DEBUG - 2017-04-14 01:53:21 --> Config Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Hooks Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Utf8 Class Initialized
DEBUG - 2017-04-14 01:53:21 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 01:53:21 --> URI Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Router Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Output Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Security Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Input Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 01:53:21 --> Language Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Loader Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Helper loaded: date_helper
DEBUG - 2017-04-14 01:53:21 --> Controller Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Database Driver Class Initialized
ERROR - 2017-04-14 01:53:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 01:53:21 --> Model Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Model Class Initialized
DEBUG - 2017-04-14 01:53:21 --> Helper loaded: url_helper
DEBUG - 2017-04-14 01:53:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 01:53:21 --> Final output sent to browser
DEBUG - 2017-04-14 01:53:21 --> Total execution time: 0.0344
DEBUG - 2017-04-14 01:53:30 --> Config Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Hooks Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Utf8 Class Initialized
DEBUG - 2017-04-14 01:53:30 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 01:53:30 --> URI Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Router Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Output Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Security Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Input Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 01:53:30 --> Language Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Loader Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Helper loaded: date_helper
DEBUG - 2017-04-14 01:53:30 --> Controller Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Database Driver Class Initialized
ERROR - 2017-04-14 01:53:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 01:53:30 --> Model Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Model Class Initialized
DEBUG - 2017-04-14 01:53:30 --> Helper loaded: url_helper
DEBUG - 2017-04-14 01:53:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 01:53:30 --> Final output sent to browser
DEBUG - 2017-04-14 01:53:30 --> Total execution time: 0.0307
DEBUG - 2017-04-14 04:41:34 --> Config Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Hooks Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Utf8 Class Initialized
DEBUG - 2017-04-14 04:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 04:41:34 --> URI Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Router Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Output Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Security Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Input Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 04:41:34 --> Language Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Loader Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Helper loaded: date_helper
DEBUG - 2017-04-14 04:41:34 --> Controller Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Database Driver Class Initialized
ERROR - 2017-04-14 04:41:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 04:41:34 --> Model Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Model Class Initialized
DEBUG - 2017-04-14 04:41:34 --> Helper loaded: url_helper
DEBUG - 2017-04-14 04:41:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 04:41:34 --> Final output sent to browser
DEBUG - 2017-04-14 04:41:34 --> Total execution time: 0.0363
DEBUG - 2017-04-14 07:48:16 --> Config Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Hooks Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Utf8 Class Initialized
DEBUG - 2017-04-14 07:48:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 07:48:16 --> URI Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Router Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Output Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Security Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Input Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 07:48:16 --> Language Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Loader Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Helper loaded: date_helper
DEBUG - 2017-04-14 07:48:16 --> Controller Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Database Driver Class Initialized
ERROR - 2017-04-14 07:48:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 07:48:16 --> Model Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Model Class Initialized
DEBUG - 2017-04-14 07:48:16 --> Helper loaded: url_helper
DEBUG - 2017-04-14 07:48:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 07:48:16 --> Final output sent to browser
DEBUG - 2017-04-14 07:48:16 --> Total execution time: 0.0407
DEBUG - 2017-04-14 07:50:33 --> Config Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Hooks Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Utf8 Class Initialized
DEBUG - 2017-04-14 07:50:33 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 07:50:33 --> URI Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Router Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Output Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Security Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Input Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 07:50:33 --> Language Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Loader Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Helper loaded: date_helper
DEBUG - 2017-04-14 07:50:33 --> Controller Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Database Driver Class Initialized
ERROR - 2017-04-14 07:50:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 07:50:33 --> Model Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Model Class Initialized
DEBUG - 2017-04-14 07:50:33 --> Helper loaded: url_helper
DEBUG - 2017-04-14 07:50:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 07:50:33 --> Final output sent to browser
DEBUG - 2017-04-14 07:50:33 --> Total execution time: 0.0295
DEBUG - 2017-04-14 11:38:29 --> Config Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Hooks Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Utf8 Class Initialized
DEBUG - 2017-04-14 11:38:29 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 11:38:29 --> URI Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Router Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Output Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Security Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Input Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 11:38:29 --> Language Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Loader Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Helper loaded: date_helper
DEBUG - 2017-04-14 11:38:29 --> Controller Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Database Driver Class Initialized
ERROR - 2017-04-14 11:38:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 11:38:29 --> Model Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Model Class Initialized
DEBUG - 2017-04-14 11:38:29 --> Helper loaded: url_helper
DEBUG - 2017-04-14 11:38:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 11:38:29 --> Final output sent to browser
DEBUG - 2017-04-14 11:38:29 --> Total execution time: 0.0388
DEBUG - 2017-04-14 23:03:28 --> Config Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:03:28 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:03:28 --> URI Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Router Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Output Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Security Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Input Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:03:28 --> Language Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Loader Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:03:28 --> Controller Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:03:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:03:28 --> Model Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Model Class Initialized
DEBUG - 2017-04-14 23:03:28 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:03:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:03:28 --> Final output sent to browser
DEBUG - 2017-04-14 23:03:28 --> Total execution time: 0.0518
DEBUG - 2017-04-14 23:27:31 --> Config Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:27:31 --> URI Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Router Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Output Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Security Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Input Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:27:31 --> Language Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Loader Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:27:31 --> Controller Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:27:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:27:31 --> Model Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Model Class Initialized
DEBUG - 2017-04-14 23:27:31 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:27:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:27:32 --> Final output sent to browser
DEBUG - 2017-04-14 23:27:32 --> Total execution time: 0.0340
DEBUG - 2017-04-14 23:49:02 --> Config Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:49:02 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:49:02 --> URI Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Router Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Output Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Security Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Input Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:49:02 --> Language Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Loader Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:49:02 --> Controller Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:49:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:49:02 --> Model Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Model Class Initialized
DEBUG - 2017-04-14 23:49:02 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:49:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:49:02 --> Final output sent to browser
DEBUG - 2017-04-14 23:49:02 --> Total execution time: 0.0333
DEBUG - 2017-04-14 23:54:26 --> Config Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:54:26 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:54:26 --> URI Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Router Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Output Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Security Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Input Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:54:26 --> Language Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Loader Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:54:26 --> Controller Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:54:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:54:26 --> Model Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Model Class Initialized
DEBUG - 2017-04-14 23:54:26 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:54:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:54:26 --> Final output sent to browser
DEBUG - 2017-04-14 23:54:26 --> Total execution time: 0.0301
DEBUG - 2017-04-14 23:55:31 --> Config Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:55:31 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:55:31 --> URI Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Router Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Output Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Security Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Input Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:55:31 --> Language Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Loader Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:55:31 --> Controller Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:55:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:55:31 --> Model Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Model Class Initialized
DEBUG - 2017-04-14 23:55:31 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:55:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:55:31 --> Final output sent to browser
DEBUG - 2017-04-14 23:55:31 --> Total execution time: 0.0298
DEBUG - 2017-04-14 23:55:52 --> Config Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:55:52 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:55:52 --> URI Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Router Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Output Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Security Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Input Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:55:52 --> Language Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Loader Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:55:52 --> Controller Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:55:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:55:52 --> Model Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Model Class Initialized
DEBUG - 2017-04-14 23:55:52 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:55:52 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:55:52 --> Final output sent to browser
DEBUG - 2017-04-14 23:55:52 --> Total execution time: 0.0307
DEBUG - 2017-04-14 23:55:56 --> Config Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:55:56 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:55:56 --> URI Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Router Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Output Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Security Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Input Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:55:56 --> Language Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Loader Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:55:56 --> Controller Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:55:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:55:56 --> Model Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Model Class Initialized
DEBUG - 2017-04-14 23:55:56 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:55:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:55:56 --> Final output sent to browser
DEBUG - 2017-04-14 23:55:56 --> Total execution time: 0.0307
DEBUG - 2017-04-14 23:57:16 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:16 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:16 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:16 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:16 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:16 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:16 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:16 --> Total execution time: 0.0286
DEBUG - 2017-04-14 23:57:24 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:24 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:24 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:24 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:24 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:24 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:24 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:24 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:24 --> Total execution time: 0.0287
DEBUG - 2017-04-14 23:57:35 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:35 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:35 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:35 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:35 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:35 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:35 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:35 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:35 --> Total execution time: 0.0284
DEBUG - 2017-04-14 23:57:39 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:39 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:39 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:39 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:39 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:39 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:39 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:39 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:39 --> Total execution time: 0.0293
DEBUG - 2017-04-14 23:57:42 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:42 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:42 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:42 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:42 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:42 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:42 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:42 --> Total execution time: 0.0289
DEBUG - 2017-04-14 23:57:46 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:46 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:46 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:46 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:46 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:46 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:46 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:46 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:46 --> Total execution time: 0.0293
DEBUG - 2017-04-14 23:57:51 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:51 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:51 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:51 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:51 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:51 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:51 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:51 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:51 --> Total execution time: 0.0288
DEBUG - 2017-04-14 23:57:59 --> Config Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:57:59 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:57:59 --> URI Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Router Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Output Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Security Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Input Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:57:59 --> Language Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Loader Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:57:59 --> Controller Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:57:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:57:59 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Model Class Initialized
DEBUG - 2017-04-14 23:57:59 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:57:59 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:57:59 --> Final output sent to browser
DEBUG - 2017-04-14 23:57:59 --> Total execution time: 0.0298
DEBUG - 2017-04-14 23:58:03 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:03 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:03 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:03 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:03 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:03 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:03 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:03 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:03 --> Total execution time: 0.0300
DEBUG - 2017-04-14 23:58:06 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:06 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:06 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:06 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:06 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:06 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:06 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:06 --> Total execution time: 0.0287
DEBUG - 2017-04-14 23:58:15 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:15 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:15 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:15 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:15 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:15 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:15 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:15 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:15 --> Total execution time: 0.0284
DEBUG - 2017-04-14 23:58:20 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:20 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:20 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:20 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:20 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:20 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:20 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:20 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:20 --> Total execution time: 0.0291
DEBUG - 2017-04-14 23:58:28 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:28 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:28 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:28 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:28 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:28 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:28 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:28 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:28 --> Total execution time: 0.0294
DEBUG - 2017-04-14 23:58:34 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:34 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:34 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:34 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:34 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:34 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:34 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:35 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:35 --> Total execution time: 0.0321
DEBUG - 2017-04-14 23:58:41 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:41 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:41 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:41 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:41 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:41 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:41 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:42 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:42 --> Total execution time: 0.0292
DEBUG - 2017-04-14 23:58:46 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:46 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:46 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:46 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:46 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:46 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:46 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:46 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:46 --> Total execution time: 0.0299
DEBUG - 2017-04-14 23:58:53 --> Config Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:58:53 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:58:53 --> URI Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Router Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Output Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Security Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Input Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:58:53 --> Language Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Loader Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:58:53 --> Controller Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:58:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:58:53 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Model Class Initialized
DEBUG - 2017-04-14 23:58:53 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:58:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:58:53 --> Final output sent to browser
DEBUG - 2017-04-14 23:58:53 --> Total execution time: 0.0294
DEBUG - 2017-04-14 23:59:05 --> Config Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:59:05 --> URI Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Router Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Output Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Security Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Input Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:59:05 --> Language Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Loader Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:59:05 --> Controller Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:59:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:59:05 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:05 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:59:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:59:05 --> Final output sent to browser
DEBUG - 2017-04-14 23:59:05 --> Total execution time: 0.0286
DEBUG - 2017-04-14 23:59:16 --> Config Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:59:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:59:16 --> URI Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Router Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Output Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Security Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Input Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:59:16 --> Language Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Loader Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:59:16 --> Controller Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:59:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:59:16 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:16 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:59:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:59:16 --> Final output sent to browser
DEBUG - 2017-04-14 23:59:16 --> Total execution time: 0.0291
DEBUG - 2017-04-14 23:59:23 --> Config Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:59:23 --> URI Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Router Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Output Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Security Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Input Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:59:23 --> Language Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Loader Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:59:23 --> Controller Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:59:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:59:23 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:23 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:59:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:59:23 --> Final output sent to browser
DEBUG - 2017-04-14 23:59:23 --> Total execution time: 0.0294
DEBUG - 2017-04-14 23:59:31 --> Config Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:59:31 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:59:31 --> URI Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Router Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Output Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Security Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Input Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:59:31 --> Language Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Loader Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:59:31 --> Controller Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:59:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:59:31 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:31 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:59:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:59:31 --> Final output sent to browser
DEBUG - 2017-04-14 23:59:31 --> Total execution time: 0.0302
DEBUG - 2017-04-14 23:59:46 --> Config Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Hooks Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Utf8 Class Initialized
DEBUG - 2017-04-14 23:59:46 --> UTF-8 Support Enabled
DEBUG - 2017-04-14 23:59:46 --> URI Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Router Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Output Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Security Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Input Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-14 23:59:46 --> Language Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Loader Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Helper loaded: date_helper
DEBUG - 2017-04-14 23:59:46 --> Controller Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Database Driver Class Initialized
ERROR - 2017-04-14 23:59:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-14 23:59:46 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Model Class Initialized
DEBUG - 2017-04-14 23:59:46 --> Helper loaded: url_helper
DEBUG - 2017-04-14 23:59:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-14 23:59:46 --> Final output sent to browser
DEBUG - 2017-04-14 23:59:46 --> Total execution time: 0.0303
