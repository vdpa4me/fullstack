<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-29 00:36:29 --> Config Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Hooks Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Utf8 Class Initialized
DEBUG - 2019-05-29 00:36:29 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 00:36:29 --> URI Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Router Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Output Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Security Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Input Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 00:36:29 --> Language Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Loader Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Helper loaded: date_helper
DEBUG - 2019-05-29 00:36:29 --> Controller Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Database Driver Class Initialized
ERROR - 2019-05-29 00:36:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 00:36:29 --> Model Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Model Class Initialized
DEBUG - 2019-05-29 00:36:29 --> Helper loaded: url_helper
DEBUG - 2019-05-29 00:36:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-05-29 00:36:29 --> Final output sent to browser
DEBUG - 2019-05-29 00:36:29 --> Total execution time: 0.1096
DEBUG - 2019-05-29 00:36:41 --> Config Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Hooks Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Utf8 Class Initialized
DEBUG - 2019-05-29 00:36:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 00:36:41 --> URI Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Router Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Output Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Security Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Input Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 00:36:41 --> Language Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Loader Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Helper loaded: date_helper
DEBUG - 2019-05-29 00:36:41 --> Controller Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Database Driver Class Initialized
ERROR - 2019-05-29 00:36:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 00:36:41 --> Model Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Model Class Initialized
DEBUG - 2019-05-29 00:36:41 --> Helper loaded: url_helper
ERROR - 2019-05-29 00:36:41 --> Severity: Warning  --> strstr(): Empty needle /uncleben/www/todo/application/views/todo/yumi_v.php 142
DEBUG - 2019-05-29 00:36:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-05-29 00:36:41 --> Final output sent to browser
DEBUG - 2019-05-29 00:36:41 --> Total execution time: 0.0753
DEBUG - 2019-05-29 00:37:00 --> Config Class Initialized
DEBUG - 2019-05-29 00:37:00 --> Hooks Class Initialized
DEBUG - 2019-05-29 00:37:00 --> Utf8 Class Initialized
DEBUG - 2019-05-29 00:37:00 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 00:37:00 --> URI Class Initialized
DEBUG - 2019-05-29 00:37:00 --> Router Class Initialized
DEBUG - 2019-05-29 00:37:00 --> Output Class Initialized
DEBUG - 2019-05-29 00:37:00 --> Security Class Initialized
DEBUG - 2019-05-29 00:37:00 --> Input Class Initialized
DEBUG - 2019-05-29 00:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 00:37:00 --> Language Class Initialized
DEBUG - 2019-05-29 00:37:01 --> Loader Class Initialized
DEBUG - 2019-05-29 00:37:01 --> Helper loaded: date_helper
DEBUG - 2019-05-29 00:37:01 --> Controller Class Initialized
DEBUG - 2019-05-29 00:37:01 --> Database Driver Class Initialized
ERROR - 2019-05-29 00:37:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 00:37:01 --> Model Class Initialized
DEBUG - 2019-05-29 00:37:01 --> Model Class Initialized
DEBUG - 2019-05-29 00:37:01 --> Helper loaded: url_helper
ERROR - 2019-05-29 00:37:01 --> Severity: Warning  --> strstr(): Empty needle /uncleben/www/todo/application/views/todo/yumi_v.php 142
DEBUG - 2019-05-29 00:37:01 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-05-29 00:37:01 --> Final output sent to browser
DEBUG - 2019-05-29 00:37:01 --> Total execution time: 0.0649
DEBUG - 2019-05-29 06:22:38 --> Config Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Hooks Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Utf8 Class Initialized
DEBUG - 2019-05-29 06:22:38 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 06:22:38 --> URI Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Router Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Output Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Security Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Input Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 06:22:38 --> Language Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Loader Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Helper loaded: date_helper
DEBUG - 2019-05-29 06:22:38 --> Controller Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Database Driver Class Initialized
ERROR - 2019-05-29 06:22:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 06:22:38 --> Model Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Model Class Initialized
DEBUG - 2019-05-29 06:22:38 --> Helper loaded: url_helper
DEBUG - 2019-05-29 06:22:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 06:22:38 --> Final output sent to browser
DEBUG - 2019-05-29 06:22:38 --> Total execution time: 0.0317
DEBUG - 2019-05-29 13:01:31 --> Config Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Hooks Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Utf8 Class Initialized
DEBUG - 2019-05-29 13:01:31 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 13:01:31 --> URI Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Router Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Output Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Security Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Input Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 13:01:31 --> Language Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Loader Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Helper loaded: date_helper
DEBUG - 2019-05-29 13:01:31 --> Controller Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Database Driver Class Initialized
ERROR - 2019-05-29 13:01:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 13:01:31 --> Model Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Model Class Initialized
DEBUG - 2019-05-29 13:01:31 --> Helper loaded: url_helper
DEBUG - 2019-05-29 13:01:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 13:01:31 --> Final output sent to browser
DEBUG - 2019-05-29 13:01:31 --> Total execution time: 0.0711
DEBUG - 2019-05-29 16:27:34 --> Config Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Hooks Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Utf8 Class Initialized
DEBUG - 2019-05-29 16:27:34 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 16:27:34 --> URI Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Router Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Output Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Security Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Input Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 16:27:34 --> Language Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Loader Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Helper loaded: date_helper
DEBUG - 2019-05-29 16:27:34 --> Controller Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Database Driver Class Initialized
ERROR - 2019-05-29 16:27:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 16:27:34 --> Model Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Model Class Initialized
DEBUG - 2019-05-29 16:27:34 --> Helper loaded: url_helper
DEBUG - 2019-05-29 16:27:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 16:27:34 --> Final output sent to browser
DEBUG - 2019-05-29 16:27:34 --> Total execution time: 0.0364
DEBUG - 2019-05-29 17:28:04 --> Config Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Hooks Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Utf8 Class Initialized
DEBUG - 2019-05-29 17:28:04 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 17:28:04 --> URI Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Router Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Output Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Security Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Input Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 17:28:04 --> Language Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Loader Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Helper loaded: date_helper
DEBUG - 2019-05-29 17:28:04 --> Controller Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Database Driver Class Initialized
ERROR - 2019-05-29 17:28:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 17:28:04 --> Model Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Model Class Initialized
DEBUG - 2019-05-29 17:28:04 --> Helper loaded: url_helper
DEBUG - 2019-05-29 17:28:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 17:28:04 --> Final output sent to browser
DEBUG - 2019-05-29 17:28:04 --> Total execution time: 0.0334
DEBUG - 2019-05-29 17:28:16 --> Config Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Hooks Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Utf8 Class Initialized
DEBUG - 2019-05-29 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 17:28:16 --> URI Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Router Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Output Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Security Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Input Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 17:28:16 --> Language Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Loader Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Helper loaded: date_helper
DEBUG - 2019-05-29 17:28:16 --> Controller Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Database Driver Class Initialized
ERROR - 2019-05-29 17:28:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 17:28:16 --> Model Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Model Class Initialized
DEBUG - 2019-05-29 17:28:16 --> Helper loaded: url_helper
DEBUG - 2019-05-29 17:28:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 17:28:16 --> Final output sent to browser
DEBUG - 2019-05-29 17:28:16 --> Total execution time: 0.0214
DEBUG - 2019-05-29 20:57:24 --> Config Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Hooks Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Utf8 Class Initialized
DEBUG - 2019-05-29 20:57:24 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 20:57:24 --> URI Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Router Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Output Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Security Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Input Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 20:57:24 --> Language Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Loader Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Helper loaded: date_helper
DEBUG - 2019-05-29 20:57:24 --> Controller Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Database Driver Class Initialized
ERROR - 2019-05-29 20:57:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 20:57:24 --> Model Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Model Class Initialized
DEBUG - 2019-05-29 20:57:24 --> Helper loaded: url_helper
DEBUG - 2019-05-29 20:57:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 20:57:24 --> Final output sent to browser
DEBUG - 2019-05-29 20:57:24 --> Total execution time: 0.0287
DEBUG - 2019-05-29 21:15:55 --> Config Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Hooks Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Utf8 Class Initialized
DEBUG - 2019-05-29 21:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 21:15:55 --> URI Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Router Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Output Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Security Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Input Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 21:15:55 --> Language Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Loader Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Helper loaded: date_helper
DEBUG - 2019-05-29 21:15:55 --> Controller Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Database Driver Class Initialized
ERROR - 2019-05-29 21:15:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 21:15:55 --> Model Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Model Class Initialized
DEBUG - 2019-05-29 21:15:55 --> Helper loaded: url_helper
DEBUG - 2019-05-29 21:15:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 21:15:55 --> Final output sent to browser
DEBUG - 2019-05-29 21:15:55 --> Total execution time: 0.0215
DEBUG - 2019-05-29 22:39:51 --> Config Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Hooks Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Utf8 Class Initialized
DEBUG - 2019-05-29 22:39:51 --> UTF-8 Support Enabled
DEBUG - 2019-05-29 22:39:51 --> URI Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Router Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Output Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Security Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Input Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-29 22:39:51 --> Language Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Loader Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Helper loaded: date_helper
DEBUG - 2019-05-29 22:39:51 --> Controller Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Database Driver Class Initialized
ERROR - 2019-05-29 22:39:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-29 22:39:51 --> Model Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Model Class Initialized
DEBUG - 2019-05-29 22:39:51 --> Helper loaded: url_helper
DEBUG - 2019-05-29 22:39:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-29 22:39:51 --> Final output sent to browser
DEBUG - 2019-05-29 22:39:51 --> Total execution time: 0.0210
