<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-08-11 04:52:13 --> Config Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Hooks Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Utf8 Class Initialized
DEBUG - 2018-08-11 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 04:52:13 --> URI Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Router Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Output Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Security Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Input Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 04:52:13 --> Language Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Loader Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Helper loaded: date_helper
DEBUG - 2018-08-11 04:52:13 --> Controller Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Database Driver Class Initialized
ERROR - 2018-08-11 04:52:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 04:52:13 --> Model Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Model Class Initialized
DEBUG - 2018-08-11 04:52:13 --> Helper loaded: url_helper
DEBUG - 2018-08-11 04:52:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-11 04:52:13 --> Final output sent to browser
DEBUG - 2018-08-11 04:52:13 --> Total execution time: 0.0224
DEBUG - 2018-08-11 04:55:02 --> Config Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Hooks Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Utf8 Class Initialized
DEBUG - 2018-08-11 04:55:02 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 04:55:02 --> URI Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Router Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Output Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Security Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Input Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 04:55:02 --> Language Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Loader Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Helper loaded: date_helper
DEBUG - 2018-08-11 04:55:02 --> Controller Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Database Driver Class Initialized
ERROR - 2018-08-11 04:55:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 04:55:02 --> Model Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Model Class Initialized
DEBUG - 2018-08-11 04:55:02 --> Helper loaded: url_helper
DEBUG - 2018-08-11 04:55:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-11 04:55:02 --> Final output sent to browser
DEBUG - 2018-08-11 04:55:02 --> Total execution time: 0.0210
DEBUG - 2018-08-11 10:55:05 --> Config Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Hooks Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Utf8 Class Initialized
DEBUG - 2018-08-11 10:55:05 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 10:55:05 --> URI Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Router Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Output Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Security Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Input Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 10:55:05 --> Language Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Loader Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Helper loaded: date_helper
DEBUG - 2018-08-11 10:55:05 --> Controller Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Database Driver Class Initialized
ERROR - 2018-08-11 10:55:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 10:55:05 --> Model Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Model Class Initialized
DEBUG - 2018-08-11 10:55:05 --> Helper loaded: url_helper
DEBUG - 2018-08-11 10:55:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-11 10:55:05 --> Final output sent to browser
DEBUG - 2018-08-11 10:55:05 --> Total execution time: 0.0343
DEBUG - 2018-08-11 21:45:53 --> Config Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Hooks Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Utf8 Class Initialized
DEBUG - 2018-08-11 21:45:53 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 21:45:53 --> URI Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Router Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Output Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Security Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Input Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 21:45:53 --> Language Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Loader Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Helper loaded: date_helper
DEBUG - 2018-08-11 21:45:53 --> Controller Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Database Driver Class Initialized
ERROR - 2018-08-11 21:45:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 21:45:53 --> Model Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Model Class Initialized
DEBUG - 2018-08-11 21:45:53 --> Helper loaded: url_helper
DEBUG - 2018-08-11 21:45:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-11 21:45:53 --> Final output sent to browser
DEBUG - 2018-08-11 21:45:53 --> Total execution time: 0.0219
DEBUG - 2018-08-11 21:46:04 --> Config Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Hooks Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Utf8 Class Initialized
DEBUG - 2018-08-11 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 21:46:04 --> URI Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Router Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Output Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Security Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Input Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 21:46:04 --> Language Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Loader Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Helper loaded: date_helper
DEBUG - 2018-08-11 21:46:04 --> Controller Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Database Driver Class Initialized
ERROR - 2018-08-11 21:46:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 21:46:04 --> Model Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Model Class Initialized
DEBUG - 2018-08-11 21:46:04 --> Helper loaded: url_helper
DEBUG - 2018-08-11 21:46:04 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-08-11 21:46:04 --> Final output sent to browser
DEBUG - 2018-08-11 21:46:04 --> Total execution time: 0.0248
DEBUG - 2018-08-11 21:46:15 --> Config Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Hooks Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Utf8 Class Initialized
DEBUG - 2018-08-11 21:46:15 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 21:46:15 --> URI Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Router Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Output Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Security Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Input Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 21:46:15 --> Language Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Loader Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Helper loaded: date_helper
DEBUG - 2018-08-11 21:46:15 --> Controller Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Database Driver Class Initialized
ERROR - 2018-08-11 21:46:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 21:46:15 --> Model Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Model Class Initialized
DEBUG - 2018-08-11 21:46:15 --> Helper loaded: url_helper
DEBUG - 2018-08-11 21:46:15 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-08-11 21:46:15 --> Final output sent to browser
DEBUG - 2018-08-11 21:46:15 --> Total execution time: 0.0214
DEBUG - 2018-08-11 22:57:47 --> Config Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Hooks Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Utf8 Class Initialized
DEBUG - 2018-08-11 22:57:47 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 22:57:47 --> URI Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Router Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Output Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Security Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Input Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 22:57:47 --> Language Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Loader Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Helper loaded: date_helper
DEBUG - 2018-08-11 22:57:47 --> Controller Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Database Driver Class Initialized
ERROR - 2018-08-11 22:57:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 22:57:47 --> Model Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Model Class Initialized
DEBUG - 2018-08-11 22:57:47 --> Helper loaded: url_helper
DEBUG - 2018-08-11 22:57:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-11 22:57:47 --> Final output sent to browser
DEBUG - 2018-08-11 22:57:47 --> Total execution time: 0.0209
DEBUG - 2018-08-11 23:08:16 --> Config Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Hooks Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Utf8 Class Initialized
DEBUG - 2018-08-11 23:08:16 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 23:08:16 --> URI Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Router Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Output Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Security Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Input Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 23:08:16 --> Language Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Loader Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Helper loaded: date_helper
DEBUG - 2018-08-11 23:08:16 --> Controller Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Database Driver Class Initialized
ERROR - 2018-08-11 23:08:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 23:08:16 --> Model Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Model Class Initialized
DEBUG - 2018-08-11 23:08:16 --> Helper loaded: url_helper
DEBUG - 2018-08-11 23:08:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-11 23:08:16 --> Final output sent to browser
DEBUG - 2018-08-11 23:08:16 --> Total execution time: 0.0204
DEBUG - 2018-08-11 23:10:45 --> Config Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Hooks Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Utf8 Class Initialized
DEBUG - 2018-08-11 23:10:45 --> UTF-8 Support Enabled
DEBUG - 2018-08-11 23:10:45 --> URI Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Router Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Output Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Security Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Input Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-08-11 23:10:45 --> Language Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Loader Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Helper loaded: date_helper
DEBUG - 2018-08-11 23:10:45 --> Controller Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Database Driver Class Initialized
ERROR - 2018-08-11 23:10:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-08-11 23:10:45 --> Model Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Model Class Initialized
DEBUG - 2018-08-11 23:10:45 --> Helper loaded: url_helper
DEBUG - 2018-08-11 23:10:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-08-11 23:10:45 --> Final output sent to browser
DEBUG - 2018-08-11 23:10:45 --> Total execution time: 0.0215
