<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-01-15 03:10:40 --> Config Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Hooks Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Utf8 Class Initialized
DEBUG - 2018-01-15 03:10:40 --> UTF-8 Support Enabled
DEBUG - 2018-01-15 03:10:40 --> URI Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Router Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Output Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Security Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Input Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-15 03:10:40 --> Language Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Loader Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Helper loaded: date_helper
DEBUG - 2018-01-15 03:10:40 --> Controller Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Database Driver Class Initialized
ERROR - 2018-01-15 03:10:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-15 03:10:40 --> Model Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Model Class Initialized
DEBUG - 2018-01-15 03:10:40 --> Helper loaded: url_helper
DEBUG - 2018-01-15 03:10:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-15 03:10:40 --> Final output sent to browser
DEBUG - 2018-01-15 03:10:40 --> Total execution time: 0.0464
DEBUG - 2018-01-15 16:47:27 --> Config Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Hooks Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Utf8 Class Initialized
DEBUG - 2018-01-15 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2018-01-15 16:47:27 --> URI Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Router Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Output Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Security Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Input Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-01-15 16:47:27 --> Language Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Loader Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Helper loaded: date_helper
DEBUG - 2018-01-15 16:47:27 --> Controller Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Database Driver Class Initialized
ERROR - 2018-01-15 16:47:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-01-15 16:47:27 --> Model Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Model Class Initialized
DEBUG - 2018-01-15 16:47:27 --> Helper loaded: url_helper
DEBUG - 2018-01-15 16:47:27 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-01-15 16:47:27 --> Final output sent to browser
DEBUG - 2018-01-15 16:47:27 --> Total execution time: 0.0496
