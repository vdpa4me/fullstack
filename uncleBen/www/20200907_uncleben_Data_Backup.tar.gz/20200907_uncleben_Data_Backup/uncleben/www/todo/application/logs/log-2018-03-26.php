<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-03-26 06:54:54 --> Config Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Utf8 Class Initialized
DEBUG - 2018-03-26 06:54:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-26 06:54:54 --> URI Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Router Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Output Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Security Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Input Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2018-03-26 06:54:54 --> Language Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Loader Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Helper loaded: date_helper
DEBUG - 2018-03-26 06:54:54 --> Controller Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Database Driver Class Initialized
ERROR - 2018-03-26 06:54:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-03-26 06:54:54 --> Model Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Model Class Initialized
DEBUG - 2018-03-26 06:54:54 --> Helper loaded: url_helper
DEBUG - 2018-03-26 06:54:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-03-26 06:54:54 --> Final output sent to browser
DEBUG - 2018-03-26 06:54:54 --> Total execution time: 0.0448
DEBUG - 2018-03-26 08:29:04 --> Config Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Utf8 Class Initialized
DEBUG - 2018-03-26 08:29:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-26 08:29:04 --> URI Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Router Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Output Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Security Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Input Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2018-03-26 08:29:04 --> Language Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Loader Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Helper loaded: date_helper
DEBUG - 2018-03-26 08:29:04 --> Controller Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Database Driver Class Initialized
ERROR - 2018-03-26 08:29:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-03-26 08:29:04 --> Model Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Model Class Initialized
DEBUG - 2018-03-26 08:29:04 --> Helper loaded: url_helper
DEBUG - 2018-03-26 08:29:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-03-26 08:29:04 --> Final output sent to browser
DEBUG - 2018-03-26 08:29:04 --> Total execution time: 0.0219
DEBUG - 2018-03-26 14:58:28 --> Config Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Utf8 Class Initialized
DEBUG - 2018-03-26 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-26 14:58:28 --> URI Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Router Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Output Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Security Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Input Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2018-03-26 14:58:28 --> Language Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Loader Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Helper loaded: date_helper
DEBUG - 2018-03-26 14:58:28 --> Controller Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Database Driver Class Initialized
ERROR - 2018-03-26 14:58:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-03-26 14:58:28 --> Model Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Model Class Initialized
DEBUG - 2018-03-26 14:58:28 --> Helper loaded: url_helper
DEBUG - 2018-03-26 14:58:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-03-26 14:58:28 --> Final output sent to browser
DEBUG - 2018-03-26 14:58:28 --> Total execution time: 0.0224
DEBUG - 2018-03-26 22:39:33 --> Config Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Utf8 Class Initialized
DEBUG - 2018-03-26 22:39:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-26 22:39:33 --> URI Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Router Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Output Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Security Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Input Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2018-03-26 22:39:33 --> Language Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Loader Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Helper loaded: date_helper
DEBUG - 2018-03-26 22:39:33 --> Controller Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Database Driver Class Initialized
ERROR - 2018-03-26 22:39:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-03-26 22:39:33 --> Model Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Model Class Initialized
DEBUG - 2018-03-26 22:39:33 --> Helper loaded: url_helper
DEBUG - 2018-03-26 22:39:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-03-26 22:39:33 --> Final output sent to browser
DEBUG - 2018-03-26 22:39:33 --> Total execution time: 0.0254
