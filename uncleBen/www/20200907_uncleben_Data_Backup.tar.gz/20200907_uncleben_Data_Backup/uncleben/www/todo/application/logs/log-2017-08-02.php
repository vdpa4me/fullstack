<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-08-02 05:54:22 --> Config Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Hooks Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Utf8 Class Initialized
DEBUG - 2017-08-02 05:54:22 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 05:54:22 --> URI Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Router Class Initialized
ERROR - 2017-08-02 05:54:22 --> 404 Page Not Found --> wlwmanifest.xml
DEBUG - 2017-08-02 05:54:22 --> Config Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Hooks Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Utf8 Class Initialized
DEBUG - 2017-08-02 05:54:22 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 05:54:22 --> URI Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Router Class Initialized
ERROR - 2017-08-02 05:54:22 --> 404 Page Not Found --> xmlrpc.php
DEBUG - 2017-08-02 05:54:22 --> Config Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Hooks Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Utf8 Class Initialized
DEBUG - 2017-08-02 05:54:22 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 05:54:22 --> URI Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Router Class Initialized
DEBUG - 2017-08-02 05:54:22 --> No URI present. Default controller set.
DEBUG - 2017-08-02 05:54:22 --> Output Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Security Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Input Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-02 05:54:22 --> Language Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Loader Class Initialized
DEBUG - 2017-08-02 05:54:22 --> Helper loaded: date_helper
DEBUG - 2017-08-02 05:54:22 --> Controller Class Initialized
DEBUG - 2017-08-02 05:54:22 --> File loaded: application/views/welcome_message.php
DEBUG - 2017-08-02 05:54:22 --> Final output sent to browser
DEBUG - 2017-08-02 05:54:22 --> Total execution time: 0.0139
DEBUG - 2017-08-02 05:54:23 --> Config Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Hooks Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Utf8 Class Initialized
DEBUG - 2017-08-02 05:54:23 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 05:54:23 --> URI Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Router Class Initialized
ERROR - 2017-08-02 05:54:23 --> 404 Page Not Found --> wp-includes
DEBUG - 2017-08-02 05:54:23 --> Config Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Hooks Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Utf8 Class Initialized
DEBUG - 2017-08-02 05:54:23 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 05:54:23 --> URI Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Router Class Initialized
ERROR - 2017-08-02 05:54:23 --> 404 Page Not Found --> wp-includes
DEBUG - 2017-08-02 05:54:23 --> Config Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Hooks Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Utf8 Class Initialized
DEBUG - 2017-08-02 05:54:23 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 05:54:23 --> URI Class Initialized
DEBUG - 2017-08-02 05:54:23 --> Router Class Initialized
ERROR - 2017-08-02 05:54:23 --> 404 Page Not Found --> wp-includes
DEBUG - 2017-08-02 05:54:24 --> Config Class Initialized
DEBUG - 2017-08-02 05:54:24 --> Hooks Class Initialized
DEBUG - 2017-08-02 05:54:24 --> Utf8 Class Initialized
DEBUG - 2017-08-02 05:54:24 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 05:54:24 --> URI Class Initialized
DEBUG - 2017-08-02 05:54:24 --> Router Class Initialized
ERROR - 2017-08-02 05:54:24 --> 404 Page Not Found --> wp-includes
DEBUG - 2017-08-02 10:27:29 --> Config Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Hooks Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Utf8 Class Initialized
DEBUG - 2017-08-02 10:27:29 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 10:27:29 --> URI Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Router Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Output Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Security Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Input Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-02 10:27:29 --> Language Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Loader Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Helper loaded: date_helper
DEBUG - 2017-08-02 10:27:29 --> Controller Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Database Driver Class Initialized
ERROR - 2017-08-02 10:27:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-02 10:27:29 --> Model Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Model Class Initialized
DEBUG - 2017-08-02 10:27:29 --> Helper loaded: url_helper
DEBUG - 2017-08-02 10:27:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-08-02 10:27:29 --> Final output sent to browser
DEBUG - 2017-08-02 10:27:29 --> Total execution time: 0.0592
DEBUG - 2017-08-02 12:52:20 --> Config Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Hooks Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Utf8 Class Initialized
DEBUG - 2017-08-02 12:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-08-02 12:52:20 --> URI Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Router Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Output Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Security Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Input Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-02 12:52:20 --> Language Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Loader Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Helper loaded: date_helper
DEBUG - 2017-08-02 12:52:20 --> Controller Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Database Driver Class Initialized
ERROR - 2017-08-02 12:52:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-02 12:52:20 --> Model Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Model Class Initialized
DEBUG - 2017-08-02 12:52:20 --> Helper loaded: url_helper
DEBUG - 2017-08-02 12:52:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-08-02 12:52:20 --> Final output sent to browser
DEBUG - 2017-08-02 12:52:20 --> Total execution time: 0.0316
