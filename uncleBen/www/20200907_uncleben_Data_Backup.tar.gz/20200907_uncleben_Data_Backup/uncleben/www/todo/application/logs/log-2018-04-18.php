<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-04-18 11:33:59 --> Config Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Hooks Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Utf8 Class Initialized
DEBUG - 2018-04-18 11:33:59 --> UTF-8 Support Enabled
DEBUG - 2018-04-18 11:33:59 --> URI Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Router Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Output Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Security Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Input Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-04-18 11:33:59 --> Language Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Loader Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Helper loaded: date_helper
DEBUG - 2018-04-18 11:33:59 --> Controller Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Database Driver Class Initialized
ERROR - 2018-04-18 11:33:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-04-18 11:33:59 --> Model Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Model Class Initialized
DEBUG - 2018-04-18 11:33:59 --> Helper loaded: url_helper
DEBUG - 2018-04-18 11:33:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-04-18 11:33:59 --> Final output sent to browser
DEBUG - 2018-04-18 11:33:59 --> Total execution time: 0.0319
DEBUG - 2018-04-18 11:34:13 --> Config Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Hooks Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Utf8 Class Initialized
DEBUG - 2018-04-18 11:34:13 --> UTF-8 Support Enabled
DEBUG - 2018-04-18 11:34:13 --> URI Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Router Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Output Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Security Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Input Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2018-04-18 11:34:13 --> Language Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Loader Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Helper loaded: date_helper
DEBUG - 2018-04-18 11:34:13 --> Controller Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Database Driver Class Initialized
ERROR - 2018-04-18 11:34:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-04-18 11:34:13 --> Model Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Model Class Initialized
DEBUG - 2018-04-18 11:34:13 --> Helper loaded: url_helper
DEBUG - 2018-04-18 11:34:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-04-18 11:34:13 --> Final output sent to browser
DEBUG - 2018-04-18 11:34:13 --> Total execution time: 0.0200
DEBUG - 2018-04-18 15:46:36 --> Config Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Hooks Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Utf8 Class Initialized
DEBUG - 2018-04-18 15:46:36 --> UTF-8 Support Enabled
DEBUG - 2018-04-18 15:46:36 --> URI Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Router Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Output Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Security Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Input Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2018-04-18 15:46:36 --> Language Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Loader Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Helper loaded: date_helper
DEBUG - 2018-04-18 15:46:36 --> Controller Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Database Driver Class Initialized
ERROR - 2018-04-18 15:46:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-04-18 15:46:36 --> Model Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Model Class Initialized
DEBUG - 2018-04-18 15:46:36 --> Helper loaded: url_helper
DEBUG - 2018-04-18 15:46:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-04-18 15:46:36 --> Final output sent to browser
DEBUG - 2018-04-18 15:46:36 --> Total execution time: 0.0204
