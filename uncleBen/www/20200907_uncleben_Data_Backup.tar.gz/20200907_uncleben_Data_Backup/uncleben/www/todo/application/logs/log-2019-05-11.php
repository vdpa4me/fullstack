<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-11 00:01:06 --> Config Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Hooks Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Utf8 Class Initialized
DEBUG - 2019-05-11 00:01:06 --> UTF-8 Support Enabled
DEBUG - 2019-05-11 00:01:06 --> URI Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Router Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Output Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Security Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Input Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-11 00:01:06 --> Language Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Loader Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Helper loaded: date_helper
DEBUG - 2019-05-11 00:01:06 --> Controller Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Database Driver Class Initialized
ERROR - 2019-05-11 00:01:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-11 00:01:06 --> Model Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Model Class Initialized
DEBUG - 2019-05-11 00:01:06 --> Helper loaded: url_helper
DEBUG - 2019-05-11 00:01:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-11 00:01:06 --> Final output sent to browser
DEBUG - 2019-05-11 00:01:06 --> Total execution time: 0.0731
DEBUG - 2019-05-11 00:43:43 --> Config Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Hooks Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Utf8 Class Initialized
DEBUG - 2019-05-11 00:43:43 --> UTF-8 Support Enabled
DEBUG - 2019-05-11 00:43:43 --> URI Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Router Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Output Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Security Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Input Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-11 00:43:43 --> Language Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Loader Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Helper loaded: date_helper
DEBUG - 2019-05-11 00:43:43 --> Controller Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Database Driver Class Initialized
ERROR - 2019-05-11 00:43:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-11 00:43:43 --> Model Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Model Class Initialized
DEBUG - 2019-05-11 00:43:43 --> Helper loaded: url_helper
DEBUG - 2019-05-11 00:43:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-11 00:43:43 --> Final output sent to browser
DEBUG - 2019-05-11 00:43:43 --> Total execution time: 0.0316
DEBUG - 2019-05-11 08:38:10 --> Config Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Hooks Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Utf8 Class Initialized
DEBUG - 2019-05-11 08:38:10 --> UTF-8 Support Enabled
DEBUG - 2019-05-11 08:38:10 --> URI Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Router Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Output Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Security Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Input Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-11 08:38:10 --> Language Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Loader Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Helper loaded: date_helper
DEBUG - 2019-05-11 08:38:10 --> Controller Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Database Driver Class Initialized
ERROR - 2019-05-11 08:38:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-11 08:38:10 --> Model Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Model Class Initialized
DEBUG - 2019-05-11 08:38:10 --> Helper loaded: url_helper
DEBUG - 2019-05-11 08:38:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-11 08:38:10 --> Final output sent to browser
DEBUG - 2019-05-11 08:38:10 --> Total execution time: 0.0470
DEBUG - 2019-05-11 09:19:54 --> Config Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Hooks Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Utf8 Class Initialized
DEBUG - 2019-05-11 09:19:54 --> UTF-8 Support Enabled
DEBUG - 2019-05-11 09:19:54 --> URI Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Router Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Output Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Security Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Input Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-11 09:19:54 --> Language Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Loader Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Helper loaded: date_helper
DEBUG - 2019-05-11 09:19:54 --> Controller Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Database Driver Class Initialized
ERROR - 2019-05-11 09:19:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-11 09:19:54 --> Model Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Model Class Initialized
DEBUG - 2019-05-11 09:19:54 --> Helper loaded: url_helper
DEBUG - 2019-05-11 09:19:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-11 09:19:54 --> Final output sent to browser
DEBUG - 2019-05-11 09:19:54 --> Total execution time: 0.0375
DEBUG - 2019-05-11 20:43:38 --> Config Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Hooks Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Utf8 Class Initialized
DEBUG - 2019-05-11 20:43:38 --> UTF-8 Support Enabled
DEBUG - 2019-05-11 20:43:38 --> URI Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Router Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Output Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Security Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Input Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-11 20:43:38 --> Language Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Loader Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Helper loaded: date_helper
DEBUG - 2019-05-11 20:43:38 --> Controller Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Database Driver Class Initialized
ERROR - 2019-05-11 20:43:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-11 20:43:38 --> Model Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Model Class Initialized
DEBUG - 2019-05-11 20:43:38 --> Helper loaded: url_helper
DEBUG - 2019-05-11 20:43:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-11 20:43:38 --> Final output sent to browser
DEBUG - 2019-05-11 20:43:38 --> Total execution time: 0.0416
DEBUG - 2019-05-11 22:51:37 --> Config Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Hooks Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Utf8 Class Initialized
DEBUG - 2019-05-11 22:51:37 --> UTF-8 Support Enabled
DEBUG - 2019-05-11 22:51:37 --> URI Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Router Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Output Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Security Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Input Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-11 22:51:37 --> Language Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Loader Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Helper loaded: date_helper
DEBUG - 2019-05-11 22:51:37 --> Controller Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Database Driver Class Initialized
ERROR - 2019-05-11 22:51:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-11 22:51:37 --> Model Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Model Class Initialized
DEBUG - 2019-05-11 22:51:37 --> Helper loaded: url_helper
DEBUG - 2019-05-11 22:51:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-11 22:51:37 --> Final output sent to browser
DEBUG - 2019-05-11 22:51:37 --> Total execution time: 0.0323
DEBUG - 2019-05-11 23:02:08 --> Config Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Hooks Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Utf8 Class Initialized
DEBUG - 2019-05-11 23:02:08 --> UTF-8 Support Enabled
DEBUG - 2019-05-11 23:02:08 --> URI Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Router Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Output Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Security Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Input Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-11 23:02:08 --> Language Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Loader Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Helper loaded: date_helper
DEBUG - 2019-05-11 23:02:08 --> Controller Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Database Driver Class Initialized
ERROR - 2019-05-11 23:02:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-05-11 23:02:08 --> Model Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Model Class Initialized
DEBUG - 2019-05-11 23:02:08 --> Helper loaded: url_helper
DEBUG - 2019-05-11 23:02:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-05-11 23:02:08 --> Final output sent to browser
DEBUG - 2019-05-11 23:02:08 --> Total execution time: 0.0253
