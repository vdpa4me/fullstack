<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-06-14 05:11:55 --> Config Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Hooks Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Utf8 Class Initialized
DEBUG - 2020-06-14 05:11:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-14 05:11:55 --> URI Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Router Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Output Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Security Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Input Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-14 05:11:55 --> Language Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Loader Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Helper loaded: date_helper
DEBUG - 2020-06-14 05:11:55 --> Controller Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Database Driver Class Initialized
ERROR - 2020-06-14 05:11:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-14 05:11:55 --> Model Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Model Class Initialized
DEBUG - 2020-06-14 05:11:55 --> Helper loaded: url_helper
DEBUG - 2020-06-14 05:11:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-14 05:11:55 --> Final output sent to browser
DEBUG - 2020-06-14 05:11:55 --> Total execution time: 0.1831
DEBUG - 2020-06-14 17:14:20 --> Config Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Hooks Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Utf8 Class Initialized
DEBUG - 2020-06-14 17:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-14 17:14:20 --> URI Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Router Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Output Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Security Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Input Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2020-06-14 17:14:20 --> Language Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Loader Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Helper loaded: date_helper
DEBUG - 2020-06-14 17:14:20 --> Controller Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Database Driver Class Initialized
ERROR - 2020-06-14 17:14:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-06-14 17:14:20 --> Model Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Model Class Initialized
DEBUG - 2020-06-14 17:14:20 --> Helper loaded: url_helper
DEBUG - 2020-06-14 17:14:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-06-14 17:14:20 --> Final output sent to browser
DEBUG - 2020-06-14 17:14:20 --> Total execution time: 0.1738
