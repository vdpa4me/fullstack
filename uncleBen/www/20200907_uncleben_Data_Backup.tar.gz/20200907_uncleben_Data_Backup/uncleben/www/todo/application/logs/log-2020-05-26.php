<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-05-26 01:20:29 --> Config Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Hooks Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Utf8 Class Initialized
DEBUG - 2020-05-26 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2020-05-26 01:20:29 --> URI Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Router Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Output Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Security Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Input Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2020-05-26 01:20:29 --> Language Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Loader Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Helper loaded: date_helper
DEBUG - 2020-05-26 01:20:29 --> Controller Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Database Driver Class Initialized
ERROR - 2020-05-26 01:20:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-05-26 01:20:29 --> Model Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Model Class Initialized
DEBUG - 2020-05-26 01:20:29 --> Helper loaded: url_helper
DEBUG - 2020-05-26 01:20:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-05-26 01:20:29 --> Final output sent to browser
DEBUG - 2020-05-26 01:20:29 --> Total execution time: 0.1949
DEBUG - 2020-05-26 20:45:08 --> Config Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Hooks Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Utf8 Class Initialized
DEBUG - 2020-05-26 20:45:08 --> UTF-8 Support Enabled
DEBUG - 2020-05-26 20:45:08 --> URI Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Router Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Output Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Security Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Input Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2020-05-26 20:45:08 --> Language Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Loader Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Helper loaded: date_helper
DEBUG - 2020-05-26 20:45:08 --> Controller Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Database Driver Class Initialized
ERROR - 2020-05-26 20:45:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-05-26 20:45:08 --> Model Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Model Class Initialized
DEBUG - 2020-05-26 20:45:08 --> Helper loaded: url_helper
DEBUG - 2020-05-26 20:45:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-05-26 20:45:08 --> Final output sent to browser
DEBUG - 2020-05-26 20:45:08 --> Total execution time: 0.2249
