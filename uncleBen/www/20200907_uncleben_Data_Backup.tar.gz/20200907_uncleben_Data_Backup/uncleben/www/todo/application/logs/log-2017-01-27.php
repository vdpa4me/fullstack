<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-27 06:56:32 --> Config Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Hooks Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Utf8 Class Initialized
DEBUG - 2017-01-27 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 06:56:32 --> URI Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Router Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Output Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Security Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Input Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 06:56:32 --> Language Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Loader Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Helper loaded: date_helper
DEBUG - 2017-01-27 06:56:32 --> Controller Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Database Driver Class Initialized
ERROR - 2017-01-27 06:56:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 06:56:32 --> Model Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Model Class Initialized
DEBUG - 2017-01-27 06:56:32 --> Helper loaded: url_helper
DEBUG - 2017-01-27 06:56:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 06:56:33 --> Final output sent to browser
DEBUG - 2017-01-27 06:56:33 --> Total execution time: 0.0434
DEBUG - 2017-01-27 07:02:12 --> Config Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Hooks Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Utf8 Class Initialized
DEBUG - 2017-01-27 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 07:02:12 --> URI Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Router Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Output Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Security Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Input Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 07:02:12 --> Language Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Loader Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Helper loaded: date_helper
DEBUG - 2017-01-27 07:02:12 --> Controller Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Database Driver Class Initialized
ERROR - 2017-01-27 07:02:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 07:02:12 --> Model Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Model Class Initialized
DEBUG - 2017-01-27 07:02:12 --> Helper loaded: url_helper
DEBUG - 2017-01-27 07:02:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 07:02:12 --> Final output sent to browser
DEBUG - 2017-01-27 07:02:12 --> Total execution time: 0.0319
DEBUG - 2017-01-27 07:02:19 --> Config Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Hooks Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Utf8 Class Initialized
DEBUG - 2017-01-27 07:02:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 07:02:19 --> URI Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Router Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Output Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Security Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Input Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 07:02:19 --> Language Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Loader Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Helper loaded: date_helper
DEBUG - 2017-01-27 07:02:19 --> Controller Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Database Driver Class Initialized
ERROR - 2017-01-27 07:02:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 07:02:19 --> Model Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Model Class Initialized
DEBUG - 2017-01-27 07:02:19 --> Helper loaded: url_helper
DEBUG - 2017-01-27 07:02:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 07:02:19 --> Final output sent to browser
DEBUG - 2017-01-27 07:02:19 --> Total execution time: 0.0317
DEBUG - 2017-01-27 07:31:22 --> Config Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Hooks Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Utf8 Class Initialized
DEBUG - 2017-01-27 07:31:22 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 07:31:22 --> URI Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Router Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Output Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Security Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Input Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 07:31:22 --> Language Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Loader Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Helper loaded: date_helper
DEBUG - 2017-01-27 07:31:22 --> Controller Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Database Driver Class Initialized
ERROR - 2017-01-27 07:31:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 07:31:22 --> Model Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Model Class Initialized
DEBUG - 2017-01-27 07:31:22 --> Helper loaded: url_helper
DEBUG - 2017-01-27 07:31:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 07:31:22 --> Final output sent to browser
DEBUG - 2017-01-27 07:31:22 --> Total execution time: 0.0291
DEBUG - 2017-01-27 07:31:47 --> Config Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Hooks Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Utf8 Class Initialized
DEBUG - 2017-01-27 07:31:47 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 07:31:47 --> URI Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Router Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Output Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Security Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Input Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 07:31:47 --> Language Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Loader Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Helper loaded: date_helper
DEBUG - 2017-01-27 07:31:47 --> Controller Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Database Driver Class Initialized
ERROR - 2017-01-27 07:31:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 07:31:47 --> Model Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Model Class Initialized
DEBUG - 2017-01-27 07:31:47 --> Helper loaded: url_helper
DEBUG - 2017-01-27 07:31:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 07:31:47 --> Final output sent to browser
DEBUG - 2017-01-27 07:31:47 --> Total execution time: 0.0291
DEBUG - 2017-01-27 08:07:40 --> Config Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Hooks Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Utf8 Class Initialized
DEBUG - 2017-01-27 08:07:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 08:07:40 --> URI Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Router Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Output Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Security Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Input Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 08:07:40 --> Language Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Loader Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Helper loaded: date_helper
DEBUG - 2017-01-27 08:07:40 --> Controller Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Database Driver Class Initialized
ERROR - 2017-01-27 08:07:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 08:07:40 --> Model Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Model Class Initialized
DEBUG - 2017-01-27 08:07:40 --> Helper loaded: url_helper
DEBUG - 2017-01-27 08:07:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 08:07:40 --> Final output sent to browser
DEBUG - 2017-01-27 08:07:40 --> Total execution time: 0.0290
DEBUG - 2017-01-27 08:21:46 --> Config Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Hooks Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Utf8 Class Initialized
DEBUG - 2017-01-27 08:21:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 08:21:46 --> URI Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Router Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Output Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Security Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Input Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 08:21:46 --> Language Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Loader Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Helper loaded: date_helper
DEBUG - 2017-01-27 08:21:46 --> Controller Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Database Driver Class Initialized
ERROR - 2017-01-27 08:21:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 08:21:46 --> Model Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Model Class Initialized
DEBUG - 2017-01-27 08:21:46 --> Helper loaded: url_helper
DEBUG - 2017-01-27 08:21:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 08:21:46 --> Final output sent to browser
DEBUG - 2017-01-27 08:21:46 --> Total execution time: 0.0299
DEBUG - 2017-01-27 08:22:10 --> Config Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Hooks Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Utf8 Class Initialized
DEBUG - 2017-01-27 08:22:10 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 08:22:10 --> URI Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Router Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Output Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Security Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Input Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 08:22:10 --> Language Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Loader Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Helper loaded: date_helper
DEBUG - 2017-01-27 08:22:10 --> Controller Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Database Driver Class Initialized
ERROR - 2017-01-27 08:22:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 08:22:10 --> Model Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Model Class Initialized
DEBUG - 2017-01-27 08:22:10 --> Helper loaded: url_helper
DEBUG - 2017-01-27 08:22:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 08:22:10 --> Final output sent to browser
DEBUG - 2017-01-27 08:22:10 --> Total execution time: 0.0283
DEBUG - 2017-01-27 12:19:54 --> Config Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Hooks Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Utf8 Class Initialized
DEBUG - 2017-01-27 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 12:19:54 --> URI Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Router Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Output Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Security Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Input Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 12:19:54 --> Language Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Loader Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Helper loaded: date_helper
DEBUG - 2017-01-27 12:19:54 --> Controller Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Database Driver Class Initialized
ERROR - 2017-01-27 12:19:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 12:19:54 --> Model Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Model Class Initialized
DEBUG - 2017-01-27 12:19:54 --> Helper loaded: url_helper
DEBUG - 2017-01-27 12:19:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 12:19:54 --> Final output sent to browser
DEBUG - 2017-01-27 12:19:54 --> Total execution time: 0.0336
DEBUG - 2017-01-27 12:19:58 --> Config Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Hooks Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Utf8 Class Initialized
DEBUG - 2017-01-27 12:19:58 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 12:19:58 --> URI Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Router Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Output Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Security Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Input Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 12:19:58 --> Language Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Loader Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Helper loaded: date_helper
DEBUG - 2017-01-27 12:19:58 --> Controller Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Database Driver Class Initialized
ERROR - 2017-01-27 12:19:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 12:19:58 --> Model Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Model Class Initialized
DEBUG - 2017-01-27 12:19:58 --> Helper loaded: url_helper
DEBUG - 2017-01-27 12:19:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 12:19:58 --> Final output sent to browser
DEBUG - 2017-01-27 12:19:58 --> Total execution time: 0.0292
DEBUG - 2017-01-27 12:20:23 --> Config Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Hooks Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Utf8 Class Initialized
DEBUG - 2017-01-27 12:20:23 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 12:20:23 --> URI Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Router Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Output Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Security Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Input Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 12:20:23 --> Language Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Loader Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Helper loaded: date_helper
DEBUG - 2017-01-27 12:20:23 --> Controller Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Database Driver Class Initialized
ERROR - 2017-01-27 12:20:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 12:20:23 --> Model Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Model Class Initialized
DEBUG - 2017-01-27 12:20:23 --> Helper loaded: url_helper
DEBUG - 2017-01-27 12:20:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 12:20:23 --> Final output sent to browser
DEBUG - 2017-01-27 12:20:23 --> Total execution time: 0.0295
DEBUG - 2017-01-27 12:20:26 --> Config Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Hooks Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Utf8 Class Initialized
DEBUG - 2017-01-27 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 12:20:26 --> URI Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Router Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Output Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Security Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Input Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 12:20:26 --> Language Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Loader Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Helper loaded: date_helper
DEBUG - 2017-01-27 12:20:26 --> Controller Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Database Driver Class Initialized
ERROR - 2017-01-27 12:20:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 12:20:26 --> Model Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Model Class Initialized
DEBUG - 2017-01-27 12:20:26 --> Helper loaded: url_helper
DEBUG - 2017-01-27 12:20:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 12:20:26 --> Final output sent to browser
DEBUG - 2017-01-27 12:20:26 --> Total execution time: 0.0296
DEBUG - 2017-01-27 12:20:33 --> Config Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Hooks Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Utf8 Class Initialized
DEBUG - 2017-01-27 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2017-01-27 12:20:33 --> URI Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Router Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Output Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Security Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Input Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-27 12:20:33 --> Language Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Loader Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Helper loaded: date_helper
DEBUG - 2017-01-27 12:20:33 --> Controller Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Database Driver Class Initialized
ERROR - 2017-01-27 12:20:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-27 12:20:33 --> Model Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Model Class Initialized
DEBUG - 2017-01-27 12:20:33 --> Helper loaded: url_helper
DEBUG - 2017-01-27 12:20:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-27 12:20:33 --> Final output sent to browser
DEBUG - 2017-01-27 12:20:33 --> Total execution time: 0.0288
