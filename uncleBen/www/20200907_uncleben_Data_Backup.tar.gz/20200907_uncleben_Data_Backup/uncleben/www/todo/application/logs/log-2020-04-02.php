<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-04-02 23:27:36 --> Config Class Initialized
DEBUG - 2020-04-02 23:27:36 --> Hooks Class Initialized
DEBUG - 2020-04-02 23:27:36 --> Utf8 Class Initialized
DEBUG - 2020-04-02 23:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-02 23:27:36 --> URI Class Initialized
DEBUG - 2020-04-02 23:27:36 --> Router Class Initialized
DEBUG - 2020-04-02 23:27:36 --> Output Class Initialized
DEBUG - 2020-04-02 23:27:36 --> Security Class Initialized
DEBUG - 2020-04-02 23:27:36 --> Input Class Initialized
DEBUG - 2020-04-02 23:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-02 23:27:36 --> Language Class Initialized
DEBUG - 2020-04-02 23:27:37 --> Loader Class Initialized
DEBUG - 2020-04-02 23:27:37 --> Helper loaded: date_helper
DEBUG - 2020-04-02 23:27:37 --> Controller Class Initialized
DEBUG - 2020-04-02 23:27:37 --> Database Driver Class Initialized
ERROR - 2020-04-02 23:27:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-02 23:27:37 --> Model Class Initialized
DEBUG - 2020-04-02 23:27:37 --> Model Class Initialized
DEBUG - 2020-04-02 23:27:37 --> Helper loaded: url_helper
DEBUG - 2020-04-02 23:27:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-02 23:27:37 --> Final output sent to browser
DEBUG - 2020-04-02 23:27:37 --> Total execution time: 0.1896
