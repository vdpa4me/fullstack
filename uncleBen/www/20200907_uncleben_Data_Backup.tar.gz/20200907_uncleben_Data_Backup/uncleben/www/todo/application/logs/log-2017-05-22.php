<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-05-22 06:09:07 --> Config Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Hooks Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Utf8 Class Initialized
DEBUG - 2017-05-22 06:09:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 06:09:07 --> URI Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Router Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Output Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Security Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Input Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 06:09:07 --> Language Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Loader Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Helper loaded: date_helper
DEBUG - 2017-05-22 06:09:07 --> Controller Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Database Driver Class Initialized
ERROR - 2017-05-22 06:09:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 06:09:07 --> Model Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Model Class Initialized
DEBUG - 2017-05-22 06:09:07 --> Helper loaded: url_helper
DEBUG - 2017-05-22 06:09:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 06:09:07 --> Final output sent to browser
DEBUG - 2017-05-22 06:09:07 --> Total execution time: 0.0465
DEBUG - 2017-05-22 06:09:12 --> Config Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Hooks Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Utf8 Class Initialized
DEBUG - 2017-05-22 06:09:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 06:09:12 --> URI Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Router Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Output Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Security Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Input Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 06:09:12 --> Language Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Loader Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Helper loaded: date_helper
DEBUG - 2017-05-22 06:09:12 --> Controller Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Database Driver Class Initialized
ERROR - 2017-05-22 06:09:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 06:09:12 --> Model Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Model Class Initialized
DEBUG - 2017-05-22 06:09:12 --> Helper loaded: url_helper
DEBUG - 2017-05-22 06:09:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 06:09:12 --> Final output sent to browser
DEBUG - 2017-05-22 06:09:12 --> Total execution time: 0.0310
DEBUG - 2017-05-22 06:18:36 --> Config Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Hooks Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Utf8 Class Initialized
DEBUG - 2017-05-22 06:18:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 06:18:36 --> URI Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Router Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Output Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Security Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Input Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 06:18:36 --> Language Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Loader Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Helper loaded: date_helper
DEBUG - 2017-05-22 06:18:36 --> Controller Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Database Driver Class Initialized
ERROR - 2017-05-22 06:18:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 06:18:36 --> Model Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Model Class Initialized
DEBUG - 2017-05-22 06:18:36 --> Helper loaded: url_helper
DEBUG - 2017-05-22 06:18:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 06:18:36 --> Final output sent to browser
DEBUG - 2017-05-22 06:18:36 --> Total execution time: 0.0308
DEBUG - 2017-05-22 06:39:36 --> Config Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Hooks Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Utf8 Class Initialized
DEBUG - 2017-05-22 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 06:39:36 --> URI Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Router Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Output Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Security Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Input Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 06:39:36 --> Language Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Loader Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Helper loaded: date_helper
DEBUG - 2017-05-22 06:39:36 --> Controller Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Database Driver Class Initialized
ERROR - 2017-05-22 06:39:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 06:39:36 --> Model Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Model Class Initialized
DEBUG - 2017-05-22 06:39:36 --> Helper loaded: url_helper
DEBUG - 2017-05-22 06:39:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 06:39:36 --> Final output sent to browser
DEBUG - 2017-05-22 06:39:36 --> Total execution time: 0.0317
DEBUG - 2017-05-22 07:09:23 --> Config Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Hooks Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Utf8 Class Initialized
DEBUG - 2017-05-22 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:09:23 --> URI Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Router Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Output Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Security Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Input Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 07:09:23 --> Language Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Loader Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Helper loaded: date_helper
DEBUG - 2017-05-22 07:09:23 --> Controller Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Database Driver Class Initialized
ERROR - 2017-05-22 07:09:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 07:09:23 --> Model Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Model Class Initialized
DEBUG - 2017-05-22 07:09:23 --> Helper loaded: url_helper
DEBUG - 2017-05-22 07:09:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 07:09:23 --> Final output sent to browser
DEBUG - 2017-05-22 07:09:23 --> Total execution time: 0.0375
DEBUG - 2017-05-22 07:09:35 --> Config Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Hooks Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Utf8 Class Initialized
DEBUG - 2017-05-22 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:09:35 --> URI Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Router Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Output Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Security Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Input Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 07:09:35 --> Language Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Loader Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Helper loaded: date_helper
DEBUG - 2017-05-22 07:09:35 --> Controller Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Database Driver Class Initialized
ERROR - 2017-05-22 07:09:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 07:09:35 --> Model Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Model Class Initialized
DEBUG - 2017-05-22 07:09:35 --> Helper loaded: url_helper
DEBUG - 2017-05-22 07:09:35 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 07:09:35 --> Final output sent to browser
DEBUG - 2017-05-22 07:09:35 --> Total execution time: 0.0313
DEBUG - 2017-05-22 08:56:12 --> Config Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Hooks Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Utf8 Class Initialized
DEBUG - 2017-05-22 08:56:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 08:56:12 --> URI Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Router Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Output Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Security Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Input Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 08:56:12 --> Language Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Loader Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Helper loaded: date_helper
DEBUG - 2017-05-22 08:56:12 --> Controller Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Database Driver Class Initialized
ERROR - 2017-05-22 08:56:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 08:56:12 --> Model Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Model Class Initialized
DEBUG - 2017-05-22 08:56:12 --> Helper loaded: url_helper
DEBUG - 2017-05-22 08:56:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 08:56:12 --> Final output sent to browser
DEBUG - 2017-05-22 08:56:12 --> Total execution time: 0.0390
DEBUG - 2017-05-22 08:59:06 --> Config Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Hooks Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Utf8 Class Initialized
DEBUG - 2017-05-22 08:59:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 08:59:06 --> URI Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Router Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Output Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Security Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Input Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 08:59:06 --> Language Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Loader Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Helper loaded: date_helper
DEBUG - 2017-05-22 08:59:06 --> Controller Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Database Driver Class Initialized
ERROR - 2017-05-22 08:59:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 08:59:06 --> Model Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Model Class Initialized
DEBUG - 2017-05-22 08:59:06 --> Helper loaded: url_helper
DEBUG - 2017-05-22 08:59:06 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 08:59:06 --> Final output sent to browser
DEBUG - 2017-05-22 08:59:06 --> Total execution time: 0.0316
DEBUG - 2017-05-22 09:01:22 --> Config Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Hooks Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Utf8 Class Initialized
DEBUG - 2017-05-22 09:01:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 09:01:22 --> URI Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Router Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Output Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Security Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Input Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 09:01:22 --> Language Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Loader Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Helper loaded: date_helper
DEBUG - 2017-05-22 09:01:22 --> Controller Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Database Driver Class Initialized
ERROR - 2017-05-22 09:01:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 09:01:22 --> Model Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Model Class Initialized
DEBUG - 2017-05-22 09:01:22 --> Helper loaded: url_helper
DEBUG - 2017-05-22 09:01:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 09:01:22 --> Final output sent to browser
DEBUG - 2017-05-22 09:01:22 --> Total execution time: 0.0315
DEBUG - 2017-05-22 11:20:48 --> Config Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Hooks Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Utf8 Class Initialized
DEBUG - 2017-05-22 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 11:20:48 --> URI Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Router Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Output Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Security Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Input Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 11:20:48 --> Language Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Loader Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Helper loaded: date_helper
DEBUG - 2017-05-22 11:20:48 --> Controller Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Database Driver Class Initialized
ERROR - 2017-05-22 11:20:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 11:20:48 --> Model Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Model Class Initialized
DEBUG - 2017-05-22 11:20:48 --> Helper loaded: url_helper
DEBUG - 2017-05-22 11:20:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 11:20:48 --> Final output sent to browser
DEBUG - 2017-05-22 11:20:48 --> Total execution time: 0.0381
DEBUG - 2017-05-22 11:24:15 --> Config Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Hooks Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Utf8 Class Initialized
DEBUG - 2017-05-22 11:24:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 11:24:15 --> URI Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Router Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Output Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Security Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Input Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-05-22 11:24:15 --> Language Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Loader Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Helper loaded: date_helper
DEBUG - 2017-05-22 11:24:15 --> Controller Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Database Driver Class Initialized
ERROR - 2017-05-22 11:24:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-05-22 11:24:15 --> Model Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Model Class Initialized
DEBUG - 2017-05-22 11:24:15 --> Helper loaded: url_helper
DEBUG - 2017-05-22 11:24:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-05-22 11:24:15 --> Final output sent to browser
DEBUG - 2017-05-22 11:24:15 --> Total execution time: 0.0317
