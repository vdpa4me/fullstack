<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-09-09 16:06:29 --> Config Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Hooks Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Utf8 Class Initialized
DEBUG - 2019-09-09 16:06:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-09 16:06:29 --> URI Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Router Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Output Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Security Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Input Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-09 16:06:29 --> Language Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Loader Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Helper loaded: date_helper
DEBUG - 2019-09-09 16:06:29 --> Controller Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Database Driver Class Initialized
ERROR - 2019-09-09 16:06:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-09 16:06:29 --> Model Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Model Class Initialized
DEBUG - 2019-09-09 16:06:29 --> Helper loaded: url_helper
DEBUG - 2019-09-09 16:06:29 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-09-09 16:06:29 --> Final output sent to browser
DEBUG - 2019-09-09 16:06:29 --> Total execution time: 0.0971
DEBUG - 2019-09-09 16:06:34 --> Config Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Hooks Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Utf8 Class Initialized
DEBUG - 2019-09-09 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-09 16:06:34 --> URI Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Router Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Output Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Security Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Input Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-09 16:06:34 --> Language Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Loader Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Helper loaded: date_helper
DEBUG - 2019-09-09 16:06:34 --> Controller Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Database Driver Class Initialized
ERROR - 2019-09-09 16:06:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-09 16:06:34 --> Model Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Model Class Initialized
DEBUG - 2019-09-09 16:06:34 --> Helper loaded: url_helper
DEBUG - 2019-09-09 16:06:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-09-09 16:06:34 --> Final output sent to browser
DEBUG - 2019-09-09 16:06:34 --> Total execution time: 0.0488
DEBUG - 2019-09-09 16:08:03 --> Config Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Hooks Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Utf8 Class Initialized
DEBUG - 2019-09-09 16:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-09 16:08:03 --> URI Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Router Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Output Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Security Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Input Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-09 16:08:03 --> Language Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Loader Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Helper loaded: date_helper
DEBUG - 2019-09-09 16:08:03 --> Controller Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Database Driver Class Initialized
ERROR - 2019-09-09 16:08:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-09 16:08:03 --> Model Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Model Class Initialized
DEBUG - 2019-09-09 16:08:03 --> Helper loaded: url_helper
DEBUG - 2019-09-09 16:08:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-09-09 16:08:03 --> Final output sent to browser
DEBUG - 2019-09-09 16:08:03 --> Total execution time: 0.0492
DEBUG - 2019-09-09 16:08:15 --> Config Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Hooks Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Utf8 Class Initialized
DEBUG - 2019-09-09 16:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-09 16:08:15 --> URI Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Router Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Output Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Security Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Input Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-09 16:08:15 --> Language Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Loader Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Helper loaded: date_helper
DEBUG - 2019-09-09 16:08:15 --> Controller Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Database Driver Class Initialized
ERROR - 2019-09-09 16:08:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-09 16:08:15 --> Model Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Model Class Initialized
DEBUG - 2019-09-09 16:08:15 --> Helper loaded: url_helper
DEBUG - 2019-09-09 16:08:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2019-09-09 16:08:15 --> Final output sent to browser
DEBUG - 2019-09-09 16:08:15 --> Total execution time: 0.0444
