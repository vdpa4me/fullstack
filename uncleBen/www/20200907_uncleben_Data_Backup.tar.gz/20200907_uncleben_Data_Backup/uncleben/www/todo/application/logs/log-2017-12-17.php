<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-12-17 11:28:09 --> Config Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Hooks Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Utf8 Class Initialized
DEBUG - 2017-12-17 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2017-12-17 11:28:09 --> URI Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Router Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Output Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Security Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Input Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-17 11:28:09 --> Language Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Loader Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Helper loaded: date_helper
DEBUG - 2017-12-17 11:28:09 --> Controller Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Database Driver Class Initialized
ERROR - 2017-12-17 11:28:09 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-17 11:28:09 --> Model Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Model Class Initialized
DEBUG - 2017-12-17 11:28:09 --> Helper loaded: url_helper
DEBUG - 2017-12-17 11:28:09 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-17 11:28:09 --> Final output sent to browser
DEBUG - 2017-12-17 11:28:09 --> Total execution time: 0.0345
DEBUG - 2017-12-17 11:31:16 --> Config Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Hooks Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Utf8 Class Initialized
DEBUG - 2017-12-17 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2017-12-17 11:31:16 --> URI Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Router Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Output Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Security Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Input Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-17 11:31:16 --> Language Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Loader Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Helper loaded: date_helper
DEBUG - 2017-12-17 11:31:16 --> Controller Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Database Driver Class Initialized
ERROR - 2017-12-17 11:31:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-17 11:31:16 --> Model Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Model Class Initialized
DEBUG - 2017-12-17 11:31:16 --> Helper loaded: url_helper
DEBUG - 2017-12-17 11:31:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-17 11:31:16 --> Final output sent to browser
DEBUG - 2017-12-17 11:31:16 --> Total execution time: 0.0198
DEBUG - 2017-12-17 11:34:13 --> Config Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Hooks Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Utf8 Class Initialized
DEBUG - 2017-12-17 11:34:13 --> UTF-8 Support Enabled
DEBUG - 2017-12-17 11:34:13 --> URI Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Router Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Output Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Security Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Input Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-17 11:34:13 --> Language Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Loader Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Helper loaded: date_helper
DEBUG - 2017-12-17 11:34:13 --> Controller Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Database Driver Class Initialized
ERROR - 2017-12-17 11:34:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-17 11:34:13 --> Model Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Model Class Initialized
DEBUG - 2017-12-17 11:34:13 --> Helper loaded: url_helper
DEBUG - 2017-12-17 11:34:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-17 11:34:13 --> Final output sent to browser
DEBUG - 2017-12-17 11:34:13 --> Total execution time: 0.0200
DEBUG - 2017-12-17 12:26:38 --> Config Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Hooks Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Utf8 Class Initialized
DEBUG - 2017-12-17 12:26:38 --> UTF-8 Support Enabled
DEBUG - 2017-12-17 12:26:38 --> URI Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Router Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Output Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Security Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Input Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-17 12:26:38 --> Language Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Loader Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Helper loaded: date_helper
DEBUG - 2017-12-17 12:26:38 --> Controller Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Database Driver Class Initialized
ERROR - 2017-12-17 12:26:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-17 12:26:38 --> Model Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Model Class Initialized
DEBUG - 2017-12-17 12:26:38 --> Helper loaded: url_helper
DEBUG - 2017-12-17 12:26:38 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-17 12:26:38 --> Final output sent to browser
DEBUG - 2017-12-17 12:26:38 --> Total execution time: 0.0520
DEBUG - 2017-12-17 12:26:48 --> Config Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Hooks Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Utf8 Class Initialized
DEBUG - 2017-12-17 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2017-12-17 12:26:48 --> URI Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Router Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Output Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Security Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Input Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-17 12:26:48 --> Language Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Loader Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Helper loaded: date_helper
DEBUG - 2017-12-17 12:26:48 --> Controller Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Database Driver Class Initialized
ERROR - 2017-12-17 12:26:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-17 12:26:48 --> Model Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Model Class Initialized
DEBUG - 2017-12-17 12:26:48 --> Helper loaded: url_helper
DEBUG - 2017-12-17 12:26:48 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-17 12:26:48 --> Final output sent to browser
DEBUG - 2017-12-17 12:26:48 --> Total execution time: 0.0403
DEBUG - 2017-12-17 19:59:11 --> Config Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Hooks Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Utf8 Class Initialized
DEBUG - 2017-12-17 19:59:11 --> UTF-8 Support Enabled
DEBUG - 2017-12-17 19:59:11 --> URI Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Router Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Output Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Security Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Input Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-17 19:59:11 --> Language Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Loader Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Helper loaded: date_helper
DEBUG - 2017-12-17 19:59:11 --> Controller Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Database Driver Class Initialized
ERROR - 2017-12-17 19:59:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-17 19:59:11 --> Model Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Model Class Initialized
DEBUG - 2017-12-17 19:59:11 --> Helper loaded: url_helper
DEBUG - 2017-12-17 19:59:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-17 19:59:11 --> Final output sent to browser
DEBUG - 2017-12-17 19:59:11 --> Total execution time: 0.0217
