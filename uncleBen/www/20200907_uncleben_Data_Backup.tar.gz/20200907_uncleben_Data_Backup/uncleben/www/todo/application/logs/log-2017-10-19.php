<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-19 01:00:47 --> Config Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Hooks Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Utf8 Class Initialized
DEBUG - 2017-10-19 01:00:47 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 01:00:47 --> URI Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Router Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Output Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Security Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Input Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 01:00:47 --> Language Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Loader Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Helper loaded: date_helper
DEBUG - 2017-10-19 01:00:47 --> Controller Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Database Driver Class Initialized
ERROR - 2017-10-19 01:00:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 01:00:47 --> Model Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Model Class Initialized
DEBUG - 2017-10-19 01:00:47 --> Helper loaded: url_helper
DEBUG - 2017-10-19 01:00:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-19 01:00:47 --> Final output sent to browser
DEBUG - 2017-10-19 01:00:47 --> Total execution time: 0.0233
DEBUG - 2017-10-19 04:18:00 --> Config Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Hooks Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Utf8 Class Initialized
DEBUG - 2017-10-19 04:18:00 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 04:18:00 --> URI Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Router Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Output Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Security Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Input Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 04:18:00 --> Language Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Loader Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Helper loaded: date_helper
DEBUG - 2017-10-19 04:18:00 --> Controller Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Database Driver Class Initialized
ERROR - 2017-10-19 04:18:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 04:18:00 --> Model Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Model Class Initialized
DEBUG - 2017-10-19 04:18:00 --> Helper loaded: url_helper
DEBUG - 2017-10-19 04:18:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-19 04:18:00 --> Final output sent to browser
DEBUG - 2017-10-19 04:18:00 --> Total execution time: 0.0255
DEBUG - 2017-10-19 07:51:12 --> Config Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Hooks Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Utf8 Class Initialized
DEBUG - 2017-10-19 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 07:51:12 --> URI Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Router Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Output Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Security Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Input Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 07:51:12 --> Language Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Loader Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Helper loaded: date_helper
DEBUG - 2017-10-19 07:51:12 --> Controller Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Database Driver Class Initialized
ERROR - 2017-10-19 07:51:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 07:51:12 --> Model Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Model Class Initialized
DEBUG - 2017-10-19 07:51:12 --> Helper loaded: url_helper
DEBUG - 2017-10-19 07:51:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-19 07:51:12 --> Final output sent to browser
DEBUG - 2017-10-19 07:51:12 --> Total execution time: 0.0264
DEBUG - 2017-10-19 10:12:32 --> Config Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Hooks Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Utf8 Class Initialized
DEBUG - 2017-10-19 10:12:32 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 10:12:32 --> URI Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Router Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Output Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Security Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Input Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 10:12:32 --> Language Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Loader Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Helper loaded: date_helper
DEBUG - 2017-10-19 10:12:32 --> Controller Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Database Driver Class Initialized
ERROR - 2017-10-19 10:12:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 10:12:32 --> Model Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Model Class Initialized
DEBUG - 2017-10-19 10:12:32 --> Helper loaded: url_helper
DEBUG - 2017-10-19 10:12:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-19 10:12:32 --> Final output sent to browser
DEBUG - 2017-10-19 10:12:32 --> Total execution time: 0.0527
DEBUG - 2017-10-19 10:12:40 --> Config Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Hooks Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Utf8 Class Initialized
DEBUG - 2017-10-19 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 10:12:40 --> URI Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Router Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Output Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Security Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Input Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 10:12:40 --> Language Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Loader Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Helper loaded: date_helper
DEBUG - 2017-10-19 10:12:40 --> Controller Class Initialized
DEBUG - 2017-10-19 10:12:40 --> Database Driver Class Initialized
ERROR - 2017-10-19 10:12:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 10:12:40 --> Model Class Initialized
DEBUG - 2017-10-19 10:12:41 --> Model Class Initialized
DEBUG - 2017-10-19 10:12:41 --> Helper loaded: url_helper
DEBUG - 2017-10-19 10:12:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-19 10:12:41 --> Final output sent to browser
DEBUG - 2017-10-19 10:12:41 --> Total execution time: 0.0399
DEBUG - 2017-10-19 10:13:31 --> Config Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Hooks Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Utf8 Class Initialized
DEBUG - 2017-10-19 10:13:31 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 10:13:31 --> URI Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Router Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Output Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Security Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Input Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 10:13:31 --> Language Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Loader Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Helper loaded: date_helper
DEBUG - 2017-10-19 10:13:31 --> Controller Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Database Driver Class Initialized
ERROR - 2017-10-19 10:13:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 10:13:31 --> Model Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Model Class Initialized
DEBUG - 2017-10-19 10:13:31 --> Helper loaded: url_helper
DEBUG - 2017-10-19 10:13:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-19 10:13:31 --> Final output sent to browser
DEBUG - 2017-10-19 10:13:31 --> Total execution time: 0.0397
DEBUG - 2017-10-19 16:08:15 --> Config Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Hooks Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Utf8 Class Initialized
DEBUG - 2017-10-19 16:08:15 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 16:08:15 --> URI Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Router Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Output Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Security Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Input Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 16:08:15 --> Language Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Loader Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Helper loaded: date_helper
DEBUG - 2017-10-19 16:08:15 --> Controller Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Database Driver Class Initialized
ERROR - 2017-10-19 16:08:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 16:08:15 --> Model Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Model Class Initialized
DEBUG - 2017-10-19 16:08:15 --> Helper loaded: url_helper
DEBUG - 2017-10-19 16:08:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-19 16:08:15 --> Final output sent to browser
DEBUG - 2017-10-19 16:08:15 --> Total execution time: 0.0362
DEBUG - 2017-10-19 19:07:07 --> Config Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Hooks Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Utf8 Class Initialized
DEBUG - 2017-10-19 19:07:07 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 19:07:07 --> URI Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Router Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Output Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Security Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Input Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 19:07:07 --> Language Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Loader Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Helper loaded: date_helper
DEBUG - 2017-10-19 19:07:07 --> Controller Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Database Driver Class Initialized
ERROR - 2017-10-19 19:07:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 19:07:07 --> Model Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Model Class Initialized
DEBUG - 2017-10-19 19:07:07 --> Helper loaded: url_helper
DEBUG - 2017-10-19 19:07:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-19 19:07:07 --> Final output sent to browser
DEBUG - 2017-10-19 19:07:07 --> Total execution time: 0.0200
DEBUG - 2017-10-19 23:41:17 --> Config Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Hooks Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Utf8 Class Initialized
DEBUG - 2017-10-19 23:41:17 --> UTF-8 Support Enabled
DEBUG - 2017-10-19 23:41:17 --> URI Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Router Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Output Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Security Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Input Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-19 23:41:17 --> Language Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Loader Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Helper loaded: date_helper
DEBUG - 2017-10-19 23:41:17 --> Controller Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Database Driver Class Initialized
ERROR - 2017-10-19 23:41:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-19 23:41:17 --> Model Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Model Class Initialized
DEBUG - 2017-10-19 23:41:17 --> Helper loaded: url_helper
DEBUG - 2017-10-19 23:41:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-19 23:41:17 --> Final output sent to browser
DEBUG - 2017-10-19 23:41:17 --> Total execution time: 0.0197
