<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-04-11 02:51:51 --> Config Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Hooks Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Utf8 Class Initialized
DEBUG - 2020-04-11 02:51:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 02:51:51 --> URI Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Router Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Output Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Security Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Input Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-11 02:51:51 --> Language Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Loader Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Helper loaded: date_helper
DEBUG - 2020-04-11 02:51:51 --> Controller Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Database Driver Class Initialized
ERROR - 2020-04-11 02:51:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-11 02:51:51 --> Model Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Model Class Initialized
DEBUG - 2020-04-11 02:51:51 --> Helper loaded: url_helper
DEBUG - 2020-04-11 02:51:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-11 02:51:51 --> Final output sent to browser
DEBUG - 2020-04-11 02:51:51 --> Total execution time: 0.1969
DEBUG - 2020-04-11 17:25:15 --> Config Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Hooks Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Utf8 Class Initialized
DEBUG - 2020-04-11 17:25:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 17:25:15 --> URI Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Router Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Output Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Security Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Input Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-11 17:25:15 --> Language Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Loader Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Helper loaded: date_helper
DEBUG - 2020-04-11 17:25:15 --> Controller Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Database Driver Class Initialized
ERROR - 2020-04-11 17:25:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-11 17:25:15 --> Model Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Model Class Initialized
DEBUG - 2020-04-11 17:25:15 --> Helper loaded: url_helper
DEBUG - 2020-04-11 17:25:15 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-11 17:25:15 --> Final output sent to browser
DEBUG - 2020-04-11 17:25:15 --> Total execution time: 0.2172
DEBUG - 2020-04-11 18:30:12 --> Config Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Hooks Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Utf8 Class Initialized
DEBUG - 2020-04-11 18:30:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 18:30:12 --> URI Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Router Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Output Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Security Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Input Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-11 18:30:12 --> Language Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Loader Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Helper loaded: date_helper
DEBUG - 2020-04-11 18:30:12 --> Controller Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Database Driver Class Initialized
ERROR - 2020-04-11 18:30:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-11 18:30:12 --> Model Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Model Class Initialized
DEBUG - 2020-04-11 18:30:12 --> Helper loaded: url_helper
DEBUG - 2020-04-11 18:30:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-11 18:30:12 --> Final output sent to browser
DEBUG - 2020-04-11 18:30:12 --> Total execution time: 0.0882
