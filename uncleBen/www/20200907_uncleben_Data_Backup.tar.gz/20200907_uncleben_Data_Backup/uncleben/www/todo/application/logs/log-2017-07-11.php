<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-07-11 09:07:30 --> Config Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Utf8 Class Initialized
DEBUG - 2017-07-11 09:07:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-11 09:07:30 --> URI Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Router Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Output Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Security Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Input Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-11 09:07:30 --> Language Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Loader Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Helper loaded: date_helper
DEBUG - 2017-07-11 09:07:30 --> Controller Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Database Driver Class Initialized
ERROR - 2017-07-11 09:07:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-11 09:07:30 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:30 --> Helper loaded: url_helper
DEBUG - 2017-07-11 09:07:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-11 09:07:30 --> Final output sent to browser
DEBUG - 2017-07-11 09:07:30 --> Total execution time: 0.0697
DEBUG - 2017-07-11 09:07:40 --> Config Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Utf8 Class Initialized
DEBUG - 2017-07-11 09:07:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-11 09:07:40 --> URI Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Router Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Output Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Security Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Input Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-11 09:07:40 --> Language Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Loader Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Helper loaded: date_helper
DEBUG - 2017-07-11 09:07:40 --> Controller Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Database Driver Class Initialized
ERROR - 2017-07-11 09:07:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-11 09:07:40 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:40 --> Helper loaded: url_helper
DEBUG - 2017-07-11 09:07:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-11 09:07:40 --> Final output sent to browser
DEBUG - 2017-07-11 09:07:40 --> Total execution time: 0.0350
DEBUG - 2017-07-11 09:07:44 --> Config Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Utf8 Class Initialized
DEBUG - 2017-07-11 09:07:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-11 09:07:44 --> URI Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Router Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Output Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Security Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Input Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-11 09:07:44 --> Language Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Loader Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Helper loaded: date_helper
DEBUG - 2017-07-11 09:07:44 --> Controller Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Database Driver Class Initialized
ERROR - 2017-07-11 09:07:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-11 09:07:44 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:44 --> Helper loaded: url_helper
DEBUG - 2017-07-11 09:07:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-11 09:07:44 --> Final output sent to browser
DEBUG - 2017-07-11 09:07:44 --> Total execution time: 0.0351
DEBUG - 2017-07-11 09:07:49 --> Config Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Hooks Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Utf8 Class Initialized
DEBUG - 2017-07-11 09:07:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-11 09:07:49 --> URI Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Router Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Output Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Security Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Input Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-07-11 09:07:49 --> Language Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Loader Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Helper loaded: date_helper
DEBUG - 2017-07-11 09:07:49 --> Controller Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Database Driver Class Initialized
ERROR - 2017-07-11 09:07:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-07-11 09:07:49 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Model Class Initialized
DEBUG - 2017-07-11 09:07:49 --> Helper loaded: url_helper
DEBUG - 2017-07-11 09:07:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-07-11 09:07:49 --> Final output sent to browser
DEBUG - 2017-07-11 09:07:49 --> Total execution time: 0.0349
