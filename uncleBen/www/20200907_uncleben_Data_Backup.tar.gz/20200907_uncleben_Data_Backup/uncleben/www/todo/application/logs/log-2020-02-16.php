<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-02-16 08:48:12 --> Config Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Hooks Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Utf8 Class Initialized
DEBUG - 2020-02-16 08:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-02-16 08:48:12 --> URI Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Router Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Output Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Security Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Input Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-16 08:48:12 --> Language Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Loader Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Helper loaded: date_helper
DEBUG - 2020-02-16 08:48:12 --> Controller Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Database Driver Class Initialized
ERROR - 2020-02-16 08:48:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-16 08:48:12 --> Model Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Model Class Initialized
DEBUG - 2020-02-16 08:48:12 --> Helper loaded: url_helper
DEBUG - 2020-02-16 08:48:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-16 08:48:12 --> Final output sent to browser
DEBUG - 2020-02-16 08:48:12 --> Total execution time: 0.1953
DEBUG - 2020-02-16 17:33:20 --> Config Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Hooks Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Utf8 Class Initialized
DEBUG - 2020-02-16 17:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-02-16 17:33:20 --> URI Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Router Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Output Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Security Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Input Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2020-02-16 17:33:20 --> Language Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Loader Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Helper loaded: date_helper
DEBUG - 2020-02-16 17:33:20 --> Controller Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Database Driver Class Initialized
ERROR - 2020-02-16 17:33:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-02-16 17:33:20 --> Model Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Model Class Initialized
DEBUG - 2020-02-16 17:33:20 --> Helper loaded: url_helper
DEBUG - 2020-02-16 17:33:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-02-16 17:33:20 --> Final output sent to browser
DEBUG - 2020-02-16 17:33:20 --> Total execution time: 0.1363
