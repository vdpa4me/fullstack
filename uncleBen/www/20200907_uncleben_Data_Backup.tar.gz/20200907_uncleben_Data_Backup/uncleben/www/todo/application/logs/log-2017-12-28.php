<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-12-28 11:36:18 --> Config Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Hooks Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Utf8 Class Initialized
DEBUG - 2017-12-28 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 11:36:18 --> URI Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Router Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Output Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Security Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Input Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 11:36:18 --> Language Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Loader Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Helper loaded: date_helper
DEBUG - 2017-12-28 11:36:18 --> Controller Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Database Driver Class Initialized
ERROR - 2017-12-28 11:36:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 11:36:18 --> Model Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Model Class Initialized
DEBUG - 2017-12-28 11:36:18 --> Helper loaded: url_helper
DEBUG - 2017-12-28 11:36:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-28 11:36:18 --> Final output sent to browser
DEBUG - 2017-12-28 11:36:18 --> Total execution time: 0.0295
DEBUG - 2017-12-28 11:39:35 --> Config Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Hooks Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Utf8 Class Initialized
DEBUG - 2017-12-28 11:39:35 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 11:39:35 --> URI Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Router Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Output Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Security Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Input Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 11:39:35 --> Language Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Loader Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Helper loaded: date_helper
DEBUG - 2017-12-28 11:39:35 --> Controller Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Database Driver Class Initialized
ERROR - 2017-12-28 11:39:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 11:39:35 --> Model Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Model Class Initialized
DEBUG - 2017-12-28 11:39:35 --> Helper loaded: url_helper
DEBUG - 2017-12-28 11:39:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-28 11:39:35 --> Final output sent to browser
DEBUG - 2017-12-28 11:39:35 --> Total execution time: 0.0198
DEBUG - 2017-12-28 11:57:17 --> Config Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Hooks Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Utf8 Class Initialized
DEBUG - 2017-12-28 11:57:17 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 11:57:17 --> URI Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Router Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Output Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Security Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Input Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 11:57:17 --> Language Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Loader Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Helper loaded: date_helper
DEBUG - 2017-12-28 11:57:17 --> Controller Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Database Driver Class Initialized
ERROR - 2017-12-28 11:57:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 11:57:17 --> Model Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Model Class Initialized
DEBUG - 2017-12-28 11:57:17 --> Helper loaded: url_helper
DEBUG - 2017-12-28 11:57:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-28 11:57:17 --> Final output sent to browser
DEBUG - 2017-12-28 11:57:17 --> Total execution time: 0.0207
DEBUG - 2017-12-28 18:24:08 --> Config Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Utf8 Class Initialized
DEBUG - 2017-12-28 18:24:08 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 18:24:08 --> URI Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Router Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Output Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Security Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Input Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 18:24:08 --> Language Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Loader Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Helper loaded: date_helper
DEBUG - 2017-12-28 18:24:08 --> Controller Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Database Driver Class Initialized
ERROR - 2017-12-28 18:24:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 18:24:08 --> Model Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Model Class Initialized
DEBUG - 2017-12-28 18:24:08 --> Helper loaded: url_helper
DEBUG - 2017-12-28 18:24:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 18:24:08 --> Final output sent to browser
DEBUG - 2017-12-28 18:24:08 --> Total execution time: 0.0543
DEBUG - 2017-12-28 18:24:13 --> Config Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Hooks Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Utf8 Class Initialized
DEBUG - 2017-12-28 18:24:13 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 18:24:13 --> URI Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Router Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Output Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Security Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Input Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 18:24:13 --> Language Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Loader Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Helper loaded: date_helper
DEBUG - 2017-12-28 18:24:13 --> Controller Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Database Driver Class Initialized
ERROR - 2017-12-28 18:24:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 18:24:13 --> Model Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Model Class Initialized
DEBUG - 2017-12-28 18:24:13 --> Helper loaded: url_helper
DEBUG - 2017-12-28 18:24:13 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 18:24:13 --> Final output sent to browser
DEBUG - 2017-12-28 18:24:13 --> Total execution time: 0.0421
DEBUG - 2017-12-28 18:24:20 --> Config Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Hooks Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Utf8 Class Initialized
DEBUG - 2017-12-28 18:24:20 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 18:24:20 --> URI Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Router Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Output Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Security Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Input Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 18:24:20 --> Language Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Loader Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Helper loaded: date_helper
DEBUG - 2017-12-28 18:24:20 --> Controller Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Database Driver Class Initialized
ERROR - 2017-12-28 18:24:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 18:24:20 --> Model Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Model Class Initialized
DEBUG - 2017-12-28 18:24:20 --> Helper loaded: url_helper
DEBUG - 2017-12-28 18:24:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 18:24:20 --> Final output sent to browser
DEBUG - 2017-12-28 18:24:20 --> Total execution time: 0.0403
DEBUG - 2017-12-28 18:27:10 --> Config Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Hooks Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Utf8 Class Initialized
DEBUG - 2017-12-28 18:27:10 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 18:27:10 --> URI Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Router Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Output Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Security Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Input Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 18:27:10 --> Language Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Loader Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Helper loaded: date_helper
DEBUG - 2017-12-28 18:27:10 --> Controller Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Database Driver Class Initialized
ERROR - 2017-12-28 18:27:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 18:27:10 --> Model Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Model Class Initialized
DEBUG - 2017-12-28 18:27:10 --> Helper loaded: url_helper
DEBUG - 2017-12-28 18:27:10 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 18:27:10 --> Final output sent to browser
DEBUG - 2017-12-28 18:27:10 --> Total execution time: 0.0417
DEBUG - 2017-12-28 18:34:07 --> Config Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Utf8 Class Initialized
DEBUG - 2017-12-28 18:34:07 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 18:34:07 --> URI Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Router Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Output Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Security Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Input Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 18:34:07 --> Language Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Loader Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Helper loaded: date_helper
DEBUG - 2017-12-28 18:34:07 --> Controller Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Database Driver Class Initialized
ERROR - 2017-12-28 18:34:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 18:34:07 --> Model Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Model Class Initialized
DEBUG - 2017-12-28 18:34:07 --> Helper loaded: url_helper
DEBUG - 2017-12-28 18:34:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 18:34:07 --> Final output sent to browser
DEBUG - 2017-12-28 18:34:07 --> Total execution time: 0.0429
DEBUG - 2017-12-28 19:35:02 --> Config Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Hooks Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Utf8 Class Initialized
DEBUG - 2017-12-28 19:35:02 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 19:35:02 --> URI Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Router Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Output Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Security Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Input Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 19:35:02 --> Language Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Loader Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Helper loaded: date_helper
DEBUG - 2017-12-28 19:35:02 --> Controller Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Database Driver Class Initialized
ERROR - 2017-12-28 19:35:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 19:35:02 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Model Class Initialized
DEBUG - 2017-12-28 19:35:02 --> Helper loaded: url_helper
DEBUG - 2017-12-28 19:35:02 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 19:35:02 --> Final output sent to browser
DEBUG - 2017-12-28 19:35:02 --> Total execution time: 0.0519
DEBUG - 2017-12-28 20:10:41 --> Config Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Hooks Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Utf8 Class Initialized
DEBUG - 2017-12-28 20:10:41 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 20:10:41 --> URI Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Router Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Output Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Security Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Input Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 20:10:41 --> Language Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Loader Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Helper loaded: date_helper
DEBUG - 2017-12-28 20:10:41 --> Controller Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Database Driver Class Initialized
ERROR - 2017-12-28 20:10:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 20:10:41 --> Model Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Model Class Initialized
DEBUG - 2017-12-28 20:10:41 --> Helper loaded: url_helper
DEBUG - 2017-12-28 20:10:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-28 20:10:41 --> Final output sent to browser
DEBUG - 2017-12-28 20:10:41 --> Total execution time: 0.0244
DEBUG - 2017-12-28 22:01:06 --> Config Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Hooks Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Utf8 Class Initialized
DEBUG - 2017-12-28 22:01:07 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 22:01:07 --> URI Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Router Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Output Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Security Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Input Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 22:01:07 --> Language Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Loader Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Helper loaded: date_helper
DEBUG - 2017-12-28 22:01:07 --> Controller Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Database Driver Class Initialized
ERROR - 2017-12-28 22:01:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 22:01:07 --> Model Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Model Class Initialized
DEBUG - 2017-12-28 22:01:07 --> Helper loaded: url_helper
DEBUG - 2017-12-28 22:01:07 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 22:01:07 --> Final output sent to browser
DEBUG - 2017-12-28 22:01:07 --> Total execution time: 0.0481
DEBUG - 2017-12-28 22:23:16 --> Config Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Hooks Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Utf8 Class Initialized
DEBUG - 2017-12-28 22:23:16 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 22:23:16 --> URI Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Router Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Output Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Security Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Input Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 22:23:16 --> Language Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Loader Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Helper loaded: date_helper
DEBUG - 2017-12-28 22:23:16 --> Controller Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Database Driver Class Initialized
ERROR - 2017-12-28 22:23:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 22:23:16 --> Model Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Model Class Initialized
DEBUG - 2017-12-28 22:23:16 --> Helper loaded: url_helper
DEBUG - 2017-12-28 22:23:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 22:23:16 --> Final output sent to browser
DEBUG - 2017-12-28 22:23:16 --> Total execution time: 0.0439
DEBUG - 2017-12-28 22:24:08 --> Config Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Hooks Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Utf8 Class Initialized
DEBUG - 2017-12-28 22:24:08 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 22:24:08 --> URI Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Router Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Output Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Security Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Input Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 22:24:08 --> Language Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Loader Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Helper loaded: date_helper
DEBUG - 2017-12-28 22:24:08 --> Controller Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Database Driver Class Initialized
ERROR - 2017-12-28 22:24:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 22:24:08 --> Model Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Model Class Initialized
DEBUG - 2017-12-28 22:24:08 --> Helper loaded: url_helper
DEBUG - 2017-12-28 22:24:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 22:24:08 --> Final output sent to browser
DEBUG - 2017-12-28 22:24:08 --> Total execution time: 0.0425
DEBUG - 2017-12-28 22:53:56 --> Config Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Hooks Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Utf8 Class Initialized
DEBUG - 2017-12-28 22:53:56 --> UTF-8 Support Enabled
DEBUG - 2017-12-28 22:53:56 --> URI Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Router Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Output Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Security Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Input Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-28 22:53:56 --> Language Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Loader Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Helper loaded: date_helper
DEBUG - 2017-12-28 22:53:56 --> Controller Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Database Driver Class Initialized
ERROR - 2017-12-28 22:53:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-28 22:53:56 --> Model Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Model Class Initialized
DEBUG - 2017-12-28 22:53:56 --> Helper loaded: url_helper
DEBUG - 2017-12-28 22:53:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-12-28 22:53:56 --> Final output sent to browser
DEBUG - 2017-12-28 22:53:56 --> Total execution time: 0.0424
