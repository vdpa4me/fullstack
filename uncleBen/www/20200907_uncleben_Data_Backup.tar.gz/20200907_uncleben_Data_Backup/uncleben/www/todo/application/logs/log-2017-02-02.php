<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-02-02 12:14:57 --> Config Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Hooks Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Utf8 Class Initialized
DEBUG - 2017-02-02 12:14:57 --> UTF-8 Support Enabled
DEBUG - 2017-02-02 12:14:57 --> URI Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Router Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Output Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Security Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Input Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-02 12:14:57 --> Language Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Loader Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Helper loaded: date_helper
DEBUG - 2017-02-02 12:14:57 --> Controller Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Database Driver Class Initialized
ERROR - 2017-02-02 12:14:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-02 12:14:57 --> Model Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Model Class Initialized
DEBUG - 2017-02-02 12:14:57 --> Helper loaded: url_helper
DEBUG - 2017-02-02 12:14:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-02-02 12:14:57 --> Final output sent to browser
DEBUG - 2017-02-02 12:14:57 --> Total execution time: 0.0534
DEBUG - 2017-02-02 12:28:36 --> Config Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Hooks Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Utf8 Class Initialized
DEBUG - 2017-02-02 12:28:36 --> UTF-8 Support Enabled
DEBUG - 2017-02-02 12:28:36 --> URI Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Router Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Output Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Security Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Input Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-02 12:28:36 --> Language Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Loader Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Helper loaded: date_helper
DEBUG - 2017-02-02 12:28:36 --> Controller Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Database Driver Class Initialized
ERROR - 2017-02-02 12:28:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-02 12:28:36 --> Model Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Model Class Initialized
DEBUG - 2017-02-02 12:28:36 --> Helper loaded: url_helper
DEBUG - 2017-02-02 12:28:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-02-02 12:28:36 --> Final output sent to browser
DEBUG - 2017-02-02 12:28:36 --> Total execution time: 0.0335
DEBUG - 2017-02-02 21:49:58 --> Config Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Hooks Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Utf8 Class Initialized
DEBUG - 2017-02-02 21:49:58 --> UTF-8 Support Enabled
DEBUG - 2017-02-02 21:49:58 --> URI Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Router Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Output Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Security Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Input Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-02-02 21:49:58 --> Language Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Loader Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Helper loaded: date_helper
DEBUG - 2017-02-02 21:49:58 --> Controller Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Database Driver Class Initialized
ERROR - 2017-02-02 21:49:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-02-02 21:49:58 --> Model Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Model Class Initialized
DEBUG - 2017-02-02 21:49:58 --> Helper loaded: url_helper
DEBUG - 2017-02-02 21:49:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-02-02 21:49:58 --> Final output sent to browser
DEBUG - 2017-02-02 21:49:58 --> Total execution time: 0.0238
