<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-04-30 06:53:43 --> Config Class Initialized
DEBUG - 2020-04-30 06:53:43 --> Hooks Class Initialized
DEBUG - 2020-04-30 06:53:43 --> Utf8 Class Initialized
DEBUG - 2020-04-30 06:53:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 06:53:43 --> URI Class Initialized
DEBUG - 2020-04-30 06:53:43 --> Router Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Output Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Security Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Input Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 06:53:44 --> Language Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Loader Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Helper loaded: date_helper
DEBUG - 2020-04-30 06:53:44 --> Controller Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Database Driver Class Initialized
ERROR - 2020-04-30 06:53:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 06:53:44 --> Model Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Model Class Initialized
DEBUG - 2020-04-30 06:53:44 --> Helper loaded: url_helper
DEBUG - 2020-04-30 06:53:44 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 06:53:44 --> Final output sent to browser
DEBUG - 2020-04-30 06:53:44 --> Total execution time: 0.1513
DEBUG - 2020-04-30 09:40:17 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:17 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:17 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:17 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:17 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:17 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 09:40:17 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:17 --> Total execution time: 0.0958
DEBUG - 2020-04-30 09:40:21 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:21 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:21 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:21 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:21 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:21 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:21 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 09:40:21 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:21 --> Total execution time: 0.1090
DEBUG - 2020-04-30 09:40:32 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:32 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:32 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:32 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:32 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:32 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:32 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:32 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:33 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:33 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:33 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:33 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:33 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:33 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:33 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:33 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 09:40:33 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:33 --> Total execution time: 0.0841
DEBUG - 2020-04-30 09:40:35 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:35 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:35 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:35 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:35 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:35 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:35 --> File loaded: application/views/todo/search_v.php
DEBUG - 2020-04-30 09:40:35 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:35 --> Total execution time: 0.1072
DEBUG - 2020-04-30 09:40:36 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:36 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:36 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:36 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:36 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:36 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:36 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2020-04-30 09:40:36 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:36 --> Total execution time: 0.0788
DEBUG - 2020-04-30 09:40:37 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:37 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:37 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:37 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:37 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:37 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 09:40:37 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:37 --> Total execution time: 0.0759
DEBUG - 2020-04-30 09:40:38 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:38 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:38 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:38 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:38 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:38 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:38 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2020-04-30 09:40:38 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:38 --> Total execution time: 0.1127
DEBUG - 2020-04-30 09:40:39 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:39 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:39 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:39 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:39 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:39 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:39 --> File loaded: application/views/todo/search_v.php
DEBUG - 2020-04-30 09:40:39 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:39 --> Total execution time: 0.0936
DEBUG - 2020-04-30 09:40:40 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:40 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:40 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:40 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:40 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:40 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:40 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2020-04-30 09:40:40 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:40 --> Total execution time: 0.0735
DEBUG - 2020-04-30 09:40:41 --> Config Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Hooks Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Utf8 Class Initialized
DEBUG - 2020-04-30 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 09:40:41 --> URI Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Router Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Output Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Security Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Input Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 09:40:41 --> Language Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Loader Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Helper loaded: date_helper
DEBUG - 2020-04-30 09:40:41 --> Controller Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Database Driver Class Initialized
ERROR - 2020-04-30 09:40:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 09:40:41 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Model Class Initialized
DEBUG - 2020-04-30 09:40:41 --> Helper loaded: url_helper
DEBUG - 2020-04-30 09:40:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 09:40:41 --> Final output sent to browser
DEBUG - 2020-04-30 09:40:41 --> Total execution time: 0.0950
DEBUG - 2020-04-30 10:06:19 --> Config Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Hooks Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Utf8 Class Initialized
DEBUG - 2020-04-30 10:06:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 10:06:19 --> URI Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Router Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Output Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Security Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Input Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 10:06:19 --> Language Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Loader Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Helper loaded: date_helper
DEBUG - 2020-04-30 10:06:19 --> Controller Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Database Driver Class Initialized
ERROR - 2020-04-30 10:06:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 10:06:19 --> Model Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Model Class Initialized
DEBUG - 2020-04-30 10:06:19 --> Helper loaded: url_helper
DEBUG - 2020-04-30 10:06:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2020-04-30 10:06:19 --> Final output sent to browser
DEBUG - 2020-04-30 10:06:19 --> Total execution time: 0.1400
DEBUG - 2020-04-30 16:06:07 --> Config Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Hooks Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Utf8 Class Initialized
DEBUG - 2020-04-30 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 16:06:07 --> URI Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Router Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Output Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Security Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Input Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 16:06:07 --> Language Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Loader Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Helper loaded: date_helper
DEBUG - 2020-04-30 16:06:07 --> Controller Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Database Driver Class Initialized
ERROR - 2020-04-30 16:06:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 16:06:07 --> Model Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Model Class Initialized
DEBUG - 2020-04-30 16:06:07 --> Helper loaded: url_helper
DEBUG - 2020-04-30 16:06:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 16:06:07 --> Final output sent to browser
DEBUG - 2020-04-30 16:06:07 --> Total execution time: 0.1016
DEBUG - 2020-04-30 23:37:39 --> Config Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Hooks Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Utf8 Class Initialized
DEBUG - 2020-04-30 23:37:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-30 23:37:39 --> URI Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Router Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Output Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Security Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Input Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2020-04-30 23:37:39 --> Language Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Loader Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Helper loaded: date_helper
DEBUG - 2020-04-30 23:37:39 --> Controller Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Database Driver Class Initialized
ERROR - 2020-04-30 23:37:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-04-30 23:37:39 --> Model Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Model Class Initialized
DEBUG - 2020-04-30 23:37:39 --> Helper loaded: url_helper
DEBUG - 2020-04-30 23:37:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-04-30 23:37:39 --> Final output sent to browser
DEBUG - 2020-04-30 23:37:39 --> Total execution time: 0.1723
