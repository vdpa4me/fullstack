<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-01-22 01:39:38 --> Config Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Hooks Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Utf8 Class Initialized
DEBUG - 2019-01-22 01:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 01:39:38 --> URI Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Router Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Output Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Security Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Input Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 01:39:38 --> Language Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Loader Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Helper loaded: date_helper
DEBUG - 2019-01-22 01:39:38 --> Controller Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Database Driver Class Initialized
ERROR - 2019-01-22 01:39:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 01:39:38 --> Model Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Model Class Initialized
DEBUG - 2019-01-22 01:39:38 --> Helper loaded: url_helper
DEBUG - 2019-01-22 01:39:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 01:39:38 --> Final output sent to browser
DEBUG - 2019-01-22 01:39:38 --> Total execution time: 0.0487
DEBUG - 2019-01-22 01:56:52 --> Config Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Hooks Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Utf8 Class Initialized
DEBUG - 2019-01-22 01:56:52 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 01:56:52 --> URI Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Router Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Output Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Security Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Input Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 01:56:52 --> Language Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Loader Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Helper loaded: date_helper
DEBUG - 2019-01-22 01:56:52 --> Controller Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Database Driver Class Initialized
ERROR - 2019-01-22 01:56:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 01:56:52 --> Model Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Model Class Initialized
DEBUG - 2019-01-22 01:56:52 --> Helper loaded: url_helper
DEBUG - 2019-01-22 01:56:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 01:56:52 --> Final output sent to browser
DEBUG - 2019-01-22 01:56:52 --> Total execution time: 0.0288
DEBUG - 2019-01-22 05:48:57 --> Config Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Hooks Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Utf8 Class Initialized
DEBUG - 2019-01-22 05:48:57 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 05:48:57 --> URI Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Router Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Output Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Security Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Input Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 05:48:57 --> Language Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Loader Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Helper loaded: date_helper
DEBUG - 2019-01-22 05:48:57 --> Controller Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Database Driver Class Initialized
ERROR - 2019-01-22 05:48:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 05:48:57 --> Model Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Model Class Initialized
DEBUG - 2019-01-22 05:48:57 --> Helper loaded: url_helper
DEBUG - 2019-01-22 05:48:57 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 05:48:57 --> Final output sent to browser
DEBUG - 2019-01-22 05:48:57 --> Total execution time: 0.0392
DEBUG - 2019-01-22 13:16:40 --> Config Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Hooks Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Utf8 Class Initialized
DEBUG - 2019-01-22 13:16:40 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 13:16:40 --> URI Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Router Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Output Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Security Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Input Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 13:16:40 --> Language Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Loader Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Helper loaded: date_helper
DEBUG - 2019-01-22 13:16:40 --> Controller Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Database Driver Class Initialized
ERROR - 2019-01-22 13:16:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 13:16:40 --> Model Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Model Class Initialized
DEBUG - 2019-01-22 13:16:40 --> Helper loaded: url_helper
DEBUG - 2019-01-22 13:16:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 13:16:40 --> Final output sent to browser
DEBUG - 2019-01-22 13:16:40 --> Total execution time: 0.0328
DEBUG - 2019-01-22 13:55:42 --> Config Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Hooks Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Utf8 Class Initialized
DEBUG - 2019-01-22 13:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 13:55:42 --> URI Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Router Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Output Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Security Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Input Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 13:55:42 --> Language Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Loader Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Helper loaded: date_helper
DEBUG - 2019-01-22 13:55:42 --> Controller Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Database Driver Class Initialized
ERROR - 2019-01-22 13:55:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 13:55:42 --> Model Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Model Class Initialized
DEBUG - 2019-01-22 13:55:42 --> Helper loaded: url_helper
DEBUG - 2019-01-22 13:55:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 13:55:42 --> Final output sent to browser
DEBUG - 2019-01-22 13:55:42 --> Total execution time: 0.0224
DEBUG - 2019-01-22 16:42:43 --> Config Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Hooks Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Utf8 Class Initialized
DEBUG - 2019-01-22 16:42:43 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 16:42:43 --> URI Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Router Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Output Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Security Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Input Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 16:42:43 --> Language Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Loader Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Helper loaded: date_helper
DEBUG - 2019-01-22 16:42:43 --> Controller Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Database Driver Class Initialized
ERROR - 2019-01-22 16:42:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 16:42:43 --> Model Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Model Class Initialized
DEBUG - 2019-01-22 16:42:43 --> Helper loaded: url_helper
DEBUG - 2019-01-22 16:42:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 16:42:43 --> Final output sent to browser
DEBUG - 2019-01-22 16:42:43 --> Total execution time: 0.0340
DEBUG - 2019-01-22 16:42:50 --> Config Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Hooks Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Utf8 Class Initialized
DEBUG - 2019-01-22 16:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 16:42:50 --> URI Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Router Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Output Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Security Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Input Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 16:42:50 --> Language Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Loader Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Helper loaded: date_helper
DEBUG - 2019-01-22 16:42:50 --> Controller Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Database Driver Class Initialized
ERROR - 2019-01-22 16:42:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 16:42:50 --> Model Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Model Class Initialized
DEBUG - 2019-01-22 16:42:50 --> Helper loaded: url_helper
DEBUG - 2019-01-22 16:42:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 16:42:50 --> Final output sent to browser
DEBUG - 2019-01-22 16:42:50 --> Total execution time: 0.0335
DEBUG - 2019-01-22 16:43:50 --> Config Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Hooks Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Utf8 Class Initialized
DEBUG - 2019-01-22 16:43:50 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 16:43:50 --> URI Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Router Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Output Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Security Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Input Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 16:43:50 --> Language Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Loader Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Helper loaded: date_helper
DEBUG - 2019-01-22 16:43:50 --> Controller Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Database Driver Class Initialized
ERROR - 2019-01-22 16:43:50 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 16:43:50 --> Model Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Model Class Initialized
DEBUG - 2019-01-22 16:43:50 --> Helper loaded: url_helper
DEBUG - 2019-01-22 16:43:50 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 16:43:50 --> Final output sent to browser
DEBUG - 2019-01-22 16:43:50 --> Total execution time: 0.0346
DEBUG - 2019-01-22 17:22:29 --> Config Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Hooks Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Utf8 Class Initialized
DEBUG - 2019-01-22 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2019-01-22 17:22:29 --> URI Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Router Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Output Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Security Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Input Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-22 17:22:29 --> Language Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Loader Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Helper loaded: date_helper
DEBUG - 2019-01-22 17:22:29 --> Controller Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Database Driver Class Initialized
ERROR - 2019-01-22 17:22:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-22 17:22:29 --> Model Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Model Class Initialized
DEBUG - 2019-01-22 17:22:29 --> Helper loaded: url_helper
DEBUG - 2019-01-22 17:22:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-22 17:22:29 --> Final output sent to browser
DEBUG - 2019-01-22 17:22:29 --> Total execution time: 0.0205
