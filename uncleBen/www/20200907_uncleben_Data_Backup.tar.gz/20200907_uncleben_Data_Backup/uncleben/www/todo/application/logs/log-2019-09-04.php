<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-09-04 05:54:38 --> Config Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Hooks Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Utf8 Class Initialized
DEBUG - 2019-09-04 05:54:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-04 05:54:38 --> URI Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Router Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Output Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Security Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Input Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-04 05:54:38 --> Language Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Loader Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Helper loaded: date_helper
DEBUG - 2019-09-04 05:54:38 --> Controller Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Database Driver Class Initialized
ERROR - 2019-09-04 05:54:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-04 05:54:38 --> Model Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Model Class Initialized
DEBUG - 2019-09-04 05:54:38 --> Helper loaded: url_helper
DEBUG - 2019-09-04 05:54:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-04 05:54:38 --> Final output sent to browser
DEBUG - 2019-09-04 05:54:38 --> Total execution time: 0.0487
DEBUG - 2019-09-04 11:51:02 --> Config Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Hooks Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Utf8 Class Initialized
DEBUG - 2019-09-04 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-04 11:51:02 --> URI Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Router Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Output Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Security Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Input Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-09-04 11:51:02 --> Language Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Loader Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Helper loaded: date_helper
DEBUG - 2019-09-04 11:51:02 --> Controller Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Database Driver Class Initialized
ERROR - 2019-09-04 11:51:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-09-04 11:51:02 --> Model Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Model Class Initialized
DEBUG - 2019-09-04 11:51:02 --> Helper loaded: url_helper
DEBUG - 2019-09-04 11:51:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-09-04 11:51:02 --> Final output sent to browser
DEBUG - 2019-09-04 11:51:02 --> Total execution time: 0.0433
