<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-05-17 02:08:48 --> Config Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Utf8 Class Initialized
DEBUG - 2018-05-17 02:08:48 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 02:08:48 --> URI Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Router Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Output Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Security Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Input Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 02:08:48 --> Language Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Loader Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Helper loaded: date_helper
DEBUG - 2018-05-17 02:08:48 --> Controller Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Database Driver Class Initialized
ERROR - 2018-05-17 02:08:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 02:08:48 --> Model Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Model Class Initialized
DEBUG - 2018-05-17 02:08:48 --> Helper loaded: url_helper
DEBUG - 2018-05-17 02:08:48 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 02:08:48 --> Final output sent to browser
DEBUG - 2018-05-17 02:08:48 --> Total execution time: 0.0406
DEBUG - 2018-05-17 02:48:53 --> Config Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Hooks Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Utf8 Class Initialized
DEBUG - 2018-05-17 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 02:48:53 --> URI Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Router Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Output Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Security Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Input Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 02:48:53 --> Language Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Loader Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Helper loaded: date_helper
DEBUG - 2018-05-17 02:48:53 --> Controller Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Database Driver Class Initialized
ERROR - 2018-05-17 02:48:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 02:48:53 --> Model Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Model Class Initialized
DEBUG - 2018-05-17 02:48:53 --> Helper loaded: url_helper
DEBUG - 2018-05-17 02:48:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 02:48:53 --> Final output sent to browser
DEBUG - 2018-05-17 02:48:53 --> Total execution time: 0.0261
DEBUG - 2018-05-17 04:12:54 --> Config Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Hooks Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Utf8 Class Initialized
DEBUG - 2018-05-17 04:12:54 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 04:12:54 --> URI Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Router Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Output Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Security Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Input Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 04:12:54 --> Language Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Loader Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Helper loaded: date_helper
DEBUG - 2018-05-17 04:12:54 --> Controller Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Database Driver Class Initialized
ERROR - 2018-05-17 04:12:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 04:12:54 --> Model Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Model Class Initialized
DEBUG - 2018-05-17 04:12:54 --> Helper loaded: url_helper
DEBUG - 2018-05-17 04:12:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 04:12:54 --> Final output sent to browser
DEBUG - 2018-05-17 04:12:54 --> Total execution time: 0.0201
DEBUG - 2018-05-17 06:51:16 --> Config Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Hooks Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Utf8 Class Initialized
DEBUG - 2018-05-17 06:51:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 06:51:16 --> URI Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Router Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Output Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Security Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Input Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 06:51:16 --> Language Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Loader Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Helper loaded: date_helper
DEBUG - 2018-05-17 06:51:16 --> Controller Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Database Driver Class Initialized
ERROR - 2018-05-17 06:51:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 06:51:16 --> Model Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Model Class Initialized
DEBUG - 2018-05-17 06:51:16 --> Helper loaded: url_helper
DEBUG - 2018-05-17 06:51:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 06:51:16 --> Final output sent to browser
DEBUG - 2018-05-17 06:51:16 --> Total execution time: 0.0324
DEBUG - 2018-05-17 07:37:59 --> Config Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Hooks Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Utf8 Class Initialized
DEBUG - 2018-05-17 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 07:37:59 --> URI Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Router Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Output Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Security Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Input Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 07:37:59 --> Language Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Loader Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Helper loaded: date_helper
DEBUG - 2018-05-17 07:37:59 --> Controller Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Database Driver Class Initialized
ERROR - 2018-05-17 07:37:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 07:37:59 --> Model Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Model Class Initialized
DEBUG - 2018-05-17 07:37:59 --> Helper loaded: url_helper
DEBUG - 2018-05-17 07:37:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 07:37:59 --> Final output sent to browser
DEBUG - 2018-05-17 07:37:59 --> Total execution time: 0.0211
DEBUG - 2018-05-17 11:56:42 --> Config Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Hooks Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Utf8 Class Initialized
DEBUG - 2018-05-17 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 11:56:42 --> URI Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Router Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Output Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Security Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Input Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 11:56:42 --> Language Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Loader Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Helper loaded: date_helper
DEBUG - 2018-05-17 11:56:42 --> Controller Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Database Driver Class Initialized
ERROR - 2018-05-17 11:56:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 11:56:42 --> Model Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Model Class Initialized
DEBUG - 2018-05-17 11:56:42 --> Helper loaded: url_helper
DEBUG - 2018-05-17 11:56:42 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 11:56:42 --> Final output sent to browser
DEBUG - 2018-05-17 11:56:42 --> Total execution time: 0.0225
DEBUG - 2018-05-17 14:43:36 --> Config Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Hooks Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Utf8 Class Initialized
DEBUG - 2018-05-17 14:43:36 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 14:43:36 --> URI Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Router Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Output Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Security Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Input Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 14:43:36 --> Language Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Loader Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Helper loaded: date_helper
DEBUG - 2018-05-17 14:43:36 --> Controller Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Database Driver Class Initialized
ERROR - 2018-05-17 14:43:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 14:43:36 --> Model Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Model Class Initialized
DEBUG - 2018-05-17 14:43:36 --> Helper loaded: url_helper
DEBUG - 2018-05-17 14:43:36 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 14:43:36 --> Final output sent to browser
DEBUG - 2018-05-17 14:43:36 --> Total execution time: 0.0210
DEBUG - 2018-05-17 15:16:52 --> Config Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Hooks Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Utf8 Class Initialized
DEBUG - 2018-05-17 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 15:16:52 --> URI Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Router Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Output Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Security Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Input Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 15:16:52 --> Language Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Loader Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Helper loaded: date_helper
DEBUG - 2018-05-17 15:16:52 --> Controller Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Database Driver Class Initialized
ERROR - 2018-05-17 15:16:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 15:16:52 --> Model Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Model Class Initialized
DEBUG - 2018-05-17 15:16:52 --> Helper loaded: url_helper
DEBUG - 2018-05-17 15:16:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 15:16:52 --> Final output sent to browser
DEBUG - 2018-05-17 15:16:52 --> Total execution time: 0.0215
DEBUG - 2018-05-17 15:34:01 --> Config Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Hooks Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Utf8 Class Initialized
DEBUG - 2018-05-17 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 15:34:01 --> URI Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Router Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Output Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Security Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Input Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 15:34:01 --> Language Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Loader Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Helper loaded: date_helper
DEBUG - 2018-05-17 15:34:01 --> Controller Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Database Driver Class Initialized
ERROR - 2018-05-17 15:34:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 15:34:01 --> Model Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Model Class Initialized
DEBUG - 2018-05-17 15:34:01 --> Helper loaded: url_helper
DEBUG - 2018-05-17 15:34:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 15:34:01 --> Final output sent to browser
DEBUG - 2018-05-17 15:34:01 --> Total execution time: 0.0208
DEBUG - 2018-05-17 21:41:33 --> Config Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Hooks Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Utf8 Class Initialized
DEBUG - 2018-05-17 21:41:33 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 21:41:33 --> URI Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Router Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Output Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Security Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Input Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 21:41:33 --> Language Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Loader Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Helper loaded: date_helper
DEBUG - 2018-05-17 21:41:33 --> Controller Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Database Driver Class Initialized
ERROR - 2018-05-17 21:41:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 21:41:33 --> Model Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Model Class Initialized
DEBUG - 2018-05-17 21:41:33 --> Helper loaded: url_helper
DEBUG - 2018-05-17 21:41:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 21:41:33 --> Final output sent to browser
DEBUG - 2018-05-17 21:41:33 --> Total execution time: 0.0366
DEBUG - 2018-05-17 22:50:40 --> Config Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Hooks Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Utf8 Class Initialized
DEBUG - 2018-05-17 22:50:40 --> UTF-8 Support Enabled
DEBUG - 2018-05-17 22:50:40 --> URI Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Router Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Output Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Security Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Input Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-17 22:50:40 --> Language Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Loader Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Helper loaded: date_helper
DEBUG - 2018-05-17 22:50:40 --> Controller Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Database Driver Class Initialized
ERROR - 2018-05-17 22:50:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-17 22:50:40 --> Model Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Model Class Initialized
DEBUG - 2018-05-17 22:50:40 --> Helper loaded: url_helper
DEBUG - 2018-05-17 22:50:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-17 22:50:40 --> Final output sent to browser
DEBUG - 2018-05-17 22:50:40 --> Total execution time: 0.0213
