<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-08-30 06:29:12 --> Config Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Hooks Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Utf8 Class Initialized
DEBUG - 2017-08-30 06:29:12 --> UTF-8 Support Enabled
DEBUG - 2017-08-30 06:29:12 --> URI Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Router Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Output Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Security Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Input Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-30 06:29:12 --> Language Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Loader Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Helper loaded: date_helper
DEBUG - 2017-08-30 06:29:12 --> Controller Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Database Driver Class Initialized
ERROR - 2017-08-30 06:29:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-30 06:29:12 --> Model Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Model Class Initialized
DEBUG - 2017-08-30 06:29:12 --> Helper loaded: url_helper
DEBUG - 2017-08-30 06:29:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-08-30 06:29:12 --> Final output sent to browser
DEBUG - 2017-08-30 06:29:12 --> Total execution time: 0.0310
DEBUG - 2017-08-30 11:12:32 --> Config Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Hooks Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Utf8 Class Initialized
DEBUG - 2017-08-30 11:12:32 --> UTF-8 Support Enabled
DEBUG - 2017-08-30 11:12:32 --> URI Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Router Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Output Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Security Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Input Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-30 11:12:32 --> Language Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Loader Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Helper loaded: date_helper
DEBUG - 2017-08-30 11:12:32 --> Controller Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Database Driver Class Initialized
ERROR - 2017-08-30 11:12:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-30 11:12:32 --> Model Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Model Class Initialized
DEBUG - 2017-08-30 11:12:32 --> Helper loaded: url_helper
DEBUG - 2017-08-30 11:12:32 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-30 11:12:32 --> Final output sent to browser
DEBUG - 2017-08-30 11:12:32 --> Total execution time: 0.0493
DEBUG - 2017-08-30 11:12:40 --> Config Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Hooks Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Utf8 Class Initialized
DEBUG - 2017-08-30 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2017-08-30 11:12:40 --> URI Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Router Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Output Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Security Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Input Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-30 11:12:40 --> Language Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Loader Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Helper loaded: date_helper
DEBUG - 2017-08-30 11:12:40 --> Controller Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Database Driver Class Initialized
ERROR - 2017-08-30 11:12:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-30 11:12:40 --> Model Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Model Class Initialized
DEBUG - 2017-08-30 11:12:40 --> Helper loaded: url_helper
DEBUG - 2017-08-30 11:12:40 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-30 11:12:40 --> Final output sent to browser
DEBUG - 2017-08-30 11:12:40 --> Total execution time: 0.0410
DEBUG - 2017-08-30 11:17:53 --> Config Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Hooks Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Utf8 Class Initialized
DEBUG - 2017-08-30 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2017-08-30 11:17:53 --> URI Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Router Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Output Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Security Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Input Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2017-08-30 11:17:53 --> Language Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Loader Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Helper loaded: date_helper
DEBUG - 2017-08-30 11:17:53 --> Controller Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Database Driver Class Initialized
ERROR - 2017-08-30 11:17:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-08-30 11:17:53 --> Model Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Model Class Initialized
DEBUG - 2017-08-30 11:17:53 --> Helper loaded: url_helper
DEBUG - 2017-08-30 11:17:53 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-08-30 11:17:53 --> Final output sent to browser
DEBUG - 2017-08-30 11:17:53 --> Total execution time: 0.0391
