<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-07-30 03:21:01 --> Config Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Hooks Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Utf8 Class Initialized
DEBUG - 2018-07-30 03:21:01 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 03:21:01 --> URI Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Router Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Output Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Security Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Input Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 03:21:01 --> Language Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Loader Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Helper loaded: date_helper
DEBUG - 2018-07-30 03:21:01 --> Controller Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Database Driver Class Initialized
ERROR - 2018-07-30 03:21:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 03:21:01 --> Model Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Model Class Initialized
DEBUG - 2018-07-30 03:21:01 --> Helper loaded: url_helper
DEBUG - 2018-07-30 03:21:01 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-30 03:21:01 --> Final output sent to browser
DEBUG - 2018-07-30 03:21:01 --> Total execution time: 0.0238
DEBUG - 2018-07-30 03:49:45 --> Config Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Hooks Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Utf8 Class Initialized
DEBUG - 2018-07-30 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 03:49:45 --> URI Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Router Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Output Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Security Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Input Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 03:49:45 --> Language Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Loader Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Helper loaded: date_helper
DEBUG - 2018-07-30 03:49:45 --> Controller Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Database Driver Class Initialized
ERROR - 2018-07-30 03:49:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 03:49:45 --> Model Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Model Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Helper loaded: url_helper
DEBUG - 2018-07-30 03:49:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-30 03:49:45 --> Final output sent to browser
DEBUG - 2018-07-30 03:49:45 --> Total execution time: 0.0223
DEBUG - 2018-07-30 03:49:45 --> Config Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Hooks Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Utf8 Class Initialized
DEBUG - 2018-07-30 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 03:49:45 --> URI Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Router Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Output Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Security Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Input Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 03:49:45 --> Language Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Loader Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Helper loaded: date_helper
DEBUG - 2018-07-30 03:49:45 --> Controller Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Database Driver Class Initialized
ERROR - 2018-07-30 03:49:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 03:49:45 --> Model Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Model Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Helper loaded: url_helper
DEBUG - 2018-07-30 03:49:45 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2018-07-30 03:49:45 --> Final output sent to browser
DEBUG - 2018-07-30 03:49:45 --> Total execution time: 0.0237
DEBUG - 2018-07-30 03:49:45 --> Config Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Hooks Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Utf8 Class Initialized
DEBUG - 2018-07-30 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 03:49:45 --> URI Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Router Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Output Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Security Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Input Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 03:49:45 --> Language Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Loader Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Helper loaded: date_helper
DEBUG - 2018-07-30 03:49:45 --> Controller Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Database Driver Class Initialized
ERROR - 2018-07-30 03:49:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 03:49:45 --> Model Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Model Class Initialized
DEBUG - 2018-07-30 03:49:45 --> Helper loaded: url_helper
DEBUG - 2018-07-30 03:49:45 --> File loaded: application/views/todo/search_v.php
DEBUG - 2018-07-30 03:49:45 --> Final output sent to browser
DEBUG - 2018-07-30 03:49:45 --> Total execution time: 0.0201
DEBUG - 2018-07-30 14:45:54 --> Config Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Hooks Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Utf8 Class Initialized
DEBUG - 2018-07-30 14:45:54 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 14:45:54 --> URI Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Router Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Output Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Security Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Input Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 14:45:54 --> Language Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Loader Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Helper loaded: date_helper
DEBUG - 2018-07-30 14:45:54 --> Controller Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Database Driver Class Initialized
ERROR - 2018-07-30 14:45:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 14:45:54 --> Model Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Model Class Initialized
DEBUG - 2018-07-30 14:45:54 --> Helper loaded: url_helper
DEBUG - 2018-07-30 14:45:54 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-30 14:45:54 --> Final output sent to browser
DEBUG - 2018-07-30 14:45:54 --> Total execution time: 0.0388
DEBUG - 2018-07-30 18:26:02 --> Config Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Hooks Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Utf8 Class Initialized
DEBUG - 2018-07-30 18:26:02 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 18:26:02 --> URI Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Router Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Output Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Security Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Input Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 18:26:02 --> Language Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Loader Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Helper loaded: date_helper
DEBUG - 2018-07-30 18:26:02 --> Controller Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Database Driver Class Initialized
ERROR - 2018-07-30 18:26:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 18:26:02 --> Model Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Model Class Initialized
DEBUG - 2018-07-30 18:26:02 --> Helper loaded: url_helper
DEBUG - 2018-07-30 18:26:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-30 18:26:03 --> Final output sent to browser
DEBUG - 2018-07-30 18:26:03 --> Total execution time: 0.0210
DEBUG - 2018-07-30 21:14:38 --> Config Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Hooks Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Utf8 Class Initialized
DEBUG - 2018-07-30 21:14:38 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 21:14:38 --> URI Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Router Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Output Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Security Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Input Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 21:14:38 --> Language Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Loader Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Helper loaded: date_helper
DEBUG - 2018-07-30 21:14:38 --> Controller Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Database Driver Class Initialized
ERROR - 2018-07-30 21:14:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 21:14:38 --> Model Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Model Class Initialized
DEBUG - 2018-07-30 21:14:38 --> Helper loaded: url_helper
DEBUG - 2018-07-30 21:14:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-30 21:14:38 --> Final output sent to browser
DEBUG - 2018-07-30 21:14:38 --> Total execution time: 0.0205
DEBUG - 2018-07-30 22:05:52 --> Config Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Hooks Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Utf8 Class Initialized
DEBUG - 2018-07-30 22:05:52 --> UTF-8 Support Enabled
DEBUG - 2018-07-30 22:05:52 --> URI Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Router Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Output Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Security Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Input Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2018-07-30 22:05:52 --> Language Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Loader Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Helper loaded: date_helper
DEBUG - 2018-07-30 22:05:52 --> Controller Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Database Driver Class Initialized
ERROR - 2018-07-30 22:05:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-07-30 22:05:52 --> Model Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Model Class Initialized
DEBUG - 2018-07-30 22:05:52 --> Helper loaded: url_helper
DEBUG - 2018-07-30 22:05:52 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-07-30 22:05:52 --> Final output sent to browser
DEBUG - 2018-07-30 22:05:52 --> Total execution time: 0.0210
