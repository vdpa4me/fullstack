<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-09 02:02:26 --> Config Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Hooks Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Utf8 Class Initialized
DEBUG - 2017-10-09 02:02:26 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 02:02:26 --> URI Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Router Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Output Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Security Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Input Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 02:02:26 --> Language Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Loader Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Helper loaded: date_helper
DEBUG - 2017-10-09 02:02:26 --> Controller Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Database Driver Class Initialized
ERROR - 2017-10-09 02:02:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 02:02:26 --> Model Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Model Class Initialized
DEBUG - 2017-10-09 02:02:26 --> Helper loaded: url_helper
DEBUG - 2017-10-09 02:02:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-09 02:02:26 --> Final output sent to browser
DEBUG - 2017-10-09 02:02:26 --> Total execution time: 0.0508
DEBUG - 2017-10-09 04:02:21 --> Config Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Hooks Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Utf8 Class Initialized
DEBUG - 2017-10-09 04:02:21 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 04:02:21 --> URI Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Router Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Output Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Security Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Input Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 04:02:21 --> Language Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Loader Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Helper loaded: date_helper
DEBUG - 2017-10-09 04:02:21 --> Controller Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Database Driver Class Initialized
ERROR - 2017-10-09 04:02:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 04:02:21 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:21 --> Helper loaded: url_helper
DEBUG - 2017-10-09 04:02:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-09 04:02:21 --> Final output sent to browser
DEBUG - 2017-10-09 04:02:21 --> Total execution time: 0.0461
DEBUG - 2017-10-09 04:02:30 --> Config Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Hooks Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Utf8 Class Initialized
DEBUG - 2017-10-09 04:02:30 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 04:02:30 --> URI Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Router Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Output Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Security Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Input Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 04:02:30 --> Language Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Loader Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Helper loaded: date_helper
DEBUG - 2017-10-09 04:02:30 --> Controller Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Database Driver Class Initialized
ERROR - 2017-10-09 04:02:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 04:02:30 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:30 --> Helper loaded: url_helper
DEBUG - 2017-10-09 04:02:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-09 04:02:30 --> Final output sent to browser
DEBUG - 2017-10-09 04:02:30 --> Total execution time: 0.0411
DEBUG - 2017-10-09 04:02:36 --> Config Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Hooks Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Utf8 Class Initialized
DEBUG - 2017-10-09 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 04:02:36 --> URI Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Router Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Output Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Security Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Input Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 04:02:36 --> Language Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Loader Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Helper loaded: date_helper
DEBUG - 2017-10-09 04:02:36 --> Controller Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Database Driver Class Initialized
ERROR - 2017-10-09 04:02:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 04:02:36 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:36 --> Helper loaded: url_helper
DEBUG - 2017-10-09 04:02:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-09 04:02:36 --> Final output sent to browser
DEBUG - 2017-10-09 04:02:36 --> Total execution time: 0.0393
DEBUG - 2017-10-09 04:02:45 --> Config Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Hooks Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Utf8 Class Initialized
DEBUG - 2017-10-09 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 04:02:45 --> URI Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Router Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Output Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Security Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Input Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 04:02:45 --> Language Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Loader Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Helper loaded: date_helper
DEBUG - 2017-10-09 04:02:45 --> Controller Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Database Driver Class Initialized
ERROR - 2017-10-09 04:02:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 04:02:45 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Model Class Initialized
DEBUG - 2017-10-09 04:02:45 --> Helper loaded: url_helper
DEBUG - 2017-10-09 04:02:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-09 04:02:45 --> Final output sent to browser
DEBUG - 2017-10-09 04:02:45 --> Total execution time: 0.0404
DEBUG - 2017-10-09 11:40:20 --> Config Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Hooks Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Utf8 Class Initialized
DEBUG - 2017-10-09 11:40:20 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 11:40:20 --> URI Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Router Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Output Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Security Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Input Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 11:40:20 --> Language Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Loader Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Helper loaded: date_helper
DEBUG - 2017-10-09 11:40:20 --> Controller Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Database Driver Class Initialized
ERROR - 2017-10-09 11:40:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 11:40:20 --> Model Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Model Class Initialized
DEBUG - 2017-10-09 11:40:20 --> Helper loaded: url_helper
DEBUG - 2017-10-09 11:40:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-09 11:40:20 --> Final output sent to browser
DEBUG - 2017-10-09 11:40:20 --> Total execution time: 0.0328
DEBUG - 2017-10-09 18:58:12 --> Config Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Hooks Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Utf8 Class Initialized
DEBUG - 2017-10-09 18:58:12 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 18:58:12 --> URI Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Router Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Output Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Security Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Input Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 18:58:12 --> Language Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Loader Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Helper loaded: date_helper
DEBUG - 2017-10-09 18:58:12 --> Controller Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Database Driver Class Initialized
ERROR - 2017-10-09 18:58:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 18:58:12 --> Model Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Model Class Initialized
DEBUG - 2017-10-09 18:58:12 --> Helper loaded: url_helper
DEBUG - 2017-10-09 18:58:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-09 18:58:12 --> Final output sent to browser
DEBUG - 2017-10-09 18:58:12 --> Total execution time: 0.0201
DEBUG - 2017-10-09 18:58:13 --> Config Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Hooks Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Utf8 Class Initialized
DEBUG - 2017-10-09 18:58:13 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 18:58:13 --> URI Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Router Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Output Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Security Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Input Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 18:58:13 --> Language Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Loader Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Helper loaded: date_helper
DEBUG - 2017-10-09 18:58:13 --> Controller Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Database Driver Class Initialized
ERROR - 2017-10-09 18:58:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 18:58:13 --> Model Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Model Class Initialized
DEBUG - 2017-10-09 18:58:13 --> Helper loaded: url_helper
DEBUG - 2017-10-09 18:58:13 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-10-09 18:58:13 --> Final output sent to browser
DEBUG - 2017-10-09 18:58:13 --> Total execution time: 0.0243
DEBUG - 2017-10-09 18:58:14 --> Config Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Hooks Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Utf8 Class Initialized
DEBUG - 2017-10-09 18:58:14 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 18:58:14 --> URI Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Router Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Output Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Security Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Input Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 18:58:14 --> Language Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Loader Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Helper loaded: date_helper
DEBUG - 2017-10-09 18:58:14 --> Controller Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Database Driver Class Initialized
ERROR - 2017-10-09 18:58:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 18:58:14 --> Model Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Model Class Initialized
DEBUG - 2017-10-09 18:58:14 --> Helper loaded: url_helper
DEBUG - 2017-10-09 18:58:14 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-10-09 18:58:14 --> Final output sent to browser
DEBUG - 2017-10-09 18:58:14 --> Total execution time: 0.0203
DEBUG - 2017-10-09 22:11:55 --> Config Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Hooks Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Utf8 Class Initialized
DEBUG - 2017-10-09 22:11:55 --> UTF-8 Support Enabled
DEBUG - 2017-10-09 22:11:55 --> URI Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Router Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Output Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Security Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Input Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-09 22:11:55 --> Language Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Loader Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Helper loaded: date_helper
DEBUG - 2017-10-09 22:11:55 --> Controller Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Database Driver Class Initialized
ERROR - 2017-10-09 22:11:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-09 22:11:55 --> Model Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Model Class Initialized
DEBUG - 2017-10-09 22:11:55 --> Helper loaded: url_helper
DEBUG - 2017-10-09 22:11:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-09 22:11:55 --> Final output sent to browser
DEBUG - 2017-10-09 22:11:55 --> Total execution time: 0.0199
