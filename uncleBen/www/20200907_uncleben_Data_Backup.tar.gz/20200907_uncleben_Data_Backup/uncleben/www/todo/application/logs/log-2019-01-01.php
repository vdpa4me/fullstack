<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-01-01 04:03:57 --> Config Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Hooks Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Utf8 Class Initialized
DEBUG - 2019-01-01 04:03:57 --> UTF-8 Support Enabled
DEBUG - 2019-01-01 04:03:57 --> URI Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Router Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Output Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Security Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Input Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-01 04:03:57 --> Language Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Loader Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Helper loaded: date_helper
DEBUG - 2019-01-01 04:03:57 --> Controller Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Database Driver Class Initialized
ERROR - 2019-01-01 04:03:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-01 04:03:57 --> Model Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Model Class Initialized
DEBUG - 2019-01-01 04:03:57 --> Helper loaded: url_helper
DEBUG - 2019-01-01 04:03:57 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-01 04:03:57 --> Final output sent to browser
DEBUG - 2019-01-01 04:03:57 --> Total execution time: 0.0559
DEBUG - 2019-01-01 09:51:40 --> Config Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Hooks Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Utf8 Class Initialized
DEBUG - 2019-01-01 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2019-01-01 09:51:40 --> URI Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Router Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Output Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Security Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Input Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-01 09:51:40 --> Language Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Loader Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Helper loaded: date_helper
DEBUG - 2019-01-01 09:51:40 --> Controller Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Database Driver Class Initialized
ERROR - 2019-01-01 09:51:40 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-01 09:51:40 --> Model Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Model Class Initialized
DEBUG - 2019-01-01 09:51:40 --> Helper loaded: url_helper
DEBUG - 2019-01-01 09:51:40 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-01 09:51:40 --> Final output sent to browser
DEBUG - 2019-01-01 09:51:40 --> Total execution time: 0.0535
DEBUG - 2019-01-01 10:53:12 --> Config Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Hooks Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Utf8 Class Initialized
DEBUG - 2019-01-01 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2019-01-01 10:53:12 --> URI Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Router Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Output Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Security Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Input Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-01 10:53:12 --> Language Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Loader Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Helper loaded: date_helper
DEBUG - 2019-01-01 10:53:12 --> Controller Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Database Driver Class Initialized
ERROR - 2019-01-01 10:53:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-01 10:53:12 --> Model Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Model Class Initialized
DEBUG - 2019-01-01 10:53:12 --> Helper loaded: url_helper
DEBUG - 2019-01-01 10:53:12 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-01 10:53:12 --> Final output sent to browser
DEBUG - 2019-01-01 10:53:12 --> Total execution time: 0.0322
DEBUG - 2019-01-01 17:17:38 --> Config Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Hooks Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Utf8 Class Initialized
DEBUG - 2019-01-01 17:17:38 --> UTF-8 Support Enabled
DEBUG - 2019-01-01 17:17:38 --> URI Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Router Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Output Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Security Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Input Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-01 17:17:38 --> Language Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Loader Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Helper loaded: date_helper
DEBUG - 2019-01-01 17:17:38 --> Controller Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Database Driver Class Initialized
ERROR - 2019-01-01 17:17:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-01 17:17:38 --> Model Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Model Class Initialized
DEBUG - 2019-01-01 17:17:38 --> Helper loaded: url_helper
DEBUG - 2019-01-01 17:17:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-01 17:17:38 --> Final output sent to browser
DEBUG - 2019-01-01 17:17:38 --> Total execution time: 0.0262
DEBUG - 2019-01-01 23:59:39 --> Config Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Hooks Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Utf8 Class Initialized
DEBUG - 2019-01-01 23:59:39 --> UTF-8 Support Enabled
DEBUG - 2019-01-01 23:59:39 --> URI Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Router Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Output Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Security Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Input Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-01-01 23:59:39 --> Language Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Loader Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Helper loaded: date_helper
DEBUG - 2019-01-01 23:59:39 --> Controller Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Database Driver Class Initialized
ERROR - 2019-01-01 23:59:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-01-01 23:59:39 --> Model Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Model Class Initialized
DEBUG - 2019-01-01 23:59:39 --> Helper loaded: url_helper
DEBUG - 2019-01-01 23:59:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-01-01 23:59:39 --> Final output sent to browser
DEBUG - 2019-01-01 23:59:39 --> Total execution time: 0.0646
