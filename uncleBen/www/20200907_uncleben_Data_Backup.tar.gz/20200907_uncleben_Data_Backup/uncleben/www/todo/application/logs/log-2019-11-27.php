<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-11-27 23:47:35 --> Config Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Hooks Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Utf8 Class Initialized
DEBUG - 2019-11-27 23:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 23:47:35 --> URI Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Router Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Output Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Security Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Input Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-11-27 23:47:35 --> Language Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Loader Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Helper loaded: date_helper
DEBUG - 2019-11-27 23:47:35 --> Controller Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Database Driver Class Initialized
ERROR - 2019-11-27 23:47:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-11-27 23:47:35 --> Model Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Model Class Initialized
DEBUG - 2019-11-27 23:47:35 --> Helper loaded: url_helper
DEBUG - 2019-11-27 23:47:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-11-27 23:47:35 --> Final output sent to browser
DEBUG - 2019-11-27 23:47:35 --> Total execution time: 0.2275
