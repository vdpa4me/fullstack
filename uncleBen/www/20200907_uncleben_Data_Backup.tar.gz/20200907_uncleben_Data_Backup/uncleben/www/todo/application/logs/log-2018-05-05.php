<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-05-05 06:32:00 --> Config Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Hooks Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Utf8 Class Initialized
DEBUG - 2018-05-05 06:32:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-05 06:32:00 --> URI Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Router Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Output Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Security Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Input Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-05 06:32:00 --> Language Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Loader Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Helper loaded: date_helper
DEBUG - 2018-05-05 06:32:00 --> Controller Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Database Driver Class Initialized
ERROR - 2018-05-05 06:32:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-05 06:32:00 --> Model Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Model Class Initialized
DEBUG - 2018-05-05 06:32:00 --> Helper loaded: url_helper
DEBUG - 2018-05-05 06:32:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-05 06:32:00 --> Final output sent to browser
DEBUG - 2018-05-05 06:32:00 --> Total execution time: 0.0278
DEBUG - 2018-05-05 13:21:10 --> Config Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Hooks Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Utf8 Class Initialized
DEBUG - 2018-05-05 13:21:10 --> UTF-8 Support Enabled
DEBUG - 2018-05-05 13:21:10 --> URI Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Router Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Output Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Security Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Input Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-05 13:21:10 --> Language Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Loader Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Helper loaded: date_helper
DEBUG - 2018-05-05 13:21:10 --> Controller Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Database Driver Class Initialized
ERROR - 2018-05-05 13:21:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-05 13:21:10 --> Model Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Model Class Initialized
DEBUG - 2018-05-05 13:21:10 --> Helper loaded: url_helper
DEBUG - 2018-05-05 13:21:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-05 13:21:10 --> Final output sent to browser
DEBUG - 2018-05-05 13:21:10 --> Total execution time: 0.0253
DEBUG - 2018-05-05 13:33:58 --> Config Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Hooks Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Utf8 Class Initialized
DEBUG - 2018-05-05 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2018-05-05 13:33:58 --> URI Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Router Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Output Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Security Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Input Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-05 13:33:58 --> Language Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Loader Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Helper loaded: date_helper
DEBUG - 2018-05-05 13:33:58 --> Controller Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Database Driver Class Initialized
ERROR - 2018-05-05 13:33:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-05 13:33:58 --> Model Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Model Class Initialized
DEBUG - 2018-05-05 13:33:58 --> Helper loaded: url_helper
DEBUG - 2018-05-05 13:33:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-05 13:33:58 --> Final output sent to browser
DEBUG - 2018-05-05 13:33:58 --> Total execution time: 0.0214
DEBUG - 2018-05-05 18:03:13 --> Config Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Hooks Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Utf8 Class Initialized
DEBUG - 2018-05-05 18:03:13 --> UTF-8 Support Enabled
DEBUG - 2018-05-05 18:03:13 --> URI Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Router Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Output Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Security Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Input Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-05 18:03:13 --> Language Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Loader Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Helper loaded: date_helper
DEBUG - 2018-05-05 18:03:13 --> Controller Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Database Driver Class Initialized
ERROR - 2018-05-05 18:03:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-05 18:03:13 --> Model Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Model Class Initialized
DEBUG - 2018-05-05 18:03:13 --> Helper loaded: url_helper
DEBUG - 2018-05-05 18:03:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-05 18:03:13 --> Final output sent to browser
DEBUG - 2018-05-05 18:03:13 --> Total execution time: 0.0207
DEBUG - 2018-05-05 20:21:31 --> Config Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Hooks Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Utf8 Class Initialized
DEBUG - 2018-05-05 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2018-05-05 20:21:31 --> URI Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Router Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Output Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Security Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Input Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-05 20:21:31 --> Language Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Loader Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Helper loaded: date_helper
DEBUG - 2018-05-05 20:21:31 --> Controller Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Database Driver Class Initialized
ERROR - 2018-05-05 20:21:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-05 20:21:31 --> Model Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Model Class Initialized
DEBUG - 2018-05-05 20:21:31 --> Helper loaded: url_helper
DEBUG - 2018-05-05 20:21:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-05 20:21:31 --> Final output sent to browser
DEBUG - 2018-05-05 20:21:31 --> Total execution time: 0.0214
