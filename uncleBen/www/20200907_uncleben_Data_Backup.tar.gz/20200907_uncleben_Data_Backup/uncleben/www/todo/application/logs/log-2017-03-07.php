<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-03-07 21:40:32 --> Config Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Utf8 Class Initialized
DEBUG - 2017-03-07 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:40:32 --> URI Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Router Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Output Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Security Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Input Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 21:40:32 --> Language Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Loader Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:40:32 --> Controller Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Database Driver Class Initialized
ERROR - 2017-03-07 21:40:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 21:40:32 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:32 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:40:32 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-07 21:40:32 --> Final output sent to browser
DEBUG - 2017-03-07 21:40:32 --> Total execution time: 0.0321
DEBUG - 2017-03-07 21:40:34 --> Config Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Utf8 Class Initialized
DEBUG - 2017-03-07 21:40:34 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:40:34 --> URI Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Router Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Output Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Security Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Input Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 21:40:34 --> Language Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Loader Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:40:34 --> Controller Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Database Driver Class Initialized
ERROR - 2017-03-07 21:40:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 21:40:34 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:34 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:40:34 --> File loaded: application/views/todo/rank_v.php
DEBUG - 2017-03-07 21:40:34 --> Final output sent to browser
DEBUG - 2017-03-07 21:40:34 --> Total execution time: 0.0233
DEBUG - 2017-03-07 21:40:37 --> Config Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Utf8 Class Initialized
DEBUG - 2017-03-07 21:40:37 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:40:37 --> URI Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Router Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Output Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Security Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Input Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 21:40:37 --> Language Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Loader Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:40:37 --> Controller Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Database Driver Class Initialized
ERROR - 2017-03-07 21:40:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 21:40:37 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:37 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:40:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-07 21:40:37 --> Final output sent to browser
DEBUG - 2017-03-07 21:40:37 --> Total execution time: 0.0204
DEBUG - 2017-03-07 21:40:41 --> Config Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Utf8 Class Initialized
DEBUG - 2017-03-07 21:40:41 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:40:41 --> URI Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Router Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Output Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Security Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Input Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 21:40:41 --> Language Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Loader Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:40:41 --> Controller Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Database Driver Class Initialized
ERROR - 2017-03-07 21:40:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 21:40:41 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Model Class Initialized
DEBUG - 2017-03-07 21:40:41 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:40:41 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-07 21:40:41 --> Final output sent to browser
DEBUG - 2017-03-07 21:40:41 --> Total execution time: 0.0202
DEBUG - 2017-03-07 21:47:38 --> Config Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Utf8 Class Initialized
DEBUG - 2017-03-07 21:47:38 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:47:38 --> URI Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Router Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Output Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Security Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Input Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 21:47:38 --> Language Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Loader Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:47:38 --> Controller Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Database Driver Class Initialized
ERROR - 2017-03-07 21:47:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 21:47:38 --> Model Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Model Class Initialized
DEBUG - 2017-03-07 21:47:38 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:47:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-07 21:47:38 --> Final output sent to browser
DEBUG - 2017-03-07 21:47:38 --> Total execution time: 0.0195
DEBUG - 2017-03-07 21:47:44 --> Config Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Utf8 Class Initialized
DEBUG - 2017-03-07 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:47:44 --> URI Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Router Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Output Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Security Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Input Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 21:47:44 --> Language Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Loader Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:47:44 --> Controller Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Database Driver Class Initialized
ERROR - 2017-03-07 21:47:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 21:47:44 --> Model Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Model Class Initialized
DEBUG - 2017-03-07 21:47:44 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:47:44 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-03-07 21:47:44 --> Final output sent to browser
DEBUG - 2017-03-07 21:47:44 --> Total execution time: 0.0203
DEBUG - 2017-03-07 21:49:35 --> Config Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Hooks Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Utf8 Class Initialized
DEBUG - 2017-03-07 21:49:35 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 21:49:35 --> URI Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Router Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Output Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Security Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Input Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 21:49:35 --> Language Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Loader Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Helper loaded: date_helper
DEBUG - 2017-03-07 21:49:35 --> Controller Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Database Driver Class Initialized
ERROR - 2017-03-07 21:49:35 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 21:49:35 --> Model Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Model Class Initialized
DEBUG - 2017-03-07 21:49:35 --> Helper loaded: url_helper
DEBUG - 2017-03-07 21:49:35 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-07 21:49:35 --> Final output sent to browser
DEBUG - 2017-03-07 21:49:35 --> Total execution time: 0.0207
DEBUG - 2017-03-07 22:12:38 --> Config Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Hooks Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Utf8 Class Initialized
DEBUG - 2017-03-07 22:12:38 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 22:12:38 --> URI Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Router Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Output Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Security Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Input Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 22:12:38 --> Language Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Loader Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Helper loaded: date_helper
DEBUG - 2017-03-07 22:12:38 --> Controller Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Database Driver Class Initialized
ERROR - 2017-03-07 22:12:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 22:12:38 --> Model Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Model Class Initialized
DEBUG - 2017-03-07 22:12:38 --> Helper loaded: url_helper
DEBUG - 2017-03-07 22:12:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-03-07 22:12:38 --> Final output sent to browser
DEBUG - 2017-03-07 22:12:38 --> Total execution time: 0.0202
DEBUG - 2017-03-07 22:12:44 --> Config Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Hooks Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Utf8 Class Initialized
DEBUG - 2017-03-07 22:12:44 --> UTF-8 Support Enabled
DEBUG - 2017-03-07 22:12:44 --> URI Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Router Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Output Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Security Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Input Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-03-07 22:12:44 --> Language Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Loader Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Helper loaded: date_helper
DEBUG - 2017-03-07 22:12:44 --> Controller Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Database Driver Class Initialized
ERROR - 2017-03-07 22:12:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-03-07 22:12:44 --> Model Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Model Class Initialized
DEBUG - 2017-03-07 22:12:44 --> Helper loaded: url_helper
DEBUG - 2017-03-07 22:12:44 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-03-07 22:12:44 --> Final output sent to browser
DEBUG - 2017-03-07 22:12:44 --> Total execution time: 0.0199
