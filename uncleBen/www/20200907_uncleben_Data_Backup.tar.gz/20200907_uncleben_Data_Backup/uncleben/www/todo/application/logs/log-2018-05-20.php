<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-05-20 13:34:14 --> Config Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Hooks Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Utf8 Class Initialized
DEBUG - 2018-05-20 13:34:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-20 13:34:14 --> URI Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Router Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Output Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Security Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Input Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2018-05-20 13:34:14 --> Language Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Loader Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Helper loaded: date_helper
DEBUG - 2018-05-20 13:34:14 --> Controller Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Database Driver Class Initialized
ERROR - 2018-05-20 13:34:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-05-20 13:34:14 --> Model Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Model Class Initialized
DEBUG - 2018-05-20 13:34:14 --> Helper loaded: url_helper
DEBUG - 2018-05-20 13:34:14 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-05-20 13:34:14 --> Final output sent to browser
DEBUG - 2018-05-20 13:34:14 --> Total execution time: 0.0309
