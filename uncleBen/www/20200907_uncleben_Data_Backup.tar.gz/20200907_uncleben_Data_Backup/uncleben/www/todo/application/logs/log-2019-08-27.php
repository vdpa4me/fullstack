<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-08-27 13:04:55 --> Config Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Hooks Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Utf8 Class Initialized
DEBUG - 2019-08-27 13:04:55 --> UTF-8 Support Enabled
DEBUG - 2019-08-27 13:04:55 --> URI Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Router Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Output Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Security Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Input Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-27 13:04:55 --> Language Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Loader Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Helper loaded: date_helper
DEBUG - 2019-08-27 13:04:55 --> Controller Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Database Driver Class Initialized
ERROR - 2019-08-27 13:04:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-27 13:04:55 --> Model Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Model Class Initialized
DEBUG - 2019-08-27 13:04:55 --> Helper loaded: url_helper
DEBUG - 2019-08-27 13:04:55 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-27 13:04:55 --> Final output sent to browser
DEBUG - 2019-08-27 13:04:55 --> Total execution time: 0.0647
DEBUG - 2019-08-27 19:40:53 --> Config Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Hooks Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Utf8 Class Initialized
DEBUG - 2019-08-27 19:40:53 --> UTF-8 Support Enabled
DEBUG - 2019-08-27 19:40:53 --> URI Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Router Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Output Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Security Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Input Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-08-27 19:40:53 --> Language Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Loader Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Helper loaded: date_helper
DEBUG - 2019-08-27 19:40:53 --> Controller Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Database Driver Class Initialized
ERROR - 2019-08-27 19:40:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-08-27 19:40:53 --> Model Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Model Class Initialized
DEBUG - 2019-08-27 19:40:53 --> Helper loaded: url_helper
DEBUG - 2019-08-27 19:40:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-08-27 19:40:53 --> Final output sent to browser
DEBUG - 2019-08-27 19:40:53 --> Total execution time: 0.0775
