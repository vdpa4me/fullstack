<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-09-17 05:09:04 --> Config Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Hooks Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Utf8 Class Initialized
DEBUG - 2017-09-17 05:09:04 --> UTF-8 Support Enabled
DEBUG - 2017-09-17 05:09:04 --> URI Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Router Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Output Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Security Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Input Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-17 05:09:04 --> Language Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Loader Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Helper loaded: date_helper
DEBUG - 2017-09-17 05:09:04 --> Controller Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Database Driver Class Initialized
ERROR - 2017-09-17 05:09:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-17 05:09:04 --> Model Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Model Class Initialized
DEBUG - 2017-09-17 05:09:04 --> Helper loaded: url_helper
DEBUG - 2017-09-17 05:09:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-17 05:09:04 --> Final output sent to browser
DEBUG - 2017-09-17 05:09:04 --> Total execution time: 0.0314
DEBUG - 2017-09-17 05:33:11 --> Config Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Hooks Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Utf8 Class Initialized
DEBUG - 2017-09-17 05:33:11 --> UTF-8 Support Enabled
DEBUG - 2017-09-17 05:33:11 --> URI Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Router Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Output Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Security Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Input Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-17 05:33:11 --> Language Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Loader Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Helper loaded: date_helper
DEBUG - 2017-09-17 05:33:11 --> Controller Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Database Driver Class Initialized
ERROR - 2017-09-17 05:33:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-17 05:33:11 --> Model Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Model Class Initialized
DEBUG - 2017-09-17 05:33:11 --> Helper loaded: url_helper
DEBUG - 2017-09-17 05:33:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-17 05:33:11 --> Final output sent to browser
DEBUG - 2017-09-17 05:33:11 --> Total execution time: 0.0251
DEBUG - 2017-09-17 11:56:37 --> Config Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Hooks Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Utf8 Class Initialized
DEBUG - 2017-09-17 11:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-09-17 11:56:37 --> URI Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Router Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Output Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Security Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Input Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-17 11:56:37 --> Language Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Loader Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Helper loaded: date_helper
DEBUG - 2017-09-17 11:56:37 --> Controller Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Database Driver Class Initialized
ERROR - 2017-09-17 11:56:37 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-17 11:56:37 --> Model Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Model Class Initialized
DEBUG - 2017-09-17 11:56:37 --> Helper loaded: url_helper
DEBUG - 2017-09-17 11:56:37 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-17 11:56:37 --> Final output sent to browser
DEBUG - 2017-09-17 11:56:37 --> Total execution time: 0.0354
DEBUG - 2017-09-17 12:20:04 --> Config Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Hooks Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Utf8 Class Initialized
DEBUG - 2017-09-17 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2017-09-17 12:20:04 --> URI Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Router Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Output Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Security Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Input Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-17 12:20:04 --> Language Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Loader Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Helper loaded: date_helper
DEBUG - 2017-09-17 12:20:04 --> Controller Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Database Driver Class Initialized
ERROR - 2017-09-17 12:20:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-17 12:20:04 --> Model Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Model Class Initialized
DEBUG - 2017-09-17 12:20:04 --> Helper loaded: url_helper
DEBUG - 2017-09-17 12:20:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-17 12:20:04 --> Final output sent to browser
DEBUG - 2017-09-17 12:20:04 --> Total execution time: 0.0220
DEBUG - 2017-09-17 18:25:00 --> Config Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Hooks Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Utf8 Class Initialized
DEBUG - 2017-09-17 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2017-09-17 18:25:00 --> URI Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Router Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Output Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Security Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Input Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-17 18:25:00 --> Language Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Loader Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Helper loaded: date_helper
DEBUG - 2017-09-17 18:25:00 --> Controller Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Database Driver Class Initialized
ERROR - 2017-09-17 18:25:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-17 18:25:00 --> Model Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Model Class Initialized
DEBUG - 2017-09-17 18:25:00 --> Helper loaded: url_helper
DEBUG - 2017-09-17 18:25:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-17 18:25:00 --> Final output sent to browser
DEBUG - 2017-09-17 18:25:00 --> Total execution time: 0.0232
DEBUG - 2017-09-17 18:25:04 --> Config Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Hooks Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Utf8 Class Initialized
DEBUG - 2017-09-17 18:25:04 --> UTF-8 Support Enabled
DEBUG - 2017-09-17 18:25:04 --> URI Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Router Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Output Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Security Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Input Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-09-17 18:25:04 --> Language Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Loader Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Helper loaded: date_helper
DEBUG - 2017-09-17 18:25:04 --> Controller Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Database Driver Class Initialized
ERROR - 2017-09-17 18:25:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-09-17 18:25:04 --> Model Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Model Class Initialized
DEBUG - 2017-09-17 18:25:04 --> Helper loaded: url_helper
DEBUG - 2017-09-17 18:25:04 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-09-17 18:25:04 --> Final output sent to browser
DEBUG - 2017-09-17 18:25:04 --> Total execution time: 0.0198
