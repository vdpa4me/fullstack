<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-02-07 11:42:34 --> Config Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Utf8 Class Initialized
DEBUG - 2018-02-07 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-07 11:42:34 --> URI Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Router Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Output Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Security Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Input Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-07 11:42:34 --> Language Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Loader Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Helper loaded: date_helper
DEBUG - 2018-02-07 11:42:34 --> Controller Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Database Driver Class Initialized
ERROR - 2018-02-07 11:42:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-02-07 11:42:34 --> Model Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Model Class Initialized
DEBUG - 2018-02-07 11:42:34 --> Helper loaded: url_helper
DEBUG - 2018-02-07 11:42:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-02-07 11:42:34 --> Final output sent to browser
DEBUG - 2018-02-07 11:42:34 --> Total execution time: 0.0310
