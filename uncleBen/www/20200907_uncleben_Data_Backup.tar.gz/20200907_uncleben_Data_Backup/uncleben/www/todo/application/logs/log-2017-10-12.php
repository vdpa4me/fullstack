<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-12 01:33:41 --> Config Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Hooks Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Utf8 Class Initialized
DEBUG - 2017-10-12 01:33:41 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 01:33:41 --> URI Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Router Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Output Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Security Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Input Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 01:33:41 --> Language Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Loader Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Helper loaded: date_helper
DEBUG - 2017-10-12 01:33:41 --> Controller Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Database Driver Class Initialized
ERROR - 2017-10-12 01:33:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 01:33:41 --> Model Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Model Class Initialized
DEBUG - 2017-10-12 01:33:41 --> Helper loaded: url_helper
DEBUG - 2017-10-12 01:33:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-12 01:33:41 --> Final output sent to browser
DEBUG - 2017-10-12 01:33:41 --> Total execution time: 0.0482
DEBUG - 2017-10-12 01:33:45 --> Config Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Hooks Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Utf8 Class Initialized
DEBUG - 2017-10-12 01:33:45 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 01:33:45 --> URI Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Router Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Output Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Security Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Input Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 01:33:45 --> Language Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Loader Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Helper loaded: date_helper
DEBUG - 2017-10-12 01:33:45 --> Controller Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Database Driver Class Initialized
ERROR - 2017-10-12 01:33:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 01:33:45 --> Model Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Model Class Initialized
DEBUG - 2017-10-12 01:33:45 --> Helper loaded: url_helper
DEBUG - 2017-10-12 01:33:45 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-12 01:33:45 --> Final output sent to browser
DEBUG - 2017-10-12 01:33:45 --> Total execution time: 0.0406
DEBUG - 2017-10-12 01:33:58 --> Config Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Hooks Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Utf8 Class Initialized
DEBUG - 2017-10-12 01:33:58 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 01:33:58 --> URI Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Router Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Output Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Security Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Input Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 01:33:58 --> Language Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Loader Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Helper loaded: date_helper
DEBUG - 2017-10-12 01:33:58 --> Controller Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Database Driver Class Initialized
ERROR - 2017-10-12 01:33:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 01:33:58 --> Model Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Model Class Initialized
DEBUG - 2017-10-12 01:33:58 --> Helper loaded: url_helper
DEBUG - 2017-10-12 01:33:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-12 01:33:58 --> Final output sent to browser
DEBUG - 2017-10-12 01:33:58 --> Total execution time: 0.0413
DEBUG - 2017-10-12 01:34:04 --> Config Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Hooks Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Utf8 Class Initialized
DEBUG - 2017-10-12 01:34:04 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 01:34:04 --> URI Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Router Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Output Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Security Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Input Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 01:34:04 --> Language Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Loader Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Helper loaded: date_helper
DEBUG - 2017-10-12 01:34:04 --> Controller Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Database Driver Class Initialized
ERROR - 2017-10-12 01:34:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 01:34:04 --> Model Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Model Class Initialized
DEBUG - 2017-10-12 01:34:04 --> Helper loaded: url_helper
DEBUG - 2017-10-12 01:34:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-12 01:34:04 --> Final output sent to browser
DEBUG - 2017-10-12 01:34:04 --> Total execution time: 0.0401
DEBUG - 2017-10-12 01:35:03 --> Config Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Hooks Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Utf8 Class Initialized
DEBUG - 2017-10-12 01:35:03 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 01:35:03 --> URI Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Router Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Output Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Security Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Input Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 01:35:03 --> Language Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Loader Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Helper loaded: date_helper
DEBUG - 2017-10-12 01:35:03 --> Controller Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Database Driver Class Initialized
ERROR - 2017-10-12 01:35:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 01:35:03 --> Model Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Model Class Initialized
DEBUG - 2017-10-12 01:35:03 --> Helper loaded: url_helper
DEBUG - 2017-10-12 01:35:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-12 01:35:03 --> Final output sent to browser
DEBUG - 2017-10-12 01:35:03 --> Total execution time: 0.0425
DEBUG - 2017-10-12 02:35:13 --> Config Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Hooks Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Utf8 Class Initialized
DEBUG - 2017-10-12 02:35:13 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 02:35:13 --> URI Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Router Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Output Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Security Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Input Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 02:35:13 --> Language Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Loader Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Helper loaded: date_helper
DEBUG - 2017-10-12 02:35:13 --> Controller Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Database Driver Class Initialized
ERROR - 2017-10-12 02:35:13 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 02:35:13 --> Model Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Model Class Initialized
DEBUG - 2017-10-12 02:35:13 --> Helper loaded: url_helper
DEBUG - 2017-10-12 02:35:13 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-12 02:35:13 --> Final output sent to browser
DEBUG - 2017-10-12 02:35:13 --> Total execution time: 0.0206
DEBUG - 2017-10-12 05:40:34 --> Config Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Hooks Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Utf8 Class Initialized
DEBUG - 2017-10-12 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 05:40:34 --> URI Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Router Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Output Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Security Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Input Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 05:40:34 --> Language Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Loader Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Helper loaded: date_helper
DEBUG - 2017-10-12 05:40:34 --> Controller Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Database Driver Class Initialized
ERROR - 2017-10-12 05:40:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 05:40:34 --> Model Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Model Class Initialized
DEBUG - 2017-10-12 05:40:34 --> Helper loaded: url_helper
DEBUG - 2017-10-12 05:40:34 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-12 05:40:34 --> Final output sent to browser
DEBUG - 2017-10-12 05:40:34 --> Total execution time: 0.0375
DEBUG - 2017-10-12 07:16:25 --> Config Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Utf8 Class Initialized
DEBUG - 2017-10-12 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 07:16:25 --> URI Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Router Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Output Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Security Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Input Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 07:16:25 --> Language Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Loader Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Helper loaded: date_helper
DEBUG - 2017-10-12 07:16:25 --> Controller Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Database Driver Class Initialized
ERROR - 2017-10-12 07:16:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 07:16:25 --> Model Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Model Class Initialized
DEBUG - 2017-10-12 07:16:25 --> Helper loaded: url_helper
DEBUG - 2017-10-12 07:16:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-12 07:16:26 --> Final output sent to browser
DEBUG - 2017-10-12 07:16:26 --> Total execution time: 0.0623
DEBUG - 2017-10-12 07:21:14 --> Config Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Hooks Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Utf8 Class Initialized
DEBUG - 2017-10-12 07:21:14 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 07:21:14 --> URI Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Router Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Output Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Security Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Input Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 07:21:14 --> Language Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Loader Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Helper loaded: date_helper
DEBUG - 2017-10-12 07:21:14 --> Controller Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Database Driver Class Initialized
ERROR - 2017-10-12 07:21:14 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 07:21:14 --> Model Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Model Class Initialized
DEBUG - 2017-10-12 07:21:14 --> Helper loaded: url_helper
DEBUG - 2017-10-12 07:21:14 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-12 07:21:14 --> Final output sent to browser
DEBUG - 2017-10-12 07:21:14 --> Total execution time: 0.0405
DEBUG - 2017-10-12 07:43:48 --> Config Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Hooks Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Utf8 Class Initialized
DEBUG - 2017-10-12 07:43:48 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 07:43:48 --> URI Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Router Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Output Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Security Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Input Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 07:43:48 --> Language Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Loader Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Helper loaded: date_helper
DEBUG - 2017-10-12 07:43:48 --> Controller Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Database Driver Class Initialized
ERROR - 2017-10-12 07:43:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 07:43:48 --> Model Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Model Class Initialized
DEBUG - 2017-10-12 07:43:48 --> Helper loaded: url_helper
DEBUG - 2017-10-12 07:43:48 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-10-12 07:43:48 --> Final output sent to browser
DEBUG - 2017-10-12 07:43:48 --> Total execution time: 0.0214
DEBUG - 2017-10-12 09:47:51 --> Config Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Hooks Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Utf8 Class Initialized
DEBUG - 2017-10-12 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 09:47:51 --> URI Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Router Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Output Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Security Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Input Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 09:47:51 --> Language Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Loader Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Helper loaded: date_helper
DEBUG - 2017-10-12 09:47:51 --> Controller Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Database Driver Class Initialized
ERROR - 2017-10-12 09:47:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 09:47:51 --> Model Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Model Class Initialized
DEBUG - 2017-10-12 09:47:51 --> Helper loaded: url_helper
DEBUG - 2017-10-12 09:47:51 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-12 09:47:51 --> Final output sent to browser
DEBUG - 2017-10-12 09:47:51 --> Total execution time: 0.0220
DEBUG - 2017-10-12 11:09:09 --> Config Class Initialized
DEBUG - 2017-10-12 11:09:09 --> Hooks Class Initialized
DEBUG - 2017-10-12 11:09:09 --> Utf8 Class Initialized
DEBUG - 2017-10-12 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 11:09:09 --> URI Class Initialized
DEBUG - 2017-10-12 11:09:09 --> Router Class Initialized
DEBUG - 2017-10-12 11:09:09 --> Output Class Initialized
DEBUG - 2017-10-12 11:09:09 --> Security Class Initialized
DEBUG - 2017-10-12 11:09:09 --> Input Class Initialized
DEBUG - 2017-10-12 11:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 11:09:10 --> Language Class Initialized
DEBUG - 2017-10-12 11:09:10 --> Loader Class Initialized
DEBUG - 2017-10-12 11:09:10 --> Helper loaded: date_helper
DEBUG - 2017-10-12 11:09:10 --> Controller Class Initialized
DEBUG - 2017-10-12 11:09:10 --> Database Driver Class Initialized
ERROR - 2017-10-12 11:09:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 11:09:10 --> Model Class Initialized
DEBUG - 2017-10-12 11:09:10 --> Model Class Initialized
DEBUG - 2017-10-12 11:09:10 --> Helper loaded: url_helper
DEBUG - 2017-10-12 11:09:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-12 11:09:10 --> Final output sent to browser
DEBUG - 2017-10-12 11:09:10 --> Total execution time: 0.0198
DEBUG - 2017-10-12 13:12:28 --> Config Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Hooks Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Utf8 Class Initialized
DEBUG - 2017-10-12 13:12:28 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 13:12:28 --> URI Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Router Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Output Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Security Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Input Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 13:12:28 --> Language Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Loader Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Helper loaded: date_helper
DEBUG - 2017-10-12 13:12:28 --> Controller Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Database Driver Class Initialized
ERROR - 2017-10-12 13:12:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 13:12:28 --> Model Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Model Class Initialized
DEBUG - 2017-10-12 13:12:28 --> Helper loaded: url_helper
DEBUG - 2017-10-12 13:12:28 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-12 13:12:28 --> Final output sent to browser
DEBUG - 2017-10-12 13:12:28 --> Total execution time: 0.0197
DEBUG - 2017-10-12 18:15:29 --> Config Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Hooks Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Utf8 Class Initialized
DEBUG - 2017-10-12 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2017-10-12 18:15:29 --> URI Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Router Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Output Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Security Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Input Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-12 18:15:29 --> Language Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Loader Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Helper loaded: date_helper
DEBUG - 2017-10-12 18:15:29 --> Controller Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Database Driver Class Initialized
ERROR - 2017-10-12 18:15:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-12 18:15:29 --> Model Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Model Class Initialized
DEBUG - 2017-10-12 18:15:29 --> Helper loaded: url_helper
DEBUG - 2017-10-12 18:15:29 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-12 18:15:29 --> Final output sent to browser
DEBUG - 2017-10-12 18:15:29 --> Total execution time: 0.0241
