<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-04-16 05:37:33 --> Config Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Hooks Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Utf8 Class Initialized
DEBUG - 2017-04-16 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2017-04-16 05:37:33 --> URI Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Router Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Output Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Security Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Input Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-16 05:37:33 --> Language Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Loader Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Helper loaded: date_helper
DEBUG - 2017-04-16 05:37:33 --> Controller Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Database Driver Class Initialized
ERROR - 2017-04-16 05:37:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-16 05:37:33 --> Model Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Model Class Initialized
DEBUG - 2017-04-16 05:37:33 --> Helper loaded: url_helper
DEBUG - 2017-04-16 05:37:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-16 05:37:34 --> Final output sent to browser
DEBUG - 2017-04-16 05:37:34 --> Total execution time: 0.0547
DEBUG - 2017-04-16 05:38:11 --> Config Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Hooks Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Utf8 Class Initialized
DEBUG - 2017-04-16 05:38:11 --> UTF-8 Support Enabled
DEBUG - 2017-04-16 05:38:11 --> URI Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Router Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Output Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Security Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Input Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-16 05:38:11 --> Language Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Loader Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Helper loaded: date_helper
DEBUG - 2017-04-16 05:38:11 --> Controller Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Database Driver Class Initialized
ERROR - 2017-04-16 05:38:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-16 05:38:11 --> Model Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Model Class Initialized
DEBUG - 2017-04-16 05:38:11 --> Helper loaded: url_helper
DEBUG - 2017-04-16 05:38:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-16 05:38:11 --> Final output sent to browser
DEBUG - 2017-04-16 05:38:11 --> Total execution time: 0.0311
DEBUG - 2017-04-16 05:38:16 --> Config Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Hooks Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Utf8 Class Initialized
DEBUG - 2017-04-16 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2017-04-16 05:38:16 --> URI Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Router Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Output Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Security Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Input Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-16 05:38:16 --> Language Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Loader Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Helper loaded: date_helper
DEBUG - 2017-04-16 05:38:16 --> Controller Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Database Driver Class Initialized
ERROR - 2017-04-16 05:38:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-16 05:38:16 --> Model Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Model Class Initialized
DEBUG - 2017-04-16 05:38:16 --> Helper loaded: url_helper
DEBUG - 2017-04-16 05:38:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-16 05:38:16 --> Final output sent to browser
DEBUG - 2017-04-16 05:38:16 --> Total execution time: 0.0310
DEBUG - 2017-04-16 05:38:22 --> Config Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Hooks Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Utf8 Class Initialized
DEBUG - 2017-04-16 05:38:22 --> UTF-8 Support Enabled
DEBUG - 2017-04-16 05:38:22 --> URI Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Router Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Output Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Security Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Input Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-16 05:38:22 --> Language Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Loader Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Helper loaded: date_helper
DEBUG - 2017-04-16 05:38:22 --> Controller Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Database Driver Class Initialized
ERROR - 2017-04-16 05:38:22 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-16 05:38:22 --> Model Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Model Class Initialized
DEBUG - 2017-04-16 05:38:22 --> Helper loaded: url_helper
DEBUG - 2017-04-16 05:38:22 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-16 05:38:22 --> Final output sent to browser
DEBUG - 2017-04-16 05:38:22 --> Total execution time: 0.0320
DEBUG - 2017-04-16 05:45:54 --> Config Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Hooks Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Utf8 Class Initialized
DEBUG - 2017-04-16 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2017-04-16 05:45:54 --> URI Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Router Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Output Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Security Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Input Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-16 05:45:54 --> Language Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Loader Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Helper loaded: date_helper
DEBUG - 2017-04-16 05:45:54 --> Controller Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Database Driver Class Initialized
ERROR - 2017-04-16 05:45:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-16 05:45:54 --> Model Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Model Class Initialized
DEBUG - 2017-04-16 05:45:54 --> Helper loaded: url_helper
DEBUG - 2017-04-16 05:45:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-16 05:45:54 --> Final output sent to browser
DEBUG - 2017-04-16 05:45:54 --> Total execution time: 0.0313
DEBUG - 2017-04-16 05:45:58 --> Config Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Hooks Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Utf8 Class Initialized
DEBUG - 2017-04-16 05:45:58 --> UTF-8 Support Enabled
DEBUG - 2017-04-16 05:45:58 --> URI Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Router Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Output Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Security Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Input Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-04-16 05:45:58 --> Language Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Loader Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Helper loaded: date_helper
DEBUG - 2017-04-16 05:45:58 --> Controller Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Database Driver Class Initialized
ERROR - 2017-04-16 05:45:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-04-16 05:45:58 --> Model Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Model Class Initialized
DEBUG - 2017-04-16 05:45:58 --> Helper loaded: url_helper
DEBUG - 2017-04-16 05:45:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-04-16 05:45:58 --> Final output sent to browser
DEBUG - 2017-04-16 05:45:58 --> Total execution time: 0.0310
