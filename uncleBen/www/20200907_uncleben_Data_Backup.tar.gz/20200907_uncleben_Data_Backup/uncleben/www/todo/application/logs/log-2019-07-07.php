<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-07-07 01:13:49 --> Config Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Hooks Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Utf8 Class Initialized
DEBUG - 2019-07-07 01:13:49 --> UTF-8 Support Enabled
DEBUG - 2019-07-07 01:13:49 --> URI Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Router Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Output Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Security Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Input Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-07 01:13:49 --> Language Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Loader Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Helper loaded: date_helper
DEBUG - 2019-07-07 01:13:49 --> Controller Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Database Driver Class Initialized
ERROR - 2019-07-07 01:13:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-07 01:13:49 --> Model Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Model Class Initialized
DEBUG - 2019-07-07 01:13:49 --> Helper loaded: url_helper
DEBUG - 2019-07-07 01:13:49 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-07 01:13:49 --> Final output sent to browser
DEBUG - 2019-07-07 01:13:49 --> Total execution time: 0.0487
DEBUG - 2019-07-07 07:09:49 --> Config Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Hooks Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Utf8 Class Initialized
DEBUG - 2019-07-07 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2019-07-07 07:09:49 --> URI Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Router Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Output Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Security Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Input Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-07 07:09:49 --> Language Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Loader Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Helper loaded: date_helper
DEBUG - 2019-07-07 07:09:49 --> Controller Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Database Driver Class Initialized
ERROR - 2019-07-07 07:09:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-07 07:09:49 --> Model Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Model Class Initialized
DEBUG - 2019-07-07 07:09:49 --> Helper loaded: url_helper
DEBUG - 2019-07-07 07:09:49 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-07 07:09:49 --> Final output sent to browser
DEBUG - 2019-07-07 07:09:49 --> Total execution time: 0.0479
DEBUG - 2019-07-07 12:46:25 --> Config Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Hooks Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Utf8 Class Initialized
DEBUG - 2019-07-07 12:46:25 --> UTF-8 Support Enabled
DEBUG - 2019-07-07 12:46:25 --> URI Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Router Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Output Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Security Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Input Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-07 12:46:25 --> Language Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Loader Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Helper loaded: date_helper
DEBUG - 2019-07-07 12:46:25 --> Controller Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Database Driver Class Initialized
ERROR - 2019-07-07 12:46:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-07 12:46:25 --> Model Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Model Class Initialized
DEBUG - 2019-07-07 12:46:25 --> Helper loaded: url_helper
DEBUG - 2019-07-07 12:46:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-07 12:46:25 --> Final output sent to browser
DEBUG - 2019-07-07 12:46:25 --> Total execution time: 0.0518
DEBUG - 2019-07-07 19:08:31 --> Config Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Hooks Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Utf8 Class Initialized
DEBUG - 2019-07-07 19:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-07-07 19:08:31 --> URI Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Router Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Output Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Security Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Input Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-07 19:08:31 --> Language Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Loader Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Helper loaded: date_helper
DEBUG - 2019-07-07 19:08:31 --> Controller Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Database Driver Class Initialized
ERROR - 2019-07-07 19:08:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-07 19:08:31 --> Model Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Model Class Initialized
DEBUG - 2019-07-07 19:08:31 --> Helper loaded: url_helper
DEBUG - 2019-07-07 19:08:31 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-07 19:08:31 --> Final output sent to browser
DEBUG - 2019-07-07 19:08:31 --> Total execution time: 0.0503
DEBUG - 2019-07-07 22:35:33 --> Config Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Hooks Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Utf8 Class Initialized
DEBUG - 2019-07-07 22:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-07-07 22:35:33 --> URI Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Router Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Output Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Security Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Input Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-07-07 22:35:33 --> Language Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Loader Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Helper loaded: date_helper
DEBUG - 2019-07-07 22:35:33 --> Controller Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Database Driver Class Initialized
ERROR - 2019-07-07 22:35:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-07-07 22:35:33 --> Model Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Model Class Initialized
DEBUG - 2019-07-07 22:35:33 --> Helper loaded: url_helper
DEBUG - 2019-07-07 22:35:33 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-07-07 22:35:33 --> Final output sent to browser
DEBUG - 2019-07-07 22:35:33 --> Total execution time: 0.0316
