<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-10-20 06:21:25 --> Config Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Hooks Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Utf8 Class Initialized
DEBUG - 2019-10-20 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-20 06:21:25 --> URI Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Router Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Output Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Security Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Input Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-20 06:21:25 --> Language Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Loader Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Helper loaded: date_helper
DEBUG - 2019-10-20 06:21:25 --> Controller Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Database Driver Class Initialized
ERROR - 2019-10-20 06:21:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-20 06:21:25 --> Model Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Model Class Initialized
DEBUG - 2019-10-20 06:21:25 --> Helper loaded: url_helper
DEBUG - 2019-10-20 06:21:25 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-20 06:21:25 --> Final output sent to browser
DEBUG - 2019-10-20 06:21:25 --> Total execution time: 0.1806
DEBUG - 2019-10-20 14:03:58 --> Config Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Hooks Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Utf8 Class Initialized
DEBUG - 2019-10-20 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-20 14:03:58 --> URI Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Router Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Output Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Security Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Input Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-20 14:03:58 --> Language Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Loader Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Helper loaded: date_helper
DEBUG - 2019-10-20 14:03:58 --> Controller Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Database Driver Class Initialized
ERROR - 2019-10-20 14:03:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-20 14:03:58 --> Model Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Model Class Initialized
DEBUG - 2019-10-20 14:03:58 --> Helper loaded: url_helper
DEBUG - 2019-10-20 14:03:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-20 14:03:58 --> Final output sent to browser
DEBUG - 2019-10-20 14:03:58 --> Total execution time: 0.2077
DEBUG - 2019-10-20 18:09:08 --> Config Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Hooks Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Utf8 Class Initialized
DEBUG - 2019-10-20 18:09:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-20 18:09:08 --> URI Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Router Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Output Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Security Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Input Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-20 18:09:08 --> Language Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Loader Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Helper loaded: date_helper
DEBUG - 2019-10-20 18:09:08 --> Controller Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Database Driver Class Initialized
ERROR - 2019-10-20 18:09:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-20 18:09:08 --> Model Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Model Class Initialized
DEBUG - 2019-10-20 18:09:08 --> Helper loaded: url_helper
DEBUG - 2019-10-20 18:09:08 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-20 18:09:08 --> Final output sent to browser
DEBUG - 2019-10-20 18:09:08 --> Total execution time: 0.1067
DEBUG - 2019-10-20 18:09:11 --> Config Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Hooks Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Utf8 Class Initialized
DEBUG - 2019-10-20 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-20 18:09:11 --> URI Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Router Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Output Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Security Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Input Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-20 18:09:11 --> Language Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Loader Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Helper loaded: date_helper
DEBUG - 2019-10-20 18:09:11 --> Controller Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Database Driver Class Initialized
ERROR - 2019-10-20 18:09:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-20 18:09:11 --> Model Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Model Class Initialized
DEBUG - 2019-10-20 18:09:11 --> Helper loaded: url_helper
DEBUG - 2019-10-20 18:09:11 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-20 18:09:11 --> Final output sent to browser
DEBUG - 2019-10-20 18:09:11 --> Total execution time: 0.0925
DEBUG - 2019-10-20 18:17:53 --> Config Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Hooks Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Utf8 Class Initialized
DEBUG - 2019-10-20 18:17:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-20 18:17:53 --> URI Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Router Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Output Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Security Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Input Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-10-20 18:17:53 --> Language Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Loader Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Helper loaded: date_helper
DEBUG - 2019-10-20 18:17:53 --> Controller Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Database Driver Class Initialized
ERROR - 2019-10-20 18:17:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2019-10-20 18:17:53 --> Model Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Model Class Initialized
DEBUG - 2019-10-20 18:17:53 --> Helper loaded: url_helper
DEBUG - 2019-10-20 18:17:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2019-10-20 18:17:53 --> Final output sent to browser
DEBUG - 2019-10-20 18:17:53 --> Total execution time: 0.1190
