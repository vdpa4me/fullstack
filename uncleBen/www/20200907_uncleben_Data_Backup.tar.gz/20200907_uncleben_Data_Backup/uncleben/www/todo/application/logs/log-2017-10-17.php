<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-17 03:30:58 --> Config Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Hooks Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Utf8 Class Initialized
DEBUG - 2017-10-17 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 03:30:58 --> URI Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Router Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Output Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Security Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Input Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 03:30:58 --> Language Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Loader Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Helper loaded: date_helper
DEBUG - 2017-10-17 03:30:58 --> Controller Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Database Driver Class Initialized
ERROR - 2017-10-17 03:30:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 03:30:58 --> Model Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Model Class Initialized
DEBUG - 2017-10-17 03:30:58 --> Helper loaded: url_helper
DEBUG - 2017-10-17 03:30:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-17 03:30:58 --> Final output sent to browser
DEBUG - 2017-10-17 03:30:58 --> Total execution time: 0.0597
DEBUG - 2017-10-17 03:31:05 --> Config Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Hooks Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Utf8 Class Initialized
DEBUG - 2017-10-17 03:31:05 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 03:31:05 --> URI Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Router Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Output Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Security Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Input Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 03:31:05 --> Language Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Loader Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Helper loaded: date_helper
DEBUG - 2017-10-17 03:31:05 --> Controller Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Database Driver Class Initialized
ERROR - 2017-10-17 03:31:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 03:31:05 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:05 --> Helper loaded: url_helper
DEBUG - 2017-10-17 03:31:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-17 03:31:05 --> Final output sent to browser
DEBUG - 2017-10-17 03:31:05 --> Total execution time: 0.0395
DEBUG - 2017-10-17 03:31:19 --> Config Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Hooks Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Utf8 Class Initialized
DEBUG - 2017-10-17 03:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 03:31:19 --> URI Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Router Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Output Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Security Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Input Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 03:31:19 --> Language Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Loader Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Helper loaded: date_helper
DEBUG - 2017-10-17 03:31:19 --> Controller Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Database Driver Class Initialized
ERROR - 2017-10-17 03:31:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 03:31:19 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:19 --> Helper loaded: url_helper
DEBUG - 2017-10-17 03:31:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-17 03:31:19 --> Final output sent to browser
DEBUG - 2017-10-17 03:31:19 --> Total execution time: 0.0395
DEBUG - 2017-10-17 03:31:28 --> Config Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Hooks Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Utf8 Class Initialized
DEBUG - 2017-10-17 03:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 03:31:28 --> URI Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Router Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Output Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Security Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Input Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 03:31:28 --> Language Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Loader Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Helper loaded: date_helper
DEBUG - 2017-10-17 03:31:28 --> Controller Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Database Driver Class Initialized
ERROR - 2017-10-17 03:31:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 03:31:28 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:28 --> Helper loaded: url_helper
DEBUG - 2017-10-17 03:31:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-17 03:31:28 --> Final output sent to browser
DEBUG - 2017-10-17 03:31:28 --> Total execution time: 0.0387
DEBUG - 2017-10-17 03:31:42 --> Config Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Hooks Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Utf8 Class Initialized
DEBUG - 2017-10-17 03:31:42 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 03:31:42 --> URI Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Router Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Output Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Security Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Input Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 03:31:42 --> Language Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Loader Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Helper loaded: date_helper
DEBUG - 2017-10-17 03:31:42 --> Controller Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Database Driver Class Initialized
ERROR - 2017-10-17 03:31:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 03:31:42 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Model Class Initialized
DEBUG - 2017-10-17 03:31:42 --> Helper loaded: url_helper
DEBUG - 2017-10-17 03:31:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-17 03:31:42 --> Final output sent to browser
DEBUG - 2017-10-17 03:31:42 --> Total execution time: 0.0397
DEBUG - 2017-10-17 03:39:05 --> Config Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Hooks Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Utf8 Class Initialized
DEBUG - 2017-10-17 03:39:05 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 03:39:05 --> URI Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Router Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Output Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Security Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Input Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 03:39:05 --> Language Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Loader Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Helper loaded: date_helper
DEBUG - 2017-10-17 03:39:05 --> Controller Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Database Driver Class Initialized
ERROR - 2017-10-17 03:39:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 03:39:05 --> Model Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Model Class Initialized
DEBUG - 2017-10-17 03:39:05 --> Helper loaded: url_helper
DEBUG - 2017-10-17 03:39:05 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-17 03:39:05 --> Final output sent to browser
DEBUG - 2017-10-17 03:39:05 --> Total execution time: 0.0208
DEBUG - 2017-10-17 04:07:46 --> Config Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Hooks Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Utf8 Class Initialized
DEBUG - 2017-10-17 04:07:46 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 04:07:46 --> URI Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Router Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Output Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Security Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Input Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 04:07:46 --> Language Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Loader Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Helper loaded: date_helper
DEBUG - 2017-10-17 04:07:46 --> Controller Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Database Driver Class Initialized
ERROR - 2017-10-17 04:07:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 04:07:46 --> Model Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Model Class Initialized
DEBUG - 2017-10-17 04:07:46 --> Helper loaded: url_helper
DEBUG - 2017-10-17 04:07:46 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-17 04:07:46 --> Final output sent to browser
DEBUG - 2017-10-17 04:07:46 --> Total execution time: 0.0200
DEBUG - 2017-10-17 12:51:30 --> Config Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Hooks Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Utf8 Class Initialized
DEBUG - 2017-10-17 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 12:51:30 --> URI Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Router Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Output Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Security Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Input Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 12:51:30 --> Language Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Loader Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Helper loaded: date_helper
DEBUG - 2017-10-17 12:51:30 --> Controller Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Database Driver Class Initialized
ERROR - 2017-10-17 12:51:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 12:51:30 --> Model Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Model Class Initialized
DEBUG - 2017-10-17 12:51:30 --> Helper loaded: url_helper
DEBUG - 2017-10-17 12:51:30 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-17 12:51:30 --> Final output sent to browser
DEBUG - 2017-10-17 12:51:30 --> Total execution time: 0.0558
DEBUG - 2017-10-17 16:56:45 --> Config Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Hooks Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Utf8 Class Initialized
DEBUG - 2017-10-17 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 16:56:45 --> URI Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Router Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Output Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Security Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Input Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 16:56:45 --> Language Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Loader Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Helper loaded: date_helper
DEBUG - 2017-10-17 16:56:45 --> Controller Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Database Driver Class Initialized
ERROR - 2017-10-17 16:56:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 16:56:45 --> Model Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Model Class Initialized
DEBUG - 2017-10-17 16:56:45 --> Helper loaded: url_helper
DEBUG - 2017-10-17 16:56:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-17 16:56:45 --> Final output sent to browser
DEBUG - 2017-10-17 16:56:45 --> Total execution time: 0.0199
DEBUG - 2017-10-17 19:04:20 --> Config Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Hooks Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Utf8 Class Initialized
DEBUG - 2017-10-17 19:04:20 --> UTF-8 Support Enabled
DEBUG - 2017-10-17 19:04:20 --> URI Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Router Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Output Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Security Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Input Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-17 19:04:20 --> Language Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Loader Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Helper loaded: date_helper
DEBUG - 2017-10-17 19:04:20 --> Controller Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Database Driver Class Initialized
ERROR - 2017-10-17 19:04:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-17 19:04:20 --> Model Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Model Class Initialized
DEBUG - 2017-10-17 19:04:20 --> Helper loaded: url_helper
DEBUG - 2017-10-17 19:04:20 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-17 19:04:20 --> Final output sent to browser
DEBUG - 2017-10-17 19:04:20 --> Total execution time: 0.0213
