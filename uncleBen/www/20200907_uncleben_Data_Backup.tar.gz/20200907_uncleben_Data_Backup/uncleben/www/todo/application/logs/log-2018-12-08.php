<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-08 00:22:00 --> Config Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Hooks Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Utf8 Class Initialized
DEBUG - 2018-12-08 00:22:00 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 00:22:00 --> URI Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Router Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Output Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Security Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Input Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 00:22:00 --> Language Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Loader Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Helper loaded: date_helper
DEBUG - 2018-12-08 00:22:00 --> Controller Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Database Driver Class Initialized
ERROR - 2018-12-08 00:22:00 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 00:22:00 --> Model Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Model Class Initialized
DEBUG - 2018-12-08 00:22:00 --> Helper loaded: url_helper
DEBUG - 2018-12-08 00:22:00 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-08 00:22:00 --> Final output sent to browser
DEBUG - 2018-12-08 00:22:00 --> Total execution time: 0.0529
DEBUG - 2018-12-08 06:29:03 --> Config Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Hooks Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Utf8 Class Initialized
DEBUG - 2018-12-08 06:29:03 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 06:29:03 --> URI Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Router Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Output Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Security Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Input Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 06:29:03 --> Language Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Loader Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Helper loaded: date_helper
DEBUG - 2018-12-08 06:29:03 --> Controller Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Database Driver Class Initialized
ERROR - 2018-12-08 06:29:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 06:29:03 --> Model Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Model Class Initialized
DEBUG - 2018-12-08 06:29:03 --> Helper loaded: url_helper
DEBUG - 2018-12-08 06:29:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-08 06:29:03 --> Final output sent to browser
DEBUG - 2018-12-08 06:29:03 --> Total execution time: 0.0352
DEBUG - 2018-12-08 06:57:38 --> Config Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Hooks Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Utf8 Class Initialized
DEBUG - 2018-12-08 06:57:38 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 06:57:38 --> URI Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Router Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Output Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Security Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Input Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 06:57:38 --> Language Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Loader Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Helper loaded: date_helper
DEBUG - 2018-12-08 06:57:38 --> Controller Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Database Driver Class Initialized
ERROR - 2018-12-08 06:57:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 06:57:38 --> Model Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Model Class Initialized
DEBUG - 2018-12-08 06:57:38 --> Helper loaded: url_helper
DEBUG - 2018-12-08 06:57:38 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-08 06:57:38 --> Final output sent to browser
DEBUG - 2018-12-08 06:57:38 --> Total execution time: 0.0290
DEBUG - 2018-12-08 12:58:58 --> Config Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Hooks Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Utf8 Class Initialized
DEBUG - 2018-12-08 12:58:58 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 12:58:58 --> URI Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Router Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Output Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Security Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Input Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 12:58:58 --> Language Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Loader Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Helper loaded: date_helper
DEBUG - 2018-12-08 12:58:58 --> Controller Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Database Driver Class Initialized
ERROR - 2018-12-08 12:58:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 12:58:58 --> Model Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Model Class Initialized
DEBUG - 2018-12-08 12:58:58 --> Helper loaded: url_helper
DEBUG - 2018-12-08 12:58:58 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-08 12:58:58 --> Final output sent to browser
DEBUG - 2018-12-08 12:58:58 --> Total execution time: 0.0552
DEBUG - 2018-12-08 17:38:02 --> Config Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Hooks Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Utf8 Class Initialized
DEBUG - 2018-12-08 17:38:02 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 17:38:02 --> URI Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Router Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Output Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Security Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Input Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 17:38:02 --> Language Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Loader Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Helper loaded: date_helper
DEBUG - 2018-12-08 17:38:02 --> Controller Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Database Driver Class Initialized
ERROR - 2018-12-08 17:38:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 17:38:02 --> Model Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Model Class Initialized
DEBUG - 2018-12-08 17:38:02 --> Helper loaded: url_helper
DEBUG - 2018-12-08 17:38:02 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-08 17:38:02 --> Final output sent to browser
DEBUG - 2018-12-08 17:38:02 --> Total execution time: 0.0493
DEBUG - 2018-12-08 19:30:05 --> Config Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:30:05 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:30:05 --> URI Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Router Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Output Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Security Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Input Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:30:05 --> Language Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Loader Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:30:05 --> Controller Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:30:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:30:05 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:05 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:30:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:30:05 --> Final output sent to browser
DEBUG - 2018-12-08 19:30:05 --> Total execution time: 0.0675
DEBUG - 2018-12-08 19:30:08 --> Config Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:30:08 --> URI Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Router Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Output Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Security Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Input Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:30:08 --> Language Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Loader Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:30:08 --> Controller Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:30:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:30:08 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:08 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:30:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:30:08 --> Final output sent to browser
DEBUG - 2018-12-08 19:30:08 --> Total execution time: 0.0459
DEBUG - 2018-12-08 19:30:19 --> Config Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:30:19 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:30:19 --> URI Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Router Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Output Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Security Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Input Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:30:19 --> Language Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Loader Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:30:19 --> Controller Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:30:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:30:19 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:19 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:30:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:30:19 --> Final output sent to browser
DEBUG - 2018-12-08 19:30:19 --> Total execution time: 0.0629
DEBUG - 2018-12-08 19:30:24 --> Config Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:30:24 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:30:24 --> URI Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Router Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Output Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Security Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Input Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:30:24 --> Language Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Loader Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:30:24 --> Controller Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:30:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:30:24 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:24 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:30:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:30:24 --> Final output sent to browser
DEBUG - 2018-12-08 19:30:24 --> Total execution time: 0.0581
DEBUG - 2018-12-08 19:30:44 --> Config Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:30:44 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:30:44 --> URI Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Router Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Output Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Security Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Input Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:30:44 --> Language Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Loader Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:30:44 --> Controller Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:30:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:30:44 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:44 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:30:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:30:44 --> Final output sent to browser
DEBUG - 2018-12-08 19:30:44 --> Total execution time: 0.0455
DEBUG - 2018-12-08 19:30:47 --> Config Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:30:47 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:30:47 --> URI Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Router Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Output Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Security Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Input Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:30:47 --> Language Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Loader Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:30:47 --> Controller Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:30:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:30:47 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:47 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:30:47 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:30:47 --> Final output sent to browser
DEBUG - 2018-12-08 19:30:47 --> Total execution time: 0.0693
DEBUG - 2018-12-08 19:30:51 --> Config Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:30:51 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:30:51 --> URI Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Router Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Output Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Security Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Input Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:30:51 --> Language Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Loader Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:30:51 --> Controller Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:30:51 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:30:51 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Model Class Initialized
DEBUG - 2018-12-08 19:30:51 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:30:51 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:30:51 --> Final output sent to browser
DEBUG - 2018-12-08 19:30:51 --> Total execution time: 0.0754
DEBUG - 2018-12-08 19:31:04 --> Config Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:31:04 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:31:04 --> URI Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Router Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Output Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Security Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Input Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:31:04 --> Language Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Loader Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:31:04 --> Controller Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:31:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:31:04 --> Model Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Model Class Initialized
DEBUG - 2018-12-08 19:31:04 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:31:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:31:04 --> Final output sent to browser
DEBUG - 2018-12-08 19:31:04 --> Total execution time: 0.0584
DEBUG - 2018-12-08 19:31:18 --> Config Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:31:18 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:31:18 --> URI Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Router Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Output Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Security Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Input Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:31:18 --> Language Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Loader Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:31:18 --> Controller Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:31:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:31:18 --> Model Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Model Class Initialized
DEBUG - 2018-12-08 19:31:18 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:31:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:31:18 --> Final output sent to browser
DEBUG - 2018-12-08 19:31:18 --> Total execution time: 0.0652
DEBUG - 2018-12-08 19:31:21 --> Config Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Hooks Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Utf8 Class Initialized
DEBUG - 2018-12-08 19:31:21 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 19:31:21 --> URI Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Router Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Output Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Security Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Input Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 19:31:21 --> Language Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Loader Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Helper loaded: date_helper
DEBUG - 2018-12-08 19:31:21 --> Controller Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Database Driver Class Initialized
ERROR - 2018-12-08 19:31:21 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 19:31:21 --> Model Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Model Class Initialized
DEBUG - 2018-12-08 19:31:21 --> Helper loaded: url_helper
DEBUG - 2018-12-08 19:31:21 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 19:31:21 --> Final output sent to browser
DEBUG - 2018-12-08 19:31:21 --> Total execution time: 0.0464
DEBUG - 2018-12-08 22:09:20 --> Config Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Hooks Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Utf8 Class Initialized
DEBUG - 2018-12-08 22:09:20 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 22:09:20 --> URI Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Router Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Output Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Security Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Input Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 22:09:20 --> Language Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Loader Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Helper loaded: date_helper
DEBUG - 2018-12-08 22:09:20 --> Controller Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Database Driver Class Initialized
ERROR - 2018-12-08 22:09:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 22:09:20 --> Model Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Model Class Initialized
DEBUG - 2018-12-08 22:09:20 --> Helper loaded: url_helper
DEBUG - 2018-12-08 22:09:20 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 22:09:20 --> Final output sent to browser
DEBUG - 2018-12-08 22:09:20 --> Total execution time: 0.0802
DEBUG - 2018-12-08 22:09:24 --> Config Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Hooks Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Utf8 Class Initialized
DEBUG - 2018-12-08 22:09:24 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 22:09:24 --> URI Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Router Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Output Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Security Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Input Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 22:09:24 --> Language Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Loader Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Helper loaded: date_helper
DEBUG - 2018-12-08 22:09:24 --> Controller Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Database Driver Class Initialized
ERROR - 2018-12-08 22:09:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 22:09:24 --> Model Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Model Class Initialized
DEBUG - 2018-12-08 22:09:24 --> Helper loaded: url_helper
DEBUG - 2018-12-08 22:09:24 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 22:09:24 --> Final output sent to browser
DEBUG - 2018-12-08 22:09:24 --> Total execution time: 0.0589
DEBUG - 2018-12-08 23:30:31 --> Config Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Hooks Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Utf8 Class Initialized
DEBUG - 2018-12-08 23:30:31 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 23:30:31 --> URI Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Router Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Output Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Security Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Input Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 23:30:31 --> Language Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Loader Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Helper loaded: date_helper
DEBUG - 2018-12-08 23:30:31 --> Controller Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Database Driver Class Initialized
ERROR - 2018-12-08 23:30:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 23:30:31 --> Model Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Model Class Initialized
DEBUG - 2018-12-08 23:30:31 --> Helper loaded: url_helper
DEBUG - 2018-12-08 23:30:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 23:30:31 --> Final output sent to browser
DEBUG - 2018-12-08 23:30:31 --> Total execution time: 0.0481
DEBUG - 2018-12-08 23:30:36 --> Config Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Hooks Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Utf8 Class Initialized
DEBUG - 2018-12-08 23:30:36 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 23:30:36 --> URI Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Router Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Output Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Security Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Input Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 23:30:36 --> Language Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Loader Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Helper loaded: date_helper
DEBUG - 2018-12-08 23:30:36 --> Controller Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Database Driver Class Initialized
ERROR - 2018-12-08 23:30:36 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 23:30:36 --> Model Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Model Class Initialized
DEBUG - 2018-12-08 23:30:36 --> Helper loaded: url_helper
ERROR - 2018-12-08 23:30:36 --> Severity: Warning  --> strstr(): Empty needle /home/hosting_users/uncleben/www/todo/application/views/todo/yumi_v.php 142
DEBUG - 2018-12-08 23:30:36 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 23:30:36 --> Final output sent to browser
DEBUG - 2018-12-08 23:30:36 --> Total execution time: 0.0470
DEBUG - 2018-12-08 23:48:30 --> Config Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Hooks Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Utf8 Class Initialized
DEBUG - 2018-12-08 23:48:30 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 23:48:30 --> URI Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Router Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Output Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Security Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Input Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 23:48:30 --> Language Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Loader Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Helper loaded: date_helper
DEBUG - 2018-12-08 23:48:30 --> Controller Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Database Driver Class Initialized
ERROR - 2018-12-08 23:48:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 23:48:30 --> Model Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Model Class Initialized
DEBUG - 2018-12-08 23:48:30 --> Helper loaded: url_helper
DEBUG - 2018-12-08 23:48:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 23:48:30 --> Final output sent to browser
DEBUG - 2018-12-08 23:48:30 --> Total execution time: 0.0644
DEBUG - 2018-12-08 23:49:58 --> Config Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Hooks Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Utf8 Class Initialized
DEBUG - 2018-12-08 23:49:58 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 23:49:58 --> URI Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Router Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Output Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Security Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Input Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 23:49:58 --> Language Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Loader Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Helper loaded: date_helper
DEBUG - 2018-12-08 23:49:58 --> Controller Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Database Driver Class Initialized
ERROR - 2018-12-08 23:49:58 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 23:49:58 --> Model Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Model Class Initialized
DEBUG - 2018-12-08 23:49:58 --> Helper loaded: url_helper
ERROR - 2018-12-08 23:49:58 --> Severity: Warning  --> strstr(): Empty needle /home/hosting_users/uncleben/www/todo/application/views/todo/yumi_v.php 142
DEBUG - 2018-12-08 23:49:58 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 23:49:58 --> Final output sent to browser
DEBUG - 2018-12-08 23:49:58 --> Total execution time: 0.0698
DEBUG - 2018-12-08 23:50:27 --> Config Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Hooks Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Utf8 Class Initialized
DEBUG - 2018-12-08 23:50:27 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 23:50:27 --> URI Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Router Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Output Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Security Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Input Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 23:50:27 --> Language Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Loader Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Helper loaded: date_helper
DEBUG - 2018-12-08 23:50:27 --> Controller Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Database Driver Class Initialized
ERROR - 2018-12-08 23:50:27 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 23:50:27 --> Model Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Model Class Initialized
DEBUG - 2018-12-08 23:50:27 --> Helper loaded: url_helper
DEBUG - 2018-12-08 23:50:27 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 23:50:27 --> Final output sent to browser
DEBUG - 2018-12-08 23:50:27 --> Total execution time: 0.0504
DEBUG - 2018-12-08 23:54:25 --> Config Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Hooks Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Utf8 Class Initialized
DEBUG - 2018-12-08 23:54:25 --> UTF-8 Support Enabled
DEBUG - 2018-12-08 23:54:25 --> URI Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Router Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Output Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Security Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Input Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-08 23:54:25 --> Language Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Loader Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Helper loaded: date_helper
DEBUG - 2018-12-08 23:54:25 --> Controller Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Database Driver Class Initialized
ERROR - 2018-12-08 23:54:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-08 23:54:25 --> Model Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Model Class Initialized
DEBUG - 2018-12-08 23:54:25 --> Helper loaded: url_helper
DEBUG - 2018-12-08 23:54:25 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2018-12-08 23:54:25 --> Final output sent to browser
DEBUG - 2018-12-08 23:54:25 --> Total execution time: 0.0626
