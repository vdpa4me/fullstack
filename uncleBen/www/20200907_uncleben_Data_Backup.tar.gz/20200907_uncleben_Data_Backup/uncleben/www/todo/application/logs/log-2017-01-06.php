<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-06 00:48:04 --> Config Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Hooks Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Utf8 Class Initialized
DEBUG - 2017-01-06 00:48:04 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 00:48:04 --> URI Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Router Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Output Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Security Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Input Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 00:48:04 --> Language Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Loader Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Helper loaded: date_helper
DEBUG - 2017-01-06 00:48:04 --> Controller Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Database Driver Class Initialized
ERROR - 2017-01-06 00:48:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 00:48:04 --> Model Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Model Class Initialized
DEBUG - 2017-01-06 00:48:04 --> Helper loaded: url_helper
DEBUG - 2017-01-06 00:48:04 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 00:48:04 --> Final output sent to browser
DEBUG - 2017-01-06 00:48:04 --> Total execution time: 0.0363
DEBUG - 2017-01-06 00:49:12 --> Config Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Hooks Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Utf8 Class Initialized
DEBUG - 2017-01-06 00:49:12 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 00:49:12 --> URI Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Router Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Output Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Security Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Input Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 00:49:12 --> Language Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Loader Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Helper loaded: date_helper
DEBUG - 2017-01-06 00:49:12 --> Controller Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Database Driver Class Initialized
ERROR - 2017-01-06 00:49:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 00:49:12 --> Model Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Model Class Initialized
DEBUG - 2017-01-06 00:49:12 --> Helper loaded: url_helper
DEBUG - 2017-01-06 00:49:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 00:49:12 --> Final output sent to browser
DEBUG - 2017-01-06 00:49:12 --> Total execution time: 0.0283
DEBUG - 2017-01-06 00:49:18 --> Config Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Hooks Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Utf8 Class Initialized
DEBUG - 2017-01-06 00:49:18 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 00:49:18 --> URI Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Router Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Output Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Security Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Input Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 00:49:18 --> Language Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Loader Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Helper loaded: date_helper
DEBUG - 2017-01-06 00:49:18 --> Controller Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Database Driver Class Initialized
ERROR - 2017-01-06 00:49:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 00:49:18 --> Model Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Model Class Initialized
DEBUG - 2017-01-06 00:49:18 --> Helper loaded: url_helper
DEBUG - 2017-01-06 00:49:18 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 00:49:18 --> Final output sent to browser
DEBUG - 2017-01-06 00:49:18 --> Total execution time: 0.0277
DEBUG - 2017-01-06 01:19:15 --> Config Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Hooks Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Utf8 Class Initialized
DEBUG - 2017-01-06 01:19:15 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 01:19:15 --> URI Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Router Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Output Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Security Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Input Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 01:19:15 --> Language Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Loader Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Helper loaded: date_helper
DEBUG - 2017-01-06 01:19:15 --> Controller Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Database Driver Class Initialized
ERROR - 2017-01-06 01:19:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 01:19:15 --> Model Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Model Class Initialized
DEBUG - 2017-01-06 01:19:15 --> Helper loaded: url_helper
DEBUG - 2017-01-06 01:19:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 01:19:15 --> Final output sent to browser
DEBUG - 2017-01-06 01:19:15 --> Total execution time: 0.0275
DEBUG - 2017-01-06 02:17:08 --> Config Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Utf8 Class Initialized
DEBUG - 2017-01-06 02:17:08 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 02:17:08 --> URI Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Router Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Output Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Security Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Input Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 02:17:08 --> Language Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Loader Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:17:08 --> Controller Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Database Driver Class Initialized
ERROR - 2017-01-06 02:17:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 02:17:08 --> Model Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Model Class Initialized
DEBUG - 2017-01-06 02:17:08 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:17:08 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 02:17:08 --> Final output sent to browser
DEBUG - 2017-01-06 02:17:08 --> Total execution time: 0.0314
DEBUG - 2017-01-06 02:44:57 --> Config Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Utf8 Class Initialized
DEBUG - 2017-01-06 02:44:57 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 02:44:57 --> URI Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Router Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Output Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Security Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Input Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 02:44:57 --> Language Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Loader Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:44:57 --> Controller Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Database Driver Class Initialized
ERROR - 2017-01-06 02:44:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 02:44:57 --> Model Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Model Class Initialized
DEBUG - 2017-01-06 02:44:57 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:44:57 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 02:44:57 --> Final output sent to browser
DEBUG - 2017-01-06 02:44:57 --> Total execution time: 0.0315
DEBUG - 2017-01-06 02:46:26 --> Config Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Utf8 Class Initialized
DEBUG - 2017-01-06 02:46:26 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 02:46:26 --> URI Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Router Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Output Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Security Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Input Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 02:46:26 --> Language Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Loader Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:46:26 --> Controller Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Database Driver Class Initialized
ERROR - 2017-01-06 02:46:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 02:46:26 --> Model Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Model Class Initialized
DEBUG - 2017-01-06 02:46:26 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:46:26 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 02:46:26 --> Final output sent to browser
DEBUG - 2017-01-06 02:46:26 --> Total execution time: 0.0274
DEBUG - 2017-01-06 02:46:31 --> Config Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Hooks Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Utf8 Class Initialized
DEBUG - 2017-01-06 02:46:31 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 02:46:31 --> URI Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Router Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Output Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Security Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Input Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 02:46:31 --> Language Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Loader Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Helper loaded: date_helper
DEBUG - 2017-01-06 02:46:31 --> Controller Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Database Driver Class Initialized
ERROR - 2017-01-06 02:46:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 02:46:31 --> Model Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Model Class Initialized
DEBUG - 2017-01-06 02:46:31 --> Helper loaded: url_helper
DEBUG - 2017-01-06 02:46:31 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 02:46:31 --> Final output sent to browser
DEBUG - 2017-01-06 02:46:31 --> Total execution time: 0.0278
DEBUG - 2017-01-06 03:02:23 --> Config Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Hooks Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Utf8 Class Initialized
DEBUG - 2017-01-06 03:02:23 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 03:02:23 --> URI Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Router Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Output Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Security Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Input Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 03:02:23 --> Language Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Loader Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Helper loaded: date_helper
DEBUG - 2017-01-06 03:02:23 --> Controller Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Database Driver Class Initialized
ERROR - 2017-01-06 03:02:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 03:02:23 --> Model Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Model Class Initialized
DEBUG - 2017-01-06 03:02:23 --> Helper loaded: url_helper
DEBUG - 2017-01-06 03:02:23 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 03:02:23 --> Final output sent to browser
DEBUG - 2017-01-06 03:02:23 --> Total execution time: 0.0312
DEBUG - 2017-01-06 03:19:39 --> Config Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Hooks Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Utf8 Class Initialized
DEBUG - 2017-01-06 03:19:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 03:19:39 --> URI Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Router Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Output Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Security Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Input Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 03:19:39 --> Language Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Loader Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Helper loaded: date_helper
DEBUG - 2017-01-06 03:19:39 --> Controller Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Database Driver Class Initialized
ERROR - 2017-01-06 03:19:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 03:19:39 --> Model Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Model Class Initialized
DEBUG - 2017-01-06 03:19:39 --> Helper loaded: url_helper
DEBUG - 2017-01-06 03:19:39 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 03:19:39 --> Final output sent to browser
DEBUG - 2017-01-06 03:19:39 --> Total execution time: 0.0318
DEBUG - 2017-01-06 03:21:12 --> Config Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Hooks Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Utf8 Class Initialized
DEBUG - 2017-01-06 03:21:12 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 03:21:12 --> URI Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Router Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Output Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Security Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Input Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 03:21:12 --> Language Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Loader Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Helper loaded: date_helper
DEBUG - 2017-01-06 03:21:12 --> Controller Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Database Driver Class Initialized
ERROR - 2017-01-06 03:21:12 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 03:21:12 --> Model Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Model Class Initialized
DEBUG - 2017-01-06 03:21:12 --> Helper loaded: url_helper
DEBUG - 2017-01-06 03:21:12 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 03:21:12 --> Final output sent to browser
DEBUG - 2017-01-06 03:21:12 --> Total execution time: 0.0283
DEBUG - 2017-01-06 05:09:41 --> Config Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Hooks Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Utf8 Class Initialized
DEBUG - 2017-01-06 05:09:41 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 05:09:41 --> URI Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Router Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Output Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Security Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Input Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 05:09:41 --> Language Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Loader Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Helper loaded: date_helper
DEBUG - 2017-01-06 05:09:41 --> Controller Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Database Driver Class Initialized
ERROR - 2017-01-06 05:09:41 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 05:09:41 --> Model Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Model Class Initialized
DEBUG - 2017-01-06 05:09:41 --> Helper loaded: url_helper
DEBUG - 2017-01-06 05:09:41 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 05:09:41 --> Final output sent to browser
DEBUG - 2017-01-06 05:09:41 --> Total execution time: 0.0322
DEBUG - 2017-01-06 09:26:02 --> Config Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Hooks Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Utf8 Class Initialized
DEBUG - 2017-01-06 09:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 09:26:02 --> URI Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Router Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Output Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Security Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Input Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 09:26:02 --> Language Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Loader Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Helper loaded: date_helper
DEBUG - 2017-01-06 09:26:02 --> Controller Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Database Driver Class Initialized
ERROR - 2017-01-06 09:26:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 09:26:02 --> Model Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Model Class Initialized
DEBUG - 2017-01-06 09:26:02 --> Helper loaded: url_helper
DEBUG - 2017-01-06 09:26:02 --> File loaded: application/views/todo/search_v.php
DEBUG - 2017-01-06 09:26:02 --> Final output sent to browser
DEBUG - 2017-01-06 09:26:02 --> Total execution time: 0.0294
DEBUG - 2017-01-06 13:59:33 --> Config Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Hooks Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Utf8 Class Initialized
DEBUG - 2017-01-06 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 13:59:33 --> URI Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Router Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Output Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Security Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Input Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 13:59:33 --> Language Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Loader Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Helper loaded: date_helper
DEBUG - 2017-01-06 13:59:33 --> Controller Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Database Driver Class Initialized
ERROR - 2017-01-06 13:59:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 13:59:33 --> Model Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Model Class Initialized
DEBUG - 2017-01-06 13:59:33 --> Helper loaded: url_helper
DEBUG - 2017-01-06 13:59:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 13:59:33 --> Final output sent to browser
DEBUG - 2017-01-06 13:59:33 --> Total execution time: 0.0363
DEBUG - 2017-01-06 14:00:46 --> Config Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:00:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:00:46 --> URI Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Router Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Output Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Security Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Input Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:00:46 --> Language Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Loader Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:00:46 --> Controller Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:00:46 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:00:46 --> Model Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Model Class Initialized
DEBUG - 2017-01-06 14:00:46 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:00:46 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:00:46 --> Final output sent to browser
DEBUG - 2017-01-06 14:00:46 --> Total execution time: 0.0282
DEBUG - 2017-01-06 14:03:11 --> Config Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:03:11 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:03:11 --> URI Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Router Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Output Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Security Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Input Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:03:11 --> Language Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Loader Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:03:11 --> Controller Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:03:11 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:03:11 --> Model Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Model Class Initialized
DEBUG - 2017-01-06 14:03:11 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:03:11 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:03:11 --> Final output sent to browser
DEBUG - 2017-01-06 14:03:11 --> Total execution time: 0.0276
DEBUG - 2017-01-06 14:03:16 --> Config Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:03:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:03:16 --> URI Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Router Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Output Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Security Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Input Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:03:16 --> Language Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Loader Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:03:16 --> Controller Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:03:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:03:16 --> Model Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Model Class Initialized
DEBUG - 2017-01-06 14:03:16 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:03:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:03:16 --> Final output sent to browser
DEBUG - 2017-01-06 14:03:16 --> Total execution time: 0.0289
DEBUG - 2017-01-06 14:06:16 --> Config Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:06:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:06:16 --> URI Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Router Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Output Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Security Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Input Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:06:16 --> Language Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Loader Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:06:16 --> Controller Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:06:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:06:16 --> Model Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Model Class Initialized
DEBUG - 2017-01-06 14:06:16 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:06:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:06:16 --> Final output sent to browser
DEBUG - 2017-01-06 14:06:16 --> Total execution time: 0.0285
DEBUG - 2017-01-06 14:15:44 --> Config Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:15:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:15:44 --> URI Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Router Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Output Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Security Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Input Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:15:44 --> Language Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Loader Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:15:44 --> Controller Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:15:44 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:15:44 --> Model Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Model Class Initialized
DEBUG - 2017-01-06 14:15:44 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:15:44 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:15:44 --> Final output sent to browser
DEBUG - 2017-01-06 14:15:44 --> Total execution time: 0.0439
DEBUG - 2017-01-06 14:31:03 --> Config Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:31:03 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:31:03 --> URI Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Router Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Output Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Security Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Input Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:31:03 --> Language Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Loader Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:31:03 --> Controller Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:31:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:31:03 --> Model Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Model Class Initialized
DEBUG - 2017-01-06 14:31:03 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:31:03 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:31:03 --> Final output sent to browser
DEBUG - 2017-01-06 14:31:03 --> Total execution time: 0.0329
DEBUG - 2017-01-06 14:31:19 --> Config Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:31:19 --> URI Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Router Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Output Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Security Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Input Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:31:19 --> Language Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Loader Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:31:19 --> Controller Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:31:19 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:31:19 --> Model Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Model Class Initialized
DEBUG - 2017-01-06 14:31:19 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:31:19 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:31:19 --> Final output sent to browser
DEBUG - 2017-01-06 14:31:19 --> Total execution time: 0.0289
DEBUG - 2017-01-06 14:46:42 --> Config Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:46:42 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:46:42 --> URI Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Router Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Output Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Security Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Input Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:46:42 --> Language Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Loader Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:46:42 --> Controller Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:46:42 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:46:42 --> Model Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Model Class Initialized
DEBUG - 2017-01-06 14:46:42 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:46:42 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:46:42 --> Final output sent to browser
DEBUG - 2017-01-06 14:46:42 --> Total execution time: 0.0325
DEBUG - 2017-01-06 14:47:49 --> Config Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:47:49 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:47:49 --> URI Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Router Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Output Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Security Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Input Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:47:49 --> Language Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Loader Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:47:49 --> Controller Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:47:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:47:49 --> Model Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Model Class Initialized
DEBUG - 2017-01-06 14:47:49 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:47:49 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:47:49 --> Final output sent to browser
DEBUG - 2017-01-06 14:47:49 --> Total execution time: 0.0286
DEBUG - 2017-01-06 14:47:56 --> Config Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Hooks Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Utf8 Class Initialized
DEBUG - 2017-01-06 14:47:56 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 14:47:56 --> URI Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Router Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Output Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Security Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Input Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 14:47:56 --> Language Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Loader Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Helper loaded: date_helper
DEBUG - 2017-01-06 14:47:56 --> Controller Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Database Driver Class Initialized
ERROR - 2017-01-06 14:47:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 14:47:56 --> Model Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Model Class Initialized
DEBUG - 2017-01-06 14:47:56 --> Helper loaded: url_helper
DEBUG - 2017-01-06 14:47:56 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 14:47:56 --> Final output sent to browser
DEBUG - 2017-01-06 14:47:56 --> Total execution time: 0.0287
DEBUG - 2017-01-06 23:54:28 --> Config Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Hooks Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Utf8 Class Initialized
DEBUG - 2017-01-06 23:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 23:54:28 --> URI Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Router Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Output Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Security Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Input Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 23:54:28 --> Language Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Loader Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Helper loaded: date_helper
DEBUG - 2017-01-06 23:54:28 --> Controller Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Database Driver Class Initialized
ERROR - 2017-01-06 23:54:28 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 23:54:28 --> Model Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Model Class Initialized
DEBUG - 2017-01-06 23:54:28 --> Helper loaded: url_helper
DEBUG - 2017-01-06 23:54:28 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 23:54:28 --> Final output sent to browser
DEBUG - 2017-01-06 23:54:28 --> Total execution time: 0.0478
DEBUG - 2017-01-06 23:54:34 --> Config Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Hooks Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Utf8 Class Initialized
DEBUG - 2017-01-06 23:54:34 --> UTF-8 Support Enabled
DEBUG - 2017-01-06 23:54:34 --> URI Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Router Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Output Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Security Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Input Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-06 23:54:34 --> Language Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Loader Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Helper loaded: date_helper
DEBUG - 2017-01-06 23:54:34 --> Controller Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Database Driver Class Initialized
ERROR - 2017-01-06 23:54:34 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-01-06 23:54:34 --> Model Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Model Class Initialized
DEBUG - 2017-01-06 23:54:34 --> Helper loaded: url_helper
DEBUG - 2017-01-06 23:54:34 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-01-06 23:54:34 --> Final output sent to browser
DEBUG - 2017-01-06 23:54:34 --> Total execution time: 0.0291
