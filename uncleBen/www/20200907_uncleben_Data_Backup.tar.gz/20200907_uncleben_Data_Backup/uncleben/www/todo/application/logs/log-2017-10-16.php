<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-16 02:07:16 --> Config Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Hooks Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Utf8 Class Initialized
DEBUG - 2017-10-16 02:07:16 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 02:07:16 --> URI Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Router Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Output Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Security Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Input Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 02:07:16 --> Language Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Loader Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Helper loaded: date_helper
DEBUG - 2017-10-16 02:07:16 --> Controller Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Database Driver Class Initialized
ERROR - 2017-10-16 02:07:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 02:07:16 --> Model Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Model Class Initialized
DEBUG - 2017-10-16 02:07:16 --> Helper loaded: url_helper
DEBUG - 2017-10-16 02:07:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 02:07:16 --> Final output sent to browser
DEBUG - 2017-10-16 02:07:16 --> Total execution time: 0.0217
DEBUG - 2017-10-16 05:42:45 --> Config Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Hooks Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Utf8 Class Initialized
DEBUG - 2017-10-16 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 05:42:45 --> URI Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Router Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Output Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Security Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Input Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 05:42:45 --> Language Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Loader Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Helper loaded: date_helper
DEBUG - 2017-10-16 05:42:45 --> Controller Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Database Driver Class Initialized
ERROR - 2017-10-16 05:42:45 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 05:42:45 --> Model Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Model Class Initialized
DEBUG - 2017-10-16 05:42:45 --> Helper loaded: url_helper
DEBUG - 2017-10-16 05:42:45 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 05:42:45 --> Final output sent to browser
DEBUG - 2017-10-16 05:42:45 --> Total execution time: 0.0307
DEBUG - 2017-10-16 06:18:24 --> Config Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Hooks Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Utf8 Class Initialized
DEBUG - 2017-10-16 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 06:18:24 --> URI Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Router Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Output Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Security Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Input Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 06:18:24 --> Language Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Loader Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Helper loaded: date_helper
DEBUG - 2017-10-16 06:18:24 --> Controller Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Database Driver Class Initialized
ERROR - 2017-10-16 06:18:24 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 06:18:24 --> Model Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Model Class Initialized
DEBUG - 2017-10-16 06:18:24 --> Helper loaded: url_helper
DEBUG - 2017-10-16 06:18:24 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 06:18:24 --> Final output sent to browser
DEBUG - 2017-10-16 06:18:24 --> Total execution time: 0.0826
DEBUG - 2017-10-16 06:56:56 --> Config Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Hooks Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Utf8 Class Initialized
DEBUG - 2017-10-16 06:56:56 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 06:56:56 --> URI Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Router Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Output Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Security Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Input Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 06:56:56 --> Language Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Loader Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Helper loaded: date_helper
DEBUG - 2017-10-16 06:56:56 --> Controller Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Database Driver Class Initialized
ERROR - 2017-10-16 06:56:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 06:56:56 --> Model Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Model Class Initialized
DEBUG - 2017-10-16 06:56:56 --> Helper loaded: url_helper
DEBUG - 2017-10-16 06:56:56 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 06:56:56 --> Final output sent to browser
DEBUG - 2017-10-16 06:56:56 --> Total execution time: 0.0207
DEBUG - 2017-10-16 09:40:06 --> Config Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Hooks Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Utf8 Class Initialized
DEBUG - 2017-10-16 09:40:06 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 09:40:06 --> URI Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Router Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Output Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Security Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Input Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 09:40:06 --> Language Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Loader Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Helper loaded: date_helper
DEBUG - 2017-10-16 09:40:06 --> Controller Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Database Driver Class Initialized
ERROR - 2017-10-16 09:40:06 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 09:40:06 --> Model Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Model Class Initialized
DEBUG - 2017-10-16 09:40:06 --> Helper loaded: url_helper
DEBUG - 2017-10-16 09:40:06 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 09:40:06 --> Final output sent to browser
DEBUG - 2017-10-16 09:40:06 --> Total execution time: 0.0204
DEBUG - 2017-10-16 10:39:05 --> Config Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Utf8 Class Initialized
DEBUG - 2017-10-16 10:39:05 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 10:39:05 --> URI Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Router Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Output Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Security Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Input Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 10:39:05 --> Language Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Loader Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Helper loaded: date_helper
DEBUG - 2017-10-16 10:39:05 --> Controller Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Database Driver Class Initialized
ERROR - 2017-10-16 10:39:05 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 10:39:05 --> Model Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Model Class Initialized
DEBUG - 2017-10-16 10:39:05 --> Helper loaded: url_helper
DEBUG - 2017-10-16 10:39:05 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-16 10:39:05 --> Final output sent to browser
DEBUG - 2017-10-16 10:39:05 --> Total execution time: 0.0568
DEBUG - 2017-10-16 10:39:15 --> Config Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Hooks Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Utf8 Class Initialized
DEBUG - 2017-10-16 10:39:15 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 10:39:15 --> URI Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Router Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Output Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Security Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Input Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 10:39:15 --> Language Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Loader Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Helper loaded: date_helper
DEBUG - 2017-10-16 10:39:15 --> Controller Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Database Driver Class Initialized
ERROR - 2017-10-16 10:39:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 10:39:15 --> Model Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Model Class Initialized
DEBUG - 2017-10-16 10:39:15 --> Helper loaded: url_helper
DEBUG - 2017-10-16 10:39:15 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-16 10:39:15 --> Final output sent to browser
DEBUG - 2017-10-16 10:39:15 --> Total execution time: 0.0407
DEBUG - 2017-10-16 13:02:39 --> Config Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Hooks Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Utf8 Class Initialized
DEBUG - 2017-10-16 13:02:39 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 13:02:39 --> URI Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Router Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Output Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Security Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Input Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 13:02:39 --> Language Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Loader Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Helper loaded: date_helper
DEBUG - 2017-10-16 13:02:39 --> Controller Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Database Driver Class Initialized
ERROR - 2017-10-16 13:02:39 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 13:02:39 --> Model Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Model Class Initialized
DEBUG - 2017-10-16 13:02:39 --> Helper loaded: url_helper
DEBUG - 2017-10-16 13:02:39 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 13:02:39 --> Final output sent to browser
DEBUG - 2017-10-16 13:02:39 --> Total execution time: 0.0312
DEBUG - 2017-10-16 16:28:43 --> Config Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Hooks Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Utf8 Class Initialized
DEBUG - 2017-10-16 16:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 16:28:43 --> URI Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Router Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Output Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Security Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Input Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 16:28:43 --> Language Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Loader Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Helper loaded: date_helper
DEBUG - 2017-10-16 16:28:43 --> Controller Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Database Driver Class Initialized
ERROR - 2017-10-16 16:28:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 16:28:43 --> Model Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Model Class Initialized
DEBUG - 2017-10-16 16:28:43 --> Helper loaded: url_helper
DEBUG - 2017-10-16 16:28:43 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 16:28:43 --> Final output sent to browser
DEBUG - 2017-10-16 16:28:43 --> Total execution time: 0.0214
DEBUG - 2017-10-16 22:13:48 --> Config Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Hooks Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Utf8 Class Initialized
DEBUG - 2017-10-16 22:13:48 --> UTF-8 Support Enabled
DEBUG - 2017-10-16 22:13:48 --> URI Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Router Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Output Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Security Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Input Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-16 22:13:48 --> Language Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Loader Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Helper loaded: date_helper
DEBUG - 2017-10-16 22:13:48 --> Controller Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Database Driver Class Initialized
ERROR - 2017-10-16 22:13:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-16 22:13:48 --> Model Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Model Class Initialized
DEBUG - 2017-10-16 22:13:48 --> Helper loaded: url_helper
DEBUG - 2017-10-16 22:13:48 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-10-16 22:13:48 --> Final output sent to browser
DEBUG - 2017-10-16 22:13:48 --> Total execution time: 0.0203
