<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2020-01-14 19:35:58 --> Config Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Hooks Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Utf8 Class Initialized
DEBUG - 2020-01-14 19:35:58 --> UTF-8 Support Enabled
DEBUG - 2020-01-14 19:35:58 --> URI Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Router Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Output Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Security Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Input Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2020-01-14 19:35:58 --> Language Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Loader Class Initialized
DEBUG - 2020-01-14 19:35:58 --> Helper loaded: date_helper
DEBUG - 2020-01-14 19:35:58 --> Controller Class Initialized
DEBUG - 2020-01-14 19:35:59 --> Database Driver Class Initialized
ERROR - 2020-01-14 19:35:59 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-01-14 19:35:59 --> Model Class Initialized
DEBUG - 2020-01-14 19:35:59 --> Model Class Initialized
DEBUG - 2020-01-14 19:35:59 --> Helper loaded: url_helper
DEBUG - 2020-01-14 19:35:59 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-01-14 19:35:59 --> Final output sent to browser
DEBUG - 2020-01-14 19:35:59 --> Total execution time: 0.2105
DEBUG - 2020-01-14 23:05:23 --> Config Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Hooks Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Utf8 Class Initialized
DEBUG - 2020-01-14 23:05:23 --> UTF-8 Support Enabled
DEBUG - 2020-01-14 23:05:23 --> URI Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Router Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Output Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Security Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Input Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2020-01-14 23:05:23 --> Language Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Loader Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Helper loaded: date_helper
DEBUG - 2020-01-14 23:05:23 --> Controller Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Database Driver Class Initialized
ERROR - 2020-01-14 23:05:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2020-01-14 23:05:23 --> Model Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Model Class Initialized
DEBUG - 2020-01-14 23:05:23 --> Helper loaded: url_helper
DEBUG - 2020-01-14 23:05:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2020-01-14 23:05:23 --> Final output sent to browser
DEBUG - 2020-01-14 23:05:23 --> Total execution time: 0.0960
