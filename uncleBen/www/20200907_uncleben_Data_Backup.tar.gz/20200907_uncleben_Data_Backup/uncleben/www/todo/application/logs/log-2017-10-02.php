<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-10-02 05:14:43 --> Config Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Hooks Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Utf8 Class Initialized
DEBUG - 2017-10-02 05:14:43 --> UTF-8 Support Enabled
DEBUG - 2017-10-02 05:14:43 --> URI Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Router Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Output Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Security Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Input Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-02 05:14:43 --> Language Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Loader Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Helper loaded: date_helper
DEBUG - 2017-10-02 05:14:43 --> Controller Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Database Driver Class Initialized
ERROR - 2017-10-02 05:14:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-02 05:14:43 --> Model Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Model Class Initialized
DEBUG - 2017-10-02 05:14:43 --> Helper loaded: url_helper
DEBUG - 2017-10-02 05:14:43 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-02 05:14:43 --> Final output sent to browser
DEBUG - 2017-10-02 05:14:43 --> Total execution time: 0.0614
DEBUG - 2017-10-02 05:14:54 --> Config Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Hooks Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Utf8 Class Initialized
DEBUG - 2017-10-02 05:14:54 --> UTF-8 Support Enabled
DEBUG - 2017-10-02 05:14:54 --> URI Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Router Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Output Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Security Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Input Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-02 05:14:54 --> Language Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Loader Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Helper loaded: date_helper
DEBUG - 2017-10-02 05:14:54 --> Controller Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Database Driver Class Initialized
ERROR - 2017-10-02 05:14:54 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-02 05:14:54 --> Model Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Model Class Initialized
DEBUG - 2017-10-02 05:14:54 --> Helper loaded: url_helper
DEBUG - 2017-10-02 05:14:54 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-02 05:14:54 --> Final output sent to browser
DEBUG - 2017-10-02 05:14:54 --> Total execution time: 0.0381
DEBUG - 2017-10-02 05:15:16 --> Config Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Hooks Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Utf8 Class Initialized
DEBUG - 2017-10-02 05:15:16 --> UTF-8 Support Enabled
DEBUG - 2017-10-02 05:15:16 --> URI Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Router Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Output Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Security Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Input Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-02 05:15:16 --> Language Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Loader Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Helper loaded: date_helper
DEBUG - 2017-10-02 05:15:16 --> Controller Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Database Driver Class Initialized
ERROR - 2017-10-02 05:15:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-02 05:15:16 --> Model Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Model Class Initialized
DEBUG - 2017-10-02 05:15:16 --> Helper loaded: url_helper
DEBUG - 2017-10-02 05:15:16 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-02 05:15:16 --> Final output sent to browser
DEBUG - 2017-10-02 05:15:16 --> Total execution time: 0.0375
DEBUG - 2017-10-02 05:21:30 --> Config Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Hooks Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Utf8 Class Initialized
DEBUG - 2017-10-02 05:21:30 --> UTF-8 Support Enabled
DEBUG - 2017-10-02 05:21:30 --> URI Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Router Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Output Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Security Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Input Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-02 05:21:30 --> Language Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Loader Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Helper loaded: date_helper
DEBUG - 2017-10-02 05:21:30 --> Controller Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Database Driver Class Initialized
ERROR - 2017-10-02 05:21:30 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-02 05:21:30 --> Model Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Model Class Initialized
DEBUG - 2017-10-02 05:21:30 --> Helper loaded: url_helper
DEBUG - 2017-10-02 05:21:30 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-02 05:21:30 --> Final output sent to browser
DEBUG - 2017-10-02 05:21:30 --> Total execution time: 0.0381
DEBUG - 2017-10-02 05:21:33 --> Config Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Hooks Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Utf8 Class Initialized
DEBUG - 2017-10-02 05:21:33 --> UTF-8 Support Enabled
DEBUG - 2017-10-02 05:21:33 --> URI Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Router Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Output Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Security Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Input Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2017-10-02 05:21:33 --> Language Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Loader Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Helper loaded: date_helper
DEBUG - 2017-10-02 05:21:33 --> Controller Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Database Driver Class Initialized
ERROR - 2017-10-02 05:21:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-10-02 05:21:33 --> Model Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Model Class Initialized
DEBUG - 2017-10-02 05:21:33 --> Helper loaded: url_helper
DEBUG - 2017-10-02 05:21:33 --> File loaded: application/views/todo/yumi_v.php
DEBUG - 2017-10-02 05:21:33 --> Final output sent to browser
DEBUG - 2017-10-02 05:21:33 --> Total execution time: 0.0376
