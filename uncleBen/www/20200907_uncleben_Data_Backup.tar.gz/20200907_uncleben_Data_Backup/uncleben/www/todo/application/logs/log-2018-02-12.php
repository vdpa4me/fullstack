<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-02-12 00:36:23 --> Config Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Hooks Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Utf8 Class Initialized
DEBUG - 2018-02-12 00:36:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 00:36:23 --> URI Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Router Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Output Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Security Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Input Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-12 00:36:23 --> Language Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Loader Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Helper loaded: date_helper
DEBUG - 2018-02-12 00:36:23 --> Controller Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Database Driver Class Initialized
ERROR - 2018-02-12 00:36:23 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-02-12 00:36:23 --> Model Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Model Class Initialized
DEBUG - 2018-02-12 00:36:23 --> Helper loaded: url_helper
DEBUG - 2018-02-12 00:36:23 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-02-12 00:36:23 --> Final output sent to browser
DEBUG - 2018-02-12 00:36:23 --> Total execution time: 0.0595
DEBUG - 2018-02-12 07:15:53 --> Config Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Hooks Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Utf8 Class Initialized
DEBUG - 2018-02-12 07:15:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 07:15:53 --> URI Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Router Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Output Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Security Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Input Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-12 07:15:53 --> Language Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Loader Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Helper loaded: date_helper
DEBUG - 2018-02-12 07:15:53 --> Controller Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Database Driver Class Initialized
ERROR - 2018-02-12 07:15:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-02-12 07:15:53 --> Model Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Model Class Initialized
DEBUG - 2018-02-12 07:15:53 --> Helper loaded: url_helper
DEBUG - 2018-02-12 07:15:53 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-02-12 07:15:53 --> Final output sent to browser
DEBUG - 2018-02-12 07:15:53 --> Total execution time: 0.0309
DEBUG - 2018-02-12 16:12:10 --> Config Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Hooks Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Utf8 Class Initialized
DEBUG - 2018-02-12 16:12:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-12 16:12:10 --> URI Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Router Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Output Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Security Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Input Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-12 16:12:10 --> Language Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Loader Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Helper loaded: date_helper
DEBUG - 2018-02-12 16:12:10 --> Controller Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Database Driver Class Initialized
ERROR - 2018-02-12 16:12:10 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-02-12 16:12:10 --> Model Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Model Class Initialized
DEBUG - 2018-02-12 16:12:10 --> Helper loaded: url_helper
DEBUG - 2018-02-12 16:12:10 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-02-12 16:12:10 --> Final output sent to browser
DEBUG - 2018-02-12 16:12:10 --> Total execution time: 0.0367
