<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-12-22 18:38:03 --> Config Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Hooks Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Utf8 Class Initialized
DEBUG - 2017-12-22 18:38:03 --> UTF-8 Support Enabled
DEBUG - 2017-12-22 18:38:03 --> URI Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Router Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Output Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Security Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Input Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2017-12-22 18:38:03 --> Language Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Loader Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Helper loaded: date_helper
DEBUG - 2017-12-22 18:38:03 --> Controller Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Database Driver Class Initialized
ERROR - 2017-12-22 18:38:03 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2017-12-22 18:38:03 --> Model Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Model Class Initialized
DEBUG - 2017-12-22 18:38:03 --> Helper loaded: url_helper
DEBUG - 2017-12-22 18:38:03 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2017-12-22 18:38:03 --> Final output sent to browser
DEBUG - 2017-12-22 18:38:03 --> Total execution time: 0.0349
