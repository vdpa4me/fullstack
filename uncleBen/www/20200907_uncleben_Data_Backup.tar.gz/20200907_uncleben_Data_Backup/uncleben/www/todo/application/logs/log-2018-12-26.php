<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2018-12-26 08:05:18 --> Config Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Hooks Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Utf8 Class Initialized
DEBUG - 2018-12-26 08:05:18 --> UTF-8 Support Enabled
DEBUG - 2018-12-26 08:05:18 --> URI Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Router Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Output Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Security Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Input Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-26 08:05:18 --> Language Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Loader Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Helper loaded: date_helper
DEBUG - 2018-12-26 08:05:18 --> Controller Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Database Driver Class Initialized
ERROR - 2018-12-26 08:05:18 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-26 08:05:18 --> Model Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Model Class Initialized
DEBUG - 2018-12-26 08:05:18 --> Helper loaded: url_helper
DEBUG - 2018-12-26 08:05:18 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-26 08:05:18 --> Final output sent to browser
DEBUG - 2018-12-26 08:05:18 --> Total execution time: 0.0297
DEBUG - 2018-12-26 11:28:47 --> Config Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Hooks Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Utf8 Class Initialized
DEBUG - 2018-12-26 11:28:47 --> UTF-8 Support Enabled
DEBUG - 2018-12-26 11:28:47 --> URI Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Router Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Output Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Security Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Input Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-26 11:28:47 --> Language Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Loader Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Helper loaded: date_helper
DEBUG - 2018-12-26 11:28:47 --> Controller Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Database Driver Class Initialized
ERROR - 2018-12-26 11:28:47 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-26 11:28:47 --> Model Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Model Class Initialized
DEBUG - 2018-12-26 11:28:47 --> Helper loaded: url_helper
DEBUG - 2018-12-26 11:28:47 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-26 11:28:47 --> Final output sent to browser
DEBUG - 2018-12-26 11:28:47 --> Total execution time: 0.0279
DEBUG - 2018-12-26 17:04:16 --> Config Class Initialized
DEBUG - 2018-12-26 17:04:16 --> Hooks Class Initialized
DEBUG - 2018-12-26 17:04:16 --> Utf8 Class Initialized
DEBUG - 2018-12-26 17:04:16 --> UTF-8 Support Enabled
DEBUG - 2018-12-26 17:04:16 --> URI Class Initialized
DEBUG - 2018-12-26 17:04:16 --> Router Class Initialized
DEBUG - 2018-12-26 17:04:16 --> Output Class Initialized
DEBUG - 2018-12-26 17:04:16 --> Security Class Initialized
DEBUG - 2018-12-26 17:04:16 --> Input Class Initialized
DEBUG - 2018-12-26 17:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-26 17:04:16 --> Language Class Initialized
DEBUG - 2018-12-26 17:04:17 --> Loader Class Initialized
DEBUG - 2018-12-26 17:04:17 --> Helper loaded: date_helper
DEBUG - 2018-12-26 17:04:17 --> Controller Class Initialized
DEBUG - 2018-12-26 17:04:17 --> Database Driver Class Initialized
ERROR - 2018-12-26 17:04:17 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-26 17:04:17 --> Model Class Initialized
DEBUG - 2018-12-26 17:04:17 --> Model Class Initialized
DEBUG - 2018-12-26 17:04:17 --> Helper loaded: url_helper
DEBUG - 2018-12-26 17:04:17 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-26 17:04:17 --> Final output sent to browser
DEBUG - 2018-12-26 17:04:17 --> Total execution time: 0.0339
DEBUG - 2018-12-26 21:05:07 --> Config Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Hooks Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Utf8 Class Initialized
DEBUG - 2018-12-26 21:05:07 --> UTF-8 Support Enabled
DEBUG - 2018-12-26 21:05:07 --> URI Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Router Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Output Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Security Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Input Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-26 21:05:07 --> Language Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Loader Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Helper loaded: date_helper
DEBUG - 2018-12-26 21:05:07 --> Controller Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Database Driver Class Initialized
ERROR - 2018-12-26 21:05:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-26 21:05:07 --> Model Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Model Class Initialized
DEBUG - 2018-12-26 21:05:07 --> Helper loaded: url_helper
DEBUG - 2018-12-26 21:05:07 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-26 21:05:07 --> Final output sent to browser
DEBUG - 2018-12-26 21:05:07 --> Total execution time: 0.0380
DEBUG - 2018-12-26 21:20:16 --> Config Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Hooks Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Utf8 Class Initialized
DEBUG - 2018-12-26 21:20:16 --> UTF-8 Support Enabled
DEBUG - 2018-12-26 21:20:16 --> URI Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Router Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Output Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Security Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Input Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2018-12-26 21:20:16 --> Language Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Loader Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Helper loaded: date_helper
DEBUG - 2018-12-26 21:20:16 --> Controller Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Database Driver Class Initialized
ERROR - 2018-12-26 21:20:16 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/hosting_users/uncleben/www/todo/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2018-12-26 21:20:16 --> Model Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Model Class Initialized
DEBUG - 2018-12-26 21:20:16 --> Helper loaded: url_helper
DEBUG - 2018-12-26 21:20:16 --> File loaded: application/views/todo/sentences_v.php
DEBUG - 2018-12-26 21:20:16 --> Final output sent to browser
DEBUG - 2018-12-26 21:20:16 --> Total execution time: 0.0317
